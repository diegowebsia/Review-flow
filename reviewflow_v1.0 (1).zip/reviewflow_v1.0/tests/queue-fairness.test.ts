import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fairOrder, estimateJobMs, type JobQueueRow } from '../lib/queue';

const row = (id: string, tenantId: string, type: string, extra: Record<string, unknown> = {}, t = id): JobQueueRow => ({
  id, type, payload: { type, tenantId, ...extra }, status: 'pending', attempts: 0, created_at: t, processed_at: null,
});

test('fairOrder intercala empresas: una con muchas tareas no acapara', () => {
  const rows = [
    row('a1', 'A', 'ai.generate', { autoPublish: true }, '1'),
    row('a2', 'A', 'ai.generate', { autoPublish: true }, '2'),
    row('a3', 'A', 'ai.generate', { autoPublish: true }, '3'),
    row('b1', 'B', 'notify.owner', {}, '4'),
    row('c1', 'C', 'sync.provider', { origin: 'cron' }, '5'),
  ];
  const ids = fairOrder(rows).map((r) => r.id);
  assert.deepEqual(ids.slice(0, 3).sort(), ['a1', 'b1', 'c1']);
  assert.equal(ids[0], 'b1'); // avisos rápidos primero
  assert.deepEqual(ids.slice(3), ['a2', 'a3']);
});

test('una respuesta automática cuenta como 50 s', () => {
  const job = { type: 'ai.generate', tenantId: '00000000-0000-0000-0000-000000000000', jobId: 'abcdefgh', businessName: 'x', authorName: 'y', rating: 5, reviewText: 'z', autoPublish: true } as const;
  assert.equal(estimateJobMs(job), 50_000);
});
