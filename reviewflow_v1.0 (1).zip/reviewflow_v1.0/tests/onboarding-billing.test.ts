import test from 'node:test';
import assert from 'node:assert/strict';
import { checkQuota } from '../lib/usage';
import { markOnboardingStep } from '../lib/onboarding';

function fakeAdmin(tenant: Record<string, unknown>, counters: Record<string, number> = {}) {
  const updates: Array<Record<string, unknown>> = [];
  const admin = {
    updates,
    rpc: async () => ({ data: null, error: { message: 'no rpc' } }),
    from(table: string) {
      let isUpdate = false;
      const q: any = new Proxy({}, {
        get(_t, prop) {
          if (prop === 'then') {
            const res = isUpdate ? { error: null } : { data: [], count: 0, error: null };
            return (r: (v: unknown) => void) => r(res);
          }
          if (prop === 'single' || prop === 'maybeSingle') return async () => {
            if (table === 'tenants') return { data: { ...tenant } };
            if (table === 'usage_counters') return { data: counters };
            return { data: null };
          };
          if (prop === 'update') return (v: Record<string, unknown>) => { isUpdate = true; if (table === 'tenants') { updates.push(v); Object.assign(tenant, v); } return q; };
          return () => q;
        },
      });
      return q;
    },
  };
  return admin as any;
}

const future = new Date(Date.now() + 86400000).toISOString();
const past = new Date(Date.now() - 86400000).toISOString();

test('periodo de gracia da acceso; caducado no', async () => {
  assert.equal((await checkQuota(fakeAdmin({ id: 't', plan: 'local_starter', subscription_status: 'past_due', grace_period_ends_at: future }), 't')).hasAccess, true);
  assert.equal((await checkQuota(fakeAdmin({ id: 't', plan: 'local_starter', subscription_status: 'past_due', grace_period_ends_at: past }), 't')).hasAccess, false);
  assert.equal((await checkQuota(fakeAdmin({ id: 't', plan: 'local_starter', subscription_status: 'trialing', trial_ends_at: past }), 't')).hasAccess, false);
});

test('límites por plan y ampliaciones del ciclo', async () => {
  const cycle = new Date().toISOString().slice(0, 7);
  for (const [plan, ai] of [['local_starter', 200], ['local_pro', 1000], ['ecommerce_starter', 500], ['ecommerce_pro', 2500]] as const) {
    const q = await checkQuota(fakeAdmin({ id: 't', plan, subscription_status: 'active', extra_ai: 500, extra_quota_cycle: cycle }), 't');
    assert.equal(q.metrics.ai.quota, ai + 500, plan);
  }
  const old = fakeAdmin({ id: 't', plan: 'local_starter', subscription_status: 'active', extra_ai: 500, extra_stored: 2000, extra_quota_cycle: '2000-01' });
  const q = await checkQuota(old, 't');
  assert.equal(q.metrics.ai.quota, 200);
  assert.equal(old.updates[0].extra_stored, 0);
});

test('agotar emails no bloquea la cuota de IA', async () => {
  const q = await checkQuota(fakeAdmin({ id: 't', plan: 'local_starter', subscription_status: 'active' }, { whatsapp_sent: 250 }), 't');
  assert.equal(q.allowed, false);
  assert.equal(q.metrics.ai.allowed, true);
});

test('marcar paso de onboarding conserva los demás', async () => {
  const admin = fakeAdmin({ id: 't', settings: { tone: 'cercano', onboarding_steps: { define_tone: true } } });
  await markOnboardingStep(admin, 't', 'send_first_request');
  assert.deepEqual(admin.updates[0].settings, { tone: 'cercano', onboarding_steps: { define_tone: true, send_first_request: true } });
});
