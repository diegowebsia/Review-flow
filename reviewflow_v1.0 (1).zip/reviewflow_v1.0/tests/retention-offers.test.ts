import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildRetentionOffers,
  cheaperPlanFor,
  getRetentionConfig,
  hasUsedRetentionDiscount,
} from '../lib/retention-offers';

test('valores por defecto: todo activado, 30 % durante 3 meses, 1 mes de pausa', () => {
  const cfg = getRetentionConfig({} as unknown as NodeJS.ProcessEnv);
  assert.deepEqual(cfg, {
    discount: { enabled: true, percent: 30, months: 3 },
    pause: { enabled: true, months: 1 },
    downgrade: { enabled: true },
  });
});

test('lee el .env y limita valores fuera de rango', () => {
  const cfg = getRetentionConfig({
    RETENTION_DISCOUNT_ENABLED: 'false',
    RETENTION_DISCOUNT_PERCENT: '"150%"',
    RETENTION_DISCOUNT_MONTHS: '0',
    RETENTION_PAUSE_MONTHS: '9',
    RETENTION_DOWNGRADE_ENABLED: 'no',
  } as unknown as NodeJS.ProcessEnv);
  assert.equal(cfg.discount.enabled, false);
  assert.equal(cfg.discount.percent, 100);
  assert.equal(cfg.discount.months, 1);
  assert.equal(cfg.pause.months, 3);
  assert.equal(cfg.downgrade.enabled, false);
});

test('el descuento solo se usa una vez por empresa', () => {
  assert.equal(hasUsedRetentionDiscount({}), false);
  assert.equal(hasUsedRetentionDiscount({ retention_discount_used_at: '2026-10-03' }), true);
  assert.equal(hasUsedRetentionDiscount({}, { retention_discount_used_at: '2026-10-03' }), true);
  const offers = buildRetentionOffers('local_pro', { retention_discount_used_at: '2026-10-03' });
  assert.equal(offers.discount.available, false);
});

test('plan más barato de la misma categoría', () => {
  assert.equal(cheaperPlanFor('local_pro')?.id, 'local_starter');
  assert.equal(cheaperPlanFor('ecommerce_pro')?.id, 'ecommerce_starter');
  assert.equal(cheaperPlanFor('local_starter'), null);
});
