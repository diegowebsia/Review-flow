import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { SCALING_STEPS, scalingAdvice } from '../lib/scaling';
import { PRODUCT_FLOW_SCENARIOS } from './fixtures/product-flow-scenarios';

test('la configuración y los avisos no incluyen servicios retirados', () => {
  const env = readFileSync('.env.example', 'utf8');
  for (const obsolete of ['UPSTASH_REDIS_REST_URL=', 'UPSTASH_REDIS_REST_TOKEN=', 'TEAM_MAX_MEMBERS=']) {
    assert.equal(env.includes(obsolete), false);
  }
  assert.equal(JSON.stringify(SCALING_STEPS).includes('QStash'), false);
  assert.equal(JSON.stringify(SCALING_STEPS).includes('Railway'), false);
  const advice = scalingAdvice({ tenants: 0, reviewsPerHour: 0, aiCallsPerHour: 0, aiCostMonthUsd: 0, dbMb: 0, dbConnections: 0 });
  assert.equal(advice.length, 6);
  for (const step of advice) {
    assert.ok(Number.isFinite(step.pct));
    assert.ok(step.action.length > 0);
  }
});

test('las definiciones de flujos son datos y apuntan a rutas existentes', () => {
  assert.equal(PRODUCT_FLOW_SCENARIOS.length, 5);
  for (const scenario of PRODUCT_FLOW_SCENARIOS) {
    assert.ok(readFileSync(`app${scenario.apiEndpoint}/route.ts`, 'utf8').length > 0);
  }
});

test('la verificación de lanzamiento no promete resultados que no comprueba', () => {
  const script = readFileSync('scripts/verify-launch.mjs', 'utf8');
  assert.equal(script.includes('Listo para comercializar'), false);
  assert.equal(script.includes('ultra-bajo coste'), false);
  assert.equal(script.includes("maxConcurrency: '10'"), false);
  assert.ok(script.includes("else bad('Respuesta inesperada"));
});
