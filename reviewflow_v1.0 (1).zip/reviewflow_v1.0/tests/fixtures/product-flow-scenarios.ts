/** Definiciones de flujos de producto verificadas por la suite de arquitectura.
 * No son pruebas de navegador; se comprueban mediante `npm test`.
 */

type ProductFlowScenario = {
  id: 'signup' | 'onboarding' | 'google_connect' | 'ai_reply' | 'stripe_checkout';
  title: string;
  route: string;
  apiEndpoint: string;
  expectedStatusCodes: number[];
};

export const PRODUCT_FLOW_SCENARIOS: ProductFlowScenario[] = [
  {
    id: 'signup',
    title: 'Registro de nuevo negocio y creación de cuenta',
    route: '/registro',
    apiEndpoint: '/api/auth/signup',
    expectedStatusCodes: [200, 201, 400, 429],
  },
  {
    id: 'onboarding',
    title: 'Onboarding paso a paso y comparativa de planes con prueba gratuita',
    route: '/bienvenido',
    apiEndpoint: '/api/tenants',
    expectedStatusCodes: [200, 401],
  },
  {
    id: 'google_connect',
    title: 'Conexión de Google Business Profile OAuth y Google Places ID',
    route: '/dashboard?tab=empresa',
    apiEndpoint: '/api/integrations/google/connect',
    expectedStatusCodes: [200, 302, 401],
  },
  {
    id: 'ai_reply',
    title: 'Generación y publicación de respuesta a reseña con IA (IA configurable / cola PostgreSQL)',
    route: '/dashboard?tab=bandeja',
    apiEndpoint: '/api/ai',
    expectedStatusCodes: [200, 202, 401],
  },
  {
    id: 'stripe_checkout',
    title: 'Suscripción y pago con Stripe Checkout en modo test',
    route: '/precios',
    apiEndpoint: '/api/stripe/checkout',
    expectedStatusCodes: [200, 400, 401],
  },
];
