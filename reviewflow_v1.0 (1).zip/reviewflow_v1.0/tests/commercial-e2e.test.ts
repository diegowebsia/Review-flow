import test from 'node:test';
import assert from 'node:assert/strict';
import QRCode from 'qrcode';
import { resolvePlan, planOf, type PlanId } from '../lib/plans';
import { generateReviewReply, inspectComplaint } from '../lib/ai';
import { normalizeCampaign } from '../lib/campaign';
import { safeInternalRedirect, signOpaqueId, verifyOpaqueId } from '../lib/security';
import { encryptCredentials, decryptCredentials } from '../lib/credentials';
import { productionEnvErrors } from '../lib/env-validation';

test('FASE 1: Validación de infraestructura, cifrado y variables de producción', () => {
  // 1. Cifrado AES-256-GCM para credenciales de clientes
  process.env.INTEGRATION_ENCRYPTION_KEY = 'audited-encryption-key-for-commercial-use';
  const secretCreds = {
    google_refresh_token: '1//0gRealRefreshToken123',
    trustpilot_api_key: 'tp_real_key_XYZ',
  };
  const encrypted = encryptCredentials(secretCreds);
  assert.equal((encrypted as any)._encrypted, 'v1');
  assert.equal(typeof (encrypted as any).value, 'string');
  assert.equal(JSON.stringify(encrypted).includes('1//0gRealRefreshToken123'), false);
  const decrypted = decryptCredentials<typeof secretCreds>(encrypted);
  assert.deepEqual(decrypted, secretCreds);

  // 2. Firmado de IDs opacos para aislamiento multi-tenant
  process.env.APP_SIGNING_SECRET = 'audited-app-signing-secret-commercial';
  const signed = signOpaqueId('tenant_acme_corp');
  assert.ok(signed.length > 20);
  assert.equal(verifyOpaqueId('tenant_acme_corp', signed), true);
  assert.equal(verifyOpaqueId('tenant_competitor', signed), false);

  // 3. Auditor de entorno estricto de producción
  const invalidEnv = {
    NEXT_PUBLIC_APP_URL: 'http://insecure-domain.com',
  } as unknown as NodeJS.ProcessEnv;
  const errors = productionEnvErrors(invalidEnv);
  assert.ok(errors.some((e) => e.includes('HTTPS')));
  assert.ok(errors.some((e) => e.includes('SUPABASE_SERVICE_ROLE_KEY')));
  assert.ok(errors.some((e) => e.includes('STRIPE_SECRET_KEY')));
});

test('FASE 2: Integración comercial de planes y pasarela de suscripción', () => {
  const planKeys: PlanId[] = ['local_starter', 'ecommerce_starter', 'local_pro', 'ecommerce_pro'];

  // Verificar que cada plan tiene precio en céntimos, límites definidos, 1 plan = 1 negocio y descripción
  for (const id of planKeys) {
    const p = planOf(id);
    assert.ok(p.priceCents > 0, `El plan ${id} debe tener un precio mayor a 0`);
    assert.equal(p.limits.tenants, 1, `El plan ${id} debe cubrir exactamente 1 empresa`);
    assert.equal(p.limits.locations, 1, `El plan ${id} debe cubrir exactamente 1 ubicación/local`);
    assert.ok(p.limits.requestsPerMonth > 0);
    assert.ok(p.limits.reviewsPerMonth > 0);
    assert.ok(p.limits.aiRepliesPerMonth > 0);
    assert.ok(p.limits.reviewsStored >= p.limits.reviewsPerMonth);
  }

  // Compatibilidad hacia atrás: resolución defensiva de planes
  assert.equal(resolvePlan('pro'), 'local_pro');
  assert.equal(resolvePlan('business'), 'ecommerce_pro');
  assert.equal(resolvePlan('ecommerce'), 'ecommerce_starter');
  assert.equal(resolvePlan('local'), 'local_starter');
  assert.equal(resolvePlan('local_pro'), 'local_pro');
  assert.equal(resolvePlan('ecommerce_pro'), 'ecommerce_pro');
});

test('FASE 3: Experiencia de Onboarding y Resiliencia ante fallos', async () => {
  // 1. Sanitización de campañas (evita inyecciones de código o PII)
  assert.equal(normalizeCampaign('mostrador-mesa-1'), 'mostrador-mesa-1');
  assert.equal(normalizeCampaign('MESA #1 / TERRAZA!'), 'mesa-1-terraza');
  assert.equal(normalizeCampaign(''), null);
  assert.equal(normalizeCampaign('   '), null);

  // 2. Redirección interna segura contra ataques Open Redirect
  assert.equal(safeInternalRedirect('/bienvenido?checkout=success'), '/bienvenido?checkout=success');
  assert.equal(safeInternalRedirect('https://malicious-phishing.com/steal-creds'), '/dashboard');
  assert.equal(safeInternalRedirect('//attacker.site'), '/dashboard');
  assert.equal(safeInternalRedirect('javascript:alert(1)'), '/dashboard');

  // 3. Triaje inteligente de quejas sin que lleguen a internet (≤3★)
  const complaint = await inspectComplaint({
    businessName: 'Trattoria Napoli',
    authorName: 'Mario',
    rating: 1,
    reviewText: 'Pésima atención del camarero, la comida tardó 45 minutos y llegó fría.',
  });
  assert.ok(['alta', 'critica', 'media'].includes(complaint.severity));
  assert.ok(complaint.actionPlan.length > 0);
  assert.ok(['privado', 'telefono', 'publico'].includes(complaint.suggestedChannel));
});

test('FASE 4: Simulación End-to-End de entrega de valor al cliente', async () => {
  // 1. Simulación de respuesta con IA con Identidad y Reglas de Marca
  const replyOutcome = await generateReviewReply({
    authorName: 'Carlos Gómez',
    rating: 5,
    reviewText: 'Excelente experiencia gastronómica, el risotto estaba espectacular y nos atendieron muy rápido.',
    businessName: 'Trattoria Bella Napoli',
    tone: 'cercano',
    brandInstructions: 'Restaurante italiano artesanal fundado en 1998 en el centro de Madrid.',
    brandRules: ['Mencionar que la masa se fermenta 72 horas', 'Invitar a probar el tiramisú artesanal'],
  });

  assert.ok(replyOutcome.reply.length > 20, 'La respuesta generada debe tener contenido sustancial');
  assert.ok(['gemini', 'local-template'].includes(replyOutcome.provider));
  assert.ok(replyOutcome.usage.totalTokens >= 0);

  // 2. Simulación de generación de Cartelería física QR (A4/A5)
  const targetUrl = 'https://mitienda.com/valorar/trattoria-napoli?campaign=mesa-vip';
  const qrSvg = await QRCode.toString(targetUrl, {
    type: 'svg',
    errorCorrectionLevel: 'H',
    margin: 2,
  });

  assert.ok(qrSvg.includes('<svg'), 'Debe generar un SVG de código QR válido para impresión');
  assert.ok(qrSvg.includes('viewBox'), 'El SVG debe tener viewBox para escalado vectorial sin pixelar');

  // 3. Verificación de tolerancia a fallos: sin API key o sin internet la app nunca se cae
  const fallbackReply = await generateReviewReply({
    authorName: 'Ana R.',
    rating: 2,
    reviewText: 'El café estaba frío y la música muy alta.',
    businessName: 'Café Central',
    tone: 'profesional',
    brandRules: ['Ofrecer invitación a un café en su próxima visita'],
  });
  assert.ok(fallbackReply.reply.length > 10);
});

test('FASE 5: Ausencia total de modo demo o datos ficticios en el producto comercial', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const root = process.cwd();

  // El archivo de datos de ejemplo ya no debe existir
  assert.equal(fs.existsSync(path.join(root, 'lib/demo.ts')), false, 'lib/demo.ts debe estar eliminado');

  // Ninguna vista principal debe contener texto ni banderas de "Modo demo"
  for (const rel of [
    'app/dashboard/page.tsx',
    'app/dashboard/dashboard-client.tsx',
    'app/admin/page.tsx',
    'app/admin/admin-client.tsx',
    'app/valorar/[slug]/page.tsx',
    'app/cartel/[slug]/page.tsx',
  ]) {
    const content = fs.readFileSync(path.join(root, rel), 'utf8');
    assert.equal(content.includes('@/lib/demo'), false, `${rel} no debe importar @/lib/demo`);
    assert.equal(content.includes('Modo demo'), false, `${rel} no debe mostrar carteles de Modo demo`);
  }
});

test('FASE 6: Límites por plan contratado, bloqueo al agotar y expansión al pagar ampliaciones o subir de plan', async () => {
  const { checkQuota, enforce, enforceAi, currentCycle } = await import('@/lib/usage');
  const { PLANS, ADDON_PACKS } = await import('@/lib/plans');
  const cycle = currentCycle();

  // Estado simulado en memoria para un cliente que contrata `local_starter` (250 peticiones, 500 reseñas, 200 IA, 150k tokens)
  const state = {
    tenant: {
      id: 'tenant-1',
      plan: 'local_starter',
      subscription_status: 'active',
      suspended: false,
      trial_ends_at: null,
      extra_requests: 0,
      extra_reviews: 0,
      extra_ai: 0,
      extra_syncs: 0,
      extra_stored: 0,
      extra_quota_cycle: cycle,
    },
    counters: {
      ai_responses: 0,
      whatsapp_sent: 0,
      reviews_ingested: 0,
      google_calls: 0,
      ai_tokens_in: 0,
      ai_tokens_out: 0,
    },
    addons: [] as Array<{ events: number; reviews: number; ai: number; whatsapp: number }>,
  };

  const fakeAdmin: any = {
    from(table: string) {
      return {
        select(_cols?: string, opts?: { count?: string; head?: boolean }) {
          if (opts?.head) {
            return {
              eq() {
                return Promise.resolve({ count: 10 });
              },
            };
          }
          return {
            eq(_col: string, _val: string) {
              if (table === 'tenants') {
                return {
                  single: () => Promise.resolve({ data: state.tenant }),
                };
              }
              if (table === 'usage_counters') {
                return {
                  eq() {
                    return {
                      single: () => Promise.resolve({ data: state.counters }),
                    };
                  },
                };
              }
              if (table === 'addons') {
                return {
                  eq() {
                    return Promise.resolve({ data: state.addons });
                  },
                };
              }
              return {
                eq() {
                  return { limit: () => Promise.resolve({ data: [] }) };
                },
                order() {
                  return { range: () => Promise.resolve({ data: [] }) };
                },
              };
            },
          };
        },
        update(patch: Record<string, unknown>) {
          return {
            eq() {
              Object.assign(state.tenant, patch);
              return Promise.resolve({ error: null });
            },
          };
        },
        delete() {
          return {
            eq() {
              return { lt: () => Promise.resolve({ count: 0 }) };
            },
            lt() {
              return Promise.resolve({ count: 0 });
            },
          };
        },
      };
    },
  };

  // 1. Verificar límites iniciales del plan `local_starter` (19 €/mes)
  const initialQuota = await checkQuota(fakeAdmin, 'tenant-1');
  assert.equal(initialQuota.plan, 'local_starter');
  assert.equal(initialQuota.metrics.requests.quota, PLANS.local_starter.limits.requestsPerMonth); // 250
  assert.equal(initialQuota.metrics.reviews.quota, PLANS.local_starter.limits.reviewsPerMonth); // 500
  assert.equal(initialQuota.metrics.ai.quota, PLANS.local_starter.limits.aiRepliesPerMonth); // 200
  assert.equal(initialQuota.aiUsage.tokensLimit, PLANS.local_starter.limits.aiTokensPerMonth); // 150.000

  // 2. Simular que el cliente alcanza el límite de 250 peticiones y 200 respuestas IA
  state.counters.whatsapp_sent = 250;
  state.counters.ai_responses = 200;
  state.counters.ai_tokens_in = 150_000;

  const blockedReq = await enforce(fakeAdmin, 'tenant-1', { metric: 'requests' });
  assert.equal(blockedReq.ok, false);
  if (!blockedReq.ok) {
    assert.equal(blockedReq.status, 429);
    assert.equal(blockedReq.code, 'quota_exhausted');
  }

  const blockedAi = await enforceAi(fakeAdmin, 'tenant-1');
  assert.equal(blockedAi.ok, false);
  if (!blockedAi.ok) {
    assert.equal(blockedAi.status, 429);
  }

  // 3. El cliente paga una ampliación de +1.000 peticiones (9 €) y +500 respuestas IA (15 €)
  state.tenant.extra_requests += ADDON_PACKS.extra_requests_1000.amount; // +1000
  state.tenant.extra_ai += ADDON_PACKS.extra_ai_500.amount; // +500

  const expandedQuota = await checkQuota(fakeAdmin, 'tenant-1');
  assert.equal(expandedQuota.metrics.requests.quota, 250 + 1000); // 1.250
  assert.equal(expandedQuota.metrics.requests.allowed, true);
  assert.equal(expandedQuota.metrics.ai.quota, 200 + 500); // 700
  assert.equal(expandedQuota.aiUsage.tokensLimit, 150_000 + 500 * 800); // 550.000 tokens
  assert.equal(expandedQuota.metrics.ai.allowed, true);

  const unlockedReq = await enforce(fakeAdmin, 'tenant-1', { metric: 'requests' });
  assert.equal(unlockedReq.ok, true, 'Tras pagar la recarga de peticiones debe desbloquearse inmediatamente');

  const unlockedAi = await enforceAi(fakeAdmin, 'tenant-1');
  assert.equal(unlockedAi.ok, true, 'Tras pagar la recarga de IA debe desbloquearse inmediatamente');

  // 4. El cliente sube de plan a `ecommerce_pro` (89 €/mes)
  state.tenant.plan = 'ecommerce_pro';
  const upgradedQuota = await checkQuota(fakeAdmin, 'tenant-1');
  assert.equal(upgradedQuota.plan, 'ecommerce_pro');
  assert.equal(
    upgradedQuota.metrics.requests.quota,
    PLANS.ecommerce_pro.limits.requestsPerMonth + 1000,
    'Al subir de plan suma el nuevo límite base (4.000) más las recargas vigentes del ciclo',
  );
  assert.equal(upgradedQuota.planDefinition.features.storeIntegration, true);
  assert.equal(upgradedQuota.planDefinition.features.storeIntegration, true);
});

test('FASE 7: Regresión de auditoría (Enlaces Footer, Cron Weekly Digest, URL QR en Vercel, Seguridad Signup y proveedor Gemini)', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const root = process.cwd();

  // 1. Enlaces del Footer: sin enlaces Demo ni guías internas expuestas en public/
  const footerContent = fs.readFileSync(path.join(root, 'components/Footer.tsx'), 'utf8');
  assert.equal(footerContent.includes('GUIA_DEFINITIVA_PRODUCCION.md'), false, 'Footer no debe apuntar a guía inexistente');
  assert.equal(footerContent.includes('/valorar/demo'), false, 'Footer no debe apuntar a /valorar/demo');
  assert.equal(footerContent.includes('/dashboard?demo=1'), false, 'Footer no debe apuntar a /dashboard?demo=1');
  assert.equal(fs.existsSync(path.join(root, 'public/GUIA_GRATIS.md')), false, 'public/GUIA_GRATIS.md no debe ser público');
  assert.equal(fs.existsSync(path.join(root, 'public/GUIA_DE_PAGO.md')), false, 'public/GUIA_DE_PAGO.md no debe ser público');
  assert.equal(fs.existsSync(path.join(root, 'app/robots.ts')), true, 'app/robots.ts debe existir');
  assert.equal(fs.existsSync(path.join(root, 'app/sitemap.ts')), true, 'app/sitemap.ts debe existir');

  // 2. Cron Weekly Digest programado en vercel.json y ruta existente
  const vercelJson = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
  const cronPaths = (vercelJson.crons ?? []).map((c: any) => c.path);
  assert.ok(cronPaths.includes('/api/cron/sync-reviews'), 'vercel.json debe programar /api/cron/sync-reviews');
  assert.ok(cronPaths.includes('/api/cron/weekly-digest'), 'vercel.json debe programar /api/cron/weekly-digest');
  assert.equal(
    fs.existsSync(path.join(root, 'app/api/cron/weekly-digest/route.ts')),
    true,
    'La ruta /api/cron/weekly-digest debe existir',
  );

  // 3. Auto-detección de dominio en VERCEL_URL aunque NEXT_PUBLIC_APP_URL sea http://localhost:3000
  const { resolveAppUrlFromEnv, resolveBaseUrl } = await import('@/lib/env');
  const resolvedVercel = resolveAppUrlFromEnv({
    NODE_ENV: 'production',
    NEXT_PUBLIC_APP_URL: 'http://localhost:3000',
    VERCEL_URL: 'mi-negocio-temporal.vercel.app',
  });
  assert.equal(resolvedVercel, 'https://mi-negocio-temporal.vercel.app');

  const fakeReq = new Request('http://localhost:3000/api/tenants/qr?tenantId=123', {
    headers: {
      'x-forwarded-host': 'panel.midominio.com',
      'x-forwarded-proto': 'https',
    },
  });
  const resolvedFromHeaders = resolveBaseUrl(fakeReq, {
    NODE_ENV: 'production',
    NEXT_PUBLIC_APP_URL: 'http://localhost:3000',
  });
  assert.equal(resolvedFromHeaders, 'https://panel.midominio.com');

  // 4. Signup no sobrescribe la contraseña de una cuenta existente sin confirmar
  const signupRouteContent = fs.readFileSync(path.join(root, 'app/api/auth/signup/route.ts'), 'utf8');
  assert.equal(
    signupRouteContent.includes('updateUserById'),
    false,
    '/api/auth/signup no debe llamar a updateUserById para sobrescribir contraseñas de cuentas existentes',
  );

  // 5. Consistencia de proveedor Gemini en cola asíncrona y ausencia de referencias a GUIA_DEFINITIVA_PRODUCCION.md
  const queueContent = fs.readFileSync(path.join(root, 'lib/queue.ts'), 'utf8');
  assert.equal(queueContent.includes('gpt-4o-mini'), false, 'lib/queue.ts no debe insertar gpt-4o-mini');
});

test('FASE 8: Seguridad Enterprise, Internacionalización 3 capas, Ciclo de Vida y Moat Competitivo', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const root = process.cwd();

  // 1. Hashing SHA-256 y rotación con solape de 24h de API keys
  const { generateTenantApiKey, hashApiKey, isRotatedPreviousKeyValid } = await import('@/lib/api-keys');
  const keyPair = generateTenantApiKey();
  assert.ok(keyPair.rawKey.startsWith('rf_live_'));
  assert.equal(keyPair.hash, hashApiKey(keyPair.rawKey));
  const futureDate = new Date(Date.now() + 24 * 3600 * 1000).toISOString();
  assert.equal(
    isRotatedPreviousKeyValid(keyPair.rawKey, {
      previous_api_key_hash: keyPair.hash,
      previous_api_key_expires_at: futureDate,
    }),
    true,
  );

  // 2. Internacionalización de 3 capas (UI, cliente, auto-detección de idioma de reseña)
  const { detectReviewLocale, SUPPORTED_LOCALES } = await import('@/lib/i18n');
  assert.ok(SUPPORTED_LOCALES.length >= 6);
  assert.equal(detectReviewLocale('Great service and amazing food! Best restaurant in town.'), 'en');
  assert.equal(detectReviewLocale('Très bon service, merci beaucoup à toute l’équipe !'), 'fr');
  assert.equal(detectReviewLocale('Vielen Dank für den tollen Service und das leckere Essen!'), 'de');
  assert.equal(detectReviewLocale('Ottimo servizio, grazie mille a tutti!'), 'it');
  assert.equal(detectReviewLocale('Muito obrigado pelo excelente atendimento!'), 'pt');
  assert.equal(detectReviewLocale('Excelente atención de todo el equipo, muchas gracias.'), 'es');

  // 3. Detector de reseñas falsas/spam y cadencia humanizada de publicación
  const { detectFakeOrSpamReview, computeHumanizedPublishTime } = await import('@/lib/review-classifier');
  const spamCheck = detectFakeOrSpamReview({
    authorName: 'Bot12345',
    rating: 1,
    text: 'No vayáis aquí, mejor id a la competencia en https://spam-link.com ESTAFA!!!',
    isVerified: false,
  });
  assert.equal(spamCheck.isSuspicious, true);
  assert.ok(spamCheck.confidenceScore >= 50);
  assert.ok(spamCheck.reasons.length >= 2);
  assert.ok(spamCheck.reportDossier.includes('SOLICITUD FORMAL DE RETIRADA DE RESEÑA'));

  const schedule = computeHumanizedPublishTime(new Date('2026-05-10T10:00:00Z'));
  assert.equal(schedule.immediate, false);
  assert.ok(new Date(schedule.scheduledFor).getTime() > new Date('2026-05-10T10:00:00Z').getTime());

  // 4. Plantillas por vertical y reseñas de ejemplo para Time-to-First-Value < 60s
  const { SAMPLE_REVIEWS, VERTICAL_TEMPLATES } = await import('@/lib/sample-reviews');
  assert.equal(SAMPLE_REVIEWS.length, 12);
  assert.ok(VERTICAL_TEMPLATES.length >= 5);

  // 5. Existencia de rutas de cumplimiento RGPD Art. 17, DPA público y CI/CD GitHub Actions
  assert.equal(fs.existsSync(path.join(root, 'app/api/tenants/delete/route.ts')), true);
  assert.equal(fs.existsSync(path.join(root, 'app/api/tenants/api-key/route.ts')), true);
  assert.equal(fs.existsSync(path.join(root, 'app/dpa/page.tsx')), true);
  assert.equal(fs.existsSync(path.join(root, '.github/workflows/ci.yml')), true);
});

