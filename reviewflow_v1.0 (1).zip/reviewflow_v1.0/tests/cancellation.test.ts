import test from 'node:test';
import assert from 'node:assert/strict';
import { canReactivate, periodEndDate } from '../lib/cancellation';

const now = new Date('2026-10-03T12:00:00Z');

test('baja a final de periodo con fecha futura se puede reactivar', () => {
  assert.equal(canReactivate({ cancel_mode: 'period_end', cancel_at: '2026-11-01T00:00:00Z' }, now), true);
});

test('baja a final de periodo cuya fecha ya llegó no se puede reactivar', () => {
  assert.equal(canReactivate({ cancel_mode: 'period_end', cancel_at: '2026-10-01T00:00:00Z' }, now), false);
});

test('baja inmediata no se puede reactivar', () => {
  assert.equal(canReactivate({ cancel_mode: 'now', cancel_at: '2026-11-01T00:00:00Z' }, now), false);
});

test('fin de periodo usa la fecha de Stripe si es futura', () => {
  const sec = Math.floor(new Date('2026-10-20T00:00:00Z').getTime() / 1000);
  assert.equal(periodEndDate(sec, now).toISOString(), '2026-10-20T00:00:00.000Z');
});
