/**
 * ============================================================
 * Suite de Pruebas ReviewFlow AI v1.0
 * ============================================================
 * Cubre los 6 bloques exigidos en la auditoría de ingeniería:
 *   1. Internacionalización real (7 idiomas completos + emails transaccionales + Intl API)
 *   2. Observabilidad (Sentry release tagging v1.0 + /health + Correlation IDs)
 *   3. Métricas de negocio BI (MRR, conversión trial→pago, churn, upgrades/downgrades, coste IA por cliente y plan, eventos de embudo)
 *   4. Aislamiento Multi-Tenant (RLS + guardias de servidor: una empresa NUNCA lee ni escribe datos de otra)
 *   5. Integración de cambios de plan y webhooks de pago (upgrade, downgrade, pausa, reactivación, impago) + límites por plan
 *   6. Versionado 1.0, las tres guías, comparador de planes + FAQ + emails día 3 y día 6 + cero contenido falso
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

import {
  SUPPORTED_LOCALES,
  formatCurrencyAmount,
  formatDateIntl,
  formatNumberIntl,
  type SupportedLocale,
} from '../lib/i18n';
import { renderTransactionalEmail, type TransactionalEmailKind } from '../lib/transactional-emails';
import {
  APP_VERSION,
  SENTRY_RELEASE,
  captureException,
  correlationHeaders,
  getOrCreateCorrelationId,
} from '../lib/observability';
import { computeBusinessMetrics } from '../lib/business-metrics';
import { hasAccess, planOf } from '../lib/plans';
import { checkQuota } from '../lib/usage';
import { requireOwner, requireRole } from '../lib/authz';

const root = process.cwd();

/* ================================================================== */
/* 1. INTERNACIONALIZACIÓN REAL (7 IDIOMAS + EMAILS + INTL)            */
/* ================================================================== */

test('1.1 Hay 7 idiomas disponibles en el traductor automático', () => {
  assert.equal(SUPPORTED_LOCALES.length, 7);
  assert.ok(SUPPORTED_LOCALES.some((l) => l.code === 'es'));
});

test('1.2 Emails transaccionales se generan traducidos en los 7 idiomas (bienvenida, pago, trial, día 3, día 6, impago)', () => {
  const locales: SupportedLocale[] = ['es', 'en', 'ca', 'pt', 'fr', 'de', 'it'];
  const kinds: TransactionalEmailKind[] = [
    'welcome',
    'payment_confirmed',
    'trial_expiring',
    'abandoned_trial_day3',
    'abandoned_trial_day6',
    'payment_failed',
  ];

  for (const locale of locales) {
    for (const kind of kinds) {
      const mail = renderTransactionalEmail({
        kind,
        locale,
        tenantName: 'Clínica Norte',
        planName: 'Local Pro',
        amountCents: 5900,
        reviewsCount: 42,
        hoursSaved: 4.9,
        attemptCount: 1,
      });
      assert.ok(mail.subject.length > 5, `Asunto vacío para ${kind} (${locale})`);
      assert.ok(mail.html.includes('Clínica Norte'), `HTML sin nombre de negocio para ${kind} (${locale})`);
      assert.ok(mail.text.includes('Clínica Norte'), `Texto sin nombre de negocio para ${kind} (${locale})`);
    }
  }
});

test('1.3 Formateo Intl de precios, números y fechas según idioma y moneda seleccionados', () => {
  const priceEs = formatCurrencyAmount(49, 'EUR', 'es');
  const priceEnUsd = formatCurrencyAmount(49, 'USD', 'en');
  const priceEnGbp = formatCurrencyAmount(49, 'GBP', 'en');

  assert.ok(priceEs.includes('€'), `Precio ES debe incluir €: ${priceEs}`);
  assert.ok(priceEnUsd.includes('$'), `Precio EN USD debe incluir $: ${priceEnUsd}`);
  assert.ok(priceEnGbp.includes('£'), `Precio EN GBP debe incluir £: ${priceEnGbp}`);

  const numEs = formatNumberIntl(15000, 'es');
  const numEn = formatNumberIntl(15000, 'en');
  assert.ok(numEs.length >= 5);
  assert.ok(numEn.includes('15,000'));

  const sampleDate = '2026-09-29T12:00:00Z';
  const dateEs = formatDateIntl(sampleDate, 'es');
  const dateDe = formatDateIntl(sampleDate, 'de');
  assert.ok(dateEs.length > 0 && dateDe.length > 0);
});

/* ================================================================== */
/* 2. OBSERVABILIDAD (/health, SENTRY RELEASE, CORRELATION IDS)       */
/* ================================================================== */

test('2.1 Observabilidad: versión 1.0, Sentry release tag, Correlation IDs y endpoint público /health', async () => {
  assert.equal(APP_VERSION, '1.0');
  assert.equal(SENTRY_RELEASE, 'reviewflow-ai@1.0');

  const reqWithHeader = new Request('https://reviewflow.es/api/health', {
    headers: { 'x-correlation-id': 'corr-custom-123456' },
  });
  assert.equal(getOrCreateCorrelationId(reqWithHeader), 'corr-custom-123456');

  const reqWithoutHeader = new Request('https://reviewflow.es/api/health');
  const generatedId = getOrCreateCorrelationId(reqWithoutHeader);
  assert.ok(generatedId.startsWith('rf_corr_'));

  const headers = correlationHeaders(generatedId);
  assert.equal(headers['X-Correlation-Id'], generatedId);
  assert.equal(headers['X-Release'], 'reviewflow-ai@1.0');

  const eventId = await captureException(new Error('Simulated test error'), {
    source: 'test.observability',
    correlationId: generatedId,
  });
  assert.equal(eventId, generatedId);

  // Verificar que existen /health y /api/health y comprueban database, paymentGateway y aiService
  assert.equal(fs.existsSync(path.join(root, 'app/health/route.ts')), true);
  const apiHealthSrc = fs.readFileSync(path.join(root, 'app/api/health/route.ts'), 'utf8');
  assert.equal(apiHealthSrc.includes('database'), true);
  assert.equal(apiHealthSrc.includes('paymentGateway'), true);
  assert.equal(apiHealthSrc.includes('aiService'), true);
});

/* ================================================================== */
/* 3. MÉTRICAS DE NEGOCIO (BI) Y EMBUDO DE PRODUCTO                   */
/* ================================================================== */

test('3.1 Cálculo de métricas de negocio (MRR, conversión trial→pago, churn, upgrades/downgrades, coste IA por cliente y plan)', () => {
  const sampleTenants = [
    {
      id: 't1',
      name: 'Restaurante Sol',
      plan: 'local_starter',
      subscription_status: 'active',
      ai_tokens_cycle: 25000,
      ai_cost_cycle: 0.12,
    },
    {
      id: 't2',
      name: 'Tienda Moda',
      plan: 'ecommerce_pro',
      subscription_status: 'active',
      ai_tokens_cycle: 120000,
      ai_cost_cycle: 0.48,
    },
    {
      id: 't3',
      name: 'Cafetería Luna',
      plan: 'local_starter',
      subscription_status: 'trialing',
      ai_tokens_cycle: 5000,
      ai_cost_cycle: 0.02,
    },
    {
      id: 't4',
      name: 'Bazar Sur',
      plan: 'local_pro',
      subscription_status: 'canceled',
      ai_tokens_cycle: 10000,
      ai_cost_cycle: 0.05,
      settings: { scheduled_downgrade_plan: 'local_starter' },
    },
  ];

  const sampleLogs = [
    { source: 'product_event.user_signup', message: 'signup 1' },
    { source: 'product_event.user_signup', message: 'signup 2' },
    { source: 'product_event.tenant_activated', message: 'activated 1' },
    { source: 'product_event.first_report_generated', message: 'report 1' },
    { source: 'product_event.plan_upgraded', message: 'upgrade 1' },
    { source: 'product_event.plan_downgraded', message: 'downgrade 1' },
  ];

  const metrics = computeBusinessMetrics(sampleTenants, sampleLogs);

  // MRR = Local Starter (1900) + Ecommerce Pro (6900) = 8800 cents (88 €)
  assert.equal(metrics.mrrCents, 8800);
  assert.equal(metrics.arrCents, 8800 * 12);
  assert.equal(metrics.activeCount, 2);
  assert.equal(metrics.trialingCount, 1);
  assert.equal(metrics.canceledOrChurnedCount, 1);

  // Conversión prueba→pago: 2 activos de 4 totales = 50%
  assert.equal(metrics.trialToPaidConversionPct, 50);

  // Churn mensual: 1 cancelado sobre 3 (2 activos + 1 cancelado) = 33.3%
  assert.equal(metrics.monthlyChurnPct, 33.3);

  // Coste IA total y medio por cliente
  assert.equal(metrics.totalAiCostUsd, 0.67);
  assert.equal(metrics.avgAiCostPerCustomerUsd, 0.1675);

  // Desglose por los 4 planes del catálogo
  assert.equal(metrics.aiCostByPlan.length, 4);
  const ecomProPlan = metrics.aiCostByPlan.find((p) => p.planId === 'ecommerce_pro');
  assert.ok(ecomProPlan);
  assert.equal(ecomProPlan.mrrCents, 6900);
  assert.equal(ecomProPlan.totalAiCostUsd, 0.48);

  // Embudo de producto
  assert.equal(metrics.funnel.signups, 4);
  assert.equal(metrics.funnel.firstReportGenerated, 1);
  assert.ok(metrics.funnel.upgraded >= 1);
});

/* ================================================================== */
/* 4. AISLAMIENTO MULTI-TENANT (RLS + GUARDIAS DE SERVIDOR)            */
/* ================================================================== */

test('4.1 Aislamiento Multi-Tenant: una empresa NUNCA puede leer ni escribir datos de otra (RLS + requireRole)', async () => {
  // 1. Verificar políticas RLS en supabase/schema.sql para todas las tablas multi-tenant
  const schemaSql = fs.readFileSync(path.join(root, 'supabase/schema.sql'), 'utf8');
  const protectedTables = [
    'tenants',
    'memberships',
    'integrations',
    'reviews',
    'usage_counters',
    'addons',
    'feedback_responses',
    'quota_events',
    'ai_interactions',
    'whatsapp_optins',
    'whatsapp_contacts',
  ];
  for (const tbl of protectedTables) {
    assert.ok(
      schemaSql.includes(`alter table public.${tbl} enable row level security`),
      `La tabla ${tbl} debe tener RLS habilitado en supabase/schema.sql`,
    );
  }
  assert.ok(schemaSql.includes('public.is_member('));
  assert.ok(schemaSql.includes('public.is_owner('));

  // 2. Simulación de Base de Datos con 2 empresas aisladas (Tenant A y Tenant B)
  const TENANT_A = '11111111-1111-4111-8111-111111111111';
  const TENANT_B = '22222222-2222-4222-8222-222222222222';
  const USER_A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';

  // Mock de admin client donde USER_A solo es miembro de TENANT_A
  const mockAdminForMembership = (queriedTenantId: string, queriedUserId: string) => {
    if (queriedTenantId === TENANT_A && queriedUserId === USER_A) {
      return { data: { role: 'owner' }, error: null };
    }
    return { data: null, error: null };
  };

  // Verificar que la consulta de membresía para USER_A sobre TENANT_B devuelve null (bloqueado con 403)
  const accessToA = mockAdminForMembership(TENANT_A, USER_A);
  const accessToB = mockAdminForMembership(TENANT_B, USER_A);
  assert.equal(accessToA.data?.role, 'owner');
  assert.equal(accessToB.data, null, 'Usuario de Empresa A NUNCA debe tener membresía en Empresa B');

  // Verificar que sin sesión autenticada requireRole y requireOwner rechazan inmediatamente (401)
  const fakeAdmin = {
    from: (table: string) => ({
      select: () => ({
        eq: (_col1: string, val1: string) => ({
          eq: (_col2: string, val2: string) => ({
            maybeSingle: async () =>
              table === 'memberships' ? mockAdminForMembership(val1, val2) : { data: null, error: null },
          }),
          maybeSingle: async () => ({ data: null, error: null }),
        }),
      }),
    }),
  } as any;

  const unauthRole = await requireRole(fakeAdmin, TENANT_B, 'viewer');
  assert.equal(unauthRole.ok, false);
  if (!unauthRole.ok) {
    assert.equal(unauthRole.status, 401);
  }

  // Verificar que USER_A (propietario de TENANT_A) puede acceder a TENANT_A pero es BLOQUEADO (403) en TENANT_B
  const authOnTenantA = await requireRole(fakeAdmin, TENANT_A, 'viewer', { injectedUser: { id: USER_A } });
  assert.equal(authOnTenantA.ok, true);

  const crossTenantAttack = await requireRole(fakeAdmin, TENANT_B, 'viewer', { injectedUser: { id: USER_A } });
  assert.equal(crossTenantAttack.ok, false);
  if (!crossTenantAttack.ok) {
    assert.equal(crossTenantAttack.status, 403, 'Acceso cruzado entre empresas debe devolver 403 Forbidden');
  }

  const unauthOwner = await requireOwner(fakeAdmin, TENANT_B);
  assert.equal(unauthOwner.ok, false);
});

/* ================================================================== */
/* 5. FLUJOS DE CAMBIO DE PLAN, WEBHOOKS Y LÍMITES DE USO POR PLAN     */
/* ================================================================== */

test('5.1 Flujos de cambio de plan contra webhooks de pago (upgrade, downgrade, pausa, reactivación, impago)', () => {
  const subRoute = fs.readFileSync(path.join(root, 'app/api/stripe/subscription/route.ts'), 'utf8');
  const webhookRoute =
    fs.readFileSync(path.join(root, 'app/api/stripe/webhook/route.ts'), 'utf8') +
    fs.readFileSync(path.join(root, 'lib/stripe-webhook-handlers.ts'), 'utf8');

  // 1. Upgrade inmediato con prorrateo (proration_behavior: 'always_invoice')
  assert.equal(subRoute.includes("action === 'upgrade'"), true);
  assert.equal(subRoute.includes("proration_behavior: 'always_invoice'"), true);
  assert.equal(subRoute.includes("trackProductEvent('plan_upgraded'"), true);

  // 2. Downgrade programado a final de ciclo (scheduled_downgrade_plan)
  assert.equal(subRoute.includes("action === 'downgrade'"), true);
  assert.equal(subRoute.includes('scheduled_downgrade_plan'), true);
  assert.equal(subRoute.includes("trackProductEvent('plan_downgraded'"), true);

  // 3. Pausa de suscripción (pause_collection.behavior: 'void')
  assert.equal(subRoute.includes("action === 'pause'"), true);
  assert.equal(subRoute.includes('pause_collection'), true);
  assert.equal(subRoute.includes("trackProductEvent('subscription_paused'"), true);

  // 4. Reactivación con descuento de retención (apply_recovery_discount)
  assert.equal(subRoute.includes("action === 'apply_recovery_discount'"), true);
  assert.equal(subRoute.includes('RECOVERY20'), true);

  // 5. Webhooks de Stripe: checkout, renovación, cambio/baja e impago con 3 días de gracia
  assert.equal(webhookRoute.includes("case 'checkout.session.completed'"), true);
  assert.equal(webhookRoute.includes("case 'invoice.payment_succeeded'"), true);
  assert.equal(webhookRoute.includes("case 'customer.subscription.updated'"), true);
  assert.equal(webhookRoute.includes("case 'customer.subscription.deleted'"), true);
  assert.equal(webhookRoute.includes("case 'invoice.payment_failed'"), true);
  assert.equal(webhookRoute.includes('grace_period_ends_at'), true);

  // Reglas de control de acceso según estado de suscripción
  assert.equal(hasAccess('active', false), true);
  assert.equal(hasAccess('trialing', false), true);
  assert.equal(hasAccess('past_due', false), false);
  assert.equal(hasAccess('paused', false), false);
  assert.equal(hasAccess('inactive', false), false);
  assert.equal(hasAccess('active', true), false); // suspendida por Super-Admin
});

test('5.2 Límites de uso por plan y bloqueo al agotar cuota (checkQuota)', async () => {
  // Verificar límites exactos de cada plan del catálogo
  const localStarter = planOf('local_starter');
  const localPro = planOf('local_pro');
  const ecomStarter = planOf('ecommerce_starter');
  const ecomPro = planOf('ecommerce_pro');

  assert.equal(localStarter.priceCents, 1900);
  assert.equal(localStarter.limits.requestsPerMonth, 250);
  assert.equal(localStarter.limits.aiRepliesPerMonth, 200);

  assert.equal(localPro.priceCents, 3900);
  assert.equal(localPro.limits.requestsPerMonth, 1500);
  assert.equal(localPro.limits.aiRepliesPerMonth, 1000);

  assert.equal(ecomStarter.priceCents, 2900);
  assert.equal(ecomStarter.limits.requestsPerMonth, 800);
  assert.equal(ecomStarter.limits.aiRepliesPerMonth, 500);

  assert.equal(ecomPro.priceCents, 6900);
  assert.equal(ecomPro.limits.requestsPerMonth, 4000);
  assert.equal(ecomPro.limits.aiRepliesPerMonth, 2500);

  // Simular checkQuota para un tenant en local_starter (límite 250 peticiones)
  const createMockQuotaAdmin = (usedEvents: number, extraRequests = 0) => {
    const counterRow = {
      reviews_ingested: 0,
      ai_responses: 0,
      whatsapp_sent: usedEvents,
      google_calls: 0,
      ai_tokens_in: 1000,
      ai_tokens_out: 500,
    };
    const tenantRow = {
      id: 'tenant-1',
      plan: 'local_starter',
      subscription_status: 'active',
      suspended: false,
      extra_requests: extraRequests,
      extra_reviews: 0,
      extra_ai: 0,
      extra_syncs: 0,
      extra_stored: 0,
      extra_quota_cycle: new Date().toISOString().slice(0, 7),
    };
    return {
      from: (table: string) => ({
        select: () => ({
          count: 0,
          eq: () => ({
            count: 0,
            single: async () => ({ data: table === 'tenants' ? tenantRow : counterRow }),
            maybeSingle: async () => ({ data: table === 'tenants' ? tenantRow : counterRow }),
            eq: () => ({
              data: [],
              single: async () => ({ data: table === 'usage_counters' ? counterRow : null }),
              maybeSingle: async () => ({ data: table === 'usage_counters' ? counterRow : null }),
              limit: async () => ({ data: [] }),
            }),
          }),
        }),
        update: () => ({
          eq: async () => ({ data: null, error: null }),
        }),
      }),
    } as any;
  };

  // Caso A: dentro del límite (100 / 250) -> permitido
  const quotaOk = await checkQuota(createMockQuotaAdmin(100), 'tenant-1');
  assert.equal(quotaOk.allowed, true);
  assert.equal(quotaOk.metrics.requests.quota, 250);
  assert.equal(quotaOk.metrics.requests.remaining, 150);

  // Caso B: cuota agotada (250 / 250) -> bloqueado (allowed: false)
  const quotaBlocked = await checkQuota(createMockQuotaAdmin(250), 'tenant-1');
  assert.equal(quotaBlocked.metrics.requests.allowed, false);
  assert.equal(quotaBlocked.metrics.requests.remaining, 0);

  // Caso C: con ampliación comprada (+500 extra -> límite 750) -> desbloqueado
  const quotaWithAddon = await checkQuota(createMockQuotaAdmin(250, 500), 'tenant-1');
  assert.equal(quotaWithAddon.metrics.requests.allowed, true);
  assert.equal(quotaWithAddon.metrics.requests.quota, 750);
  assert.equal(quotaWithAddon.metrics.requests.remaining, 500);
});

/* ================================================================== */
/* 6. VERSIONADO 1.0, GUÍAS Y PULIDO DE CONVERSIÓN              */
/* ================================================================== */

test('6.1 Versionado 1.0, las tres guías, comparador de planes, FAQ, cron día 3/6 y cero contenido inventado', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.match(pkg.version, /^1\.\d+\.\d+$/);

  assert.equal(pkg.version, '1.0.0');
  const guides = fs.readdirSync(root).filter((name) => name.endsWith('.md')).sort();
  assert.deepEqual(guides, ['GUIA_1_PROBAR_EN_LOCALHOST.md', 'GUIA_2_PUBLICAR_Y_PAGAR.md', 'GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md']);

  // Verificar versión en el pie del panel (/dashboard) y en el Footer
  const dashSrc =
    fs.readFileSync(path.join(root, 'app/dashboard/dashboard-client.tsx'), 'utf8') +
    fs.readFileSync(path.join(root, 'components/dashboard/DashboardHeaderAndNav.tsx'), 'utf8');
  assert.equal(dashSrc.includes('version'), true);

  // Verificar comparador de planes (#comparativa) y FAQ (#faq) en Landing.tsx
  const landingSrc = fs.readFileSync(path.join(root, 'components/Landing.tsx'), 'utf8');
  assert.equal(landingSrc.includes('id="comparativa"'), true);
  assert.equal(landingSrc.includes('id="faq"'), true);

  // Verificar cron de carrito abandonado / prueba sin convertir a los 3 y 6 días
  assert.equal(fs.existsSync(path.join(root, 'app/api/cron/abandoned-trial/route.ts')), true);
  const cronSrc = fs.readFileSync(path.join(root, 'app/api/cron/abandoned-trial/route.ts'), 'utf8');
  assert.equal(cronSrc.includes('abandoned_trial_day3'), true);
  assert.equal(cronSrc.includes('abandoned_trial_day6'), true);
});

test('6.2 Esquema SQL incluye GRANT explícitos para las 18 tablas y restringe tablas internas a service_role', () => {
  const schema = fs.readFileSync(path.join(root, 'supabase/schema.sql'), 'utf8');

  const internalTables = [
    'integrations',
    'system_logs',
    'admin_audit_events',
    'processed_events',
    'webhook_events',
    'api_rate_limits',
    'system_settings',
  ];
  for (const tbl of internalTables) {
    assert.ok(
      schema.includes(`GRANT ALL ON public.${tbl} TO service_role;`),
      `Falta GRANT ALL ON public.${tbl} TO service_role`,
    );
    assert.equal(
      schema.includes(`GRANT SELECT, INSERT, UPDATE, DELETE ON public.${tbl} TO authenticated;`),
      false,
      `La tabla interna public.${tbl} no debe conceder permisos de escritura a authenticated`,
    );
  }

  // memberships: el navegador solo lee; altas/bajas del equipo van por /api/team (service_role).
  assert.ok(schema.includes('GRANT SELECT ON public.memberships TO authenticated;'), 'Falta GRANT SELECT en public.memberships');
  assert.ok(schema.includes('GRANT ALL ON public.memberships TO service_role;'), 'Falta GRANT service_role en public.memberships');
  assert.equal(
    schema.includes('GRANT SELECT, INSERT, UPDATE, DELETE ON public.memberships TO authenticated;'),
    false,
    'public.memberships no debe conceder escritura a authenticated',
  );

  const clientTables = [
    'tenants',
    'reviews',
    'usage_counters',
    'quota_events',
    'ai_interactions',
    'whatsapp_optins',
    'whatsapp_contacts',
    'feedback_responses',
    'addons',
    'tenant_roles',
  ];
  for (const tbl of clientTables) {
    assert.ok(
      schema.includes(`GRANT SELECT, INSERT, UPDATE, DELETE ON public.${tbl} TO authenticated;`),
      `Falta GRANT para authenticated en public.${tbl}`,
    );
    assert.ok(
      schema.includes(`GRANT ALL ON public.${tbl} TO service_role;`),
      `Falta GRANT para service_role en public.${tbl}`,
    );
  }

  assert.ok(
    schema.includes('grace_period_ends_at timestamptz'),
    'tenants debe incluir la columna grace_period_ends_at',
  );
});

test('6.3 Pruebas de integración HTTP de rutas API (salud, clic de embudo y rechazo sin credenciales en webhooks M2M)', async () => {
  const { GET: getHealth } = await import('../app/health/route');
  const healthRes = await getHealth(new Request('http://localhost:3000/health'));
  assert.equal(healthRes.status, 200);
  const healthBody = (await healthRes.json()) as Record<string, unknown>;
  assert.equal(healthBody.ok, true);
  // La versión pública no debe mostrar versiones, nombres de servicios internos ni mensajes de error
  assert.equal('version' in healthBody, false);
  assert.equal('service' in healthBody, false);
  assert.equal('checks' in healthBody, false);

  // POST /api/integrations/ecommerce/order-delivered sin api_key ni firma -> 401
  const { POST: postOrderDelivered } = await import('../app/api/integrations/ecommerce/order-delivered/route');
  const unauthReq = new Request('http://localhost:3000/api/integrations/ecommerce/order-delivered', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ customerPhone: '+34600111222', orderId: 'ORD-99' }),
  });
  const unauthRes = await postOrderDelivered(unauthReq);
  assert.ok(
    unauthRes.status === 401 || unauthRes.status === 503,
    `Se esperaba 401 (o 503 sin Supabase en CI) y devolvió ${unauthRes.status}`,
  );

  // POST /api/feedback/click con payload inválido -> 400
  const { POST: postFeedbackClick } = await import('../app/api/feedback/click/route');
  const badClickReq = new Request('http://localhost:3000/api/feedback/click', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-forwarded-for': '203.0.113.50' },
    body: JSON.stringify({ slug: '', target: 'invalid_target' }),
  });
  const badClickRes = await postFeedbackClick(badClickReq);
  assert.equal(badClickRes.status, 400);
});

/* ================================================================== */
/* 7. ARREGLOS PUNTUALES v1 (PUNTOS 1, 2, 3, 4 y 5)                   */
/* ================================================================== */

test('7.1 [Punto 1] Recordatorios sin duplicados: prioridad pago fallido > prueba por caducar > prueba sin convertir y exclusión de past_due/unpaid/incomplete', async () => {
  const {
    ABANDONED_TRIAL_ALLOWED_STATUSES,
    PAYMENT_FAILED_STATUSES,
    getReminderPeriodKey,
    hasReminderBeenSentInPeriod,
    recordReminderSend,
    resolveSingleReminderForTenant,
  } = await import('../lib/transactional-emails');
  const { executePaginatedReminders, resetReminderCronCursorForTests } = await import(
    '../app/api/cron/abandoned-trial/route'
  );

  resetReminderCronCursorForTests();

  // 1. Verificar que los estados de pago fallido están excluidos de los estados permitidos en "prueba sin convertir"
  for (const badStatus of PAYMENT_FAILED_STATUSES) {
    assert.equal(
      (ABANDONED_TRIAL_ALLOWED_STATUSES as readonly string[]).includes(badStatus),
      false,
      `El estado ${badStatus} nunca debe incluirse en la consulta de prueba sin convertir`,
    );
  }

  const nowMs = new Date('2026-09-30T10:00:00Z').getTime();
  const period = getReminderPeriodKey(nowMs);
  const sixDaysAgoIso = new Date(nowMs - 6.5 * 86_400_000).toISOString();
  const expiredTrialIso = new Date(nowMs - 12 * 3_600_000).toISOString();
  const expiringSoonIso = new Date(nowMs + 24 * 3_600_000).toISOString();

  // 2. Empresa con pago fallido (past_due) y prueba caducada / día 6:
  //    - En la consulta de "prueba sin convertir" se excluye past_due/unpaid/incomplete.
  //    - Al evaluar prioridad unificada, recibe UN ÚNICO correo: el de 'payment_failed' (jamás 'abandoned_trial_day6' ni 'trial_expiring').
  const tenantPastDueAndExpired = {
    id: 'tenant-past-due-001',
    name: 'Restaurante Impago S.L.',
    owner_email: 'dueno@impago.es',
    plan: 'local_pro',
    subscription_status: 'past_due',
    created_at: sixDaysAgoIso,
    trial_ends_at: expiredTrialIso,
    locale: 'es',
    settings: {},
  };

  const chosenKind = resolveSingleReminderForTenant(tenantPastDueAndExpired, nowMs, period);
  assert.equal(chosenKind, 'payment_failed', 'Con pago fallido y prueba caducada debe priorizar únicamente payment_failed');

  // Simular ejecución contra el procesador de recordatorios con prioridad de pago fallido activa
  const deliveredEmails: Array<{ tenantId: string; kind: string; to: string }> = [];
  let queriedAllowedStatuses: readonly string[] = [];

  const mockAdmin = {
    from: (table: string) => ({
      select: () => ({
        in: (_col: string, vals: readonly string[]) => {
          queriedAllowedStatuses = vals;
          return Promise.resolve({ data: [tenantPastDueAndExpired] });
        },
      }),
      update: (payload: Record<string, unknown>) => ({
        eq: async () => {
          if (table === 'tenants' && payload.settings) {
            tenantPastDueAndExpired.settings = payload.settings as Record<string, unknown>;
          }
          return { data: null, error: null };
        },
      }),
    }),
  };

  // A) En modo "prueba sin convertir" estricto (por defecto en cron abandoned-trial), la consulta excluye past_due/unpaid/incomplete
  const resAbandonedOnly = await executePaginatedReminders({
    admin: mockAdmin,
    nowMs,
    includePaymentFailedPriority: false,
    sendEmailFn: async (msg) => {
      deliveredEmails.push({ tenantId: msg.tenantId, kind: msg.kind, to: msg.to });
    },
  });
  assert.deepEqual(queriedAllowedStatuses, ['trialing', 'none']);
  assert.equal(resAbandonedOnly.emailsSent, 0, 'La tarea de prueba sin convertir no debe enviar correo a empresas en past_due');

  // B) Al evaluar todos los recordatorios con prioridad (pago fallido > prueba a punto de caducar > prueba sin convertir),
  //    la empresa con pago fallido y prueba caducada recibe UN ÚNICO correo: el de pago fallido.
  const resPriority = await executePaginatedReminders({
    admin: mockAdmin,
    nowMs,
    includePaymentFailedPriority: true,
    sendEmailFn: async (msg) => {
      deliveredEmails.push({ tenantId: msg.tenantId, kind: msg.kind, to: msg.to });
    },
  });
  assert.equal(resPriority.emailsSent, 1);
  assert.equal(deliveredEmails.length, 1);
  assert.equal(deliveredEmails[0].kind, 'payment_failed');
  assert.equal(resPriority.sendLog.length, 1);
  assert.equal(resPriority.sendLog[0].tenantId, 'tenant-past-due-001');
  assert.equal(resPriority.sendLog[0].kind, 'payment_failed');
  assert.equal(resPriority.sendLog[0].period, period);

  // C) Si se vuelve a ejecutar en el mismo periodo, no repite el correo ni cae en prueba sin convertir
  const resRepeat = await executePaginatedReminders({
    admin: mockAdmin,
    nowMs,
    includePaymentFailedPriority: true,
    sendEmailFn: async (msg) => {
      deliveredEmails.push({ tenantId: msg.tenantId, kind: msg.kind, to: msg.to });
    },
  });
  assert.equal(resRepeat.emailsSent, 0);
  assert.equal(deliveredEmails.length, 1, 'No debe repetir el correo en el mismo periodo');

  // D) Verificar prioridad trial_expiring > abandoned_trial_day6 en empresa trialing
  const tenantExpiringAndDay6 = {
    id: 'tenant-expiring-002',
    name: 'Clínica Dental Centro',
    owner_email: 'info@clinicacentro.es',
    plan: 'local_starter',
    subscription_status: 'trialing',
    created_at: sixDaysAgoIso,
    trial_ends_at: expiringSoonIso,
    settings: {},
  };
  assert.equal(resolveSingleReminderForTenant(tenantExpiringAndDay6, nowMs, period), 'trial_expiring');
  const updatedAfterExpiring = recordReminderSend(tenantExpiringAndDay6.settings, {
    tenantId: tenantExpiringAndDay6.id,
    kind: 'trial_expiring',
    sentAt: new Date(nowMs).toISOString(),
    period,
  });
  assert.equal(hasReminderBeenSentInPeriod(updatedAfterExpiring, 'trial_expiring', period), true);
});

test('7.2 [Punto 2] Límite de 200 empresas por ejecución: 450 empresas simuladas paginadas por id reciben su recordatorio exactamente una vez (con cursor e idempotencia)', async () => {
  const { executePaginatedReminders, resetReminderCronCursorForTests } = await import(
    '../app/api/cron/abandoned-trial/route'
  );

  resetReminderCronCursorForTests();

  const nowMs = new Date('2026-09-30T12:00:00Z').getTime();
  const day3CreatedAt = new Date(nowMs - 3.5 * 86_400_000).toISOString();

  // Crear 450 empresas simuladas desordenadas para verificar que se ordenan por id y se procesan en lotes de 200
  const simulatedTenants = Array.from({ length: 450 }, (_, idx) => {
    const num = String(idx + 1).padStart(4, '0');
    return {
      id: `tenant-${num}`,
      name: `Empresa Simulada ${num}`,
      owner_email: `contacto${num}@simulada.es`,
      plan: 'local_starter',
      subscription_status: 'trialing',
      created_at: day3CreatedAt,
      locale: 'es',
      settings: {} as Record<string, unknown>,
    };
  }).reverse();

  const sentByTenant = new Map<string, number>();

  const createPaginatedMockAdmin = () => ({
    from: (table: string) => ({
      select: () => ({
        in: () => Promise.resolve({ data: simulatedTenants }),
      }),
      update: (payload: Record<string, unknown>) => ({
        eq: async (_col: string, idVal: string) => {
          if (table === 'tenants' && payload.settings) {
            const found = simulatedTenants.find((t) => t.id === idVal);
            if (found) found.settings = payload.settings as Record<string, unknown>;
          }
          return { data: null, error: null };
        },
      }),
    }),
  });

  // 1. Prueba de corte por tiempo máximo: si se acerca al límite tras el primer lote de 200, guarda cursor y termina limpiamente
  let simulatedClock = 1000;
  const partialRun = await executePaginatedReminders({
    admin: createPaginatedMockAdmin(),
    batchSize: 200,
    maxDurationMs: 50,
    nowMs,
    nowFn: () => {
      const current = simulatedClock;
      // Al llegar a 200 empresas revisadas (1 lote completo), el reloj supera maxDurationMs
      if (sentByTenant.size >= 200) simulatedClock = 1100;
      return current;
    },
    sendEmailFn: async (msg) => {
      sentByTenant.set(msg.tenantId, (sentByTenant.get(msg.tenantId) ?? 0) + 1);
    },
  });

  assert.equal(partialRun.reviewedCount, 200);
  assert.equal(partialRun.emailsSent, 200);
  assert.equal(partialRun.hasMore, true, 'Debe indicar que quedan empresas pendientes');
  assert.equal(partialRun.quedanPendientes, true);
  assert.equal(partialRun.nextCursor, 'tenant-0200', 'Debe guardar el cursor en la empresa 200');

  // 2. Continuar en la siguiente ejecución desde el cursor guardado hasta completar las 250 restantes (total 450)
  const completionRun = await executePaginatedReminders({
    admin: createPaginatedMockAdmin(),
    batchSize: 200,
    maxDurationMs: 25_000,
    nowMs,
    sendEmailFn: async (msg) => {
      sentByTenant.set(msg.tenantId, (sentByTenant.get(msg.tenantId) ?? 0) + 1);
    },
  });

  assert.equal(completionRun.reviewedCount, 250);
  assert.equal(completionRun.emailsSent, 250);
  assert.equal(completionRun.hasMore, false, 'Tras procesar las 450 empresas no deben quedar pendientes');
  assert.equal(completionRun.quedanPendientes, false);
  assert.equal(completionRun.nextCursor, null);

  // Verificar que las 450 empresas recibieron su recordatorio EXACTAMENTE una vez
  assert.equal(sentByTenant.size, 450, 'Las 450 empresas deben haber recibido correo');
  for (let i = 1; i <= 450; i += 1) {
    const id = `tenant-${String(i).padStart(4, '0')}`;
    assert.equal(sentByTenant.get(id), 1, `La empresa ${id} debe recibir exactamente 1 correo`);
  }

  // 3. Ejecución repetida: idempotencia total (revisa las 450 en 3 lotes de 200+200+50 pero envía 0 correos duplicados)
  const duplicateCheckRun = await executePaginatedReminders({
    admin: createPaginatedMockAdmin(),
    batchSize: 200,
    maxDurationMs: 25_000,
    nowMs,
    sendEmailFn: async (msg) => {
      sentByTenant.set(msg.tenantId, (sentByTenant.get(msg.tenantId) ?? 0) + 1);
    },
  });

  assert.equal(duplicateCheckRun.reviewedCount, 450);
  assert.equal(duplicateCheckRun.batchesProcessed, 3);
  assert.equal(duplicateCheckRun.emailsSent, 0, 'Una ejecución repetida no debe duplicar ningún correo');
  assert.equal(duplicateCheckRun.hasMore, false);
});

test('7.3 [Punto 3] Clave de la página de estado (/api/health): timingSafeEqual, comprobación de longitud y 4 casos (correcta, incorrecta, vacía y sin configurar)', async () => {
  const { GET: getApiHealth } = await import('../app/api/health/route');

  const prevHealthKey = process.env.HEALTH_KEY;
  const prevHealthcheckSecret = process.env.HEALTHCHECK_SECRET;

  try {
    // Caso 1: Clave SIN CONFIGURAR en el entorno -> versión detallada desactivada (nunca abierta)
    delete process.env.HEALTH_KEY;
    delete process.env.HEALTHCHECK_SECRET;

    const unconfiguredAttempt = await getApiHealth(
      new Request('http://localhost:3000/api/health?mode=ready', {
        headers: { Authorization: 'Bearer cualquier_clave' },
      }),
    );
    assert.equal(unconfiguredAttempt.status, 401, 'Si la clave no está configurada, la vista detallada debe estar desactivada');
    const unconfBody = (await unconfiguredAttempt.json()) as Record<string, unknown>;
    assert.equal(unconfBody.ok, false);
    assert.equal('checks' in unconfBody, false);
    assert.equal('version' in unconfBody, false);

    // Petición pública sin clave -> responde 200 sin versiones, sin nombres de servicios internos ni errores
    const publicRes = await getApiHealth(new Request('http://localhost:3000/api/health'));
    assert.equal(publicRes.status, 200);
    const publicBody = (await publicRes.json()) as Record<string, unknown>;
    assert.equal(publicBody.ok, true);
    assert.equal('version' in publicBody, false, 'La versión pública no debe mostrar version');
    assert.equal('release' in publicBody, false, 'La versión pública no debe mostrar release');
    assert.equal('service' in publicBody, false, 'La versión pública no debe mostrar nombre de servicio interno');
    assert.equal('checks' in publicBody, false, 'La versión pública no debe exponer checks internos');
    assert.equal('error' in publicBody, false, 'La versión pública no debe mostrar mensajes de error');

    // Configurar clave en el entorno para probar vacía, incorrecta y correcta
    process.env.HEALTH_KEY = 'health_secret_key_test_32_chars_ok';

    // Caso 2: Clave VACÍA -> 401
    const emptyKeyRes = await getApiHealth(
      new Request('http://localhost:3000/api/health', {
        headers: { 'x-health-key': '' },
      }),
    );
    assert.equal(emptyKeyRes.status, 401, 'Clave vacía debe ser rechazada con 401');

    const emptyBearerRes = await getApiHealth(
      new Request('http://localhost:3000/api/health?mode=ready', {
        headers: { Authorization: 'Bearer   ' },
      }),
    );
    assert.equal(emptyBearerRes.status, 401, 'Bearer vacío en mode=ready debe ser rechazado con 401');

    // Caso 3: Clave INCORRECTA (distinta longitud y misma longitud) -> 401
    const wrongShortRes = await getApiHealth(
      new Request('http://localhost:3000/api/health', {
        headers: { 'x-health-key': 'corta' },
      }),
    );
    assert.equal(wrongShortRes.status, 401, 'Clave de distinta longitud debe ser rechazada con 401');

    const wrongSameLenRes = await getApiHealth(
      new Request('http://localhost:3000/api/health', {
        headers: { Authorization: 'Bearer health_secret_key_test_32_chars_NO' },
      }),
    );
    assert.equal(wrongSameLenRes.status, 401, 'Clave incorrecta de igual longitud debe ser rechazada con 401');

    // Caso 4: Clave CORRECTA -> acceso autorizado a la versión detallada
    const validKeyRes = await getApiHealth(
      new Request('http://localhost:3000/api/health', {
        headers: { Authorization: 'Bearer health_secret_key_test_32_chars_ok' },
      }),
    );
    assert.equal(validKeyRes.status, 200);
    const validBody = (await validKeyRes.json()) as {
      ok: boolean;
      version: string;
      checks: Record<string, unknown>;
    };
    assert.equal(validBody.ok, true);
    assert.equal(validBody.version, '1.0');
    assert.ok(validBody.checks && typeof validBody.checks === 'object');
    assert.ok('database' in validBody.checks);
    assert.ok('payment_gateway' in validBody.checks);
    assert.ok('ai_service' in validBody.checks);
  } finally {
    if (prevHealthKey === undefined) delete process.env.HEALTH_KEY;
    else process.env.HEALTH_KEY = prevHealthKey;
    if (prevHealthcheckSecret === undefined) delete process.env.HEALTHCHECK_SECRET;
    else process.env.HEALTHCHECK_SECRET = prevHealthcheckSecret;
  }
});

test('7.4 [Puntos 4 y 5] Flujo CI de GitHub Actions, .env.example documentado, aviso de arranque sin filtrar valores y guía 3 con seguridad y entornos', async () => {
  const { checkMissingEnvOnStartup } = await import('../lib/env-validation');

  // 1. Verificar flujo de GitHub Actions (.github/workflows/ci.yml)
  const ciYaml = fs.readFileSync(path.join(root, '.github/workflows/ci.yml'), 'utf8');
  assert.ok(ciYaml.includes('pull_request:'), 'CI debe ejecutarse en cada pull_request');
  assert.ok(ciYaml.includes('npm run typecheck'), 'CI debe ejecutar typecheck');
  assert.ok(ciYaml.includes('npm run lint'), 'CI debe ejecutar lint');
  assert.ok(ciYaml.includes('npm test'), 'CI debe ejecutar las pruebas');
  assert.ok(ciYaml.includes('npm audit'), 'CI debe ejecutar npm audit');
  assert.equal(ciYaml.includes('continue-on-error: true'), false, 'CI debe fallar si cualquier paso falla');

  // 2. Verificar .env.example con comentarios y las variables requeridas
  const envExample = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
  for (const requiredVar of [
    'GEMINI_API_KEY=',
    'STRIPE_SECRET_KEY=',
    'STRIPE_WEBHOOK_SECRET=',
    'RESEND_API_KEY=',
    'SENTRY_DSN=',
    'CRON_SECRET=',
    'HEALTH_KEY=',
  ]) {
    assert.ok(envExample.includes(requiredVar), `Falta ${requiredVar} en .env.example`);
  }
  assert.ok(envExample.includes('Para qué sirve:'));
  assert.ok(envExample.includes('Dónde se obtiene:'));

  // 3. Comprobación al arrancar: avisa de qué variables faltan sin mostrar NUNCA sus valores
  const secretValue = 'sk_live_SUPER_SECRET_NEVER_PRINT_ME_999';
  const logs: string[] = [];
  const check = checkMissingEnvOnStartup(
    {
      STRIPE_SECRET_KEY: secretValue,
      GEMINI_API_KEY: '',
    } as unknown as NodeJS.ProcessEnv,
    (msg) => logs.push(msg),
  );
  assert.ok(check.missing.includes('GEMINI_API_KEY'));
  assert.ok(check.missing.includes('CRON_SECRET'));
  assert.ok(check.missing.includes('HEALTH_KEY'));
  assert.equal(check.missing.includes('STRIPE_SECRET_KEY'), false);
  assert.equal(logs.length, 1);
  assert.equal(logs[0].includes(secretValue), false, 'El aviso de arranque NUNCA debe mostrar el valor de ningún secreto');

  // 4. La guía 3 concentra seguridad y entornos, sin índices redundantes.
  const guide = fs.readFileSync(path.join(root, 'GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md'), 'utf8');
  assert.equal(guide.includes('TU_USUARIO'), false);
  assert.ok(guide.includes('Local (`.env`)'));
  assert.ok(guide.includes('Vercel'));
  assert.ok(guide.includes('Secretos de GitHub'));
  assert.ok(guide.includes('Qué no debes compartir'));

});

test('7.5 Aislamiento multiempresa (RLS y rutas API): una empresa nunca puede leer ni modificar datos de otra', async () => {
  const { requireRole, requireOwner } = await import('../lib/authz');

  // 1. Verificar políticas RLS en el esquema SQL para todas las tablas multi-tenant
  const schemaSql = fs.readFileSync(path.join(root, 'supabase/schema.sql'), 'utf8');
  for (const table of [
    'tenants',
    'memberships',
    'integrations',
    'reviews',
    'usage_counters',
    'feedback_responses',
    'addons',
    'ai_interactions',
  ]) {
    assert.ok(
      schemaSql.includes(`alter table public.${table} enable row level security`),
      `La tabla ${table} debe tener RLS activado`,
    );
  }
  assert.ok(schemaSql.includes('public.is_member(tenant_id)'), 'RLS debe filtrar lecturas por pertenencia al tenant');
  assert.ok(schemaSql.includes('public.is_owner('), 'RLS debe restringir mutaciones críticas al propietario/rol autorizado');
  assert.ok(
    schemaSql.includes('on public.integrations') && schemaSql.includes('using (false)'),
    'La tabla integrations debe bloquear acceso directo desde cliente',
  );

  // 2. Simular dos empresas (tenant-A y tenant-B) y verificar que el usuario de tenant-A recibe 403 al intentar leer o modificar tenant-B
  const memberships: Record<string, { tenantId: string; role: 'owner' | 'admin' | 'agent' | 'viewer' }> = {
    'user-empresa-a': { tenantId: '11111111-1111-4111-8111-111111111111', role: 'owner' },
    'user-empresa-b': { tenantId: '22222222-2222-4222-8222-222222222222', role: 'owner' },
  };

  const createCrossTenantAdminMock = () => ({
    from: (table: string) => ({
      select: () => ({
        eq: (_col1: string, val1: string) => ({
          eq: (_col2: string, val2: string) => ({
            maybeSingle: async () => {
              if (table === 'memberships') {
                const m = memberships[val2];
                if (m && m.tenantId === val1) {
                  return { data: { id: `m-${val2}`, role: m.role }, error: null };
                }
                return { data: null, error: null };
              }
              return { data: null, error: null };
            },
          }),
          maybeSingle: async () => {
            if (table === 'tenants') {
              const isOwnerA = val1 === memberships['user-empresa-a'].tenantId;
              const isOwnerB = val1 === memberships['user-empresa-b'].tenantId;
              if (isOwnerA) return { data: { id: val1, owner_id: 'user-empresa-a' }, error: null };
              if (isOwnerB) return { data: { id: val1, owner_id: 'user-empresa-b' }, error: null };
            }
            return { data: null, error: null };
          },
        }),
      }),
    }),
  });

  const adminMock = createCrossTenantAdminMock() as unknown as Parameters<typeof requireRole>[0];

  // Usuario A accede a su propia empresa A -> autorizado (ok: true)
  const ownAccess = await requireRole(
    adminMock,
    '11111111-1111-4111-8111-111111111111',
    'viewer',
    { injectedUser: { id: 'user-empresa-a' } },
  );
  assert.equal(ownAccess.ok, true, 'El propietario de la empresa A debe poder leer sus propios datos');

  // Usuario A intenta leer reseñas de la empresa B -> denegado con 403
  const crossReadReviews = await requireRole(
    adminMock,
    '22222222-2222-4222-8222-222222222222',
    'viewer',
    { injectedUser: { id: 'user-empresa-a' } },
  );
  assert.equal(crossReadReviews.ok, false, 'Empresa A nunca debe poder leer reseñas de Empresa B');
  if (!crossReadReviews.ok) {
    assert.equal(crossReadReviews.status, 403);
  }

  // Usuario A intenta modificar ajustes, responder reseñas o administrar facturación de la empresa B -> denegado con 403
  for (const minRole of ['agent', 'admin', 'owner'] as const) {
    const crossWrite = await requireRole(
      adminMock,
      '22222222-2222-4222-8222-222222222222',
      minRole,
      { injectedUser: { id: 'user-empresa-a' } },
    );
    assert.equal(crossWrite.ok, false, `Empresa A nunca debe poder ejecutar acciones de rol ${minRole} sobre Empresa B`);
    if (!crossWrite.ok) {
      assert.equal(crossWrite.status, 403);
    }
  }
  assert.equal(typeof requireOwner, 'function');
});

test('7.6 Límite de peticiones persistente (tabla/RPC) y aviso claro en logs si no está configurado en producción', async () => {
  const {
    consumeRateLimit,
    isPersistentRateLimitConfigured,
    warnIfPersistentRateLimitUnconfigured,
  } = await import('../lib/rate-limit');

  const prevNodeEnv = process.env.NODE_ENV;
  const prevSupaUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const prevSupaKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const prevPepper = process.env.PRIVACY_HASH_PEPPER;

  try {
    delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    delete process.env.SUPABASE_SERVICE_ROLE_KEY;
    process.env.PRIVACY_HASH_PEPPER = 'test_pepper_for_production_rate_limit_check_32';
    (process.env as Record<string, string | undefined>).NODE_ENV = 'production';

    assert.equal(isPersistentRateLimitConfigured(), false);

    const warnLogs: string[] = [];
    const startupWarn = warnIfPersistentRateLimitUnconfigured(process.env, (msg) => warnLogs.push(msg));
    assert.equal(startupWarn.configured, false);
    assert.equal(warnLogs.length, 1);
    assert.ok(warnLogs[0].includes('[RateLimit] Aviso en producción'));

    // Además, al consumir rate limit sin backend en producción, avisa claramente y aplica fail-closed
    const runtimeWarnings: string[] = [];
    const prodRes = await consumeRateLimit('api:test', '198.51.100.10', 5, 60, {
      admin: null,
      warnFn: (msg) => runtimeWarnings.push(msg),
    });
    assert.equal(prodRes.allowed, false, 'En producción sin persistencia debe bloquear fail-closed');
    assert.equal(runtimeWarnings.length, 1, 'Debe registrar aviso claro cuando no está configurado en producción');
    assert.ok(runtimeWarnings[0].includes('no configurado'));

    // Y cuando existe tabla persistente (api_rate_limits), persiste el contador y bloquea al superar el límite
    const tableStore = new Map<string, { key_hash: string; count: number; reset_at: string }>();
    const tableAdminMock = {
      from: (table: string) => ({
        select: () => ({
          eq: (col: string, keyVal: string) => ({
            maybeSingle: async () => {
              assert.equal(col, 'key_hash', 'La columna real de api_rate_limits es key_hash');
              return {
                data: table === 'api_rate_limits' ? (tableStore.get(keyVal) ?? null) : null,
                error: null,
              };
            },
          }),
        }),
        upsert: async (row: { key_hash: string; count: number; reset_at: string }) => {
          tableStore.set(row.key_hash, row);
          return { data: row, error: null };
        },
        update: (patch: { count: number }) => ({
          eq: async (_col: string, keyVal: string) => {
            const existing = tableStore.get(keyVal);
            if (existing) tableStore.set(keyVal, { ...existing, count: patch.count });
            return { data: null, error: null };
          },
        }),
      }),
    } as unknown as Parameters<typeof consumeRateLimit>[4] extends { admin?: infer A } ? A : never;

    const r1 = await consumeRateLimit('api:persistent', '203.0.113.55', 2, 60, { admin: tableAdminMock });
    const r2 = await consumeRateLimit('api:persistent', '203.0.113.55', 2, 60, { admin: tableAdminMock });
    const r3 = await consumeRateLimit('api:persistent', '203.0.113.55', 2, 60, { admin: tableAdminMock });
    assert.equal(r1.allowed, true);
    assert.equal(r2.allowed, true);
    assert.equal(r3.allowed, false, 'La tercera petición debe bloquearse usando la tabla persistente api_rate_limits');
  } finally {
    (process.env as Record<string, string | undefined>).NODE_ENV = prevNodeEnv;
    if (prevSupaUrl === undefined) delete process.env.NEXT_PUBLIC_SUPABASE_URL;
    else process.env.NEXT_PUBLIC_SUPABASE_URL = prevSupaUrl;
    if (prevSupaKey === undefined) delete process.env.SUPABASE_SERVICE_ROLE_KEY;
    else process.env.SUPABASE_SERVICE_ROLE_KEY = prevSupaKey;
    if (prevPepper === undefined) delete process.env.PRIVACY_HASH_PEPPER;
    else process.env.PRIVACY_HASH_PEPPER = prevPepper;
  }
});

test('7.7 Health check y cron con timingSafeEqual, versión única de Node, 0 usos de any y paneles modulares', async () => {
  const { GET: syncReviewsGet } = await import('../app/api/cron/sync-reviews/route');
  const { GET: weeklyDigestGet } = await import('../app/api/cron/weekly-digest/route');
  const { GET: abandonedTrialGet } = await import('../app/api/cron/abandoned-trial/route');

  const prevCronSecret = process.env.CRON_SECRET;
  try {
    // Sin CRON_SECRET configurado -> todas las rutas cron rechazan el acceso (401 o 503)
    delete process.env.CRON_SECRET;
    for (const handler of [syncReviewsGet, weeklyDigestGet, abandonedTrialGet]) {
      const r = await handler(new Request('http://localhost:3000/api/cron/test', {
        headers: { Authorization: 'Bearer cualquier_valor' },
      }));
      assert.ok(
        r.status === 401 || r.status === 503,
        `Ruta cron debe rechazar con 401 o 503 si CRON_SECRET no está configurado (recibido ${r.status})`,
      );
    }

    // Con CRON_SECRET configurado pero clave incorrecta -> 401
    process.env.CRON_SECRET = 'cron_secret_test_value_32_chars_ok';
    for (const handler of [syncReviewsGet, weeklyDigestGet, abandonedTrialGet]) {
      const r = await handler(new Request('http://localhost:3000/api/cron/test', {
        headers: { Authorization: 'Bearer cron_secret_test_value_32_chars_NO' },
      }));
      assert.equal(r.status, 401, 'Ruta cron debe rechazar con 401 si la clave no coincide en timingSafeEqual');
    }
  } finally {
    if (prevCronSecret === undefined) delete process.env.CRON_SECRET;
    else process.env.CRON_SECRET = prevCronSecret;
  }

  // Verificar una sola versión de Node en .nvmrc, package.json engines y .github/workflows/ci.yml
  const nvmrc = fs.readFileSync(path.join(root, '.nvmrc'), 'utf8').trim();
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')) as {
    engines?: { node?: string };
  };
  const ciYaml = fs.readFileSync(path.join(root, '.github/workflows/ci.yml'), 'utf8');
  assert.equal(nvmrc, '22');
  assert.ok(pkg.engines?.node?.startsWith('22'), 'package.json engines.node debe usar Node 22');
  assert.ok(ciYaml.includes("node-version-file: '.nvmrc'"), 'CI debe usar .nvmrc para la versión de Node');
  assert.equal(ciYaml.toLowerCase().includes('vitest'), false, 'El nombre erróneo vitest debe estar corregido en GitHub Actions');
  assert.ok(ciYaml.includes('npm test'), 'CI debe ejecutar npm test');

  // Verificar 0 usos de `any` como tipo en app/, components/ y lib/
  function walkCode(dir: string, acc: string[] = []): string[] {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (['node_modules', '.next', '.git', 'tests'].includes(entry.name)) continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walkCode(full, acc);
      else if (/\.(ts|tsx)$/.test(entry.name)) acc.push(full);
    }
    return acc;
  }
  const codeFiles = [
    ...walkCode(path.join(root, 'app')),
    ...walkCode(path.join(root, 'components')),
    ...walkCode(path.join(root, 'lib')),
  ];
  const anyMatches: string[] = [];
  for (const file of codeFiles) {
    const content = fs.readFileSync(file, 'utf8');
    const lines = content.split('\n');
    lines.forEach((line, idx) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('//') || trimmed.startsWith('*')) return;
      if (/:\s*any\b|\bas\s+any\b|<\s*any\s*[,>]/.test(line)) {
        anyMatches.push(`${path.relative(root, file)}:${idx + 1}`);
      }
    });
  }
  assert.deepEqual(anyMatches, [], `No debe quedar ningún uso de any en el código fuente: ${anyMatches.join(', ')}`);

  // Verificar que todos los paneles de dashboard y admin tienen <= 300 líneas
  const dashboardAndAdminFiles = [
    ...walkCode(path.join(root, 'components/dashboard')),
    ...walkCode(path.join(root, 'components/admin')),
    path.join(root, 'app/dashboard/dashboard-client.tsx'),
    path.join(root, 'app/admin/admin-client.tsx'),
  ];
  for (const file of dashboardAndAdminFiles) {
    const lineCount = fs.readFileSync(file, 'utf8').split('\n').length;
    assert.ok(
      lineCount <= 300,
      `El archivo ${path.relative(root, file)} tiene ${lineCount} líneas (máximo permitido: 300)`,
    );
  }
});
