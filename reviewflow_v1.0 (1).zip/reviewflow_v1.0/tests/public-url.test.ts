/**
 * Regresiones de host: la URL pública debe salir SIEMPRE de lib/public-url.ts
 * y funcionar igual en localhost, proxy inverso, dominio propio, Vercel y Docker.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  resolvePublicUrl,
  resolvePublicUrlFromEnv,
  publicUrl,
  googleOAuthRedirectUri,
  normalizeOrigin,
} from '../lib/public-url';

const req = (headers: Record<string, string>, url = 'http://localhost:3000/x') => new Request(url, { headers });

test('dominio propio: NEXT_PUBLIC_APP_URL gana y se normaliza', () => {
  const env = { NEXT_PUBLIC_APP_URL: ' "https://Midominio.es/" ' };
  assert.equal(resolvePublicUrlFromEnv(env), 'https://midominio.es');
  assert.equal(publicUrl('/valorar/bar-pepe', undefined, env), 'https://midominio.es/valorar/bar-pepe');
  assert.equal(googleOAuthRedirectUri(env), 'https://midominio.es/api/integrations/google/callback');
});

test('Docker: PUBLIC_APP_URL en runtime tiene prioridad sobre el valor horneado en build', () => {
  assert.equal(
    resolvePublicUrlFromEnv({ PUBLIC_APP_URL: 'https://nuevo.es', NEXT_PUBLIC_APP_URL: 'https://viejo.es' }),
    'https://nuevo.es',
  );
});

test('NEXT_PUBLIC_DOMAIN sin protocolo produce https', () => {
  assert.equal(resolvePublicUrlFromEnv({ NEXT_PUBLIC_DOMAIN: 'midominio.es' }), 'https://midominio.es');
});

test('Vercel: si la URL sigue en localhost se usa el dominio de Vercel', () => {
  assert.equal(
    resolvePublicUrlFromEnv({ NEXT_PUBLIC_APP_URL: 'http://localhost:3000', VERCEL_URL: 'rf-abc.vercel.app' }),
    'https://rf-abc.vercel.app',
  );
  assert.equal(
    resolvePublicUrlFromEnv({ VERCEL_URL: 'rf-abc.vercel.app', VERCEL_PROJECT_PRODUCTION_URL: 'rf.vercel.app' }),
    'https://rf.vercel.app',
  );
});

test('otras plataformas (Render, Railway, Fly) se detectan', () => {
  assert.equal(resolvePublicUrlFromEnv({ RENDER_EXTERNAL_URL: 'https://rf.onrender.com' }), 'https://rf.onrender.com');
  assert.equal(resolvePublicUrlFromEnv({ RAILWAY_PUBLIC_DOMAIN: 'rf.up.railway.app' }), 'https://rf.up.railway.app');
  assert.equal(resolvePublicUrlFromEnv({ FLY_APP_NAME: 'rf' }), 'https://rf.fly.dev');
});

test('proxy inverso sin URL configurada: usa x-forwarded-host / Forwarded', () => {
  assert.equal(resolvePublicUrl(req({ 'x-forwarded-host': 'panel.midominio.com', 'x-forwarded-proto': 'https' }), {}), 'https://panel.midominio.com');
  assert.equal(resolvePublicUrl(req({ forwarded: 'for=1.2.3.4;host=rf.ejemplo.es;proto=https' }), {}), 'https://rf.ejemplo.es');
  assert.equal(resolvePublicUrl(req({ host: 'rf.ejemplo.es' }), {}), 'https://rf.ejemplo.es');
});

test('seguridad: con URL configurada se IGNORA la cabecera Host (anti host-header injection)', () => {
  const env = { NEXT_PUBLIC_APP_URL: 'https://midominio.es' };
  assert.equal(resolvePublicUrl(req({ 'x-forwarded-host': 'evil.example', host: 'evil.example' }), env), 'https://midominio.es');
});

test('seguridad: ALLOWED_HOSTS filtra hosts no autorizados', () => {
  const env = { ALLOWED_HOSTS: 'midominio.es,*.vercel.app' };
  assert.equal(resolvePublicUrl(req({ 'x-forwarded-host': 'evil.example' }), env), 'http://localhost:3000');
  assert.equal(resolvePublicUrl(req({ 'x-forwarded-host': 'rf-1.vercel.app' }), env), 'https://rf-1.vercel.app');
  assert.equal(resolvePublicUrl(req({ 'x-forwarded-host': 'evil.com/<x>' }), {}), 'http://localhost:3000');
});

test('placeholders y valores vacíos nunca se publican', () => {
  assert.equal(normalizeOrigin('https://[tudominio.com]'), '');
  assert.equal(normalizeOrigin('https://invalid.example'), '');
  assert.equal(resolvePublicUrlFromEnv({}), 'http://localhost:3000');
});

/* ---------- Guardia estática: nadie fuera de lib/public-url.ts resuelve el host ---------- */
const root = path.resolve(__dirname, '..');
function walk(dir: string, out: string[] = []): string[] {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', '.next', 'tests', '.git'].includes(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (/\.(ts|tsx|mjs|js)$/.test(e.name)) out.push(p);
  }
  return out;
}

test('ningún archivo de la app lee NEXT_PUBLIC_APP_URL, VERCEL_URL ni x-forwarded-host directamente', () => {
  const allowed = new Set(['lib/public-url.ts', 'lib/env-validation.ts', 'lib/site.ts', 'scripts/verify-launch.mjs', 'scripts/configurar.mjs', 'next.config.js']);
  const forbidden = [/process\.env\.(NEXT_PUBLIC_APP_URL|APP_URL|PUBLIC_APP_URL|VERCEL_URL|VERCEL_PROJECT_PRODUCTION_URL)\b/, /['"]x-forwarded-host['"]/, /\bwindow\.location\.origin\b/, /['"]https?:\/\/localhost:3000/];
  const offenders: string[] = [];
  for (const file of walk(root)) {
    const rel = path.relative(root, file).split(path.sep).join('/');
    if (allowed.has(rel)) continue;
    const src = fs.readFileSync(file, 'utf8');
    for (const re of forbidden) if (re.test(src)) offenders.push(`${rel} → ${re}`);
  }
  assert.deepEqual(offenders, [], `Usa lib/public-url.ts en lugar de resolver el host a mano:\n${offenders.join('\n')}`);
});
