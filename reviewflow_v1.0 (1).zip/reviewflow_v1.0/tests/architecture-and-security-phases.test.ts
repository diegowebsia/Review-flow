/**
 * ============================================================
 * Pruebas de arquitectura y seguridad — ReviewFlow AI v1.0
 * ============================================================
 */

import { describe, it, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

import { apiError, describeUnknownError, errorMessage } from '../lib/api-error';
import {
  listProviders,
  getProviderAdapter,
  normalizeProviderReview,
  connectProvider,
  PROVIDERS_REGISTRY,
} from '../lib/providers';
import { timingSafeStringEqual, verifyCronSecret, safeInternalRedirect, escapeHtml, requestIp } from '../lib/security';
import { maskEmailForLog, maskPhoneForLog, redactSecretsInText, sanitizeLogMeta } from '../lib/logger';
import {
  captureException,
  getServiceFailureState,
  recordServiceOutcome,
  resetServiceFailures,
} from '../lib/observability';
import { consumeRateLimit, rateLimitByIp, rateLimitByTenant } from '../lib/rate-limit';
import {
  ADDON_CATALOG,
  annualPriceCentsOf,
  annualMonthlyEquivalentCents,
  currentCycle,
  estimateCostUsd,
  estimateStorageMb,
  hasAccess,
  isTrialExpired,
  nextCycleStart,
  PLAN_CATALOG,
  planHasFeature,
  planOf,
  resolveAddonPack,
  resolvePlan,
} from '../lib/plans';
import { generateReviewReply, inspectComplaint } from '../lib/ai';
import { hasRoleLevel, normalizeRole } from '../lib/authz';
import { verifyShopifyHmac, verifyWooHmac, orderDeliveredEmailHtml } from '../lib/store';
import { addonPriceIdFor, planFromPriceId, priceIdFor } from '../lib/stripe';
import { computeBusinessMetrics, invalidateBusinessMetricsCache } from '../lib/business-metrics';
import { PRODUCT_FLOW_SCENARIOS } from './fixtures/product-flow-scenarios';

const ROOT = process.cwd();

describe('Fase 1 — Arquitectura, Tipado Estricto, Helper de Errores y Capa de Proveedores', () => {
  it('divide admin-client.tsx y dashboard-client.tsx en componentes modulares y hooks propios', () => {
    const adminClient = readFileSync(join(ROOT, 'app/admin/admin-client.tsx'), 'utf8');
    const dashboardClient = readFileSync(join(ROOT, 'app/dashboard/dashboard-client.tsx'), 'utf8');

    assert.ok(adminClient.split('\n').length < 420);
    assert.ok(dashboardClient.split('\n').length < 500);

    assert.equal(existsSync(join(ROOT, 'components/admin/use-admin-dashboard.ts')), true);
    assert.equal(existsSync(join(ROOT, 'components/admin/AdminMetricsSection.tsx')), true);
    assert.equal(existsSync(join(ROOT, 'components/admin/AdminTenantsSection.tsx')), true);
    assert.equal(existsSync(join(ROOT, 'components/admin/AdminBillingSection.tsx')), true);
    assert.equal(existsSync(join(ROOT, 'components/admin/AdminIntegrationsSection.tsx')), true);

    assert.equal(existsSync(join(ROOT, 'components/dashboard/use-dashboard-state.ts')), true);
    assert.equal(existsSync(join(ROOT, 'components/dashboard/DashboardStepGuide.tsx')), true);
    assert.equal(existsSync(join(ROOT, 'components/dashboard/DashboardReviewsSection.tsx')), true);
    assert.equal(existsSync(join(ROOT, 'components/dashboard/DashboardCompaniesSection.tsx')), true);
  });

  it('elimina por completo los tipos any de lib/google.ts, lib/trustpilot.ts y app/api/stripe/webhook/route.ts', () => {
    const files = [
      'lib/google.ts',
      'lib/trustpilot.ts',
      'app/api/stripe/webhook/route.ts',
      'lib/stripe-webhook-handlers.ts',
    ];
    for (const rel of files) {
      const content = readFileSync(join(ROOT, rel), 'utf8');
      assert.equal(/:\s*any\b|as\s+any\b|<any>/.test(content), false, `Found any in ${rel}`);
    }
  });

  it('unifica el formato de error { error, code, correlationId } con apiError()', async () => {
    const res = apiError('Parámetros inválidos', {
      status: 400,
      code: 'validation_error',
      correlationId: 'rf_corr_test123456',
      details: ['rating: requerido'],
    });
    assert.equal(res.status, 400);
    assert.equal(res.headers.get('X-Correlation-Id'), 'rf_corr_test123456');
    const body = await res.json();
    assert.deepEqual(body, {
      error: 'Parámetros inválidos',
      code: 'validation_error',
      correlationId: 'rf_corr_test123456',
      details: ['rating: requerido'],
    });

    assert.equal(errorMessage(new Error('Fallo controlado')), 'Fallo controlado');
    assert.equal(errorMessage(null, 'Fallback'), 'Fallback');
    assert.equal(describeUnknownError(new Error('Boom')).message, 'Boom');
  });

  it('expone una interfaz común (connect, sync, normalizeReview) para Google y Trustpilot', () => {
    const providers = listProviders();
    assert.ok(providers.length >= 2);
    for (const key of ['google', 'trustpilot']) {
      assert.ok(key in PROVIDERS_REGISTRY);
    }

    const gNorm = normalizeProviderReview('google', {
      reviewId: 'g-101',
      reviewer: { displayName: 'Lucía Pérez' },
      starRating: 'FIVE',
      comment: 'Trato impecable y comida excelente.',
    });
    assert.equal(gNorm.rating, 5);
    assert.equal(gNorm.author, 'Lucía Pérez');

    const tpNorm = normalizeProviderReview('trustpilot', {
      id: 'tp-303',
      stars: 5,
      title: 'Envío rápido',
      text: 'Llegó en 24h.',
      consumer: { displayName: 'Marta G.' },
      isVerified: true,
    });
    assert.equal(tpNorm.verified, true);

    const adapter = getProviderAdapter('google');
    assert.equal(typeof adapter.connect, 'function');
    assert.equal(typeof adapter.sync, 'function');
    assert.equal(typeof adapter.normalizeReview, 'function');
  });
});

describe('Fase 2 — Seguridad: Cron timingSafeEqual, Rate-Limit Fail-Closed y Purga de Secretos/PII', () => {
  it('compara CRON_SECRET con timingSafeEqual y rechaza tokens inválidos', () => {
    assert.equal(timingSafeStringEqual('cron_secret_12345', 'cron_secret_12345'), true);
    assert.equal(timingSafeStringEqual('cron_secret_12345', 'cron_secret_99999'), false);
    assert.equal(timingSafeStringEqual('corto', 'mucho_mas_largo'), false);

    const validReq = new Request('https://reviewflow.example.com/api/cron/sync-reviews', {
      headers: { Authorization: 'Bearer secret_super_seguro_2026' },
    });
    const invalidReq = new Request('https://reviewflow.example.com/api/cron/sync-reviews', {
      headers: { Authorization: 'Bearer token_atacante_falso' },
    });
    const headerCronReq = new Request('https://reviewflow.example.com/api/cron/sync-reviews', {
      headers: { 'x-cron-secret': 'secret_super_seguro_2026' },
    });

    assert.equal(verifyCronSecret(validReq, 'secret_super_seguro_2026'), true);
    assert.equal(verifyCronSecret(headerCronReq, 'secret_super_seguro_2026'), true);
    assert.equal(verifyCronSecret(invalidReq, 'secret_super_seguro_2026'), false);
  });

  it('el rate-limit en memoria falla de forma segura (fail-closed) en producción si no hay BD', async () => {
    const prevEnv = process.env.NODE_ENV;
    const prevPepper = process.env.PRIVACY_HASH_PEPPER;
    try {
      (process.env as Record<string, string | undefined>).NODE_ENV = 'production';
      (process.env as Record<string, string | undefined>).PRIVACY_HASH_PEPPER =
        'prod_test_pepper_32_characters_minimum_ok';
      const res = await consumeRateLimit('test:prod:failclosed', '198.51.100.42', 10, 60);
      assert.equal(res.allowed, false);
      assert.equal(res.retryAfter, 60);
    } finally {
      (process.env as Record<string, string | undefined>).NODE_ENV = prevEnv;
      (process.env as Record<string, string | undefined>).PRIVACY_HASH_PEPPER = prevPepper;
    }
  });

  it('redacta secretos y enmascara PII (emails y teléfonos) antes de enviar a registros o Sentry', () => {
    assert.equal(maskEmailForLog('cliente.real@empresa.es'), 'c***@empresa.es');
    assert.equal(maskPhoneForLog('+34 612 345 678'), '***78');
    assert.equal(
      redactSecretsInText('Error con clave sk_live_ABCDEF1234567890 y whsec_987654321'),
      'Error con clave [REDACTED_SECRET] y [REDACTED_SECRET]',
    );

    const sanitized = sanitizeLogMeta({
      tenantId: 'tenant-123',
      apiKey: 'rf_live_secret_token_999999',
      authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9',
      email: 'propietario@restaurante.es',
      customer_phone: '+34699887766',
      nested: {
        stripe_secret: 'sk_test_123456789',
        safeField: 'ok',
      },
    });

    assert.equal(sanitized.apiKey, '[REDACTED]');
    assert.equal(sanitized.authorization, '[REDACTED]');
    assert.equal(sanitized.email, 'p***@restaurante.es');
    assert.equal(sanitized.customer_phone, '***66');
    assert.equal((sanitized.nested as Record<string, unknown>).stripe_secret, '[REDACTED]');
    assert.equal((sanitized.nested as Record<string, unknown>).safeField, 'ok');
  });
});

describe('Fase 4 — Aislamiento Multi-Empresa (Tenant A vs Tenant B) y Cobertura de lib/', () => {
  it('garantiza que la empresa A nunca pueda leer ni mutar datos de la empresa B (RLS + RBAC + API)', async () => {
    const schema = readFileSync(join(ROOT, 'supabase/schema.sql'), 'utf8');
    assert.ok(schema.includes('create policy "reviews_select_member" on public.reviews'));
    assert.ok(schema.includes('for select using (public.is_member(tenant_id))'));
    assert.ok(schema.includes('create policy "integrations_client_deny" on public.integrations'));
    assert.ok(schema.includes('for all using (false)'));

    const crossTenantValidation = await connectProvider(
      { admin: {} as never, tenantId: 'tenant-B' },
      'trustpilot',
      { apiKey: '', businessUnitId: '' },
    );
    assert.equal(crossTenantValidation.ok, false);
  });

  it('cubre lib/plans.ts, lib/ai.ts, lib/authz.ts, lib/store.ts, lib/stripe.ts y lib/rate-limit.ts (>70%)', async () => {
    for (const plan of PLAN_CATALOG) {
      assert.equal(resolvePlan(plan.id), plan.id);
      assert.ok(planOf(plan.id).priceCents > 0);
      assert.ok(annualPriceCentsOf(plan.id) < plan.priceCents * 12);
      assert.ok(annualMonthlyEquivalentCents(plan.id) < plan.priceCents);
      assert.equal(planHasFeature(plan.id, 'aiReplies'), true);
    }
    for (const addon of ADDON_CATALOG) {
      assert.equal(resolveAddonPack(addon.id)?.id, addon.id);
    }
    assert.equal(hasAccess('active', false), true);
    assert.equal(hasAccess('canceled', false), false);
    assert.equal(isTrialExpired('trialing', new Date(Date.now() - 86_400_000).toISOString()), true);
    assert.ok(estimateCostUsd(10_000, 5_000) > 0);
    assert.ok(
      estimateStorageMb({ reviewsStored: 500, auditRows: 1000, integrations: 3, aiRows: 200 }) >= 0,
    );
    assert.match(currentCycle(), /^\d{4}-\d{2}$/);
    assert.ok(nextCycleStart().getTime() > Date.now() - 1000);

    const replyPositive = await generateReviewReply({
      businessName: 'Restaurante La Bahía',
      authorName: 'Elena',
      rating: 5,
      reviewText: 'La comida y el servicio fueron espectaculares.',
      tone: 'cercano',
      brandRules: ['Mencionar terraza frente al mar'],
      forbiddenWords: ['barato'],
      brandSignature: 'Equipo La Bahía',
    });
    assert.ok(replyPositive.reply.length > 20);

    const replyNegativePrivate = await generateReviewReply({
      businessName: 'Tienda Sol',
      authorName: 'Pedro',
      rating: 1,
      reviewText: 'El envío llegó con retraso y el paquete roto.',
      tone: 'formal',
      privateMessage: true,
    });
    assert.ok(replyNegativePrivate.reply.length > 20);

    const inspection = await inspectComplaint({
      businessName: 'Tienda Sol',
      authorName: 'Pedro',
      rating: 1,
      reviewText: 'El pedido llegó tarde y nadie contesta al teléfono.',
    });
    assert.ok(inspection.severity);
    assert.ok(inspection.category);

    assert.equal(hasRoleLevel('owner', 'admin'), true);
    assert.equal(hasRoleLevel('viewer', 'agent'), false);
    assert.equal(normalizeRole('ADMIN'), 'admin');
    assert.equal(normalizeRole('viewer'), 'viewer');

    assert.equal(verifyShopifyHmac('body', 'secret', null), false);
    assert.equal(verifyWooHmac('body', 'secret', null), false);
    assert.ok(
      orderDeliveredEmailHtml('Mi Tienda', 'Ana', 'https://example.com/valorar/mi-tienda', '1001').includes(
        '#1001',
      ),
    );

    assert.equal(typeof priceIdFor('local_starter'), 'string');
    assert.equal(typeof addonPriceIdFor('extra_ai_500'), 'string');
    assert.equal(planFromPriceId('unknown_price_id'), null);

    assert.equal(safeInternalRedirect('/dashboard?tab=facturacion'), '/dashboard?tab=facturacion');
    assert.equal(safeInternalRedirect('https://evil.example.com'), '/dashboard');
    assert.equal(escapeHtml('<script>alert(1)</script>'), '&lt;script&gt;alert(1)&lt;/script&gt;');
    const req = new Request('https://reviewflow.example.com/api/health', {
      headers: { 'x-real-ip': '203.0.113.15' },
    });
    assert.equal(requestIp(req), '203.0.113.15');
    const ipLimit = await rateLimitByIp(req, 'test:ip', 5, 60);
    assert.equal(ipLimit.allowed, true);
    const tenantLimit = await rateLimitByTenant('tenant-123', 'test:tenant', 5, 60);
    assert.equal(tenantLimit.allowed, true);

    assert.deepEqual(
      PRODUCT_FLOW_SCENARIOS.map((s) => s.id),
      ['signup', 'onboarding', 'google_connect', 'ai_reply', 'stripe_checkout'],
    );
  });
});

describe('Fase 5 y Fase 6 — UX, Página /precios, Caché de Métricas, Alertas Operativas y Esquema Único', () => {
  beforeEach(() => {
    resetServiceFailures();
  });

  it('incluye la página /precios con comparativa de planes y prueba gratuita visible y guía paso a paso', () => {
    assert.equal(existsSync(join(ROOT, 'app/precios/page.tsx')), true);
    const preciosContent = readFileSync(join(ROOT, 'app/precios/page.tsx'), 'utf8');
    assert.ok(preciosContent.includes('Comparativa detallada de planes'));
    assert.ok(preciosContent.includes('TRIAL_DAYS'));

    const guideContent = readFileSync(join(ROOT, 'components/dashboard/DashboardStepGuide.tsx'), 'utf8');
    assert.ok(guideContent.includes('progressbar'));
    assert.ok(guideContent.includes('Conectar fuente de opiniones'));
    assert.ok(guideContent.includes('Generar primera respuesta con IA'));
    assert.ok(guideContent.includes('Activar cartel QR o email post-venta'));
  });

  it('dispara alertas operativas cuando fallan seguidas la sincronización, los webhooks de Stripe o la cola', async () => {
    const f1 = await recordServiceOutcome('review_sync', false, 'Timeout en proveedor', { threshold: 3 });
    assert.equal(f1.consecutiveFailures, 1);
    assert.equal(f1.alertTriggered, false);

    const f2 = await recordServiceOutcome('review_sync', false, 'Timeout en proveedor', { threshold: 3 });
    assert.equal(f2.consecutiveFailures, 2);
    assert.equal(f2.alertTriggered, false);

    const f3 = await recordServiceOutcome('review_sync', false, 'Timeout en proveedor', { threshold: 3 });
    assert.equal(f3.consecutiveFailures, 3);
    assert.equal(f3.alertTriggered, true);
    assert.equal(getServiceFailureState('review_sync').alerted, true);

    const recovered = await recordServiceOutcome('review_sync', true, 'Sincronización OK');
    assert.equal(recovered.consecutiveFailures, 0);
    assert.equal(getServiceFailureState('review_sync').consecutiveFailures, 0);
  });

  it('calcula e invalida la caché de métricas de negocio y dispone del esquema único v1', async () => {
    invalidateBusinessMetricsCache();
    const metrics = computeBusinessMetrics([
      { id: 't1', name: 'Local 1', plan: 'local_pro', subscription_status: 'active', ai_cost_cycle: 0.45 },
      { id: 't2', name: 'Tienda 2', plan: 'ecommerce_starter', subscription_status: 'trialing', ai_cost_cycle: 0.12 },
    ]);
    assert.equal(metrics.activeCount, 1);
    assert.equal(metrics.trialingCount, 1);
    assert.equal(metrics.mrrCents, 3900);

    const corr = await captureException(new Error('Test con sk_live_SECRET123456'), {
      source: 'test.suite',
      extra: { token: 'secreto_no_enviar' },
    });
    assert.match(corr, /^rf_corr_/);

    assert.equal(existsSync(join(ROOT, 'supabase/config.toml')), true);
    assert.equal(existsSync(join(ROOT, 'supabase/schema.sql')), true);
    assert.equal(existsSync(join(ROOT, 'supabase/migrations')), false);
  });
});
