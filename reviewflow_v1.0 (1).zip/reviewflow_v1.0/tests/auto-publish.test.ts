import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { autoPublishConfigOf, shouldAutoPublish, autoPublishNotice } from '../lib/auto-publish';

test('piloto automático: apagado por defecto y nota mínima 4', () => {
  const cfg = autoPublishConfigOf({});
  assert.equal(cfg.enabled, false);
  assert.equal(cfg.minRating, 4);
  assert.equal(shouldAutoPublish(cfg, 5), false);
});

test('piloto automático: respeta la nota mínima', () => {
  const cfg = autoPublishConfigOf({ auto_publish: true, auto_publish_min_rating: 4 });
  assert.equal(shouldAutoPublish(cfg, 5), true);
  assert.equal(shouldAutoPublish(cfg, 3), false);
  assert.equal(autoPublishConfigOf({ auto_publish: true, auto_publish_min_rating: 9 }).minRating, 4);
});

test('piloto automático: aviso escapa HTML', () => {
  const n = autoPublishNotice({ authorName: '<b>x</b>', rating: 5, reviewText: 'ok', reply: 'gracias', pushedToGoogle: true });
  assert.ok(!n.html.includes('<b>x</b>'));
  assert.ok(n.subject.includes('Google'));
});

test('piloto automático: no pisa respuestas humanas y pide confirmación', () => {
  const q = readFileSync('lib/queue.ts', 'utf8');
  assert.ok(q.includes(".is('reply_text', null)"));
  const ui = readFileSync('components/dashboard/AutoPublishToggle.tsx', 'utf8');
  assert.ok(ui.includes('quitas el filtro humano'));
});
