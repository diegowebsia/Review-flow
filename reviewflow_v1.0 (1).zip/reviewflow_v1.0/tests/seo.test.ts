import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

function contentPages(dir = 'app'): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const path = join(dir, entry.name);
    return entry.isDirectory() ? contentPages(path) : entry.name === 'page.tsx' ? [path] : [];
  });
}

test('todas las páginas tienen metadatos propios con etiquetas sociales coherentes', async () => {
  const { pageMetadata } = await import('../lib/seo');
  for (const path of contentPages()) {
    const source = readFileSync(path, 'utf8');
    assert.ok(source.includes('pageMetadata('), path);
    assert.ok(source.includes('export const metadata') || source.includes('export async function generateMetadata'), path);
  }
  const metadata = pageMetadata('Precios y planes', 'Descripción única de precios', '/precios');
  assert.equal(metadata.description, 'Descripción única de precios');
  assert.equal(metadata.openGraph?.description, metadata.description);
  assert.equal(metadata.twitter?.description, metadata.description);
  assert.equal(metadata.openGraph?.title, metadata.twitter?.title);
  assert.equal(metadata.alternates?.canonical, '/precios');
  assert.deepEqual(pageMetadata('Área privada', 'Cuenta privada', undefined, false).robots, { index: false, follow: false });
});

test('sitemap excluye registro y páginas privadas, sin fechas de modificación inventadas', () => {
  const source = readFileSync('app/sitemap.ts', 'utf8');
  for (const path of ['/registro', '/dashboard', '/admin', '/cuenta', '/bienvenido', '/valorar', '/cartel']) {
    assert.equal(source.includes(`path: '${path}'`), false);
  }
  assert.equal(source.includes('lastModified: now'), false);
  assert.ok(source.includes("if (baseUrl === 'https://invalid.example') return []"));
  assert.ok(readFileSync('app/robots.ts', 'utf8').includes("baseUrl !== 'https://invalid.example'"));
});

test('datos estructurados solo en la portada; exclusión también en cabeceras privadas', async () => {
  const root = readFileSync('app/layout.tsx', 'utf8');
  const home = readFileSync('app/page.tsx', 'utf8');
  assert.equal(root.includes('JSON_LD_GRAPH'), false);
  assert.ok(home.includes("'@type': 'SoftwareApplication'"));
  assert.equal(home.includes("'@type': 'FAQPage'"), false);
  assert.ok(home.includes(".replace(/</g, '\\\\u003c')"));
  const { default: config } = await import('../next.config.js');
  const rules = await config.headers();
  const privateRule = rules.find((rule: { headers: Array<{ key: string }> }) => rule.headers.some((header) => header.key === 'X-Robots-Tag'));
  assert.ok(privateRule);
  for (const path of ['registro', 'admin', 'dashboard', 'valorar', 'api']) assert.ok(privateRule.source.includes(path));
});