import test from 'node:test';
import assert from 'node:assert/strict';
import { generateReviewReply, inspectComplaint, analyzeReviewIntelligence } from '../lib/ai';
import { geminiStatus, geminiRuntime, GEMINI_MODEL } from '../lib/gemini';
import { aiModelPricing, DEFAULT_AI_MODEL } from '../lib/plans';

test('geminiStatus y geminiRuntime exponen modelo por defecto y precios correctos', () => {
  const status = geminiStatus();
  const runtime = geminiRuntime();
  assert.equal(status.model, GEMINI_MODEL);
  assert.equal(runtime.model, GEMINI_MODEL);
  assert.equal(typeof status.configured, 'boolean');
  assert.ok(status.timeoutMs > 0);
  assert.ok(status.rpmPerTenant > 0);
  assert.equal(status.maxConcurrency, runtime.maxConcurrency);

  const pricing = aiModelPricing(DEFAULT_AI_MODEL);
  assert.ok(pricing.input > 0);
  assert.ok(pricing.output > 0);
  assert.deepEqual(status.pricing, pricing);
});

test('generateReviewReply genera respuesta con Gemini o plantilla local', async () => {
  const result = await generateReviewReply({
    businessName: 'Cafetería Sol',
    authorName: 'Carlos',
    rating: 5,
    reviewText: 'Excelente café y trato inmejorable',
    tone: 'cercano',
  });

  assert.ok(result.reply.length > 10);
  assert.ok(['gemini', 'local-template'].includes(result.provider));
  assert.ok(result.usage.totalTokens >= 0);
});

test('inspectComplaint realiza triaje con severidad y canal sugerido', async () => {
  const inspection = await inspectComplaint({
    businessName: 'Clínica Dental',
    authorName: 'Ana',
    rating: 1,
    reviewText: 'Pésimo trato del personal y dos horas de retraso en la cita',
  });

  assert.ok(['alta', 'critica', 'media'].includes(inspection.severity));
  assert.ok(['privado', 'telefono', 'publico'].includes(inspection.suggestedChannel));
  assert.ok(inspection.actionPlan.length > 0);
  assert.ok(['gemini', 'local-heuristic'].includes(inspection.provider));
});

test('analyzeReviewIntelligence analiza sentimiento, temas y variantes', async () => {
  const intel = await analyzeReviewIntelligence({
    businessName: 'Restaurante Mar',
    authorName: 'Laura',
    rating: 5,
    reviewText: 'La comida deliciosa y la atención del personal insuperable',
  });

  assert.equal(intel.sentiment, 'muy_positivo');
  assert.ok(intel.score >= 80);
  assert.ok(intel.topics.length > 0);
  assert.ok(intel.suggestedReplyVariant.standard.length > 10);
  assert.ok(intel.suggestedReplyVariant.short.length > 10);
});
