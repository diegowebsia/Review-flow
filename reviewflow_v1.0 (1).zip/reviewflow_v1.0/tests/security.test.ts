import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'crypto';
import { createOAuthState, createPkce, escapeHtml, safeInternalRedirect, signOpaqueId, verifyOAuthState, verifyOpaqueId } from '../lib/security';
import { decryptCredentials, encryptCredentials } from '../lib/credentials';
import { verifyShopifyHmac } from '../lib/store';

test('safeInternalRedirect bloquea esquemas, externos y protocol-relative', () => {
  assert.equal(safeInternalRedirect('/dashboard?tab=uso'), '/dashboard?tab=uso');
  for (const unsafe of ['https://evil.example', '//evil.example', 'javascript:alert(1)', '/\\evil']) {
    assert.equal(safeInternalRedirect(unsafe), '/dashboard');
  }
});

test('escapeHtml neutraliza HTML de usuario', () => {
  assert.equal(escapeHtml(`<img src=x onerror="x">&'`), '&lt;img src=x onerror=&quot;x&quot;&gt;&amp;&#039;');
});

test('state OAuth está firmado, expira y queda vinculado', () => {
  process.env.APP_SIGNING_SECRET = 'test-secret-long-enough';
  const state = createOAuthState('tenant-1', 'user-1');
  assert.deepEqual(verifyOAuthState(state)?.tenantId, 'tenant-1');
  assert.equal(verifyOAuthState(`${state}x`), null);
  const pkce = createPkce();
  assert.ok(pkce.verifier.length >= 43 && pkce.challenge.length >= 43);
});

test('tokens opacos no aceptan IDs manipulados', () => {
  process.env.APP_SIGNING_SECRET = 'test-secret-long-enough';
  const token = signOpaqueId('row-1');
  assert.equal(verifyOpaqueId('row-1', token), true);
  assert.equal(verifyOpaqueId('row-2', token), false);
});

test('credenciales usan AES-GCM y aceptan filas legacy', () => {
  process.env.INTEGRATION_ENCRYPTION_KEY = 'test-encryption-key';
  const encrypted = encryptCredentials({ access_token: 'secret' });
  assert.equal((encrypted as any)._encrypted, 'v1');
  assert.equal(JSON.stringify(encrypted).includes('secret'), false);
  assert.deepEqual(decryptCredentials(encrypted), { access_token: 'secret' });
  assert.deepEqual(decryptCredentials({ legacy: 'ok' }), { legacy: 'ok' });
});

test('HMAC de tienda se compara correctamente', () => {
  const raw = '{"id":1}';
  const sig = createHmac('sha256', 'secret').update(raw).digest('base64');
  assert.equal(verifyShopifyHmac(raw, 'secret', sig), true);
  assert.equal(verifyShopifyHmac(raw, 'secret', `${sig}x`), false);
});

test('validación de producción exige secretos y HTTPS', async () => {
  const { formatProductionConfigError, productionEnvErrors } = await import('../lib/env-validation');
  const errors = productionEnvErrors({ NEXT_PUBLIC_APP_URL: 'http://localhost:3000' } as unknown as NodeJS.ProcessEnv);
  assert.ok(errors.includes('Falta SUPABASE_SERVICE_ROLE_KEY'));
  assert.ok(errors.some((error) => error.includes('HTTPS')));
  const message = formatProductionConfigError(errors);
  assert.match(message, /CONFIGURACIÓN INCOMPLETA/);
  assert.match(message, /SUPABASE_SERVICE_ROLE_KEY/);
  assert.match(message, /npm run verify -- --url/);
  assert.equal(message.includes('undefined'), false);
});

test('clave anterior permite descifrar y recifrar credenciales', () => {
  process.env.INTEGRATION_ENCRYPTION_KEY = 'old-key';
  const old = encryptCredentials({ token: 'legacy-secret' });
  process.env.INTEGRATION_ENCRYPTION_KEY = 'new-key';
  process.env.INTEGRATION_ENCRYPTION_KEY_PREVIOUS = 'old-key';
  assert.deepEqual(decryptCredentials(old), { token: 'legacy-secret' });
  delete process.env.INTEGRATION_ENCRYPTION_KEY_PREVIOUS;
});

test('CI Security Audit: todos los handlers protegidos de app/api/**/route.ts invocan enforce/enforceAi/requireOwner/requireRole/requireAdmin', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');

  // Rutas legítimamente públicas (con rate-limit y/o anti-bot propio)
  const PUBLIC_OR_SIGNED_ALLOWLIST = new Set([
    'app/api/auth/signout/route.ts',
    'app/api/auth/signup/route.ts',
    'app/api/client-errors/route.ts',
    'app/api/contact/route.ts',
    'app/api/cron/abandoned-trial/route.ts',
    'app/api/cron/weekly-digest/route.ts',
    'app/api/cron/sync-reviews/route.ts',
    'app/api/feedback/route.ts',
    'app/api/feedback/click/route.ts',
    'app/api/feedback/respond/route.ts',
    'app/api/health/route.ts',
    'app/api/integrations/google/callback/route.ts',
    'app/api/integrations/ingest/route.ts',
    'app/api/integrations/ecommerce/order-delivered/route.ts',
    'app/api/integrations/shopify/webhook/route.ts',
    'app/api/integrations/store/order-delivered/route.ts',
    'app/api/integrations/store/webhook/route.ts',
    'app/api/integrations/woocommerce/webhook/route.ts',
    'app/api/queue/worker/route.ts',
    'app/api/reviews/request/send/route.ts',
    'app/api/stripe/checkout/route.ts',
    'app/api/stripe/portal/route.ts',
    'app/api/stripe/webhook/route.ts',
  ]);

  function walkRoutes(dir: string, acc: string[] = []): string[] {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walkRoutes(full, acc);
      } else if (entry.isFile() && entry.name === 'route.ts') {
        acc.push(path.relative(process.cwd(), full).replace(/\\/g, '/'));
      }
    }
    return acc;
  }

  const routes = walkRoutes(path.join(process.cwd(), 'app', 'api'));
  assert.ok(routes.length >= 20, 'Se esperaban al menos 20 rutas de API');

  const unprotected: string[] = [];
  for (const relPath of routes) {
    if (PUBLIC_OR_SIGNED_ALLOWLIST.has(relPath)) continue;
    const source = fs.readFileSync(path.join(process.cwd(), relPath), 'utf8');
    const hasGuard =
      /\b(enforce|enforceAi|requireOwner|requireRole|requireAdmin|requireSuperAdmin|requireSuperAdminMfa|getSupportImpersonation|checkQuota|getSessionUser)\s*\(|auth\.getUser\s*\(/.test(
        source,
      );
    if (!hasGuard) {
      unprotected.push(relPath);
    }
  }

  assert.deepEqual(
    unprotected,
    [],
    `Rutas protegidas sin enforce()/enforceAi()/requireOwner()/requireRole()/requireAdmin(): ${unprotected.join(', ')}`,
  );
});

test('Proxy Security Audit: ninguna ruta de app/api/integrations/** que se autentique con api_key queda fuera de isPublicIntegrationPath()', async () => {
  const fs = await import('node:fs');
  const path = await import('node:path');
  const { isPublicIntegrationPath } = await import('../proxy');

  function walkIntegrationRoutes(dir: string, acc: string[] = []): string[] {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walkIntegrationRoutes(full, acc);
      } else if (entry.isFile() && entry.name === 'route.ts') {
        acc.push(full);
      }
    }
    return acc;
  }

  const integrationDir = path.join(process.cwd(), 'app', 'api', 'integrations');
  const routeFiles = walkIntegrationRoutes(integrationDir);
  assert.ok(routeFiles.length >= 10, 'Se esperaban rutas dentro de app/api/integrations');

  const missingFromPublicList: string[] = [];
  for (const file of routeFiles) {
    const content = fs.readFileSync(file, 'utf8');
    // Detecta si la ruta autentica peticiones externas mediante api_key / x-api-key / verifyAndResolveTenantByApiKey
    const usesApiKeyAuth =
      content.includes('verifyAndResolveTenantByApiKey') ||
      content.includes('x-api-key') ||
      content.includes('extractApiKey') ||
      content.includes("from './../../ecommerce/order-delivered/route'") ||
      content.includes("from '../../ecommerce/order-delivered/route'");

    if (usesApiKeyAuth) {
      const rel = path.relative(path.join(process.cwd(), 'app'), file).replace(/\\/g, '/');
      const urlPath = '/' + rel.replace(/\/route\.ts$/, '');
      if (!isPublicIntegrationPath(urlPath)) {
        missingFromPublicList.push(urlPath);
      }
    }
  }

  assert.deepEqual(
    missingFromPublicList,
    [],
    `Rutas de integraciones con api_key bloqueadas por el middleware (faltan en isPublicIntegrationPath): ${missingFromPublicList.join(', ')}`,
  );

  // Verificar explícitamente los dos endpoints máquina-a-máquina críticos
  assert.equal(isPublicIntegrationPath('/api/integrations/ecommerce/order-delivered'), true);
  assert.equal(isPublicIntegrationPath('/api/integrations/whatsapp/optin'), false);
});

