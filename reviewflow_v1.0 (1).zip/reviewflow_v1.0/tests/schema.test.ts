import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync, readdirSync } from 'fs';

test('schema crea usage_counters antes de alterarla', () => {
  const sql = readFileSync('supabase/schema.sql', 'utf8');
  assert.ok(sql.indexOf('create table if not exists public.usage_counters') < sql.indexOf('alter table public.usage_counters add column'));
});

test('schema contempla estados runtime y hardening crítico', () => {
  const sql = readFileSync('supabase/schema.sql', 'utf8');
  for (const value of ["'inactive'", "'paused'", 'processed_events', 'consume_rate_limit', 'apply_addon_purchase']) assert.ok(sql.includes(value));
  assert.equal(sql.includes('create policy "tenants_insert_auth"'), false);
  assert.match(sql, /stripe_payment_id, pack/);
});


test('schema 3.12 aporta idempotencia observable de webhooks', () => {
  const sql = readFileSync('supabase/schema.sql', 'utf8');
  for (const value of ['webhook_events', 'claim_webhook_event', 'finish_webhook_event', 'fail_webhook_event']) {
    assert.ok(sql.includes(value));
  }
});


test('schema 3.13 incorpora atribución de campañas y los 4 planes oficiales con Gemini', () => {
  const sql = readFileSync('supabase/schema.sql', 'utf8');
  assert.match(sql, /campaign text/);
  assert.ok(sql.includes('feedback_tenant_campaign_created_idx'));
  assert.ok(sql.includes('feedback_campaign_format'));
  for (const plan of ['local_starter', 'ecommerce_starter', 'local_pro', 'ecommerce_pro']) {
    assert.ok(sql.includes(`'${plan}'`), `schema.sql debe incluir el plan ${plan}`);
  }
  assert.ok(sql.includes("'gemini-2.5-flash'"));
});

test('schema.sql es el único SQL y la configuración apunta a él', () => {
  assert.equal(existsSync('supabase/migrations'), false);
  assert.deepEqual(readdirSync('supabase').filter((f) => f.endsWith('.sql')), ['schema.sql']);
  assert.ok(readFileSync('supabase/config.toml', 'utf8').includes('schema_paths = ["./schema.sql"]'));
});

test('config.toml de Supabase CLI usa http://localhost en las redirecciones', () => {
  const toml = readFileSync('supabase/config.toml', 'utf8');
  assert.equal(toml.includes('https://localhost'), false);
});

test('lib/database.types.ts declara todas las tablas y vistas de schema.sql', async () => {
  const { readFileSync } = await import('node:fs');
  const sql = readFileSync('supabase/schema.sql', 'utf8');
  const types = readFileSync('lib/database.types.ts', 'utf8');
  const names = [
    ...sql.matchAll(/create table if not exists public\.([a-z_]+)/gi),
    ...sql.matchAll(/create or replace view public\.([a-z_]+)/gi),
  ].map((m) => m[1]);
  assert.ok(names.length >= 20);
  for (const n of new Set(names)) {
    assert.match(types, new RegExp(`\\n      ${n}: \\{\\n        Row`), `Falta el tipo de ${n}`);
  }
  // api_rate_limits usa key_hash (no key): el código debe coincidir
  assert.match(readFileSync('lib/rate-limit.ts', 'utf8'), /eq\('key_hash', key\)/);
});
