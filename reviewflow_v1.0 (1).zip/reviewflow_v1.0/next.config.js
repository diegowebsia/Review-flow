/** @type {import('next').NextConfig} */
const isProduction = process.env.NODE_ENV === 'production';
const cspFor = (frameAncestors) => [
  "default-src 'self'",
  "base-uri 'self'",
  "object-src 'none'",
  `frame-ancestors ${frameAncestors}`,
  "form-action 'self'",
  "img-src 'self' data: blob: https:",
  "font-src 'self' data:",
  "style-src 'self' 'unsafe-inline' https://www.gstatic.com https://translate.googleapis.com",
  `script-src 'self' 'unsafe-inline'${isProduction ? '' : " 'unsafe-eval'"} https://challenges.cloudflare.com https://translate.google.com https://translate.googleapis.com https://translate-pa.googleapis.com https://www.gstatic.com`,
  `connect-src 'self' https://*.supabase.co https://challenges.cloudflare.com https://translate.google.com https://translate.googleapis.com https://translate-pa.googleapis.com https://www.gstatic.com${isProduction ? '' : ' ws: wss:'}`,
  'frame-src https://translate.google.com https://js.stripe.com https://hooks.stripe.com https://challenges.cloudflare.com',
  'upgrade-insecure-requests',
].join('; ');

const securityHeaders = (frameAncestors) => [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=(self)' },
  { key: 'Content-Security-Policy', value: cspFor(frameAncestors) },
  ...(frameAncestors === "'none'" ? [{ key: 'X-Frame-Options', value: 'DENY' }] : []),
  ...(isProduction
    ? [{ key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' }]
    : []),
];

const nextConfig = {
  output: 'standalone',
  // Fija la raíz del proyecto para que Next no confunda carpetas superiores con el espacio de trabajo.
  outputFileTracingRoot: __dirname,
  turbopack: { root: __dirname },
  reactStrictMode: true,
  poweredByHeader: false,
  allowedDevOrigins: ['*.run.app', '*.google.com', '*.googleusercontent.com', '*.e2b.app', 'localhost:3000', 'localhost', '127.0.0.1'],
  serverExternalPackages: ['pg'],
  experimental: { serverActions: { bodySizeLimit: '2mb' } },
  async headers() {
    // Solo /valorar/* (la página pública de valoración) puede incrustarse en la web del cliente.
    return [
      {
        source: '/:section(admin|dashboard|cuenta|bienvenido|login|registro|recuperar|nueva-contrasena|status|valorar|cartel|auth|api|health)/:path*',
        headers: [{ key: 'X-Robots-Tag', value: 'noindex, nofollow' }],
      },
      { source: '/((?!valorar/).*)', headers: securityHeaders("'none'") },
      { source: '/valorar/:path*', headers: securityHeaders("'self' https:") },
    ];
  },
};
module.exports = nextConfig;
