import {
  assertProductionSiteConfig,
  checkMissingEnvOnStartup,
  formatProductionConfigError,
  productionEnvErrors,
} from '@/lib/env-validation';

export async function register() {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;
  // Next ejecuta instrumentation también durante ciertas fases del build.
  if (process.env.NEXT_PHASE === 'phase-production-build') return;

  checkMissingEnvOnStartup(process.env, (warningMsg) => {
    console.warn(warningMsg);
  });

  if (process.env.NODE_ENV === 'production') {
    const errors = productionEnvErrors();
    if (errors.length > 0) {
      const message = formatProductionConfigError(errors);
      console.error(message);
      throw new Error(message);
    }
    await assertProductionSiteConfig(process.env);
  }

  const { startInternalCron } = await import('@/lib/internal-cron');
  startInternalCron();
}

/**
 * Fallos del servidor (páginas, rutas API, acciones) que Next no ha podido
 * manejar: se guardan en el registro (`system_logs` + Sentry si hay DSN).
 */
export async function onRequestError(
  error: unknown,
  request: { path: string; method: string; headers: Record<string, string | string[] | undefined> },
  context: { routerKind: string; routePath: string; routeType: string },
) {
  if (process.env.NEXT_RUNTIME !== 'nodejs') return;
  try {
    const { captureException } = await import('@/lib/observability');
    const digest = (error as { digest?: unknown } | null)?.digest;
    const header = request.headers['x-correlation-id'];
    await captureException(error, {
      source: `server.${context.routeType}`,
      correlationId: typeof digest === 'string' ? digest : typeof header === 'string' ? header : undefined,
      tags: { route: context.routePath, method: request.method, router: context.routerKind },
      extra: { path: request.path.split('?')[0] },
    });
  } catch {
    /* el registro nunca debe tumbar la respuesta */
  }
}
