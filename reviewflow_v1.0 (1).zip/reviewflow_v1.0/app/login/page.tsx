import { pageMetadata } from '@/lib/seo';
import { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { AuthForm } from '@/components/AuthForm';
import { AuthSkeleton } from '@/components/Skeleton';
import { getSessionUser } from '@/lib/auth';
import { resolvePlan } from '@/lib/plans';
import { getFreeTrialEnabled } from '@/lib/system-settings';

export const dynamic = 'force-dynamic';

export const metadata = pageMetadata('Iniciar sesión', 'Accede a tu cuenta de ReviewFlow AI para gestionar las opiniones de tus empresas.', undefined, false);

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ mode?: string; plan?: string; error?: string; reason?: string }>;
}) {
  const sp = await searchParams;
  if (!sp.error && !sp.reason) {
    const user = await getSessionUser();
    if (user) {
      const planQuery = sp.plan ? `?plan=${resolvePlan(sp.plan)}` : '';
      redirect(`/bienvenido${planQuery}`);
    }
  }

  const freeTrialEnabled = await getFreeTrialEnabled();
  // Compat: /login?mode=signup (antiguo) sigue funcionando como registro.
  const mode = sp.mode === 'signup' ? 'signup' : 'signin';
  return (
    <Suspense fallback={<AuthSkeleton />}>
      <AuthForm mode={mode} freeTrialEnabled={freeTrialEnabled} />
    </Suspense>
  );
}
