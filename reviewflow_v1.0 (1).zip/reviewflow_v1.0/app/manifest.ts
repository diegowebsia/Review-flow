import type { MetadataRoute } from 'next';
import { SITE } from '@/lib/site';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: `${SITE.brand} — Gestión de Reputación e IA`,
    short_name: SITE.brand,
    description:
      'Centraliza reseñas de Google, Trustpilot y tu tienda online. Responde en segundos con IA y recibe alertas urgentes en el móvil.',
    start_url: '/dashboard',
    display: 'standalone',
    background_color: '#090D16',
    theme_color: '#2563EB',
    orientation: 'portrait-primary',
    categories: ['business', 'productivity', 'utilities'],
    icons: [
      {
        src: '/favicon.svg',
        sizes: 'any',
        type: 'image/svg+xml',
        purpose: 'any',
      },
      {
        src: '/logo.svg',
        sizes: '512x512',
        type: 'image/svg+xml',
        purpose: 'maskable',
      },
    ],
    shortcuts: [
      {
        name: 'Bandeja de reseñas',
        short_name: 'Bandeja',
        description: 'Responder reseñas pendientes con IA',
        url: '/dashboard?tab=bandeja',
      },
      {
        name: 'Analítica y Competencia',
        short_name: 'Analítica',
        description: 'Evolución de nota media y comparativa local',
        url: '/dashboard?tab=analitica',
      },
      {
        name: 'Embudo y Cartel QR',
        short_name: 'Cartel QR',
        description: 'Enlace público y código QR para clientes',
        url: '/dashboard?tab=embudo',
      },
    ],
  };
}
