import { SITE } from '@/lib/site';
import { PLAN_CATALOG } from '@/lib/plans';
import { pageMetadata } from '@/lib/seo';
import { redirect } from 'next/navigation';
import { Landing } from '@/components/Landing';
import { getFreeTrialEnabled } from '@/lib/system-settings';

export const dynamic = 'force-dynamic';

export const metadata = pageMetadata('ReviewFlow AI — Gestión de reseñas y respuestas con IA', 'Centraliza opiniones de Google, Trustpilot y tiendas online, solicita valoraciones por QR y correo y prepara respuestas con el tono de tu marca.', '/', true);

const PLAN_PRICES = PLAN_CATALOG.map((plan) => plan.priceCents / 100);

const JSON_LD_GRAPH = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': 'Organization',
      '@id': `${SITE.url}/#organization`,
      name: SITE.companyName,
      brand: SITE.brand,
      url: SITE.url,
      email: SITE.supportEmail,
      logo: `${SITE.url}/logo.svg`,
    },
    {
      '@type': 'SoftwareApplication',
      '@id': `${SITE.url}/#software`,
      name: SITE.brand,
      applicationCategory: 'BusinessApplication',
      operatingSystem: 'Web, PWA (iOS, Android, Desktop)',
      offers: {
        '@type': 'AggregateOffer',
        priceCurrency: 'EUR',
        lowPrice: Math.min(...PLAN_PRICES).toFixed(2),
        highPrice: Math.max(...PLAN_PRICES).toFixed(2),
        offerCount: String(PLAN_CATALOG.length),
      },
    },
  ],
};

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string; plan?: string }>;
}) {
  const sp = await searchParams;
  // Si el usuario hace clic en un enlace de confirmación de correo de Supabase
  // que apunta a Site URL (p. ej. localhost/?code=...), intercambiamos la sesión
  // automáticamente y lo llevamos directo a elegir y pagar su plan (/bienvenido).
  if (sp?.code) {
    const nextPath = sp.plan ? `/bienvenido?plan=${encodeURIComponent(sp.plan)}` : '/bienvenido';
    redirect(`/auth/callback?code=${encodeURIComponent(sp.code)}&next=${encodeURIComponent(nextPath)}`);
  }

  const freeTrialEnabled = await getFreeTrialEnabled();

  return <>
    {SITE.url !== 'https://invalid.example' && <script type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(JSON_LD_GRAPH).replace(/</g, '\\u003c') }} />}
    <Landing freeTrialEnabled={freeTrialEnabled} />
  </>;
}
