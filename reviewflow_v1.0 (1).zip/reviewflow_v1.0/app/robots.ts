import type { MetadataRoute } from 'next';
import { SITE } from '@/lib/site';

/**
 * Las páginas de cada negocio (/valorar, /cartel), el login y el estado
 * se dejan rastrear para que Google vea su "noindex" y no las muestre.
 */
export default function robots(): MetadataRoute.Robots {
  const baseUrl = SITE.url.replace(/\/$/, '');
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/admin', '/dashboard', '/cuenta', '/api/', '/bienvenido', '/auth/'],
      },
    ],
    ...(baseUrl !== 'https://invalid.example' ? { sitemap: `${baseUrl}/sitemap.xml`, host: baseUrl } : {}),
  };
}
