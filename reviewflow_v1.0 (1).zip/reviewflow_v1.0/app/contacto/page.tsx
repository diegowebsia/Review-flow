import { pageMetadata } from '@/lib/seo';
import { ContactClient } from './contact-client';

export const metadata = pageMetadata('Contacto y soporte', 'Contacta con el equipo de ReviewFlow AI para resolver consultas sobre planes, integraciones y gestión de opiniones.', '/contacto', true);

export default function ContactoPage() {
  return <ContactClient />;
}
