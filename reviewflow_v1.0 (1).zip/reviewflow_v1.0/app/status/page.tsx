import { pageMetadata } from '@/lib/seo';
import Link from 'next/link';
import { Activity, ArrowLeft, CheckCircle2, Clock, Database, Globe, Lock, Server, ShieldCheck, Sparkles } from 'lucide-react';
import { Footer } from '@/components/Footer';
import { SITE } from '@/lib/site';
import { createAdminClient } from '@/lib/supabase/admin';
import { env, isGeminiConfigured, isStripeConfigured, isSupabaseAdminConfigured, isSupabaseConfigured } from '@/lib/env';

export const dynamic = 'force-dynamic';
export const metadata = pageMetadata('Estado del servicio', 'Consulta el estado de la web y las conexiones de ReviewFlow AI.', undefined, false);

type Check = { id: string; name: string; ok: boolean; detail: string; icon: typeof Server };

async function checkDatabase(): Promise<{ ok: boolean; ms: number | null }> {
  if (!isSupabaseConfigured || !isSupabaseAdminConfigured) return { ok: false, ms: null };
  const t = Date.now();
  try {
    const admin = createAdminClient();
    const r = admin ? await admin.from('tenants').select('id', { head: true, count: 'exact' }).limit(1) : null;
    return { ok: Boolean(r && !r.error), ms: Date.now() - t };
  } catch {
    return { ok: false, ms: null };
  }
}

async function probe(url: string, headers: Record<string, string>): Promise<{ ok: boolean; ms: number | null }> {
  const t = Date.now();
  try {
    const r = await fetch(url, { headers, cache: 'no-store', signal: AbortSignal.timeout(4000) });
    return { ok: r.ok, ms: Date.now() - t };
  } catch {
    return { ok: false, ms: null };
  }
}

// Comprobación real: pregunta a Stripe con la clave configurada (solo lectura).
async function checkStripe() {
  if (!isStripeConfigured) return { ok: false, ms: null };
  return probe('https://api.stripe.com/v1/balance', { Authorization: `Bearer ${env.stripeSecretKey}` });
}

// Comprobación real: pregunta a Google si la clave de Gemini es válida (no gasta cuota de generación).
async function checkGemini() {
  if (!isGeminiConfigured) return { ok: false, ms: null };
  return probe(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(env.geminiModel)}`, {
    'x-goog-api-key': env.geminiApiKey as string,
  });
}

/**
 * Las comprobaciones (base de datos, IA y pagos) se hacen como mucho UNA vez por
 * minuto por servidor: si alguien recarga la página sin parar, se reutiliza el
 * último resultado y no se gastan consultas de IA ni llamadas a pagos.
 * Si varias visitas llegan a la vez, comparten la misma comprobación en curso.
 */
const STATUS_TTL_MS = 60_000;
type StatusSnapshot = {
  at: Date;
  db: Awaited<ReturnType<typeof checkDatabase>>;
  stripe: Awaited<ReturnType<typeof checkStripe>>;
  gemini: Awaited<ReturnType<typeof checkGemini>>;
};
let statusCache: StatusSnapshot | null = null;
let statusInFlight: Promise<StatusSnapshot> | null = null;

async function getStatusSnapshot(): Promise<StatusSnapshot> {
  if (statusCache && Date.now() - statusCache.at.getTime() < STATUS_TTL_MS) return statusCache;
  if (statusInFlight) return statusInFlight;
  statusInFlight = (async () => {
    const [db, stripe, gemini] = await Promise.all([checkDatabase(), checkStripe(), checkGemini()]);
    statusCache = { at: new Date(), db, stripe, gemini };
    return statusCache;
  })().finally(() => {
    statusInFlight = null;
  });
  return statusInFlight;
}

export default async function StatusPage() {
  const { at: now, db, stripe, gemini } = await getStatusSnapshot();
  // Comprobaciones reales en el momento de cargar la página. Sin cifras inventadas.
  const components: Check[] = [
    { id: 'core-api', name: 'Web y API', ok: true, detail: 'Respondiendo ahora mismo (estás viendo esta página).', icon: Server },
    {
      id: 'database',
      name: 'Base de datos',
      ok: db.ok,
      detail: db.ok ? `Conectada · respuesta en ${db.ms} ms` : 'No disponible o sin configurar.',
      icon: Database,
    },
    {
      id: 'ai-engine',
      name: 'Respuestas con IA',
      ok: gemini.ok,
      detail: gemini.ok
        ? `IA conectada · respuesta en ${gemini.ms} ms`
        : isGeminiConfigured
          ? 'La clave de IA no responde o no es válida. Se usan plantillas de respaldo.'
          : 'IA sin configurar. Solo se usan plantillas de respaldo.',
      icon: Sparkles,
    },
    {
      id: 'billing',
      name: 'Pagos',
      ok: stripe.ok,
      detail: stripe.ok
        ? `Conectados · respuesta en ${stripe.ms} ms`
        : isStripeConfigured
          ? 'La clave de pagos no responde o no es válida.'
          : 'Sin configurar.',
      icon: Lock,
    },
  ];
  const allOk = components.every((c) => c.ok);
  void Globe;

  return (
    <div className="min-h-screen bg-ink-950 text-ink-100">
      <header className="nav-blur sticky top-0 z-50 border-b border-white/10 bg-slate-900/80 backdrop-blur-lg">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-ink-200 hover:text-white">
            <ArrowLeft size={15} /> Volver a {SITE.brand}
          </Link>
          <span className={allOk ? 'badge-ok' : 'badge-warn'}>
            {allOk ? 'Todos los sistemas operativos' : 'Algún servicio con problemas'}
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-8 px-4 py-12">
        <div className="card ring-gradient p-7">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="kicker flex items-center gap-1.5">
                <Activity size={14} /> Estado del Servicio en Tiempo Real
              </p>
              <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-white">
                Estado del servicio de {SITE.brand}
              </h1>
              <p className="mt-1 text-sm text-ink-300">
                Última comprobación real (se repite como mucho una vez por minuto):{' '}
                <span className="font-mono text-white">{now.toUTCString()}</span>
              </p>
            </div>
            
          </div>
        </div>

        <section className="space-y-3" aria-label="Componentes del sistema">
          <h2 className="text-base font-bold text-white">Componentes de infraestructura</h2>
          {components.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.id} className="card flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-brand-300">
                    <Icon size={17} />
                  </span>
                  <div>
                    <p className="font-bold text-white">{c.name}</p>
                    <p className="mt-0.5 text-xs text-ink-400">
                      {c.detail}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 self-end sm:self-center">
                  
                  <span className={c.ok ? 'badge-ok' : 'badge-warn'}>
                    <CheckCircle2 size={12} /> {c.ok ? 'Operativo' : 'Revisar'}
                  </span>
                </div>
              </div>
            );
          })}
        </section>

        <section className="card space-y-3">
          <h2 className="flex items-center gap-2 text-base font-bold text-white">
            <Clock size={16} className="text-brand-300" /> Incidencias
          </h2>
          <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-4 text-sm text-ink-300">
            <p className="font-semibold text-emerald-300">Si hay una incidencia importante, la publicaremos aquí y te avisaremos por email.</p>
            <p className="mt-1 text-xs text-ink-400">
              El motor de IA cuenta con conmutación automática sin caída (failover a plantillas deterministas) y los webhooks de Stripe/tiendas incorporan cola idempotente con reintentos exponenciales.
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 text-xs text-ink-400">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-emerald-400" /> Endpoint de verificación automática: <code>GET /api/health</code>
            </span>
            <Link href="/dpa" className="text-brand-300 underline-offset-2 hover:underline">
              Ver Subencargados y DPA RGPD →
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
