import { pageMetadata } from '@/lib/seo';
import Link from 'next/link';
import { RequestResetForm } from '@/components/auth/PasswordRecovery';
import { SITE } from '@/lib/site';

export const metadata = pageMetadata('Recuperar contraseña', 'Solicita un enlace privado para recuperar el acceso a tu cuenta de ReviewFlow AI.', undefined, false);

export default function Page() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-ink-950 px-4 text-ink-100">
      <div className="card w-full max-w-md p-6 sm:p-8">
        <Link href="/" className="text-sm font-bold text-white">{SITE.brand}</Link>
        <h1 className="mt-4 text-2xl font-extrabold text-white">Recuperar contraseña</h1>
        <p className="mt-1 mb-6 text-sm text-ink-400">Te enviaremos un enlace a tu email.</p>
        <RequestResetForm />
      </div>
    </main>
  );
}
