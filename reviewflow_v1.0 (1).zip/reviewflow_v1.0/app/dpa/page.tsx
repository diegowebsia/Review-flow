import { pageMetadata } from '@/lib/seo';
import Link from 'next/link';
import { SITE } from '@/lib/site';

export const metadata = pageMetadata('Encargo de tratamiento y subencargados', 'Consulta el contrato de encargo de tratamiento de ReviewFlow AI y la información sobre sus subencargados.', '/dpa', true);

const SUBPROCESSORS = [
  {
    name: 'Supabase Inc. (AWS EU-Central Frankfurt)',
    purpose: 'Base de datos PostgreSQL gestionada, autenticación y almacenamiento cifrado con aislamiento RLS.',
    location: 'Unión Europea (Alemania, eu-central-1)',
    safeguards: 'Datos alojados en la UE + DPA / Cláusulas Contractuales Tipo (SCC) + SOC 2 Type II.',
  },
  {
    name: 'Stripe Payments Europe, Ltd.',
    purpose: 'Procesamiento de pagos con tarjeta, facturación recurrente, Stripe Tax y prevención del fraude.',
    location: 'Unión Europea (Irlanda) / EE. UU.',
    safeguards: 'PCI-DSS Nivel 1 + EU-U.S. Data Privacy Framework + SCC.',
  },
  {
    name: 'Google Cloud EMEA Limited (Google Gemini API & Places API)',
    purpose: 'Generación de borradores de respuesta con IA (API de pago de Gemini, cuyos datos Google no usa para entrenar modelos) e importación de reseñas públicas.',
    location: 'Unión Europea / Global',
    safeguards: 'Cloud Data Processing Addendum (CDPA) + ISO 27001 / 27701 + Sin uso para entrenamiento en la API de pago.',
  },
  {
    name: 'Resend Inc.',
    purpose: 'Envío de correos transaccionales (solicitudes de valoración, avisos de cuota y resúmenes semanales).',
    location: 'Unión Europea / EE. UU.',
    safeguards: 'DPA RGPD + Cláusulas Contractuales Tipo (SCC) + SOC 2.',
  },
  {
    name: 'Vercel Inc.',
    purpose: 'Infraestructura de alojamiento web serverless, red de distribución (CDN) y ejecución de tareas programadas.',
    location: 'Unión Europea ( Edge / Frankfurt ) / EE. UU.',
    safeguards: 'Vercel Data Processing Addendum + ISO 27001 + SOC 2 Type II.',
  },
];

export default function DpaPage() {
  return (
    <main id="main-content" className="min-h-screen bg-ink-950 px-4 py-14 text-ink-100">
      <div className="mx-auto max-w-4xl space-y-8">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-6">
          <div>
            <p className="kicker">Cumplimiento normativo B2B · Unión Europea</p>
            <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-white">
              Acuerdo de Encargo de Tratamiento (DPA) y Subencargados
            </h1>
            <p className="mt-2 text-sm text-ink-300">
              Conforme al Artículo 28 del Reglamento (UE) 2016/679 (RGPD) y la LOPDGDD 3/2018 · Versión vigente: v1.0 (2026)
            </p>
          </div>
          <Link href="/" className="btn-secondary btn-sm">
            ← Volver al inicio
          </Link>
        </div>

        <section className="card space-y-4">
          <h2 className="text-lg font-bold text-white">1. Objeto y Naturaleza del Encargo (Art. 28 RGPD)</h2>
          <p className="text-sm leading-relaxed text-ink-300">
            El presente Acuerdo de Encargo de Tratamiento (<strong>DPA</strong>) forma parte íntegra de los Términos y
            Condiciones de contratación de <strong>{SITE.brand}</strong> ({SITE.company}, NIF {SITE.cif}). El Cliente
            que contrata un plan actúa como <strong>Responsable del Tratamiento</strong> respecto a los datos de sus
            propios compradores y clientes finales, y {SITE.brand} actúa exclusivamente como{' '}
            <strong>Encargado del Tratamiento</strong> siguiendo las instrucciones documentadas del Cliente.
          </p>
          <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-300">
            <li>
              <strong>Finalidad exclusiva:</strong> Centralizar reseñas públicas, gestionar tickets privados de
              atención al cliente, enviar solicitudes de valoración con consentimiento previo y generar borradores de
              respuesta asistidos por IA.
            </li>
            <li>
              <strong>Prohibición de entrenamiento de IA:</strong> Los datos y reseñas de tu empresa se procesan a
              través de la API empresarial de Google Gemini y <strong>nunca</strong> se utilizan para entrenar modelos
              públicos.
            </li>
            <li>
              <strong>Derecho de Portabilidad y Supresión Autoservicio (Art. 15 y 17 RGPD):</strong> Desde tu panel
              puedes exportar en cualquier momento el 100 % de tus datos en CSV (`GET /api/tenants/export`) o ejecutar
              el borrado y purga definitiva con emisión de Certificado Criptográfico firmado (`DELETE /api/tenants/delete`).
            </li>
          </ul>
        </section>

        <section className="card space-y-4">
          <h2 className="text-lg font-bold text-white">2. Lista Oficial de Subencargados Autorizados (Art. 28.2 RGPD)</h2>
          <p className="text-sm text-ink-300">
            Para prestar el servicio con alta disponibilidad y seguridad, {SITE.brand} utiliza los siguientes
            proveedores de infraestructura auditados:
          </p>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-white/10 text-xs uppercase tracking-wider text-ink-400">
                  <th className="py-3 pr-4">Subencargado</th>
                  <th className="py-3 pr-4">Función desempeñada</th>
                  <th className="py-3 pr-4">Región de datos</th>
                  <th className="py-3">Garantías RGPD</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-ink-200">
                {SUBPROCESSORS.map((sub) => (
                  <tr key={sub.name}>
                    <td className="py-3 pr-4 font-semibold text-white">{sub.name}</td>
                    <td className="py-3 pr-4 text-xs text-ink-300">{sub.purpose}</td>
                    <td className="py-3 pr-4 text-xs text-emerald-300">{sub.location}</td>
                    <td className="py-3 text-xs text-ink-300">{sub.safeguards}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="card space-y-3">
          <h2 className="text-lg font-bold text-white">3. Medidas Técnicas y Organizativas (Anexo de Seguridad Art. 32 RGPD)</h2>
          <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-300">
            <li>
              <strong>Cifrado de credenciales:</strong> Todos los tokens OAuth y claves de tiendas se cifran en reposo
              mediante <code>AES-256-GCM</code> con claves rotables (`INTEGRATION_ENCRYPTION_KEY`).
            </li>
            <li>
              <strong>Pseudonimización de datos personales:</strong> Las direcciones IP y teléfonos en registros de
              control se almacenan mediante hash `HMAC-SHA256` con pepper aislado (`PRIVACY_HASH_PEPPER`).
            </li>
            <li>
              <strong>Aislamiento por empresa (RLS) y Control de Roles (RBAC):</strong> Cada fila en PostgreSQL está
              protegida por políticas Row Level Security y roles granulares (`owner`, `admin`, `agent`, `viewer`).
            </li>
            <li>
              <strong>Notificación de brechas de seguridad:</strong> En caso de incidente que afecte a datos
              personales, {SITE.brand} notificará al Responsable del Tratamiento sin dilación indebida y, como máximo, en{' '}
              <strong>48 horas</strong> desde su detección, para que pueda cumplir su propio plazo de 72 horas ante la autoridad de control.
            </li>
          </ul>
          <p className="pt-2 text-xs text-ink-400">
            Para solicitar una copia firmada electrónicamente de este DPA con los datos fiscales de tu empresa o
            hacer cualquier consulta sobre protección de datos, escribe a{' '}
            <a href={`mailto:${SITE.email}`} className="text-brand-300 underline">
              {SITE.email}
            </a>
            .
          </p>
        </section>
      </div>
    </main>
  );
}
