import { pageMetadata } from '@/lib/seo';
import { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { AuthForm } from '@/components/AuthForm';
import { AuthSkeleton } from '@/components/Skeleton';
import { getSessionUser } from '@/lib/auth';
import { resolvePlan } from '@/lib/plans';
import { getFreeTrialEnabled } from '@/lib/system-settings';

export const dynamic = 'force-dynamic';

export const metadata = pageMetadata('Crear cuenta', 'Crea tu cuenta de ReviewFlow AI para gestionar opiniones y elegir el plan de tu empresa.', undefined, false);

export default async function RegistroPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string }>;
}) {
  const sp = await searchParams;
  const user = await getSessionUser();
  if (user) {
    const planQuery = sp.plan ? `?plan=${resolvePlan(sp.plan)}` : '';
    redirect(`/bienvenido${planQuery}`);
  }

  const freeTrialEnabled = await getFreeTrialEnabled();

  return (
    <Suspense fallback={<AuthSkeleton />}>
      <AuthForm mode="signup" freeTrialEnabled={freeTrialEnabled} />
    </Suspense>
  );
}
