import { pageMetadata } from '@/lib/seo';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { requireSuperAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  isGeminiConfigured,
  isGoogleConfigured,
  isSmtpConfigured,
  isStripeConfigured,
  isStripeWebhookConfigured,
  isSupabaseConfigured,
  isSupabaseAdminConfigured,
  isSuperAdminConfigured,
} from '@/lib/env';
import { ADDON_CATALOG, DEFAULT_AI_MODEL, planOf } from '@/lib/plans';
import { addonPriceIdFor } from '@/lib/stripe';
import { getFreeTrialEnabled } from '@/lib/system-settings';
import { computeBusinessMetrics } from '@/lib/business-metrics';
import { hasPlaceholderSiteConfig } from '@/lib/site';
import type { AdminLogEntry } from '@/components/admin/use-admin-dashboard';
import { AdminClient, type AdminTenant } from './admin-client';

export const dynamic = 'force-dynamic';
export const metadata = pageMetadata('Administración', 'Área privada de administración de clientes, soporte y capacidad de ReviewFlow AI.', undefined, false);

type AdminStats = {
  tenants: number;
  activeSubscriptions: number;
  mrrCents: number;
  mrrFormatted: string;
  reviewsTotal: number;
  aiRepliesTotal: number;
  trialCount: number;
  aiTokensCycle: number;
  aiCostCycleUsd: number;
  aiFallbacksCycle: number;
  aiModel: string;
};

type AdminTenantQueryRow = {
  id: string;
  name: string;
  slug: string;
  owner_email: string;
  plan: string;
  subscription_status: string;
  stripe_customer_id?: string | null;
  suspended: boolean;
  created_at: string;
  extra_requests?: number;
  extra_reviews?: number;
  extra_ai?: number;
  extra_syncs?: number;
  extra_stored?: number;
};

/** MRR teórico de una empresa según plan + estado de la suscripción. */
function mrrFor(plan: string, status: string): number {
  if (status !== 'active') return 0;
  const p = planOf(plan);
  return p.priceCents;
}

export default async function AdminPage() {
  if (!isSupabaseConfigured || !isSupabaseAdminConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink-950 px-6 text-ink-100">
        <div className="card max-w-md space-y-4 text-center">
          <h1 className="text-2xl font-bold text-white">Base de datos no configurada</h1>
          <p className="text-sm text-ink-300">
            Configura las variables de Supabase y <code>SUPERADMIN_EMAILS</code> en tu entorno para acceder a Super-Admin.
          </p>
          <Link href="/" className="btn-secondary">Volver al inicio</Link>
        </div>
      </div>
    );
  }

  const guard = await requireSuperAdmin();
  if (!guard.ok) {
    redirect('/login?error=forbidden');
  }

  let tenants: AdminTenant[] = [];
  let stats: AdminStats = {
    tenants: 0,
    activeSubscriptions: 0,
    mrrCents: 0,
    mrrFormatted: '0,00 €',
    reviewsTotal: 0,
    aiRepliesTotal: 0,
    trialCount: 0,
    aiTokensCycle: 0,
    aiCostCycleUsd: 0,
    aiFallbacksCycle: 0,
    aiModel: DEFAULT_AI_MODEL,
  };
  let logs: AdminLogEntry[] = [];

  const admin = createAdminClient();
  if (admin) {
    try {
      const { data: t } = await admin
        .from('tenants')
        .select(
          'id, name, slug, owner_email, plan, subscription_status, stripe_customer_id, suspended, created_at, extra_requests, extra_reviews, extra_ai, extra_syncs, extra_stored',
        )
        .order('created_at', { ascending: false })
        .limit(200);

      const tenantRows = (t ?? []) as AdminTenantQueryRow[];
      if (tenantRows.length > 0) {
        const ids = tenantRows.map((x) => x.id);

        // Contadores de uso del ciclo actual (una sola consulta para todos).
        const { data: counters } = await admin
          .from('usage_counters')
          .select('tenant_id, reviews_ingested, ai_responses, whatsapp_sent, ai_tokens_in, ai_tokens_out, cycle')
          .in('tenant_id', ids);

        type CounterRow = {
          tenant_id: string;
          reviews_ingested?: number | null;
          ai_responses?: number | null;
          whatsapp_sent?: number | null;
          ai_tokens_in?: number | null;
          ai_tokens_out?: number | null;
        };
        const usedByTenant = new Map<string, number>();
        const tokensByTenant = new Map<string, number>();
        for (const c of (counters ?? []) as CounterRow[]) {
          usedByTenant.set(
            c.tenant_id,
            Number(c.reviews_ingested ?? 0) + Number(c.ai_responses ?? 0) + Number(c.whatsapp_sent ?? 0),
          );
          tokensByTenant.set(
            c.tenant_id,
            Number(c.ai_tokens_in ?? 0) + Number(c.ai_tokens_out ?? 0),
          );
        }

        // IA del ciclo por empresa (tokens, coste estimado y fallbacks).
        type AiUsageRow = {
          tenant_id: string;
          tokens_total: number;
          cost_usd_cycle: number;
          fallbacks_cycle: number;
          tokens_limit: number;
        };
        const aiByTenant = new Map<string, AiUsageRow>();
        try {
          const { data: aiRows } = await admin
            .from('v_ai_usage')
            .select('tenant_id, tokens_total, cost_usd_cycle, fallbacks_cycle, tokens_limit')
            .in('tenant_id', ids);
          for (const row of (aiRows ?? []) as AiUsageRow[]) aiByTenant.set(row.tenant_id, row);
        } catch {
          /* vista no migrada todavía */
        }

        // Reseñas y respuestas publicadas por empresa (counts paralelos).
        const withCounts = await Promise.all(
          tenantRows.map(async (tenant) => {
            const { count: reviews } = await admin
              .from('reviews')
              .select('id', { count: 'exact', head: true })
              .eq('tenant_id', tenant.id);
            const { count: replies } = await admin
              .from('reviews')
              .select('id', { count: 'exact', head: true })
              .eq('tenant_id', tenant.id)
              .not('reply_text', 'is', null);
            const ai = aiByTenant.get(tenant.id);
            return {
              ...tenant,
              reviews_count: reviews ?? 0,
              ai_replies_count: replies ?? 0,
              used_events: usedByTenant.get(tenant.id) ?? 0,
              ai_tokens_cycle: ai?.tokens_total ?? tokensByTenant.get(tenant.id) ?? 0,
              ai_tokens_limit: ai?.tokens_limit ?? planOf(tenant.plan).limits.aiTokensPerMonth,
              ai_cost_cycle: Number(ai?.cost_usd_cycle ?? 0),
              ai_fallbacks: Number(ai?.fallbacks_cycle ?? 0),
              mrr_cents: mrrFor(tenant.plan, tenant.subscription_status),
            } as AdminTenant;
          }),
        );

        tenants = withCounts;
        const mrr = tenants.reduce((a, x) => a + (x.mrr_cents ?? 0), 0);
        stats = {
          tenants: tenants.length,
          activeSubscriptions: tenants.filter((x) => x.subscription_status === 'active').length,
          mrrCents: mrr,
          mrrFormatted: `${(mrr / 100).toFixed(2).replace('.', ',')} €`,
          reviewsTotal: tenants.reduce((a, x) => a + (x.reviews_count ?? 0), 0),
          aiRepliesTotal: tenants.reduce((a, x) => a + (x.ai_replies_count ?? 0), 0),
          trialCount: tenants.filter((x) => x.subscription_status === 'trialing').length,
          aiTokensCycle: tenants.reduce((a, x) => a + Number(x.ai_tokens_cycle ?? 0), 0),
          aiCostCycleUsd: tenants.reduce((a, x) => a + Number(x.ai_cost_cycle ?? 0), 0),
          aiFallbacksCycle: tenants.reduce((a, x) => a + Number(x.ai_fallbacks ?? 0), 0),
          aiModel: DEFAULT_AI_MODEL,
        };
      }

      const { data: l } = await admin
        .from('system_logs')
        .select('id, created_at, level, source, message')
        .order('created_at', { ascending: false })
        .limit(100);
      if (l && l.length > 0) logs = l;
    } catch {
      /* noop */
    }
  }

  const integrations = [
    { name: 'Supabase (service_role)', ok: isSupabaseAdminConfigured, hint: 'BASE de datos y cuotas' },
    { name: 'SUPERADMIN_EMAILS', ok: isSuperAdminConfigured, hint: 'Acceso al panel interno' },
    { name: 'Stripe API', ok: isStripeConfigured, hint: 'Checkout, suscripciones y portal' },
    { name: 'Stripe Webhook', ok: isStripeWebhookConfigured, hint: 'Suscripciones + recargas' },
    ...ADDON_CATALOG.map((pack) => ({
      name: `Recarga · ${pack.name}`,
      ok: Boolean(addonPriceIdFor(pack.id)),
      hint: `${pack.priceEnv} (si no se define, se cobra ${pack.priceCents / 100} € con price_data)`,
    })),
    {
      name: 'SMTP / Resend correo',
      ok: isSmtpConfigured,
      hint: isSmtpConfigured
        ? 'Avisos transaccionales y resúmenes activos'
        : 'Pendiente de configurar RESEND_API_KEY o SMTP_PASS (los emails no se envían)',
    },
    {
      name: 'Datos fiscales (SITE)',
      ok: !hasPlaceholderSiteConfig(),
      hint: hasPlaceholderSiteConfig()
        ? 'Sustituye NEXT_PUBLIC_COMPANY_NAME, NEXT_PUBLIC_CIF y emails antes de facturar'
        : 'Datos fiscales y dominio configurados',
    },
    { name: 'Google Gemini (Gratis $0)', ok: isGeminiConfigured, hint: 'Sin ella: plantillas locales' },
    { name: 'Google OAuth (opcional)', ok: isGoogleConfigured, hint: 'Business Profile + publicación' },
  ];

  const freeTrialEnabled = await getFreeTrialEnabled();
  const businessMetrics = computeBusinessMetrics(tenants, logs);

  return (
    <AdminClient
      email={guard.email}
      tenants={tenants}
      stats={stats}
      logs={logs}
      integrations={integrations}
      initialFreeTrialEnabled={freeTrialEnabled}
      businessMetrics={businessMetrics}
    />
  );
}
