'use client';

import dynamic from 'next/dynamic';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BarChart3,
  Building2,
  CreditCard,
  FileText,
  Gauge,
  Activity,
  MessagesSquare,
  ShieldCheck,
} from 'lucide-react';
import type { BusinessMetricsSummary } from '@/lib/business-metrics';
import { Aurora, EASE } from '@/components/Motion';
import { TableSkeleton } from '@/components/Skeleton';
import { cn } from '@/lib/utils';
import {
  useAdminDashboard,
  type AdminLogEntry,
  type AdminTabId,
  type AdminTenant,
} from '@/components/admin/use-admin-dashboard';
import { AdminCapacitySection } from '@/components/admin/AdminCapacitySection';
import { AdminSupportSection } from '@/components/admin/AdminSupportSection';
import { AdminTopSummary } from '@/components/admin/AdminTopSummary';
import { AdminTenantsSection } from '@/components/admin/AdminTenantsSection';
import {
  AdminQuotaSection,
  AdminSubscriptionsSection,
} from '@/components/admin/AdminBillingSection';
import {
  AdminLogsSection,
  AdminSystemSection,
} from '@/components/admin/AdminIntegrationsSection';

const AdminMetricsSection = dynamic(
  () => import('@/components/admin/AdminMetricsSection').then((m) => m.AdminMetricsSection),
  { ssr: false, loading: () => <TableSkeleton rows={4} cols={3} /> },
);

export type { AdminTenant };

type Props = {
  email: string;
  tenants: AdminTenant[];
  stats: {
    tenants: number;
    activeSubscriptions: number;
    mrrCents: number;
    mrrFormatted: string;
    reviewsTotal: number;
    aiRepliesTotal: number;
    trialCount: number;
    aiTokensCycle?: number;
    aiCostCycleUsd?: number;
    aiFallbacksCycle?: number;
    aiModel?: string;
  };
  logs: AdminLogEntry[];
  integrations: Array<{ name: string; ok: boolean; hint?: string }>;
  initialFreeTrialEnabled: boolean;
  businessMetrics?: BusinessMetricsSummary;
};

const TABS: ReadonlyArray<{ id: AdminTabId; label: string; icon: typeof BarChart3 }> = [
  { id: 'metrics', label: 'Métricas de Negocio (BI)', icon: BarChart3 },
  { id: 'capacity', label: 'Capacidad en vivo', icon: Activity },
  { id: 'support', label: 'Chat soporte', icon: MessagesSquare },
  { id: 'tenants', label: 'Empresas', icon: Building2 },
  { id: 'subs', label: 'Suscripciones', icon: CreditCard },
  { id: 'quota', label: 'Cuotas y extras', icon: Gauge },
  { id: 'logs', label: 'Logs', icon: FileText },
  { id: 'system', label: 'Sistema', icon: ShieldCheck },
];

export function AdminClient({
  email,
  tenants,
  stats,
  logs,
  integrations,
  initialFreeTrialEnabled,
  businessMetrics,
}: Props) {
  const {
    tab,
    setTab,
    q,
    setQ,
    busy,
    busyRow,
    freeTrialEnabled,
    toggleFreeTrial,
    filtered,
    paginatedTenants,
    tenantPage,
    setTenantPage,
    tenantTotalPages,
    paginatedLogs,
    logPage,
    setLogPage,
    logTotalPages,
    totals,
    action,
    impersonate,
  } = useAdminDashboard({ tenants, logs, initialFreeTrialEnabled });

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-ink-950 text-ink-50">
      <Aurora />
      <AdminTopSummary
        email={email}
        integrations={integrations}
        freeTrialEnabled={freeTrialEnabled}
        busyRow={busyRow}
        toggleFreeTrial={toggleFreeTrial}
        stats={stats}
        totals={totals}
      />

      <main className="relative z-10 mx-auto max-w-6xl px-4 pb-8">
        <nav
          aria-label="Secciones de administración"
          className="mt-7 flex flex-wrap items-center gap-1 border-b border-white/[0.07]"
        >
          {TABS.map((t) => {
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'relative inline-flex items-center gap-1.5 px-3.5 py-2.5 text-sm font-semibold transition-colors',
                  active ? 'text-white' : 'text-ink-400 hover:text-ink-100',
                )}
              >
                <t.icon size={15} /> {t.label}
                {active && (
                  <motion.span
                    layoutId="admin-tab"
                    className="bg-brand-gradient absolute inset-x-2 -bottom-px h-0.5 rounded-full shadow-[0_0_14px_rgba(59,118,240,0.9)]"
                    transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                  />
                )}
              </button>
            );
          })}
        </nav>

        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.25, ease: EASE }}
            className="mt-5"
          >
            {tab === 'metrics' && businessMetrics && (
              <AdminMetricsSection businessMetrics={businessMetrics} />
            )}

            {tab === 'capacity' && <AdminCapacitySection />}

            {tab === 'support' && <AdminSupportSection onImpersonate={(id) => impersonate(id, 'Asistencia solicitada por el cliente desde el chat de soporte', `chat-${id.slice(0, 8)}`)} />}

            {tab === 'tenants' && (
              <AdminTenantsSection
                filteredCount={filtered.length}
                paginatedTenants={paginatedTenants}
                q={q}
                onSearchChange={setQ}
                page={tenantPage}
                totalPages={tenantTotalPages}
                onPageChange={setTenantPage}
                busy={busy}
                busyRow={busyRow}
                onImpersonate={impersonate}
                onAction={action}
              />
            )}

            {tab === 'subs' && (
              <AdminSubscriptionsSection
                filtered={filtered}
                busy={busy}
                busyRow={busyRow}
                onAction={action}
              />
            )}

            {tab === 'quota' && (
              <AdminQuotaSection
                tenantsCount={tenants.length}
                filtered={filtered}
                totals={totals}
              />
            )}

            {tab === 'logs' && (
              <AdminLogsSection
                totalLogsCount={logs.length}
                paginatedLogs={paginatedLogs}
                page={logPage}
                totalPages={logTotalPages}
                onPageChange={setLogPage}
              />
            )}

            {tab === 'system' && (
              <AdminSystemSection
                integrations={integrations}
                busy={busy}
                busyRow={busyRow}
                freeTrialEnabled={freeTrialEnabled}
                onToggleFreeTrial={toggleFreeTrial}
                onAction={action}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
