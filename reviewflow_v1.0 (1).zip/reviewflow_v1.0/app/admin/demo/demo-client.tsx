'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ArrowLeft,
  BarChart3,
  Bot,
  Check,
  Lock,
  MessageSquareText,
  MonitorPlay,
  Plug,
  RotateCcw,
  Send,
  ShieldAlert,
  Sparkles,
  Star,
  TrendingUp,
} from 'lucide-react';
import { PLAN_CATALOG, type PlanDefinition, type PlanFeatures } from '@/lib/plans';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/* Datos ficticios                                                     */
/* ------------------------------------------------------------------ */

type DemoReview = {
  id: number;
  author: string;
  rating: number;
  source: 'Google' | 'Trustpilot' | 'Tienda';
  text: string;
  date: string;
  reply?: string;
  status: 'pendiente' | 'borrador' | 'publicada' | 'privada';
};

const DEMO_BUSINESS = { local: 'Restaurante La Brasa (demo)', ecommerce: 'Moda Nórdica Shop (demo)' };

const SEED: DemoReview[] = [
  { id: 1, author: 'Laura G.', rating: 5, source: 'Google', date: 'hace 2 h', status: 'pendiente', text: 'Atención de 10, volveremos seguro. El personal fue muy amable.' },
  { id: 2, author: 'Carlos M.', rating: 2, source: 'Google', date: 'hace 5 h', status: 'pendiente', text: 'Tardaron 40 minutos en atendernos y la comida llegó fría.' },
  { id: 3, author: 'Ana P.', rating: 4, source: 'Trustpilot', date: 'ayer', status: 'pendiente', text: 'Muy buena experiencia, aunque el precio es algo elevado.' },
  { id: 4, author: 'Jordi R.', rating: 1, source: 'Tienda', date: 'ayer', status: 'pendiente', text: 'El pedido llegó incompleto y nadie responde al correo.' },
  { id: 5, author: 'Marta S.', rating: 5, source: 'Google', date: 'hace 2 días', status: 'publicada', text: 'Increíble, lo recomiendo a todo el mundo.', reply: '¡Gracias, Marta! Nos alegra muchísimo que lo recomiendes. ¡Te esperamos pronto!' },
];

function aiReply(r: DemoReview, business: string): string {
  const name = r.author.split(' ')[0];
  if (r.rating >= 4)
    return `¡Muchas gracias, ${name}! Nos encanta saber que disfrutaste de tu experiencia en ${business.replace(' (demo)', '')}. Comentarios como el tuyo motivan a todo el equipo. ¡Te esperamos pronto!`;
  if (r.rating === 3)
    return `Gracias por tu opinión, ${name}. Tomamos nota de lo que comentas para seguir mejorando. Nos encantaría volver a verte y superar tus expectativas.`;
  return `Hola ${name}, sentimos mucho lo ocurrido. No es la experiencia que queremos ofrecer. Te hemos escrito por privado para solucionarlo cuanto antes. Gracias por darnos la oportunidad de mejorar.`;
}

const FEATURE_LABELS: Array<[keyof PlanFeatures, string]> = [
  ['emailRequests', 'Peticiones de opinión por email'],
  ['feedbackFunnel', 'Embudo neutral de valoración'],
  ['aiReplies', 'Respuestas con IA'],
  ['privateFilter', 'Filtro privado de quejas (≤3★)'],
  ['googleBusiness', 'Google Business Profile'],
  ['publishToGoogle', 'Publicar respuesta en Google'],
  ['trustpilot', 'Trustpilot'],
  ['mapsLinks', 'Enlaces de Google Maps'],
  ['storeIntegration', 'Shopify / WooCommerce / TPV'],
  ['publicApi', 'API pública'],
];

type TabId = 'resumen' | 'opiniones' | 'embudo' | 'analitica' | 'integraciones';
const TABS: Array<{ id: TabId; label: string; icon: typeof Star }> = [
  { id: 'resumen', label: 'Resumen', icon: MonitorPlay },
  { id: 'opiniones', label: 'Opiniones', icon: MessageSquareText },
  { id: 'embudo', label: 'Embudo', icon: Send },
  { id: 'analitica', label: 'Analítica', icon: BarChart3 },
  { id: 'integraciones', label: 'Integraciones', icon: Plug },
];

const fmt = (n: number) => (n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)}M` : n.toLocaleString('es-ES'));

/* ------------------------------------------------------------------ */

export function DemoClient() {
  const [planId, setPlanId] = useState<PlanDefinition['id']>(PLAN_CATALOG[2]?.id ?? PLAN_CATALOG[0].id);
  const plan = PLAN_CATALOG.find((p) => p.id === planId) ?? PLAN_CATALOG[0];
  const business = DEMO_BUSINESS[plan.category];
  const [tab, setTab] = useState<TabId>('resumen');
  const [reviews, setReviews] = useState<DemoReview[]>(SEED);
  const [used, setUsed] = useState({ requests: 214, reviews: 87, ai: 31 });
  const [toast, setToast] = useState<string | null>(null);
  const [funnelStep, setFunnelStep] = useState<0 | 1 | 2>(0);
  const [funnelRating, setFunnelRating] = useState(0);

  const notify = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2600);
  };

  const reset = () => {
    setReviews(SEED);
    setUsed({ requests: 214, reviews: 87, ai: 31 });
    setFunnelStep(0);
    setFunnelRating(0);
    notify('Demo reiniciada');
  };

  const avg = useMemo(() => reviews.reduce((a, r) => a + r.rating, 0) / reviews.length, [reviews]);
  const answered = reviews.filter((r) => r.status === 'publicada').length;

  const generate = (id: number) => {
    if (!plan.features.aiReplies) return notify('Tu plan no incluye respuestas con IA');
    if (used.ai >= plan.limits.aiRepliesPerMonth) return notify('Cuota de IA agotada — ofrece una recarga');
    setReviews((rs) => rs.map((r) => (r.id === id ? { ...r, reply: aiReply(r, business), status: 'borrador' } : r)));
    setUsed((u) => ({ ...u, ai: u.ai + 1 }));
    notify('Borrador generado con IA (simulado)');
  };
  const publish = (id: number) => {
    setReviews((rs) => rs.map((r) => (r.id === id ? { ...r, status: 'publicada' } : r)));
    notify(plan.features.publishToGoogle ? 'Publicada en Google (simulado)' : 'Respuesta guardada (copiar y pegar en Google)');
  };
  const privatize = (id: number) => {
    setReviews((rs) => rs.map((r) => (r.id === id ? { ...r, status: 'privada' } : r)));
    notify('Queja derivada a gestión privada (simulado)');
  };
  const sendRequest = () => {
    if (used.requests >= plan.limits.requestsPerMonth) return notify('Cuota de peticiones agotada');
    setUsed((u) => ({ ...u, requests: u.requests + 25 }));
    notify('25 peticiones de opinión enviadas (simulado)');
  };

  return (
    <div className="relative min-h-screen bg-ink-950 text-ink-50">
      {/* Banda de aviso */}
      <div className="sticky top-0 z-30 border-b border-amber-400/30 bg-amber-500/15 px-4 py-2 text-center text-xs font-semibold text-amber-200 backdrop-blur">
        MODO DEMOSTRACIÓN · datos ficticios · nada se guarda, cobra ni publica de verdad
      </div>

      <header className="border-b border-white/[0.07]">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4">
          <div className="flex items-center gap-3">
            <Link href="/admin" className="btn-secondary btn-sm">
              <ArrowLeft size={15} /> Admin
            </Link>
            <div>
              <h1 className="text-lg font-bold text-white">{business}</h1>
              <p className="text-xs text-ink-400">Panel del cliente · simulador comercial</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="text-xs text-ink-400" htmlFor="demo-plan">Plan simulado</label>
            <select
              id="demo-plan"
              value={planId}
              onChange={(e) => setPlanId(e.target.value as PlanDefinition['id'])}
              className="rounded-lg border border-white/10 bg-ink-900 px-3 py-1.5 text-sm text-white"
            >
              {PLAN_CATALOG.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} · {p.price}/mes
                </option>
              ))}
            </select>
            <button type="button" onClick={reset} className="btn-secondary btn-sm">
              <RotateCcw size={15} /> Reiniciar
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-16">
        <nav className="mt-6 flex flex-wrap gap-1 border-b border-white/[0.07]">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                'relative inline-flex items-center gap-1.5 px-3.5 py-2.5 text-sm font-semibold',
                tab === t.id ? 'text-white' : 'text-ink-400 hover:text-ink-100',
              )}
            >
              <t.icon size={15} /> {t.label}
              {tab === t.id && <span className="bg-brand-gradient absolute inset-x-2 -bottom-px h-0.5 rounded-full" />}
            </button>
          ))}
        </nav>

        <AnimatePresence mode="wait">
          <motion.div key={tab + planId} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-6">
            {tab === 'resumen' && (
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <Kpi label="Nota media" value={avg.toFixed(1) + ' ★'} hint="+0,4 este mes" />
                  <Kpi label="Opiniones" value={String(reviews.length + 142)} hint="+18% vs. mes anterior" />
                  <Kpi label="Respondidas" value={`${Math.round(((answered + 120) / (reviews.length + 142)) * 100)}%`} hint="Tiempo medio 12 min" />
                  <Kpi label="Quejas filtradas" value={String(reviews.filter((r) => r.status === 'privada').length + 9)} hint="No llegaron a Google" />
                </div>
                <div className="grid gap-4 lg:grid-cols-2">
                  <div className="card space-y-4">
                    <h2 className="font-bold text-white">Uso del ciclo</h2>
                    <Usage label="Peticiones enviadas" used={used.requests} max={plan.limits.requestsPerMonth} />
                    <Usage label="Opiniones importadas" used={used.reviews} max={plan.limits.reviewsPerMonth} />
                    <Usage label="Respuestas IA" used={used.ai} max={plan.limits.aiRepliesPerMonth} />
                  </div>
                  <div className="card">
                    <h2 className="mb-1 font-bold text-white">Qué incluye {plan.name}</h2>
                    <p className="mb-4 text-sm text-ink-400">{plan.pitch}</p>
                    <ul className="grid gap-2 text-sm">
                      {FEATURE_LABELS.map(([k, label]) => {
                        const on = Boolean(plan.features[k]);
                        return (
                          <li key={k} className={cn('flex items-center gap-2', on ? 'text-ink-100' : 'text-ink-500')}>
                            {on ? <Check size={15} className="text-emerald-400" /> : <Lock size={14} />} {label}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {tab === 'opiniones' && (
              <div className="space-y-4">
                {reviews.map((r) => (
                  <div key={r.id} className="card space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <strong className="text-white">{r.author}</strong>
                        <Stars n={r.rating} />
                        <span className="badge">{r.source}</span>
                        <span className="text-xs text-ink-500">{r.date}</span>
                      </div>
                      <span className={cn('badge', r.status === 'publicada' ? 'badge-ok' : r.status === 'privada' ? 'badge-danger' : r.status === 'borrador' ? 'badge-brand' : 'badge-warn')}>
                        {r.status}
                      </span>
                    </div>
                    <p className="text-sm text-ink-200">{r.text}</p>
                    {r.reply && (
                      <div className="rounded-lg border border-white/10 bg-white/[0.03] p-3 text-sm text-ink-100">
                        <div className="mb-1 flex items-center gap-1 text-xs font-semibold text-brand-300"><Bot size={13} /> Respuesta</div>
                        {r.reply}
                      </div>
                    )}
                    {r.status !== 'publicada' && r.status !== 'privada' && (
                      <div className="flex flex-wrap gap-2">
                        <Gate on={plan.features.aiReplies}>
                          <button type="button" onClick={() => generate(r.id)} className="btn-primary btn-sm"><Sparkles size={14} /> Generar con IA</button>
                        </Gate>
                        {r.reply && <button type="button" onClick={() => publish(r.id)} className="btn-secondary btn-sm"><Send size={14} /> Publicar</button>}
                        {r.rating <= 3 && (
                          <Gate on={plan.features.privateFilter}>
                            <button type="button" onClick={() => privatize(r.id)} className="btn-secondary btn-sm"><ShieldAlert size={14} /> Gestionar en privado</button>
                          </Gate>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {tab === 'embudo' && (
              <div className="grid gap-6 lg:grid-cols-2">
                <div className="card space-y-4">
                  <h2 className="font-bold text-white">Pedir opiniones a clientes</h2>
                  <p className="text-sm text-ink-400">Envía un email o muestra un QR. El cliente valora y, según la nota, va a Google o a un formulario privado.</p>
                  <button type="button" onClick={sendRequest} className="btn-primary"><Send size={15} /> Enviar campaña (25 clientes)</button>
                  <Usage label="Peticiones enviadas" used={used.requests} max={plan.limits.requestsPerMonth} />
                </div>
                <div className="card">
                  <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-500">Vista del cliente final</p>
                  {!plan.features.feedbackFunnel ? (
                    <Locked />
                  ) : funnelStep === 0 ? (
                    <div className="space-y-4 text-center">
                      <p className="font-semibold text-white">¿Qué tal tu experiencia en {business.replace(' (demo)', '')}?</p>
                      <div className="flex justify-center gap-2">
                        {[1, 2, 3, 4, 5].map((n) => (
                          <button key={n} type="button" aria-label={`${n} estrellas`} onClick={() => { setFunnelRating(n); setFunnelStep(n >= 4 ? 2 : 1); }}>
                            <Star size={32} className="text-amber-400 hover:fill-amber-400" />
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : funnelStep === 1 ? (
                    <div className="space-y-3">
                      <p className="font-semibold text-white">Sentimos que no haya ido bien ({funnelRating}★)</p>
                      <textarea className="w-full rounded-lg border border-white/10 bg-ink-900 p-2 text-sm" rows={3} placeholder="Cuéntanos qué pasó…" />
                      <button type="button" className="btn-primary btn-sm" onClick={() => { notify('Queja recibida en privado: no llega a Google'); setFunnelStep(0); }}>Enviar al negocio</button>
                    </div>
                  ) : (
                    <div className="space-y-3 text-center">
                      <p className="font-semibold text-white">¡Gracias! ({funnelRating}★)</p>
                      <p className="text-sm text-ink-400">¿Nos ayudas compartiéndolo en Google?</p>
                      <button type="button" className="btn-primary btn-sm" onClick={() => { notify('El cliente abre Google Maps (simulado)'); setFunnelStep(0); }}>Dejar opinión en Google</button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {tab === 'analitica' && (
              <div className="grid gap-6 lg:grid-cols-2">
                <div className="card">
                  <h2 className="mb-4 flex items-center gap-2 font-bold text-white"><TrendingUp size={16} /> Evolución de la nota</h2>
                  <div className="flex h-40 items-end gap-2">
                    {[3.9, 4.0, 4.1, 4.1, 4.3, 4.4, 4.5, 4.6].map((v, i) => (
                      <div key={i} className="flex flex-1 flex-col items-center gap-1">
                        <div className="bg-brand-gradient w-full rounded-t" style={{ height: `${(v - 3.5) * 100}px` }} />
                        <span className="text-2xs text-ink-500">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="card space-y-3">
                  <h2 className="font-bold text-white">Temas detectados por IA</h2>
                  {[['Atención del personal', 82, true], ['Rapidez', 54, false], ['Precio', 61, false], ['Calidad', 77, true]].map(([t, v, pos]) => (
                    <div key={String(t)}>
                      <div className="mb-1 flex justify-between text-sm"><span>{t}</span><span className={pos ? 'text-emerald-400' : 'text-amber-400'}>{v}% positivo</span></div>
                      <div className="h-2 rounded-full bg-white/10"><div className="h-2 rounded-full bg-brand-gradient" style={{ width: `${v}%` }} /></div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === 'integraciones' && (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {([
                  ['Google Business Profile', 'googleBusiness'],
                  ['Google Places', 'googlePlaces'],
                  ['Trustpilot', 'trustpilot'],
                  ['Shopify / WooCommerce', 'storeIntegration'],
                  ['API pública', 'publicApi'],
                  ['Email de peticiones', 'emailRequests'],
                ] as Array<[string, keyof PlanFeatures]>).map(([name, k]) => {
                  const on = Boolean(plan.features[k]);
                  return (
                    <div key={k} className="card flex items-center justify-between">
                      <span className={on ? 'text-white' : 'text-ink-500'}>{name}</span>
                      {on ? (
                        <button type="button" className="btn-secondary btn-sm" onClick={() => notify(`${name} conectado (simulado)`)}>Conectar</button>
                      ) : (
                        <span className="badge"><Lock size={12} /> Plan superior</span>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="fixed bottom-6 left-1/2 z-40 -translate-x-1/2 rounded-xl border border-white/10 bg-ink-900 px-4 py-2.5 text-sm text-white shadow-xl">
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="card">
      <p className="text-xs text-ink-400">{label}</p>
      <p className="mt-1 text-2xl font-bold text-white">{value}</p>
      <p className="mt-1 text-xs text-emerald-400">{hint}</p>
    </div>
  );
}

function Usage({ label, used, max }: { label: string; used: number; max: number }) {
  const pct = Math.min(100, (used / Math.max(1, max)) * 100);
  return (
    <div>
      <div className="mb-1 flex justify-between text-sm"><span>{label}</span><span className="text-ink-400">{fmt(used)} / {fmt(max)}</span></div>
      <div className="h-2 rounded-full bg-white/10"><div className={cn('h-2 rounded-full', pct > 90 ? 'bg-red-500' : 'bg-brand-gradient')} style={{ width: `${pct}%` }} /></div>
    </div>
  );
}

function Stars({ n }: { n: number }) {
  return (
    <span className="flex">
      {[1, 2, 3, 4, 5].map((i) => <Star key={i} size={13} className={i <= n ? 'fill-amber-400 text-amber-400' : 'text-ink-600'} />)}
    </span>
  );
}

function Gate({ on, children }: { on: boolean; children: React.ReactNode }) {
  if (on) return <>{children}</>;
  return <span className="badge"><Lock size={12} /> Disponible en plan superior</span>;
}

function Locked() {
  return (
    <div className="flex flex-col items-center gap-2 py-8 text-center text-ink-400">
      <Lock size={22} /> Esta función está disponible en un plan superior.
    </div>
  );
}
