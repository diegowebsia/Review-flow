import { pageMetadata } from '@/lib/seo';
import { redirect } from 'next/navigation';
import { requireSuperAdmin } from '@/lib/auth';
import { isSupabaseConfigured } from '@/lib/env';
import { DemoClient } from './demo-client';

export const dynamic = 'force-dynamic';
export const metadata = pageMetadata('Simulador comercial', 'Simulador privado de ReviewFlow AI con datos ficticios para administración.', undefined, false);

/**
 * Zona de pruebas (simulador) SOLO para super-admin.
 * Todo funciona con datos ficticios en memoria: no lee ni escribe en la base
 * de datos, no llama a la IA real, no cobra en Stripe ni publica en Google.
 * Doble protección: middleware (`proxy.ts`, /admin/*) + `requireSuperAdmin()`.
 */
export default async function DemoPage() {
  if (isSupabaseConfigured) {
    const guard = await requireSuperAdmin();
    if (!guard.ok) redirect('/login?error=forbidden');
  } else if (process.env.NODE_ENV === 'production') {
    redirect('/login?error=forbidden');
  }
  return <DemoClient />;
}
