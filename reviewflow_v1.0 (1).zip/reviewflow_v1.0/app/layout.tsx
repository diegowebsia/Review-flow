import type { Metadata, Viewport } from 'next';
import { Inter, Space_Grotesk } from 'next/font/google';
import './globals.css';
import { ToastProvider } from '@/components/Toast';
import { ConsentProvider } from '@/lib/consent';
import { I18nProvider } from '@/lib/i18n';
import { CookieBanner } from '@/components/CookieBanner';
import { ThirdPartyScripts } from '@/components/ThirdPartyScripts';
import { ObservabilityBoundary } from '@/components/ObservabilityBoundary';
import { SITE } from '@/lib/site';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-sans',
});

/* Solo para titulares del panel (font-display). */
const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-display',
});

export const metadata: Metadata = {
  ...(SITE.url !== 'https://invalid.example' ? { metadataBase: new URL(SITE.url) } : {}),
  title: {
    default: `${SITE.brand} — Gestiona y responde reseñas con IA`,
    template: `%s · ${SITE.brand}`,
  },
  description:
    'Plataforma SaaS multi-tenant para centralizar reseñas de Google, Trustpilot y tus tiendas y responderlas automáticamente con IA. Cuotas reales, add-ons de ampliación y cumplimiento RGPD.',
  keywords: [
    'gestión de reseñas',
    'respuestas con IA',
    'Google Business Profile',
    'Trustpilot',
    'reputación online',
  ],
  applicationName: SITE.brand,
  manifest: '/manifest.webmanifest',
  authors: [{ name: SITE.brand }],
  openGraph: {
    title: `${SITE.brand} — Todas tus reseñas, respondidas con IA`,
    description:
      'Centraliza Google, Trustpilot y tus tiendas en una sola bandeja y responde en segundos con el tono de tu marca.',
    type: 'website',
    locale: 'es_ES',
    siteName: SITE.brand,
    images: [
      {
        url: '/opengraph-image',
        width: 1200,
        height: 630,
        alt: `${SITE.brand} — Gestión de Reputación Online con IA`,
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    images: ['/opengraph-image'],
  },
  icons: {
    icon: '/favicon.svg',
    apple: '/favicon.svg',
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#F8FAFC' },
    { media: '(prefers-color-scheme: dark)', color: '#090D16' },
  ],
  colorScheme: 'dark light',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={`dark ${inter.variable} ${spaceGrotesk.variable}`} suppressHydrationWarning>
      <body className="min-h-screen bg-ink-950 font-sans text-ink-100 antialiased transition-colors duration-200">
        <I18nProvider>
          <ToastProvider>
            <ConsentProvider>
              <ObservabilityBoundary />
              {children}
              <CookieBanner />
              <ThirdPartyScripts />
            </ConsentProvider>
          </ToastProvider>
        </I18nProvider>
      </body>
    </html>
  );
}
