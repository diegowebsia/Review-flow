import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { safeInternalRedirect } from '@/lib/security';
import { resolvePublicUrl } from '@/lib/public-url';

export const dynamic = 'force-dynamic';

/**
 * GET /auth/callback
 * Intercambia el código de confirmación de Supabase Auth por una sesión activa
 * y redirige al onboarding de selección y pago de plan (/bienvenido).
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const next = safeInternalRedirect(url.searchParams.get('next') ?? '/bienvenido');

  // Enlaces propios (invitación al equipo, recuperación): token_hash + type.
  const tokenHash = url.searchParams.get('token_hash');
  const otpType = url.searchParams.get('type');
  const allowedTypes = ['invite', 'recovery', 'magiclink', 'email', 'signup', 'email_change'] as const;
  if (tokenHash && otpType && (allowedTypes as readonly string[]).includes(otpType)) {
    try {
      const supabase = await createClient();
      const { error } = await supabase.auth.verifyOtp({
        token_hash: tokenHash,
        type: otpType as (typeof allowedTypes)[number],
      });
      if (error) {
        return NextResponse.redirect(new URL('/login?reason=link-expired', resolvePublicUrl(req)));
      }
    } catch {
      return NextResponse.redirect(new URL('/login?reason=link-expired', resolvePublicUrl(req)));
    }
  } else if (code) {
    try {
      const supabase = await createClient();
      await supabase.auth.exchangeCodeForSession(code);
    } catch {
      /* Si el código expiró, el usuario podrá entrar desde /login */
    }
  }

  return NextResponse.redirect(new URL(next, resolvePublicUrl(req)));
}
