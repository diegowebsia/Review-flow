'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  Printer,
  Sparkles,
  ArrowLeft,
  QrCode,
  Layout,
  Building2,
  Star,
} from 'lucide-react';

type Props = {
  slug: string;
  businessName: string;
  qrDataUrl: string;
  targetUrl: string;
  campaign?: string;
};

export default function CartelClient({
  slug: _slug,
  businessName,
  qrDataUrl,
  targetUrl,
  campaign,
}: Props) {
  const [format, setFormat] = useState<'a4' | 'a5' | 'sticker'>('a4');
  const [headline, setHeadline] = useState('¿Qué te ha parecido la experiencia?');
  const [subline, setSubline] = useState(
    'Escanea con la cámara de tu móvil para dejarnos tu valoración en 10 segundos.',
  );
  const [callout, setCallout] = useState('¡Tu opinión nos ayuda a seguir mejorando!');
  const [includeStars, setIncludeStars] = useState(true);

  function handlePrint() {
    window.print();
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 print:bg-white print:text-slate-900">
      {/* Barra de control superior (OCULTA AL IMPRIMIR) */}
      <header className="nav-blur sticky top-0 z-50 w-full border-b border-white/10 bg-slate-900/80 backdrop-blur-lg transition-all duration-300 print:hidden">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-3">
            <Link
              href="/dashboard?tab=embudo"
              className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition hover:bg-white/10 hover:text-white"
            >
              <ArrowLeft size={14} /> Panel
            </Link>
            <div>
              <h1 className="text-sm font-semibold text-white flex items-center gap-2">
                Cartelería física lista para imprimir
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-2xs font-medium text-emerald-300">
                  A4 / A5 / Adhesivo
                </span>
              </h1>
              <p className="text-2xs text-slate-400">
                {businessName} {campaign ? `· Campaña: ${campaign}` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex rounded-lg border border-white/10 bg-white/5 p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setFormat('a4')}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 font-medium transition ${
                  format === 'a4'
                    ? 'bg-brand-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                A4 Mostrador
              </button>
              <button
                type="button"
                onClick={() => setFormat('a5')}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 font-medium transition ${
                  format === 'a5'
                    ? 'bg-brand-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                A5 Mesa
              </button>
              <button
                type="button"
                onClick={() => setFormat('sticker')}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 font-medium transition ${
                  format === 'sticker'
                    ? 'bg-brand-500 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Adhesivo
              </button>
            </div>

            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-md transition hover:bg-emerald-500 active:scale-95"
            >
              <Printer size={14} /> Imprimir / Guardar PDF
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-8 print:p-0">
        <div className="grid gap-8 lg:grid-cols-[320px_1fr] print:block">
          {/* Panel de personalización lateral (OCULTO AL IMPRIMIR) */}
          <aside className="space-y-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-xs print:hidden">
            <div className="flex items-center gap-2 border-b border-white/10 pb-3 font-semibold text-white">
              <Layout size={15} className="text-brand-400" /> Personalizar cartel
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Titular del cartel</label>
              <input
                type="text"
                value={headline}
                onChange={(e) => setHeadline(e.target.value)}
                maxLength={60}
                className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-white placeholder-slate-500 focus:border-brand-400 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Subtítulo explicativo</label>
              <textarea
                value={subline}
                onChange={(e) => setSubline(e.target.value)}
                maxLength={120}
                rows={2}
                className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-white placeholder-slate-500 focus:border-brand-400 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-slate-300 font-medium">Mensaje de cierre</label>
              <input
                type="text"
                value={callout}
                onChange={(e) => setCallout(e.target.value)}
                maxLength={60}
                className="w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-white placeholder-slate-500 focus:border-brand-400 focus:outline-none"
              />
            </div>

            <div className="pt-2">
              <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeStars}
                  onChange={(e) => setIncludeStars(e.target.checked)}
                  className="rounded border-white/20 bg-black/40 text-brand-500 focus:ring-0"
                />
                Mostrar 5 estrellas de confianza
              </label>
            </div>

            <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/[0.05] p-3 text-slate-300 space-y-1.5">
              <div className="flex items-center gap-1.5 font-semibold text-emerald-400">
                <Sparkles size={14} /> Listo para producción
              </div>
              <p className="text-2xs text-slate-400 leading-relaxed">
                Pulsa en <strong>Imprimir / Guardar PDF</strong> y selecciona &quot;Guardar como PDF&quot;
                o tu impresora física. Se ajusta automáticamente al papel sin cabeceras web.
              </p>
            </div>

            <div className="pt-1">
              <a
                href={targetUrl}
                target="_blank"
                rel="noopener"
                className="flex items-center justify-center gap-1.5 w-full rounded-lg border border-white/10 bg-white/5 py-2 text-2xs font-medium text-slate-300 hover:bg-white/10 hover:text-white"
              >
                <QrCode size={13} /> Probar enlace de valoración
              </a>
            </div>
          </aside>

          {/* Hoja de impresión (LO QUE SE IMPRIME O VE EN PREVIEW) */}
          <section className="flex justify-center print:block print:w-full">
            <div
              id="printable-sign"
              className={`relative flex flex-col justify-between overflow-hidden bg-white text-slate-900 transition-all ${
                format === 'a4'
                  ? 'h-[842px] w-[595px] p-12 shadow-2xl rounded-2xl print:rounded-none print:shadow-none print:h-screen print:w-screen print:p-14'
                  : format === 'a5'
                    ? 'h-[595px] w-[420px] p-8 shadow-2xl rounded-2xl print:rounded-none print:shadow-none print:h-screen print:w-screen print:p-10'
                    : 'h-[360px] w-[360px] p-6 shadow-2xl rounded-2xl print:rounded-none print:shadow-none print:h-screen print:w-screen print:p-8'
              }`}
            >
              {/* Marco elegante de borde interior */}
              <div className="absolute inset-3 border-2 border-slate-900/10 rounded-xl pointer-events-none print:inset-4 print:border-slate-900/15" />

              {/* Encabezado del negocio */}
              <div className="text-center pt-2">
                <div className="inline-flex items-center gap-2 rounded-full border border-slate-900/10 bg-slate-50 px-3 py-1 text-2xs font-bold uppercase tracking-wider text-slate-700">
                  <Building2 size={12} className="text-brand-600" />
                  {businessName}
                </div>

                <h2
                  className={`mt-4 font-bold tracking-tight text-slate-900 ${
                    format === 'a4'
                      ? 'text-3xl'
                      : format === 'a5'
                        ? 'text-2xl'
                        : 'text-lg'
                  }`}
                >
                  {headline}
                </h2>

                {includeStars && (
                  <div className="mt-3 flex justify-center gap-1 text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={format === 'a4' ? 24 : format === 'a5' ? 20 : 16}
                        className="fill-amber-400 stroke-amber-500"
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Código QR Central con marco de alto contraste */}
              <div className="my-auto flex flex-col items-center justify-center">
                <div className="rounded-2xl border-4 border-slate-900 p-3 shadow-md bg-white">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={qrDataUrl}
                    alt={`Código QR para valorar ${businessName}`}
                    className={`object-contain ${
                      format === 'a4'
                        ? 'h-64 w-64'
                        : format === 'a5'
                          ? 'h-48 w-48'
                          : 'h-36 w-36'
                    }`}
                  />
                </div>

                <p
                  className={`mt-4 max-w-sm text-center font-medium text-slate-600 leading-snug ${
                    format === 'a4'
                      ? 'text-sm'
                      : format === 'a5'
                        ? 'text-xs'
                        : 'text-2xs'
                  }`}
                >
                  {subline}
                </p>
              </div>

              {/* Pie de cartel */}
              <div className="border-t border-slate-100 pt-3 text-center pb-1">
                <p
                  className={`font-semibold text-slate-800 ${
                    format === 'a4' ? 'text-sm' : 'text-xs'
                  }`}
                >
                  {callout}
                </p>
                <p className="mt-1 text-3xs uppercase tracking-widest text-slate-400">
                  Opiniones verificadas · Gracias por tu apoyo
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>

      {/* Reglas de impresión para asegurar 0 márgenes indeseados y tamaño de hoja limpio */}
      <style jsx global>{`
        @media print {
          @page {
            size: auto;
            margin: 0mm;
          }
          body {
            background-color: white !important;
            color: black !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          header,
          aside {
            display: none !important;
          }
          #printable-sign {
            margin: auto !important;
            max-width: 100vw !important;
            max-height: 100vh !important;
            box-shadow: none !important;
            border-radius: 0 !important;
          }
        }
      `}</style>
    </div>
  );
}
