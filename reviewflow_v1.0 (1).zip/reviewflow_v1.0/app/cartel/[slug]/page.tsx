import { pageMetadata } from '@/lib/seo';
import { notFound } from 'next/navigation';
import { headers } from 'next/headers';
import type { Metadata } from 'next';
import QRCode from 'qrcode';
import { createAdminClient } from '@/lib/supabase/admin';
import { normalizeCampaign } from '@/lib/campaign';
import { resolvePublicUrl } from '@/lib/public-url';
import CartelClient from './cartel-client';

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ campaign?: string }>;
};

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  return pageMetadata(`Cartel para imprimir · ${slug}`, 'Genera e imprime un cartel con código QR para tu negocio en ReviewFlow AI.', undefined, false);
}

export default async function CartelPage({ params, searchParams }: Props) {
  const [{ slug }, query, hdrs] = await Promise.all([params, searchParams, headers()]);
  const campaign = normalizeCampaign(query.campaign) ?? undefined;

  const baseUrl = resolvePublicUrl(hdrs);

  let targetUrl = `${baseUrl}/valorar/${encodeURIComponent(slug)}`;
  if (campaign) {
    targetUrl += `?campaign=${encodeURIComponent(campaign)}`;
  }

  const admin = createAdminClient();
  if (!admin) notFound();

  const { data: tenant } = await admin
    .from('tenants')
    .select('id, name, slug, settings')
    .eq('slug', slug)
    .single();

  if (!tenant) notFound();

  const businessName = tenant.name;

  const qrDataUrl = await QRCode.toDataURL(targetUrl, {
    errorCorrectionLevel: 'H',
    margin: 1,
    width: 512,
    color: { dark: '#0f172a', light: '#ffffff' },
  });

  return (
    <CartelClient
      slug={tenant.slug}
      businessName={businessName}
      qrDataUrl={qrDataUrl}
      targetUrl={targetUrl}
      campaign={campaign}
    />
  );
}
