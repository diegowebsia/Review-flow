import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSuperAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';
import { setFreeTrialEnabled } from '@/lib/system-settings';
import { apiError } from '@/lib/api-error';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/tenants?page=1&pageSize=20&q=...&plan=...&status=...
 * Paginación en el servidor de la tabla de empresas del panel de Super-Admin.
 */
export async function GET(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const guard = await requireSuperAdmin();
  if (!guard.ok) {
    return apiError(guard.error, {
      status: guard.status,
      code: guard.status === 401 ? 'unauthenticated' : 'forbidden',
      correlationId,
    });
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  const url = new URL(req.url);
  const page = Math.max(1, Number(url.searchParams.get('page') ?? 1) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get('pageSize') ?? 25) || 25));
  const q = url.searchParams.get('q')?.trim() ?? '';
  const plan = url.searchParams.get('plan')?.trim() ?? '';
  const status = url.searchParams.get('status')?.trim() ?? '';

  let query = admin
    .from('tenants')
    .select(
      'id, name, slug, owner_email, plan, subscription_status, stripe_customer_id, suspended, created_at',
      { count: 'exact' },
    );

  if (plan) query = query.eq('plan', plan);
  if (status) query = query.eq('subscription_status', status);
  if (q) query = query.ilike('name', `%${q}%`);

  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  const { data, count, error } = await query
    .order('created_at', { ascending: false })
    .range(from, to);

  if (error) {
    return apiError(error.message, { status: 500, code: 'internal_error', correlationId });
  }

  const total = count ?? (data ?? []).length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return NextResponse.json(
    {
      ok: true,
      correlationId,
      tenants: data ?? [],
      pagination: {
        page,
        pageSize,
        total,
        totalPages,
        hasMore: page < totalPages,
      },
    },
    { headers: correlationHeaders(correlationId) },
  );
}

const Body = z.object({
  op: z.enum(['suspend', 'unsuspend', 'delete', 'set-plan', 'ping', 'set-free-trial']),
  tenantId: z.string().optional(),
  plan: z.enum(['local_starter', 'local_pro', 'ecommerce_starter', 'ecommerce_pro', 'pro', 'business']).optional(),
  enabled: z.boolean().optional(),
});

/**
 * Acciones de super-admin sobre tenants y configuración global del sistema.
 * Protegida por requireSuperAdmin() (además del middleware).
 */
export async function POST(req: Request) {
  const guard = await requireSuperAdmin();
  if (!guard.ok) {
    return NextResponse.json({ error: guard.error }, { status: guard.status });
  }

  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: 'Operación inválida.' }, { status: 400 });
  const { op, tenantId, plan, enabled } = parsed.data;

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });
  }

  if (op === 'ping') {
    const { error } = await admin.from('tenants').select('id', { head: true, count: 'exact' });
    if (error) return NextResponse.json({ error: `BD error: ${error.message}` }, { status: 500 });
    return NextResponse.json({ ok: true, message: 'Conexión a Supabase OK ✅' });
  }

  if (op === 'set-free-trial') {
    if (typeof enabled !== 'boolean') {
      return NextResponse.json({ error: 'Falta parámetro booleano enabled.' }, { status: 400 });
    }
    const res = await setFreeTrialEnabled(enabled, guard.email);
    if (!res.ok) {
      return NextResponse.json({ error: res.error ?? 'No se pudo actualizar la configuración.' }, { status: 500 });
    }
    return NextResponse.json({
      ok: true,
      freeTrialEnabled: enabled,
      message: enabled
        ? 'Prueba gratuita de 7 días ACTIVADA en toda la plataforma y Stripe Checkout.'
        : 'Prueba gratuita de 7 días DESACTIVADA. Stripe cobrará la primera cuota al instante.',
    });
  }

  if (!tenantId) return NextResponse.json({ error: 'Falta tenantId.' }, { status: 400 });

  if (op === 'suspend' || op === 'unsuspend') {
    const { error } = await admin
      .from('tenants')
      .update({ suspended: op === 'suspend' })
      .eq('id', tenantId);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    await systemLog('warn', 'admin.tenants', `${op} tenant ${tenantId}`, { by: guard.email });
    return NextResponse.json({
      ok: true,
      message: op === 'suspend' ? 'Empresa suspendida.' : 'Empresa reactivada.',
    });
  }

  if (op === 'set-plan') {
    if (!plan) return NextResponse.json({ error: 'Falta plan.' }, { status: 400 });
    const { error } = await admin.from('tenants').update({ plan }).eq('id', tenantId);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    await systemLog('info', 'admin.tenants', `Plan de ${tenantId} → ${plan}`, { by: guard.email });
    return NextResponse.json({ ok: true, message: `Plan cambiado a ${plan}.` });
  }

  if (op === 'delete') {
    // Borrado en cascada manual (además del ON DELETE CASCADE del schema).
    await admin.from('reviews').delete().eq('tenant_id', tenantId);
    await admin.from('memberships').delete().eq('tenant_id', tenantId);
    const { error } = await admin.from('tenants').delete().eq('id', tenantId);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    await systemLog('warn', 'admin.tenants', `Tenant eliminado: ${tenantId}`, { by: guard.email });
    return NextResponse.json({ ok: true, message: 'Empresa eliminada con todos sus datos.' });
  }

  return NextResponse.json({ error: 'Operación no soportada.' }, { status: 400 });
}
