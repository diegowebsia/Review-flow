import { NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSuperAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';

export const dynamic = 'force-dynamic';

/**
 * Chat de soporte desde el lado ADMINISTRADOR.
 *   GET  /api/admin/support                 → lista de conversaciones (última, no leídos)
 *   GET  /api/admin/support?tenantId=...    → mensajes de una empresa (marca leídos)
 *   POST /api/admin/support { tenantId, body } → responde como administrador
 */
const Post = z.object({ tenantId: z.string().uuid(), body: z.string().trim().min(1).max(4000) });

type Row = { id: string; tenant_id: string; body: string; from_admin: boolean; read_by_admin: boolean; created_at: string };

export async function GET(req: Request) {
  const guard = await requireSuperAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Service role no configurada.' }, { status: 503 });

  const tenantId = new URL(req.url).searchParams.get('tenantId');
  if (tenantId) {
    if (!z.string().uuid().safeParse(tenantId).success) return NextResponse.json({ error: 'tenantId inválido.' }, { status: 400 });
    const { data } = await admin
      .from('support_messages')
      .select('id, body, from_admin, author_email, created_at')
      .eq('tenant_id', tenantId)
      .order('created_at', { ascending: true })
      .limit(500);
    await admin.from('support_messages').update({ read_by_admin: true }).eq('tenant_id', tenantId).eq('read_by_admin', false);
    return NextResponse.json({ messages: data ?? [] });
  }

  const { data: rows } = await admin
    .from('support_messages')
    .select('id, tenant_id, body, from_admin, read_by_admin, created_at')
    .order('created_at', { ascending: false })
    .limit(2000);
  const byTenant = new Map<string, { tenantId: string; last: string; lastAt: string; unread: number; lastFromAdmin: boolean }>();
  for (const r of (rows ?? []) as Row[]) {
    const cur = byTenant.get(r.tenant_id);
    if (!cur) {
      byTenant.set(r.tenant_id, { tenantId: r.tenant_id, last: r.body, lastAt: r.created_at, unread: 0, lastFromAdmin: r.from_admin });
    }
    if (!r.from_admin && !r.read_by_admin) byTenant.get(r.tenant_id)!.unread += 1;
  }
  const ids = [...byTenant.keys()];
  const names = new Map<string, { name: string; plan: string; owner_email: string }>();
  if (ids.length) {
    const { data: t } = await admin.from('tenants').select('id, name, plan, owner_email').in('id', ids);
    for (const x of (t ?? []) as Array<{ id: string; name: string; plan: string; owner_email: string }>) names.set(x.id, x);
  }
  const conversations = [...byTenant.values()].map((c) => ({ ...c, ...(names.get(c.tenantId) ?? { name: 'Empresa', plan: '-', owner_email: '' }) }));
  conversations.sort((a, b) => (b.unread - a.unread) || b.lastAt.localeCompare(a.lastAt));
  return NextResponse.json({ conversations });
}

export async function POST(req: Request) {
  const guard = await requireSuperAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Service role no configurada.' }, { status: 503 });
  const parsed = Post.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'Mensaje inválido.' }, { status: 400 });

  const { data, error } = await admin
    .from('support_messages')
    .insert({
      tenant_id: parsed.data.tenantId,
      body: parsed.data.body,
      author_id: guard.userId,
      author_email: guard.email,
      from_admin: true,
      read_by_admin: true,
    })
    .select('id, body, from_admin, author_email, created_at')
    .single();
  if (error) return NextResponse.json({ error: 'No se pudo enviar.' }, { status: 500 });
  return NextResponse.json({ message: data });
}
