import { NextResponse } from 'next/server';
import { requireSuperAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { computeBusinessMetrics, getCachedBusinessMetrics } from '@/lib/business-metrics';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';
import { apiError } from '@/lib/api-error';

export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/metrics
 * Devuelve el cuadro de mando interno (solo Super-Admin) con:
 *   - MRR y ARR
 *   - Tasa de conversión prueba → pago (%)
 *   - Churn mensual (%)
 *   - Upgrades / Downgrades / Pausas
 *   - Coste de IA por cliente y desglosado por plan
 *   - Embudo de eventos de producto
 */
export async function GET(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const guard = await requireSuperAdmin();
  if (!guard.ok) {
    return apiError(guard.error, {
      status: guard.status,
      code: guard.status === 401 ? 'unauthenticated' : 'forbidden',
      correlationId,
    });
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  const { data: tenants } = await admin
    .from('tenants')
    .select('id, name, plan, subscription_status, created_at, settings')
    .limit(500);

  const { data: logs } = await admin
    .from('system_logs')
    .select('source, message, meta')
    .order('created_at', { ascending: false })
    .limit(500);

  const tenantRows = (tenants ?? []) as Parameters<typeof computeBusinessMetrics>[0];
  const logRows = (logs ?? []) as Parameters<typeof computeBusinessMetrics>[1];
  const metrics = await getCachedBusinessMetrics(tenantRows, logRows).catch(() =>
    computeBusinessMetrics(tenantRows, logRows),
  );

  return NextResponse.json(
    { ok: true, correlationId, metrics },
    { headers: correlationHeaders(correlationId, { 'Cache-Control': 'private, max-age=60, stale-while-revalidate=120' }) },
  );
}
