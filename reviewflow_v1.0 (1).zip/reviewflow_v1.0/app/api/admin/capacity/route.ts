import { NextResponse } from 'next/server';
import { requireSuperAdmin } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { checkDbHealth, getDbPool, query } from '@/lib/db';
import { llmStatus } from '@/lib/llm';
import { scalingAdvice, type CapacitySnapshot } from '@/lib/scaling';

export const dynamic = 'force-dynamic';

/** GET /api/admin/capacity — capacidad en tiempo real + siguiente paso de escalado. */
export async function GET() {
  const guard = await requireSuperAdmin();
  if (!guard.ok) return NextResponse.json({ error: guard.error }, { status: guard.status });
  const admin = createAdminClient();

  const hourAgo = new Date(Date.now() - 3_600_000).toISOString();
  const dayAgo = new Date(Date.now() - 86_400_000).toISOString();

  type CountQuery = {
    gte: (column: string, value: string) => CountQuery;
    eq: (column: string, value: unknown) => CountQuery;
    in: (column: string, values: unknown[]) => CountQuery;
  } & PromiseLike<{ count: number | null }>;

  async function count(table: string, since?: string, extra?: (q: CountQuery) => CountQuery): Promise<number> {
    if (!admin) return 0;
    try {
      let q = admin.from(table).select('id', { count: 'exact', head: true }) as unknown as CountQuery;
      if (since) q = q.gte('created_at', since);
      if (extra) q = extra(q);
      const { count: c } = await q;
      return c ?? 0;
    } catch {
      return 0;
    }
  }

  const [tenantsTotal, tenantsActive, reviewsHour, reviewsDay, aiHour, aiDay, unreadSupport] = await Promise.all([
    count('tenants'),
    count('tenants', undefined, (q) => q.in('subscription_status', ['active', 'trialing'])),
    count('reviews', hourAgo),
    count('reviews', dayAgo),
    count('ai_interactions', hourAgo),
    count('ai_interactions', dayAgo),
    count('support_messages', undefined, (q) => q.eq('from_admin', false).eq('read_by_admin', false)),
  ]);

  let aiCostMonthUsd = 0;
  if (admin) {
    try {
      const { data } = await admin.from('v_ai_usage').select('cost_usd_cycle');
      aiCostMonthUsd = (data ?? []).reduce((s: number, r: { cost_usd_cycle: number }) => s + Number(r.cost_usd_cycle ?? 0), 0);
    } catch { /* vista no migrada */ }
  }

  const health = await checkDbHealth();
  let dbMb = 0;
  let dbConnections = 0;
  if (getDbPool()) {
    const r = await query<{ mb: string; conns: string }>(
      `select round(pg_database_size(current_database())/1024.0/1024.0)::text as mb,
              (select count(*) from pg_stat_activity where datname = current_database())::text as conns`,
    );
    if (r.ok && r.rows[0]) {
      dbMb = Number(r.rows[0].mb) || 0;
      dbConnections = Number(r.rows[0].conns) || 0;
    }
  }

  const snapshot: CapacitySnapshot = {
    tenants: tenantsActive,
    reviewsPerHour: reviewsHour,
    aiCallsPerHour: aiHour,
    aiCostMonthUsd: Math.round(aiCostMonthUsd * 100) / 100,
    dbMb,
    dbConnections,
  };

  return NextResponse.json({
    snapshot,
    totals: { tenantsTotal, tenantsActive, reviewsDay, aiDay, unreadSupport },
    db: health,
    ai: llmStatus(),
    advice: scalingAdvice(snapshot),
    generatedAt: new Date().toISOString(),
  });
}
