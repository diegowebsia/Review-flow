import { NextResponse } from 'next/server';
import { z } from 'zod';
import { captureException } from '@/lib/observability';
import { consumeRateLimit } from '@/lib/rate-limit';
import { requestIp } from '@/lib/security';
import { payloadErrorResponse, readTextLimited } from '@/lib/request';

export const dynamic = 'force-dynamic';

const Body = z.object({
  source: z.string().max(80).regex(/^frontend\.[a-z0-9_.]+$/i),
  message: z.string().min(1).max(1000),
  stack: z.string().max(4000).optional(),
  digest: z.string().max(120).optional(),
  url: z.string().max(500).optional(),
  filename: z.string().max(500).optional(),
  lineno: z.number().int().nonnegative().optional(),
  colno: z.number().int().nonnegative().optional(),
});

/**
 * Recibe los fallos del navegador (errores no controlados, promesas
 * rechazadas y pantallas de error) y los guarda en el registro
 * (`system_logs` + Sentry si hay DSN). Límite: 30 avisos por IP y minuto.
 * Siempre responde 204 para no dar pistas ni provocar bucles en el navegador.
 */
export async function POST(req: Request) {
  const rate = await consumeRateLimit('client-errors', requestIp(req), 30, 60);
  if (!rate.allowed) return new NextResponse(null, { status: 204 });

  let raw: string;
  try {
    raw = await readTextLimited(req, 16 * 1024);
  } catch (error) {
    return payloadErrorResponse(error) ?? new NextResponse(null, { status: 204 });
  }
  let json: unknown;
  try {
    json = JSON.parse(raw);
  } catch {
    return new NextResponse(null, { status: 204 });
  }
  const parsed = Body.safeParse(json);
  if (!parsed.success) return new NextResponse(null, { status: 204 });

  const { source, message, stack, digest, url, filename, lineno, colno } = parsed.data;
  const error = new Error(message);
  if (stack) error.stack = stack;
  await captureException(error, {
    source,
    correlationId: digest,
    tags: { origin: 'browser' },
    extra: {
      url: url ?? null,
      filename: filename ?? null,
      lineno: lineno ?? null,
      colno: colno ?? null,
      userAgent: (req.headers.get('user-agent') ?? '').slice(0, 200),
    },
  });
  return new NextResponse(null, { status: 204 });
}
