import { NextResponse } from 'next/server';
import { QueueJobSchema, dispatchJob, processPendingJobs, MAX_QUEUE_BATCH_SIZE } from '@/lib/queue';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';
import { verifyCronSecret } from '@/lib/security';
import { apiError } from '@/lib/api-error';
import { correlationHeaders, getOrCreateCorrelationId, recordServiceOutcome } from '@/lib/observability';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * ============================================================
 * Worker de la cola (`POST /api/queue/worker`)
 * ============================================================
 * Autorización: `Authorization: Bearer CRON_SECRET` / `x-cron-secret` (timingSafeEqual).
 * Si recibe un cuerpo vacío o `{ batch: true }`, procesa hasta 5 tareas `pending`
 * de la tabla `job_queue` en Supabase (máximo 3 reintentos).
 * Si recibe un trabajo directo válido, lo despacha con `dispatchJob`.
 */
export async function POST(req: Request) {
  const startedAt = Date.now();
  const correlationId = getOrCreateCorrelationId(req);
  const raw = await req.text();
  if (!verifyCronSecret(req)) {
    return apiError('No autorizado.', { status: 401, code: 'unauthorized', correlationId });
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  if (!raw.trim()) {
    const batch = await processPendingJobs(admin, MAX_QUEUE_BATCH_SIZE, { startedAt });
    return NextResponse.json(
      { ok: true, ...batch, correlationId },
      { status: 200, headers: correlationHeaders(correlationId) },
    );
  }

  let payload: unknown;
  try {
    payload = JSON.parse(raw);
  } catch {
    return NextResponse.json(
      { ok: false, error: 'JSON inválido.', code: 'bad_request', correlationId },
      { status: 200, headers: correlationHeaders(correlationId) },
    );
  }

  if (payload && typeof payload === 'object' && 'batch' in payload && (payload as { batch?: boolean }).batch) {
    const batch = await processPendingJobs(admin, MAX_QUEUE_BATCH_SIZE, { startedAt });
    return NextResponse.json(
      { ok: true, ...batch, correlationId },
      { status: 200, headers: correlationHeaders(correlationId) },
    );
  }

  const job = QueueJobSchema.safeParse(payload);
  if (!job.success) {
    await systemLog('warn', 'queue.worker', 'Trabajo inválido descartado', {
      correlationId,
      issues: job.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).slice(0, 5),
    });
    return NextResponse.json(
      { ok: false, error: 'Trabajo inválido.', code: 'validation_error', correlationId },
      { status: 200, headers: correlationHeaders(correlationId) },
    );
  }

  try {
    const result = await dispatchJob(admin, job.data);
    await recordServiceOutcome('job_queue', result.ok || !result.retryable, result.detail, {
      correlationId,
      tenantId: 'tenantId' in job.data ? job.data.tenantId : undefined,
    });
    return NextResponse.json(
      { ...result, correlationId },
      { status: result.ok || !result.retryable ? 200 : 500, headers: correlationHeaders(correlationId) },
    );
  } catch (e: unknown) {
    const errMsg = e instanceof Error ? e.message : 'Excepción en el worker';
    await recordServiceOutcome('job_queue', false, errMsg, {
      correlationId,
      tenantId: 'tenantId' in job.data ? job.data.tenantId : undefined,
    });
    await systemLog('error', 'queue.worker', errMsg, {
      correlationId,
      type: job.data.type,
      tenantId: 'tenantId' in job.data ? job.data.tenantId : undefined,
    });
    return NextResponse.json(
      { ok: false, retryable: true, detail: errMsg.slice(0, 300), correlationId },
      { status: 500, headers: correlationHeaders(correlationId) },
    );
  }
}
