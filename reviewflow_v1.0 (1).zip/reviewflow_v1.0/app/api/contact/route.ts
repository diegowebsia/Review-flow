import { NextResponse } from 'next/server';
import { z } from 'zod';
import { sendMail } from '@/lib/mail';
import { env } from '@/lib/env';
import { systemLog } from '@/lib/logger';
import { consumeRateLimit } from '@/lib/rate-limit';
import { escapeHtml, hashPersonalValue, requestIp } from '@/lib/security';
import { verifyAntiBot } from '@/lib/antibot';
import { payloadErrorResponse, readJsonLimited } from '@/lib/request';

const Body = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email().max(150),
  message: z.string().min(10).max(3000),
  website: z.string().max(200).optional(),
  captchaToken: z.string().max(2048).optional(),
});

/** Formulario de contacto real: campo trampa + captcha + límite por IP, email al soporte + log. */
export async function POST(req: Request) {
  const rate = await consumeRateLimit('contact', requestIp(req), 5, 3600);
  if (!rate.allowed) return NextResponse.json({ error: 'Demasiados intentos.' }, { status: 429, headers: { 'Retry-After': String(rate.retryAfter) } });
  let rawBody: unknown;
  try { rawBody = await readJsonLimited(req, 16384); } catch (error) {
    return payloadErrorResponse(error) ?? NextResponse.json({ error: 'JSON inválido.' }, { status: 400 });
  }
  const parsed = Body.safeParse(rawBody);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Revisa los campos (nombre, email válido, mensaje 10+ caracteres).' }, { status: 400 });
  }
  const { name, email, message } = parsed.data;
  // Campo trampa: respondemos "ok" sin enviar nada para no dar pistas al bot.
  if (parsed.data.website && parsed.data.website.trim()) return NextResponse.json({ ok: true, message: 'Mensaje recibido.' });
  // Captcha (Cloudflare Turnstile), igual que en el registro.
  const botCheck = await verifyAntiBot(req, { captchaToken: parsed.data.captchaToken, honeypot: parsed.data.website });
  if (!botCheck.allowed) {
    return NextResponse.json({ error: 'Verificación anti-bot fallida. Recarga la página e inténtalo de nuevo.', code: botCheck.reason }, { status: 403 });
  }
  const safeName = escapeHtml(name);
  const safeEmail = escapeHtml(email);
  const safeMessage = escapeHtml(message).replace(/\n/g, '<br>');

  const to = env.smtpFrom.includes('@') ? env.smtpFrom : 'soporte@example.com';
  const result = await sendMail({
    to,
    subject: `Contacto web: ${name.replace(/[\r\n]/g, ' ')}`,
    text: `De: ${name} <${email}>\n\n${message}`,
    replyTo: email,
    html: `<p><strong>De:</strong> ${safeName} &lt;${safeEmail}&gt;</p><p>${safeMessage}</p>`,
  });

  await systemLog('info', 'contact', 'Mensaje de contacto recibido', { sent: result.sent, emailHash: hashPersonalValue(email).slice(0, 16) });
  return NextResponse.json({ ok: true, message: result.sent ? 'Mensaje enviado. Te respondemos en 24h laborables.' : result.message });
}
