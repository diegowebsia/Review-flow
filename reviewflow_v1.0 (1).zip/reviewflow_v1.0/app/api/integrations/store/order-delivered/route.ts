import { NextResponse } from 'next/server';
import { POST as ecommerceOrderDeliveredPost } from '@/app/api/integrations/ecommerce/order-delivered/route';
import { rateLimitByIp } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

/**
 * Alias compatible hacia atrás de `/api/integrations/ecommerce/order-delivered`.
 * Autentica mediante `api_key` (cuerpo JSON, cabecera `X-Tenant-Key` / `Authorization: Bearer` o `?token=`),
 * aplica rate-limit por IP y tenant (`rateLimitByIp` + `rateLimitByTenant`),
 * verifica cuota con `requirePaidAccess` y encola el evento `store.delivered`.
 */
export async function POST(req: Request) {
  const ipLimit = await rateLimitByIp(req, 'integrations:store-order-delivered:ip', 120, 60);
  if (!ipLimit.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas peticiones. Inténtalo de nuevo en unos segundos.' },
      { status: 429, headers: { 'Retry-After': String(ipLimit.retryAfter) } },
    );
  }
  return ecommerceOrderDeliveredPost(req);
}
