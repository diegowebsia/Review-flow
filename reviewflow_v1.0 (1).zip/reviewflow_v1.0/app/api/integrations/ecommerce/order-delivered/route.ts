import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { enqueue } from '@/lib/queue';
import { requirePaidAccess } from '@/lib/usage';
import { systemLog } from '@/lib/logger';
import { payloadErrorResponse, readJsonLimited } from '@/lib/request';
import { tenantByApiKey } from '@/lib/store';
import { rateLimitByIp, rateLimitByTenant } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

type RawOrderPayload = {
  api_key?: string;
  order_id?: string | number;
  id?: string | number;
  order_number?: string | number;
  orderId?: string | number;
  customer_phone?: string;
  phone?: string;
  customer_email?: string;
  email?: string;
  customer_name?: string;
  name?: string;
  whatsapp_optin?: boolean;
  optin?: boolean;
  optin_text?: string;
  billing?: { first_name?: string; last_name?: string; phone?: string; email?: string };
  shipping_address?: { first_name?: string; last_name?: string; phone?: string };
  customer?: { first_name?: string; last_name?: string; phone?: string; email?: string };
  meta_data?: Array<{ key?: string; value?: unknown }>;
};

/**
 * Webhook Receptor Universal de E-Commerce (Shopify, WooCommerce, PrestaShop, Magento, TPVs).
 * Unifica el contrato de `/api/integrations/ecommerce/order-delivered` y `/api/integrations/store/order-delivered`.
 *
 * Autenticación:
 *  - Cabecera: `X-Tenant-Key: <api_key>`, `X-Api-Key: <api_key>` o `Authorization: Bearer <api_key>`
 *  - Query param: `?token=<api_key>` o `?key=<api_key>`
 *  - Cuerpo JSON: `{ "api_key": "<api_key>" }`
 */
export async function POST(req: Request) {
  const ipLimit = await rateLimitByIp(req, 'integrations:order-delivered:ip', 120, 60);
  if (!ipLimit.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas peticiones. Inténtalo de nuevo en unos segundos.' },
      { status: 429, headers: { 'Retry-After': String(ipLimit.retryAfter) } },
    );
  }

  const url = new URL(req.url);

  let rawBody: RawOrderPayload;
  try {
    rawBody = (await readJsonLimited(req, 65536)) as RawOrderPayload;
  } catch (error) {
    return (
      payloadErrorResponse(error) ??
      NextResponse.json({ error: 'Cuerpo JSON inválido o excede el límite de tamaño.' }, { status: 400 })
    );
  }

  if (!rawBody || typeof rawBody !== 'object') {
    return NextResponse.json({ error: 'Parámetros inválidos.' }, { status: 400 });
  }

  // 1. Extraer credencial API Key
  const apiKey =
    req.headers.get('x-tenant-key') ??
    req.headers.get('x-api-key') ??
    req.headers.get('authorization')?.replace(/^Bearer\s+/i, '').trim() ??
    url.searchParams.get('token') ??
    url.searchParams.get('key') ??
    (typeof rawBody.api_key === 'string' ? rawBody.api_key : null);

  if (!apiKey || typeof apiKey !== 'string' || apiKey.trim().length < 10) {
    return NextResponse.json(
      {
        error:
          'Falta autenticación. Envía tu API Key en la cabecera X-Tenant-Key o en el parámetro ?token=TU_KEY',
      },
      { status: 401 },
    );
  }

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: 'Servicio no disponible temporalmente.' }, { status: 503 });
  }

  // 2. Localizar Tenant por API Key (soporta hash SHA-256 y rotación con solape de 24 h)
  const tenant = await tenantByApiKey(admin, apiKey.trim());
  if (!tenant) {
    return NextResponse.json({ error: 'API Key no válida o empresa no encontrada.' }, { status: 401 });
  }

  if (tenant.suspended) {
    return NextResponse.json({ error: 'Empresa suspendida temporalmente.' }, { status: 403 });
  }

  const tenantLimit = await rateLimitByTenant(tenant.id, 'integrations:order-delivered', 60, 60);
  if (!tenantLimit.allowed) {
    return NextResponse.json(
      { error: 'Límite de envíos por minuto alcanzado para esta empresa.' },
      { status: 429, headers: { 'Retry-After': String(tenantLimit.retryAfter) } },
    );
  }

  // 3. Control estricto de Cuota y Plan
  const gate = await requirePaidAccess(admin, tenant.id, {
    feature: 'storeIntegration',
    action: 'Solicitud de reseña por e-commerce',
    metric: 'requests',
  });
  if (!gate.ok) {
    return NextResponse.json(gate.body, { status: gate.status, headers: gate.headers });
  }

  // 4. Normalizar payload de pedido (admite WooCommerce, Shopify y estándar plano)
  const orderId = String(
    rawBody.order_id ||
      rawBody.id ||
      rawBody.order_number ||
      rawBody.orderId ||
      `ord_${Date.now().toString(36)}`,
  ).slice(0, 100);

  const phone = String(
    rawBody.customer_phone ||
      rawBody.phone ||
      rawBody.billing?.phone ||
      rawBody.shipping_address?.phone ||
      rawBody.customer?.phone ||
      '',
  ).trim();

  const email = String(
    rawBody.customer_email ||
      rawBody.email ||
      rawBody.billing?.email ||
      rawBody.customer?.email ||
      '',
  ).trim();

  const customerName = String(
    rawBody.customer_name ||
      [rawBody.billing?.first_name, rawBody.billing?.last_name].filter(Boolean).join(' ') ||
      [rawBody.customer?.first_name, rawBody.customer?.last_name].filter(Boolean).join(' ') ||
      [rawBody.shipping_address?.first_name, rawBody.shipping_address?.last_name].filter(Boolean).join(' ') ||
      rawBody.name ||
      'Cliente',
  )
    .trim()
    .slice(0, 120);

  if (!email) {
    return NextResponse.json(
      { error: 'El pedido debe incluir un email del comprador.' },
      { status: 422 },
    );
  }

  // Consentimiento opt-in RGPD (si se envía en el webhook o en meta_data de WooCommerce/Shopify)
  let optin = true;
  if (rawBody.whatsapp_optin !== undefined) {
    optin = Boolean(rawBody.whatsapp_optin);
  } else if (rawBody.optin !== undefined) {
    optin = Boolean(rawBody.optin);
  } else if (Array.isArray(rawBody.meta_data)) {
    const found = rawBody.meta_data.find((m) => m?.key === 'whatsapp_optin');
    if (found) optin = found.value === 'yes' || found.value === true;
  }

  // 5. Encolar y despachar el trabajo
  try {
    const { queued, jobId } = await enqueue({
      type: 'store.delivered',
      tenantId: tenant.id,
      order: {
        orderId,
        customerName,
        customerPhone: phone || undefined,
        customerEmail: email || undefined,
        provider: 'store',
        optin: Boolean(optin),
        optinText: rawBody.optin_text || 'Consentimiento otorgado en checkout',
      },
    });

    await systemLog('info', 'ecommerce.order_delivered', `Pedido ${orderId} recibido para ${tenant.name}`, {
      tenantId: tenant.id,
      orderId,
      hasPhone: Boolean(phone),
      hasEmail: Boolean(email),
      jobId,
    });

    return NextResponse.json({
      ok: true,
      accepted: true,
      success: true,
      message: 'Pedido recibido. Solicitud de valoración encolada correctamente.',
      order_id: orderId,
      tenant_slug: tenant.slug,
      queued,
      jobId,
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Error desconocido';
    await systemLog('error', 'ecommerce.order_delivered', `Fallo al encolar pedido: ${msg}`, {
      tenantId: tenant.id,
      orderId,
    });
    return NextResponse.json({ error: 'Error procesando el pedido entregado.' }, { status: 500 });
  }
}
