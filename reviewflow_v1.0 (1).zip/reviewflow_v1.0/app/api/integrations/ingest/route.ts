import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { checkQuota, consume, enforce, enforceTableCap, publicQuota } from '@/lib/usage';
import { systemLog } from '@/lib/logger';
import { payloadErrorResponse, readJsonLimited } from '@/lib/request';
import { verifyAndResolveTenantByApiKey } from '@/lib/api-keys';
import { dispatchRealtimeAlerts } from '@/lib/outbound-webhooks';
import { rateLimitByIp, rateLimitByTenant } from '@/lib/rate-limit';
import { invalidateBusinessMetricsCache } from '@/lib/business-metrics';

const Body = z.object({
  api_key: z.string().min(10),
  source: z.enum([
    'google',
    'trustpilot',
    'facebook',
    'manual',
    'places',
    'amazon',
    'booking',
    'glassdoor',
    'yelp',
    'idealista',
  ]),
  external_id: z.string().min(1).max(300),
  author_name: z.string().min(1).max(120),
  rating: z.number().min(1).max(5),
  text: z.string().max(4000).default(''),
  verified: z.boolean().default(false),
  /** Ignorado (WhatsApp desactivado). Aceptado por compatibilidad. */
  customer_phone: z.string().max(25).optional(),
  order_id: z.string().max(100).optional(),
});

/**
 * Ingesta REAL de reseñas vía API pública (autenticada con la `api_key`
 * de cada empresa). Cada evento pasa por el motor de cuotas:
 *
 *   402 → suscripción sin acceso (impago / cancelada / suspendida)
 *   403 → la feature no está en el plan contratado
 *   429 → cuota mensual agotada (cabecera `Retry-After`)
 *   507 → tope de opiniones guardadas de la base de datos alcanzado
 *
 * Consumo: 1 unidad `reviews_ingested`.
 */
export async function POST(req: Request) {
  const ipLimit = await rateLimitByIp(req, 'integrations:ingest:ip', 120, 60);
  if (!ipLimit.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas peticiones. Inténtalo de nuevo en unos segundos.' },
      { status: 429, headers: { 'Retry-After': String(ipLimit.retryAfter) } },
    );
  }

  let rawBody: unknown;
  try { rawBody = await readJsonLimited(req, 262144); } catch (error) {
    return payloadErrorResponse(error) ?? NextResponse.json({ error: 'JSON inválido.' }, { status: 400 });
  }
  const parsed = Body.safeParse(rawBody);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Parámetros inválidos.', fields: parsed.error.issues.map((i) => i.path.join('.')) }, { status: 400 });
  }
  const input = parsed.data;

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const tenant = await verifyAndResolveTenantByApiKey(admin, input.api_key);
  if (!tenant) return NextResponse.json({ error: 'API key inválida o revocada.' }, { status: 401 });

  const tenantLimit = await rateLimitByTenant(tenant.id, 'integrations:ingest', 60, 60);
  if (!tenantLimit.allowed) {
    return NextResponse.json(
      { error: 'Límite de envíos por minuto alcanzado para esta empresa.' },
      { status: 429, headers: { 'Retry-After': String(tenantLimit.retryAfter) } },
    );
  }

  // Puerta única: suscripción + feature `publicApi` + cuota de reseñas.
  const gate = await enforce(admin, tenant.id, {
    metric: 'reviews',
    feature: 'publicApi',
    amount: 1,
    action: 'Ingesta de reseña por API',
  });
  if (!gate.ok) {
    await systemLog('warn', 'reviews.ingest', gate.error, { tenantId: tenant.id, code: gate.code });
    return NextResponse.json(gate.body, { status: gate.status, headers: gate.headers });
  }

  // Tope de base de datos: purga las opiniones más antiguas si hace falta y
  // rechaza la escritura cuando la empresa ya está en su máximo (507).
  const storage = await enforceTableCap(admin, tenant.id, 'reviews');
  if (!storage.ok) {
    await systemLog('warn', 'reviews.ingest', storage.error, { tenantId: tenant.id, code: storage.code });
    return NextResponse.json(storage.body, { status: storage.status, headers: storage.headers });
  }

  const { error } = await admin.from('reviews').upsert(
    {
      tenant_id: tenant.id,
      source: input.source,
      external_id: input.external_id,
      author_name: input.author_name,
      rating: input.rating,
      text: input.text,
      is_verified: input.verified,
      flagged_private: input.rating <= 3,
    },
    { onConflict: 'tenant_id,source,external_id' },
  );
  if (error) return NextResponse.json({ error: 'No se pudo guardar la reseña.' }, { status: 500 });

  // Descuento ATÓMICO del evento (RPC `consume_quota` con fallback upsert).
  await consume(admin, tenant.id, 'reviews', 1);

  const settings = (tenant.settings as Record<string, unknown> | null) ?? {};
  // Alertas en tiempo real a Slack, Microsoft Teams y Webhook saliente (Zapier/Make)
  await dispatchRealtimeAlerts(settings, {
    event: input.rating <= 3 ? 'review.negative_alert' : 'review.created',
    tenantId: tenant.id,
    businessName: tenant.name,
    authorName: input.author_name,
    rating: input.rating,
    text: input.text,
    source: input.source,
    createdAt: new Date().toISOString(),
  }).catch(() => undefined);

  invalidateBusinessMetricsCache();
  const fresh = await checkQuota(admin, tenant.id);
  return NextResponse.json({
    ok: true,
    quota: publicQuota(fresh),
  });
}
