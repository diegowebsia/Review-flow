import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { checkQuota, consume, enforce, enforceTableCap, publicQuota } from '@/lib/usage';
import { systemLog } from '@/lib/logger';
import { dispatchRealtimeAlerts } from '@/lib/outbound-webhooks';
import { invalidateBusinessMetricsCache } from '@/lib/business-metrics';
import { apiError } from '@/lib/api-error';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

/**
 * GET /api/reviews?tenantId=...&page=1&pageSize=20&filter=all&q=...
 * Listado de opiniones paginado en el servidor con aislamiento por `tenant_id`.
 */
export async function GET(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const url = new URL(req.url);
  const tenantId = url.searchParams.get('tenantId')?.trim() ?? '';
  const page = Math.max(1, Number(url.searchParams.get('page') ?? 1) || 1);
  const pageSize = Math.min(100, Math.max(1, Number(url.searchParams.get('pageSize') ?? 20) || 20));
  const filter = url.searchParams.get('filter') ?? 'all';
  const queryText = url.searchParams.get('q')?.trim() ?? '';

  if (!tenantId) {
    return apiError('Falta tenantId.', { status: 400, code: 'bad_request', correlationId });
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return apiError('No autenticado.', { status: 401, code: 'unauthenticated', correlationId });
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  const { data: member } = await admin
    .from('memberships')
    .select('id')
    .eq('tenant_id', tenantId)
    .eq('user_id', user.id)
    .single();
  if (!member) {
    return apiError('Sin permiso en esta empresa.', {
      status: 403,
      code: 'forbidden',
      correlationId,
    });
  }

  let q = admin
    .from('reviews')
    .select(
      'id, tenant_id, source, author_name, rating, text, reply_text, replied_at, is_verified, flagged_private, private_note, created_at',
      { count: 'exact' },
    )
    .eq('tenant_id', tenantId);

  if (filter === 'positive') q = q.gte('rating', 4);
  else if (filter === 'negative') q = q.lte('rating', 3);
  else if (filter === 'pending') q = q.is('reply_text', null);
  else if (filter === 'private') q = q.eq('flagged_private', true);

  if (queryText) {
    q = q.ilike('text', `%${queryText}%`);
  }

  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;
  const { data, count, error } = await q.order('created_at', { ascending: false }).range(from, to);

  if (error) {
    return apiError('Error al consultar reseñas.', {
      status: 500,
      code: 'internal_error',
      correlationId,
    });
  }

  const total = count ?? (data ?? []).length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return NextResponse.json(
    {
      ok: true,
      correlationId,
      reviews: data ?? [],
      pagination: {
        page,
        pageSize,
        total,
        totalPages,
        hasMore: page < totalPages,
      },
    },
    { headers: correlationHeaders(correlationId) },
  );
}

const Body = z.object({
  tenantId: z.string().min(1),
  author_name: z.string().min(1).max(120),
  rating: z.number().int().min(1).max(5),
  text: z.string().min(2).max(4000),
  source: z.enum(['google', 'trustpilot', 'facebook', 'manual', 'places']).default('google'),
  verified: z.boolean().default(true),
});

/**
 * POST /api/reviews
 * Registra una reseña real en la tabla `reviews` de Supabase de la empresa del usuario autenticado.
 * Pasa por el motor real de suscripción, cuotas (`enforce`), almacenamiento (`enforceTableCap`)
 * y dispara alertas (Slack/Teams/webhook) si es una queja (≤3★).
 */
export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Completa el nombre del autor, las estrellas (1-5) y el texto de la reseña.' },
      { status: 400 },
    );
  }
  const input = parsed.data;

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const { data: member } = await admin
    .from('memberships')
    .select('id')
    .eq('tenant_id', input.tenantId)
    .eq('user_id', user.id)
    .single();
  if (!member) return NextResponse.json({ error: 'Sin permiso en esta empresa.' }, { status: 403 });

  const { data: tenant } = await admin
    .from('tenants')
    .select('id, name, settings')
    .eq('id', input.tenantId)
    .single();
  if (!tenant) return NextResponse.json({ error: 'Empresa no encontrada.' }, { status: 404 });

  const gate = await enforce(admin, tenant.id, {
    metric: 'reviews',
    amount: 1,
    action: 'Registro de reseña',
  });
  if (!gate.ok) {
    return NextResponse.json(gate.body, { status: gate.status, headers: gate.headers });
  }

  const storage = await enforceTableCap(admin, tenant.id, 'reviews');
  if (!storage.ok) {
    return NextResponse.json(storage.body, { status: storage.status, headers: storage.headers });
  }

  const externalId = `rf-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const { data: created, error } = await admin
    .from('reviews')
    .insert({
      tenant_id: tenant.id,
      source: input.source,
      external_id: externalId,
      author_name: input.author_name.trim(),
      rating: input.rating,
      text: input.text.trim(),
      is_verified: input.verified,
      flagged_private: input.rating <= 3,
    })
    .select('id, created_at')
    .single();

  if (error || !created) {
    return NextResponse.json({ error: 'No se pudo guardar la reseña en la base de datos.' }, { status: 500 });
  }

  await consume(admin, tenant.id, 'reviews', 1);
  invalidateBusinessMetricsCache();

  const settings =
    (tenant.settings as {
      slack_webhook_url?: string;
      teams_webhook_url?: string;
      outbound_webhook_url?: string;
    } | null) ?? {};
  // Alertas en tiempo real a Slack, Microsoft Teams y Webhook saliente (Zapier/Make)
  await dispatchRealtimeAlerts(settings, {
    event: input.rating <= 3 ? 'review.negative_alert' : 'review.created',
    tenantId: tenant.id,
    businessName: tenant.name,
    reviewId: created.id,
    authorName: input.author_name.trim(),
    rating: input.rating,
    text: input.text.trim(),
    source: input.source,
    createdAt: new Date().toISOString(),
  }).catch(() => undefined);

  await systemLog('info', 'reviews.create', `Reseña registrada (${input.rating}★ · ${input.source})`, {
    tenantId: tenant.id,
    reviewId: created.id,
  });

  const fresh = await checkQuota(admin, tenant.id);
  return NextResponse.json({
    ok: true,
    reviewId: created.id,
    review: {
      id: created.id,
      tenant: tenant.name,
      tenant_id: tenant.id,
      author: input.author_name.trim(),
      rating: input.rating,
      text: input.text.trim(),
      source: input.source,
      created_at: created.created_at ?? new Date().toISOString(),
      replied: false,
      verified: input.verified,
      flagged_private: input.rating <= 3,
      private_note: null,
      reply: null,
    },
    quota: publicQuota(fresh),
  });
}
