import { NextResponse } from 'next/server';
import { z } from 'zod';
import { analyzeReviewIntelligence } from '@/lib/ai';
import { detectFakeOrSpamReview } from '@/lib/review-classifier';
import { detectReviewLocale } from '@/lib/i18n';
import { createClient } from '@/lib/supabase/server';

export const maxDuration = 60;

const Body = z.object({
  reviewId: z.string().min(1),
  businessName: z.string().min(1).max(120),
  authorName: z.string().min(1).max(120),
  rating: z.number().min(1).max(5),
  reviewText: z.string().min(1).max(4000),
  verified: z.boolean().optional(),
  tone: z.enum(['profesional', 'cercano', 'formal']).optional(),
});

export async function POST(req: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Parámetros inválidos.' }, { status: 400 });
  }

  const input = parsed.data;
  const [intelligence, spamAnalysis] = await Promise.all([
    analyzeReviewIntelligence({
      businessName: input.businessName,
      authorName: input.authorName,
      rating: input.rating,
      reviewText: input.reviewText,
      tone: input.tone,
    }),
    Promise.resolve(
      detectFakeOrSpamReview({
        authorName: input.authorName,
        rating: input.rating,
        text: input.reviewText,
        isVerified: input.verified,
      }),
    ),
  ]);

  const detectedLocale = detectReviewLocale(input.reviewText, 'es');

  return NextResponse.json({
    reviewId: input.reviewId,
    detectedLocale,
    intelligence: {
      ...intelligence,
      detectedLocale,
      spamAnalysis,
    },
  });
}
