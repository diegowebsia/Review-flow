import { NextResponse } from 'next/server';
import { z } from 'zod';
import { generateReplyForTenant } from '@/lib/ai';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { hasAccess } from '@/lib/plans';
import { checkQuota, publicQuota, quotaExhaustedMessage, quotaHeaders, upgradeHints } from '@/lib/usage';
import { systemLog } from '@/lib/logger';
import { rateLimitByIp, rateLimitByTenant } from '@/lib/rate-limit';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

export const maxDuration = 60;

const Body = z.object({
  reviewId: z.string().min(1),
  businessName: z.string().min(1).max(120),
  authorName: z.string().min(1).max(120),
  rating: z.number().min(1).max(5),
  reviewText: z.string().min(1).max(4000),
  tone: z.enum(['profesional', 'cercano', 'formal']).optional(),
  /** true = borrador PRIVADO conciliador (filtro de malas experiencias), no público. */
  private: z.boolean().optional(),
});

/**
 * Genera un borrador IA (público o privado).
 *
 * Cadena de control REAL antes de llamar a Google Gemini:
 *   rate limit (IP + Tenant) → sesión → membresía → suscripción con acceso (402) → cuota del ciclo (429).
 * Cada borrador generado descuenta 1 evento de `usage_counters.ai_responses`
 * dentro de `generateReplyForTenant` (lib/ai.ts).
 */
export async function POST(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const ipRate = await rateLimitByIp(req, 'ai-review-respond', 30, 60);
  if (!ipRate.allowed) {
    return NextResponse.json(
      { error: 'Límite de peticiones de IA excedido por IP. Espera unos segundos.', correlationId },
      { status: 429, headers: correlationHeaders(correlationId, { 'Retry-After': String(ipRate.retryAfter) }) },
    );
  }

  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Parámetros inválidos.' }, { status: 400 });
  }
  const input = parsed.data;

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const { data: review } = await admin
    .from('reviews')
    .select('id, tenant_id')
    .eq('id', input.reviewId)
    .single();
  if (!review) return NextResponse.json({ error: 'Reseña no encontrada.' }, { status: 404 });
  const tenantId = String(review.tenant_id);

  const tenantRate = await rateLimitByTenant(tenantId, 'ai-review-respond', 60, 60);
  if (!tenantRate.allowed) {
    return NextResponse.json(
      { error: 'Tu empresa ha alcanzado el límite de generación por minuto. Inténtalo de nuevo en breve.' },
      { status: 429, headers: { 'Retry-After': String(tenantRate.retryAfter) } },
    );
  }

  const { data: member } = await admin
    .from('memberships')
    .select('id')
    .eq('tenant_id', tenantId)
    .eq('user_id', user.id)
    .single();
  if (!member) return NextResponse.json({ error: 'Sin permiso en esta empresa.' }, { status: 403 });

  const { data: tenant } = await admin
    .from('tenants')
    .select('subscription_status, suspended, trial_ends_at, grace_period_ends_at, settings')
    .eq('id', tenantId)
    .single();
  // Regla estricta: sin suscripción activa o con la prueba caducada → 402.
  const trialExpired =
    tenant?.subscription_status === 'trialing' &&
    tenant?.trial_ends_at != null &&
    new Date(tenant.trial_ends_at).getTime() <= Date.now();
  if (!tenant || !hasAccess(tenant.subscription_status, tenant.suspended, tenant.grace_period_ends_at ?? null) || trialExpired) {
    return NextResponse.json(
      {
        error: trialExpired
          ? 'Tu prueba de 7 días terminó y el pago no se completó. Reactiva tu suscripción para seguir usando la IA.'
          : 'Suscripción sin acceso. Reactívala para seguir usando la IA.',
        code: trialExpired ? 'trial_expired' : 'no_subscription',
        checkoutUrl: '/bienvenido',
      },
      { status: 402 },
    );
  }

  const tenantSettings =
    (tenant.settings as {
      brand_instructions?: string;
      brand_rules?: string[];
      forbidden_words?: string[];
      brand_signature?: string;
      tone?: 'profesional' | 'cercano' | 'formal';
    } | null) ?? {};
  const brandInstructions = tenantSettings.brand_instructions;
  const brandRules = Array.isArray(tenantSettings.brand_rules) ? tenantSettings.brand_rules : undefined;
  const forbiddenWords = Array.isArray(tenantSettings.forbidden_words) ? tenantSettings.forbidden_words : undefined;
  const brandSignature = typeof tenantSettings.brand_signature === 'string' ? tenantSettings.brand_signature : undefined;
  const effectiveTone: 'profesional' | 'cercano' | 'formal' = input.tone || tenantSettings.tone || 'profesional';

  // Memoria de marca: cargar hasta 3 respuestas previas aprobadas por la empresa para aprender su estilo
  let approvedExamples: Array<{ review: string; reply: string }> = [];
  try {
    const { data: prevReplies } = await admin
      .from('reviews')
      .select('text, reply_text')
      .eq('tenant_id', tenantId)
      .not('reply_text', 'is', null)
      .order('replied_at', { ascending: false })
      .limit(3);
    const prevRows = (prevReplies ?? []) as Array<{ text?: string | null; reply_text?: string | null }>;
    approvedExamples = prevRows
      .filter((r) => Boolean(r.text && r.reply_text))
      .map((r) => ({ review: String(r.text), reply: String(r.reply_text) }));
  } catch {
    /* best effort */
  }

  // Puerta de cuota: 429 + Retry-After si el ciclo está agotado.
  const quota = await checkQuota(admin, tenantId);
  // Solo la cuota de IA bloquea un borrador (agotar p.ej. las peticiones por email no debe impedirlo).
  if (!quota.metrics.ai.allowed) {
    return NextResponse.json(
      {
        error: quotaExhaustedMessage(quota, 'ai'),
        code: 'quota_exhausted',
        quota: publicQuota(quota),
        upgrade: { ...upgradeHints(quota), billingUrl: '/dashboard?tab=facturacion' },
      },
      { status: 429, headers: quotaHeaders(quota) },
    );
  }

  const guarded = await generateReplyForTenant(
    { admin, tenantId },
    {
      businessName: input.businessName,
      authorName: input.authorName,
      rating: input.rating,
      reviewText: input.reviewText,
      tone: effectiveTone,
      privateMessage: input.private === true,
      brandInstructions,
      brandRules,
      forbiddenWords,
      brandSignature,
      approvedExamples,
    },
  );

  if (!guarded.ok) {
    return NextResponse.json(guarded.body, {
      status: guarded.status,
      headers: guarded.headers,
    });
  }

  // Persistencia del borrador (público o nota privada de triaje).
  try {
    if (input.private === true) {
      await admin.from('reviews').update({ private_note: guarded.reply }).eq('id', input.reviewId);
    }
    // El borrador PÚBLICO no se guarda como `reply_text`: esa columna significa
    // «respuesta publicada» (marca la reseña como respondida, alimenta la memoria
    // de marca y el paso 5 del onboarding). Se guarda al pulsar «Publicar».
  } catch {
    /* no bloquea la respuesta */
  }

  await systemLog(
    'info',
    'ai.responder',
    `Borrador ${input.private ? 'privado' : 'público'} generado (${guarded.provider})`,
    { reviewId: input.reviewId, tenantId, correlationId },
  );

  return NextResponse.json(
    {
      reply: guarded.reply,
      provider: guarded.provider,
      quota: guarded.quota,
      correlationId,
    },
    { headers: correlationHeaders(correlationId) },
  );
}
