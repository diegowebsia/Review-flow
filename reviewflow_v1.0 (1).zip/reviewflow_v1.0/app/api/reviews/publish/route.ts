import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { pushReplyToGoogle } from '@/lib/auto-publish';
import { requirePaidAccess } from '@/lib/usage';
import { systemLog } from '@/lib/logger';
import { computeHumanizedPublishTime } from '@/lib/review-classifier';
import { markOnboardingStep } from '@/lib/onboarding';

const Body = z.object({
  reviewId: z.string().min(1),
  reply: z.string().min(2).max(4000),
  humanizeSchedule: z.boolean().optional(),
});

/**
 * Publica (guarda) la respuesta editada de una reseña.
 * Verifica sesión + membresía y, si la reseña es de Google con integración
 * conectada, la publica EN Google a través de la capa con control de cuota
 * (`publishGoogleReplyForTenant` → feature `publishToGoogle` + contador
 * `usage_counters.google_calls`).
 */
export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Respuesta inválida (2-4000 caracteres).' }, { status: 400 });
  }
  const { reviewId, reply, humanizeSchedule } = parsed.data;
  const scheduleInfo = computeHumanizedPublishTime(new Date(), !humanizeSchedule);

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const { data: review } = await admin
    .from('reviews')
    .select('id, tenant_id, source, external_id')
    .eq('id', reviewId)
    .single();
  if (!review) return NextResponse.json({ error: 'Reseña no encontrada.' }, { status: 404 });

  const { data: member } = await admin
    .from('memberships')
    .select('id')
    .eq('tenant_id', review.tenant_id)
    .eq('user_id', user.id)
    .single();
  if (!member) return NextResponse.json({ error: 'Sin permiso en esta empresa.' }, { status: 403 });

  // Regla estricta: sin suscripción activa o con la prueba caducada → 402.
  // (Sin feature: el guardado local siempre se permite con acceso; la subida
  // a Google se filtra dentro de `publishGoogleReplyForTenant`.)
  const gate = await requirePaidAccess(admin, String(review.tenant_id), {
    action: 'Publicar respuesta',
  });
  if (!gate.ok) {
    return NextResponse.json(gate.body, { status: gate.status, headers: gate.headers });
  }

  const { error } = await admin
    .from('reviews')
    .update({ reply_text: reply, replied_at: new Date().toISOString() })
    .eq('id', reviewId);
  if (error) return NextResponse.json({ error: 'No se pudo guardar la respuesta.' }, { status: 500 });

  await markOnboardingStep(admin, String(review.tenant_id), 'publish_first_reply');

  // Publicación en Google (best-effort, con gate de plan y contador de llamadas).
  const { pushedToGoogle, googleError } = await pushReplyToGoogle(
    admin,
    { id: String(review.id), tenant_id: String(review.tenant_id), source: review.source, external_id: review.external_id },
    reply,
  );

  await systemLog('info', 'reviews.publish', `Respuesta publicada en reseña ${reviewId}`, {
    user: user.email,
    pushedToGoogle,
  });

  return NextResponse.json({
    ok: true,
    pushedToGoogle,
    googleError,
    schedule: scheduleInfo,
    message: pushedToGoogle
      ? `Respuesta publicada en Google correctamente (${scheduleInfo.humanLabel}).`
      : `Respuesta guardada (${scheduleInfo.humanLabel}).`,
  });
}
