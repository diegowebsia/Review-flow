import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { isSupabaseConfigured } from '@/lib/env';

export const dynamic = 'force-dynamic';

/**
 * Chat de soporte del CLIENTE con los administradores.
 *   GET  /api/support?tenantId=...      → mensajes de su empresa (marca como leídos los del admin)
 *   POST /api/support { tenantId, body } → envía un mensaje
 * La seguridad la aplica RLS (solo miembros de la empresa).
 */
const Post = z.object({ tenantId: z.string().uuid(), body: z.string().trim().min(1).max(4000) });

async function ctx() {
  if (!isSupabaseConfigured) return null;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  return { supabase, user };
}

export async function GET(req: Request) {
  const c = await ctx();
  if (!c) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });
  const tenantId = new URL(req.url).searchParams.get('tenantId') ?? '';
  if (!z.string().uuid().safeParse(tenantId).success) {
    return NextResponse.json({ error: 'tenantId inválido.' }, { status: 400 });
  }
  const { data, error } = await c.supabase
    .from('support_messages')
    .select('id, body, from_admin, author_email, created_at')
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: true })
    .limit(300);
  if (error) return NextResponse.json({ error: 'No se pudo cargar el chat.' }, { status: 500 });

  await c.supabase
    .from('support_messages')
    .update({ read_by_client: true })
    .eq('tenant_id', tenantId)
    .eq('from_admin', true)
    .eq('read_by_client', false);

  return NextResponse.json({ messages: data ?? [] });
}

export async function POST(req: Request) {
  const c = await ctx();
  if (!c) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });
  const parsed = Post.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'Mensaje inválido.' }, { status: 400 });

  const { data, error } = await c.supabase
    .from('support_messages')
    .insert({
      tenant_id: parsed.data.tenantId,
      body: parsed.data.body,
      author_id: c.user.id,
      author_email: c.user.email ?? null,
      from_admin: false,
      read_by_client: true,
    })
    .select('id, body, from_admin, author_email, created_at')
    .single();
  if (error) return NextResponse.json({ error: 'No tienes acceso a esta empresa.' }, { status: 403 });
  return NextResponse.json({ message: data });
}
