import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { ProfileSchema } from '@/lib/account';

export const dynamic = 'force-dynamic';

/** PUT /api/account/profile — guarda nombre, teléfono, idioma y preferencias de email del usuario. */
export async function PUT(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const parsed = ProfileSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? 'Datos no válidos.' }, { status: 400 });
  }
  const { fullName, phone, locale, emailPrefs } = parsed.data;

  const row: Record<string, unknown> = {
    user_id: user.id,
    full_name: fullName || null,
    phone: phone || null,
    locale,
    updated_at: new Date().toISOString(),
  };
  if (emailPrefs) row.email_prefs = emailPrefs;

  const { error } = await supabase.from('user_profiles').upsert(row, { onConflict: 'user_id' });
  if (error) return NextResponse.json({ error: 'No se pudo guardar el perfil.' }, { status: 500 });

  const res = NextResponse.json({ ok: true });
  res.cookies.set('NEXT_LOCALE', locale, { path: '/', maxAge: 60 * 60 * 24 * 365, sameSite: 'lax' });
  return res;
}
