import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { consumeRateLimit } from '@/lib/rate-limit';
import { systemLog } from '@/lib/logger';
import { verifyCurrentPassword } from '@/lib/reauth';
import { hashPersonalValue } from '@/lib/security';
import { BLOCKING_SUBSCRIPTION_STATUSES, type ActiveSubscription } from '@/lib/account';

export const dynamic = 'force-dynamic';

const Body = z.object({ confirmationText: z.literal('ELIMINAR'), password: z.string().min(1).max(128) });

/**
 * POST /api/account/delete — elimina la cuenta del usuario.
 * Si tiene alguna suscripción todavía activa en un negocio propio, responde 409
 * y la interfaz le pide darse de baja primero.
 */
export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: 'Escribe ELIMINAR y tu contraseña para confirmar.' }, { status: 400 });
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const rate = await consumeRateLimit('account-delete', user.id, 3, 3600);
  if (!rate.allowed) return NextResponse.json({ error: 'Demasiadas solicitudes.' }, { status: 429 });

  // Re-autenticación: una sesión robada o un equipo desatendido no bastan para borrar la cuenta.
  if (!user.email) return NextResponse.json({ error: 'Cuenta sin email: contacta con soporte.' }, { status: 400 });
  if (!(await verifyCurrentPassword(user.email, parsed.data.password))) {
    return NextResponse.json({ error: 'La contraseña no es correcta.' }, { status: 400 });
  }

  const { data: owned } = await admin
    .from('tenants')
    .select('id, name, subscription_status, stripe_subscription_id')
    .eq('owner_id', user.id);

  const active: ActiveSubscription[] = (owned ?? [])
    .filter((t) => BLOCKING_SUBSCRIPTION_STATUSES.includes(String(t.subscription_status)))
    .map((t) => ({ tenantId: t.id, name: t.name, status: t.subscription_status }));

  if (active.length > 0) {
    return NextResponse.json(
      {
        error: 'Antes de eliminar la cuenta tienes que darte de baja de tu suscripción.',
        code: 'active_subscription',
        subscriptions: active,
      },
      { status: 409 },
    );
  }

  // Negocios propios (sin suscripción activa): se borran; el resto de tablas cae en cascada.
  const ownedIds = (owned ?? []).map((t) => t.id);
  if (ownedIds.length > 0) await admin.from('tenants').delete().in('id', ownedIds);
  await admin.from('memberships').delete().eq('user_id', user.id);
  await admin.from('user_profiles').delete().eq('user_id', user.id);

  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) return NextResponse.json({ error: 'No se pudo eliminar la cuenta.' }, { status: 500 });

  await systemLog('warn', 'account.deleted', 'Cuenta eliminada por su titular', {
    subjectHash: hashPersonalValue(user.id),
    tenantsDeleted: ownedIds.length,
  });

  await supabase.auth.signOut().catch(() => undefined);
  return NextResponse.json({ ok: true });
}
