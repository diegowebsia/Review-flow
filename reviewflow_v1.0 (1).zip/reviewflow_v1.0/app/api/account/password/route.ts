import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { createClient } from '@/lib/supabase/server';
import { env } from '@/lib/env';
import { consumeRateLimit } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

const Body = z.object({
  currentPassword: z.string().min(1, 'Escribe tu contraseña actual.'),
  newPassword: z.string().min(8, 'La nueva contraseña debe tener al menos 8 caracteres.').max(72),
});

/** POST /api/account/password — cambia la contraseña tras verificar la actual. */
export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user?.email) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? 'Datos no válidos.' }, { status: 400 });
  }

  const rate = await consumeRateLimit('account-password', user.id, 5, 900);
  if (!rate.allowed) {
    return NextResponse.json({ error: 'Demasiados intentos. Prueba más tarde.' }, { status: 429 });
  }

  // Verificación de la contraseña actual con un cliente aislado (no toca las cookies de sesión).
  const verifier = createSupabaseClient(env.supabaseUrl, env.supabaseAnonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { error: verifyError } = await verifier.auth.signInWithPassword({
    email: user.email,
    password: parsed.data.currentPassword,
  });
  if (verifyError) {
    return NextResponse.json({ error: 'La contraseña actual no es correcta.' }, { status: 400 });
  }
  await verifier.auth.signOut().catch(() => undefined);

  if (parsed.data.currentPassword === parsed.data.newPassword) {
    return NextResponse.json({ error: 'La nueva contraseña debe ser distinta de la actual.' }, { status: 400 });
  }

  const { error } = await supabase.auth.updateUser({ password: parsed.data.newPassword });
  if (error) return NextResponse.json({ error: 'No se pudo cambiar la contraseña.' }, { status: 400 });
  return NextResponse.json({ ok: true });
}
