import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { createClient } from '@/lib/supabase/server';
import { normalizeRole, requireRole, type TenantRole } from '@/lib/authz';
import { consumeRateLimit } from '@/lib/rate-limit';
import { sendMail } from '@/lib/mail';
import { publicUrl } from '@/lib/public-url';
import { systemLog } from '@/lib/logger';
import { hashPersonalValue } from '@/lib/security';
import {
  ASSIGNABLE_ROLES,
  maxMembersOf,
  renderTeamInviteExistingUser,
  renderTeamInviteNewUser,
} from '@/lib/team';

export const dynamic = 'force-dynamic';

/**
 * /api/team — Equipo de una empresa.
 *   GET    ?tenantId=…               → lista del equipo (cualquier miembro).
 *   POST   { tenantId, email, role } → invitar (dueño o administrador).
 *   PATCH  { tenantId, userId, role }→ cambiar permiso (dueño o administrador).
 *   DELETE { tenantId, userId }      → quitar a alguien (dueño o administrador)
 *                                      o salir uno mismo (cualquier miembro salvo el dueño).
 * El dueño nunca se puede cambiar ni quitar desde aquí.
 */

const uuid = z.string().uuid();
const roleSchema = z.enum(ASSIGNABLE_ROLES);

function fail(error: string, status: number) {
  return NextResponse.json({ error }, { status });
}

function getAdmin() {
  return createAdminClient();
}

type MemberRow = { user_id: string; role: string | null; created_at: string };

async function loadTenant(admin: NonNullable<ReturnType<typeof getAdmin>>, tenantId: string) {
  const { data } = await admin
    .from('tenants')
    .select('id, name, owner_id, max_members')
    .eq('id', tenantId)
    .maybeSingle();
  return data as { id: string; name: string; owner_id: string | null; max_members?: number | null } | null;
}

async function targetRole(
  admin: NonNullable<ReturnType<typeof getAdmin>>,
  tenantId: string,
  userId: string,
  ownerId: string | null,
): Promise<TenantRole | null> {
  if (ownerId && ownerId === userId) return 'owner';
  const { data } = await admin
    .from('memberships')
    .select('role')
    .eq('tenant_id', tenantId)
    .eq('user_id', userId)
    .maybeSingle();
  if (!data) return null;
  return normalizeRole((data as { role?: string | null }).role);
}

export async function GET(req: Request) {
  const admin = getAdmin();
  if (!admin) return fail('Base de datos no configurada en el servidor.', 503);
  const tenantId = new URL(req.url).searchParams.get('tenantId');
  if (!uuid.safeParse(tenantId).success) return fail('Empresa no válida.', 400);

  const auth = await requireRole(admin, tenantId as string, 'viewer');
  if (!auth.ok) return fail(auth.error, auth.status);

  const tenant = await loadTenant(admin, tenantId as string);
  if (!tenant) return fail('Empresa no encontrada.', 404);

  const { data: rows } = await admin
    .from('memberships')
    .select('user_id, role, created_at')
    .eq('tenant_id', tenant.id)
    .order('created_at', { ascending: true });

  const list = (rows ?? []) as MemberRow[];
  const members = await Promise.all(
    list.map(async (m) => {
      const { data } = await admin.auth.admin.getUserById(m.user_id);
      const u = data?.user;
      const role: TenantRole = tenant.owner_id === m.user_id ? 'owner' : normalizeRole(m.role);
      return {
        userId: m.user_id,
        email: u?.email ?? '(sin email)',
        role,
        joinedAt: m.created_at,
        // Si aún no ha entrado nunca, la invitación está pendiente.
        pending: !u?.last_sign_in_at,
        isMe: m.user_id === auth.userId,
      };
    }),
  );
  const order: Record<TenantRole, number> = { owner: 0, admin: 1, agent: 2, viewer: 3 };
  members.sort((a, b) => order[a.role] - order[b.role] || a.email.localeCompare(b.email));

  return NextResponse.json({
    members,
    myRole: auth.role,
    maxMembers: maxMembersOf(tenant.max_members),
  });
}

const InviteSchema = z.object({
  tenantId: uuid,
  email: z.string().trim().toLowerCase().email().max(200),
  role: roleSchema,
});

export async function POST(req: Request) {
  const admin = getAdmin();
  if (!admin) return fail('Base de datos no configurada en el servidor.', 503);
  const parsed = InviteSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail('Escribe un email válido y elige un permiso.', 400);
  const { tenantId, email, role } = parsed.data;

  const auth = await requireRole(admin, tenantId, 'admin', { forbidImpersonation: true });
  if (!auth.ok) return fail(auth.error, auth.status);

  const rate = await consumeRateLimit('team-invite', `${tenantId}:${auth.userId}`, 30, 3600);
  if (!rate.allowed) return fail('Demasiadas invitaciones seguidas. Espera un rato.', 429);

  const tenant = await loadTenant(admin, tenantId);
  if (!tenant) return fail('Empresa no encontrada.', 404);

  const { count } = await admin
    .from('memberships')
    .select('id', { count: 'exact', head: true })
    .eq('tenant_id', tenantId);
  const max = maxMembersOf(tenant.max_members);
  if ((count ?? 0) >= max) {
    return fail(`El equipo está completo: caben ${max} personas por empresa. Quita a alguien para invitar a otra persona.`, 409);
  }

  const supabase = await createClient();
  const { data: me } = await supabase.auth.getUser();
  const inviterEmail = me.user?.email ?? 'Un administrador';

  // 1) Intentamos crear la invitación (solo funciona si NO tenía cuenta).
  const next = '/nueva-contrasena';
  let userId: string | null = null;
  let isNewUser = false;
  let inviteLink: string | null = null;

  const invite = await admin.auth.admin.generateLink({
    type: 'invite',
    email,
    options: { redirectTo: publicUrl(`/auth/callback?next=${encodeURIComponent(next)}`, req) },
  });

  if (!invite.error && invite.data?.user) {
    userId = invite.data.user.id;
    isNewUser = true;
    const tokenHash = invite.data.properties?.hashed_token;
    inviteLink = tokenHash
      ? publicUrl(
          `/auth/callback?token_hash=${encodeURIComponent(tokenHash)}&type=invite&next=${encodeURIComponent(next)}`,
          req,
        )
      : (invite.data.properties?.action_link ?? null);
  } else {
    // 2) Ya tenía cuenta: obtenemos su id sin enviarle ningún enlace de acceso.
    const existing = await admin.auth.admin.generateLink({ type: 'magiclink', email });
    if (existing.error || !existing.data?.user) {
      return fail('No se pudo invitar a esa persona. Revisa el email e inténtalo otra vez.', 400);
    }
    userId = existing.data.user.id;
  }

  if (userId === tenant.owner_id) return fail('Esa persona ya es la dueña de la empresa.', 409);

  const { data: already } = await admin
    .from('memberships')
    .select('id')
    .eq('tenant_id', tenantId)
    .eq('user_id', userId)
    .maybeSingle();
  if (already) return fail('Esa persona ya está en el equipo.', 409);

  const { error: insertError } = await admin
    .from('memberships')
    .insert({ tenant_id: tenantId, user_id: userId, role, invited_by: auth.userId });
  if (insertError) {
    // Compatibilidad con bases de datos sin la columna invited_by (migración pendiente).
    const retry = await admin.from('memberships').insert({ tenant_id: tenantId, user_id: userId, role });
    if (retry.error) return fail('No se pudo añadir a esa persona al equipo.', 500);
  }

  const mail =
    isNewUser && inviteLink
      ? renderTeamInviteNewUser({ tenantName: tenant.name, inviterEmail, role, link: inviteLink })
      : renderTeamInviteExistingUser({
          tenantName: tenant.name,
          inviterEmail,
          role,
          loginUrl: publicUrl('/login?redirect=/dashboard', req),
        });
  const sent = await sendMail({ to: email, ...mail }).catch(() => ({ sent: false, message: 'error' }));

  await systemLog('info', 'team', 'Invitación al equipo', {
    tenantId,
    role,
    isNewUser,
    mailSent: sent.sent,
    emailHash: hashPersonalValue(email).slice(0, 16),
  });

  return NextResponse.json({
    ok: true,
    isNewUser,
    mailSent: sent.sent,
    message: sent.sent
      ? isNewUser
        ? 'Invitación enviada. Recibirá un email para crear su contraseña.'
        : 'Añadido al equipo. Le hemos enviado un aviso por email.'
      : 'Añadido al equipo, pero el email no se pudo enviar (revisa la configuración de correo).',
  });
}

const PatchSchema = z.object({ tenantId: uuid, userId: uuid, role: roleSchema });

export async function PATCH(req: Request) {
  const admin = getAdmin();
  if (!admin) return fail('Base de datos no configurada en el servidor.', 503);
  const parsed = PatchSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail('Datos no válidos.', 400);
  const { tenantId, userId, role } = parsed.data;

  const auth = await requireRole(admin, tenantId, 'admin', { forbidImpersonation: true });
  if (!auth.ok) return fail(auth.error, auth.status);
  if (userId === auth.userId) return fail('No puedes cambiar tu propio permiso.', 400);

  const tenant = await loadTenant(admin, tenantId);
  if (!tenant) return fail('Empresa no encontrada.', 404);
  const current = await targetRole(admin, tenantId, userId, tenant.owner_id);
  if (!current) return fail('Esa persona no está en el equipo.', 404);
  if (current === 'owner') return fail('El permiso del dueño no se puede cambiar.', 403);

  const { error } = await admin
    .from('memberships')
    .update({ role })
    .eq('tenant_id', tenantId)
    .eq('user_id', userId);
  if (error) return fail('No se pudo cambiar el permiso.', 500);

  await systemLog('info', 'team', 'Permiso cambiado', { tenantId, from: current, to: role });
  return NextResponse.json({ ok: true });
}

const DeleteSchema = z.object({ tenantId: uuid, userId: uuid });

export async function DELETE(req: Request) {
  const admin = getAdmin();
  if (!admin) return fail('Base de datos no configurada en el servidor.', 503);
  const parsed = DeleteSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return fail('Datos no válidos.', 400);
  const { tenantId, userId } = parsed.data;

  // Cualquier miembro puede salir; quitar a otra persona exige administrar.
  const me = await requireRole(admin, tenantId, 'viewer');
  if (!me.ok) return fail(me.error, me.status);
  const leaving = userId === me.userId;

  if (!leaving) {
    const auth = await requireRole(admin, tenantId, 'admin', { forbidImpersonation: true });
    if (!auth.ok) return fail(auth.error, auth.status);
  }

  const tenant = await loadTenant(admin, tenantId);
  if (!tenant) return fail('Empresa no encontrada.', 404);
  const current = await targetRole(admin, tenantId, userId, tenant.owner_id);
  if (!current) return fail('Esa persona no está en el equipo.', 404);
  if (current === 'owner') {
    return fail(
      leaving
        ? 'El dueño no puede salir de su propia empresa. Si quieres cerrarla, usa «Borrar cuenta».'
        : 'Al dueño no se le puede quitar del equipo.',
      403,
    );
  }

  const { error } = await admin
    .from('memberships')
    .delete()
    .eq('tenant_id', tenantId)
    .eq('user_id', userId);
  if (error) return fail('No se pudo completar la baja.', 500);

  await systemLog('info', 'team', leaving ? 'Miembro sale del equipo' : 'Miembro quitado del equipo', {
    tenantId,
    role: current,
  });
  return NextResponse.json({ ok: true, left: leaving });
}
