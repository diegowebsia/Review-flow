import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { isTrialExpired } from '@/lib/plans';
import { googleReviewLink } from '@/lib/maps';
import { enqueue } from '@/lib/queue';
import { systemLog } from '@/lib/logger';
import { consumeRateLimit, rateLimitByTenant } from '@/lib/rate-limit';
import { escapeHtml, hashPersonalValue, requestIp, signOpaqueId, verifyOpaqueId } from '@/lib/security';
import { payloadErrorResponse, readJsonLimited } from '@/lib/request';
import { normalizeCampaign } from '@/lib/campaign';
import { verifyAntiBot } from '@/lib/antibot';

export const dynamic = 'force-dynamic';

/**
 * ============================================================
 * Flujo Neutral de Valoración — voto público (sin sesión)
 * ============================================================
 * `POST /api/feedback/respond`
 *   · Toda puntuación guarda el voto y recibe los mismos enlaces públicos.
 *   · Un mensaje opcional crea además un ticket privado y avisa al dueño.
 *
 * Reglas: embudo activado + suscripción usable (sin free-riding) +
 * rate-limit anti-spam por IP (10 votos/min) + rate-limit por slug +
 * anti-bot (Turnstile/honeypot) + consentimiento explícito RGPD.
 */
const Body = z.object({
  slug: z.string().min(1).max(120),
  stars: z.number().int().min(1).max(5),
  message: z.string().max(2000).optional(),
  name: z.string().max(120).optional(),
  contact: z.string().max(160).optional(),
  orderId: z.string().max(100).optional(),
  responseId: z.string().uuid().optional(),
  clickToken: z.string().min(20).optional(),
  campaign: z.string().max(100).optional(),
  privacyConsent: z.boolean().optional(),
  captchaToken: z.string().max(2048).optional(),
  website: z.string().max(200).optional(),
});


export async function POST(req: Request) {
  let rawBody: unknown;
  try { rawBody = await readJsonLimited(req, 16384); } catch (error) {
    return payloadErrorResponse(error) ?? NextResponse.json({ error: 'JSON inválido.' }, { status: 400 });
  }
  const parsed = Body.safeParse(rawBody);
  if (!parsed.success) return NextResponse.json({ error: 'Parámetros inválidos.' }, { status: 400 });
  const input = parsed.data;
  const campaign = normalizeCampaign(input.campaign);

  const botCheck = await verifyAntiBot(req, {
    captchaToken: input.captchaToken,
    honeypot: input.website,
  });
  if (!botCheck.allowed) {
    return NextResponse.json({ error: 'Verificación anti-bot no superada.' }, { status: 403 });
  }

  const ip = requestIp(req);
  const [rate, slugRate] = await Promise.all([
    consumeRateLimit('feedback', ip, 10, 60),
    consumeRateLimit('feedback-slug', input.slug.toLowerCase(), 45, 60),
  ]);
  if (!rate.allowed || !slugRate.allowed) {
    const retryAfter = Math.max(rate.retryAfter, slugRate.retryAfter);
    return NextResponse.json({ error: 'Demasiados votos. Espera un minuto.' }, { status: 429, headers: { 'Retry-After': String(retryAfter) } });
  }

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: 'Base de datos no configurada en el servidor.' }, { status: 503 });
  }

  const { data: rawTenant } = await admin
    .from('tenants')
    .select('id, name, subscription_status, suspended, trial_ends_at, settings')
    .eq('slug', input.slug)
    .single();
  const tenant = rawTenant as {
    id: string;
    name: string;
    subscription_status: string;
    suspended?: boolean;
    trial_ends_at?: string | null;
    settings?: {
      funnel_enabled?: boolean;
      place_id?: string | null;
      trustpilot_url?: string | null;
    } | null;
  } | null;
  const settings = tenant?.settings ?? {};
  const usable =
    tenant &&
    !tenant.suspended &&
    (tenant.subscription_status === 'active' || tenant.subscription_status === 'trialing') &&
    !isTrialExpired(tenant.subscription_status, tenant.trial_ends_at) &&
    settings.funnel_enabled !== false;
  if (!usable || !tenant) {
    return NextResponse.json({ error: 'Este enlace de valoración no está disponible.' }, { status: 404 });
  }

  const tenantRate = await rateLimitByTenant(tenant.id, 'feedback-funnel', 120, 60);
  if (!tenantRate.allowed) {
    return NextResponse.json({ error: 'Demasiadas solicitudes. Por favor espera un momento.' }, { status: 429 });
  }

  const ipHash = hashPersonalValue(ip).slice(0, 32);
  const userAgent = (req.headers.get('user-agent') ?? '').slice(0, 200);

  // Las opciones públicas son idénticas para todas las puntuaciones (sin review gating).
  const links = {
    google: settings.place_id ? googleReviewLink(settings.place_id) : null,
    trustpilot: (settings.trustpilot_url as string) || null,
  };
  const message = (input.message ?? '').trim();
  const isTicket = Boolean(message);

  if (isTicket && input.contact && !input.privacyConsent) {
    return NextResponse.json(
      { error: 'Debes aceptar la Política de Privacidad para el envío de datos de contacto (RGPD).' },
      { status: 400 },
    );
  }
  const existingId = isTicket && input.responseId && input.clickToken &&
    verifyOpaqueId(input.responseId, input.clickToken) ? input.responseId : null;
  const values = {
    tenant_id: tenant.id, stars: input.stars, kind: isTicket ? 'ticket' : 'redirect',
    customer_name: isTicket ? input.name?.trim() || null : null,
    contact: isTicket ? input.contact?.trim() || null : null,
    message: isTicket ? message : null,
    order_id: isTicket ? input.orderId?.trim() || null : null,
    ip_hash: ipHash, user_agent: userAgent, campaign,
  };
  const query = existingId
    ? admin.from('feedback_responses').update(values).eq('id', existingId).eq('tenant_id', tenant.id).eq('kind', 'redirect').gte('created_at', new Date(Date.now() - 60 * 60_000).toISOString()).select('id').single()
    : admin.from('feedback_responses').insert(values).select('id').single();
  const { data: row, error } = await query;
  if (error || !row) return NextResponse.json({ error: 'No se pudo registrar tu valoración.' }, { status: 500 });
  const clickToken = signOpaqueId(String(row.id));
  if (!isTicket) {
    return NextResponse.json({
      ok: true, responseId: row.id, clickToken, kind: 'redirect', links,
      allowPrivateFeedback: input.stars <= 3,
    });
  }

  // Aviso interno (nunca público): email al dueño, encolado.
  const excerpt = message.length > 220 ? `${message.slice(0, 220)}…` : message;
  const who = [input.name?.trim(), input.contact?.trim()].filter(Boolean).join(' · ') || 'Anónimo';
  try {
    await enqueue({
      type: 'notify.owner',
      tenantId: tenant.id,
      subject: `🎫 Ticket privado (${input.stars}★) en ${tenant.name} — ${who}`,
      html:
        `<p>Nuevo <strong>ticket privado de ${input.stars}★</strong> desde tu embudo de satisfacción. ` +
        `No se ha publicado en ningún sitio.</p>` +
        `<p><strong>Cliente:</strong> ${escapeHtml(who)}${input.orderId ? ` · <strong>Pedido:</strong> ${escapeHtml(input.orderId)}` : ''}</p>` +
        `<blockquote>${escapeHtml(excerpt)}</blockquote>` +
        `<p>Gestiona el ticket en tu panel → Embudo.</p>`,
      text: `Ticket privado (${input.stars}★) de ${who}: ${excerpt}`,
    });
  } catch (e: unknown) {
    const errMsg = e instanceof Error && e.message ? e.message : String(e);
    await systemLog('warn', 'feedback.ticket', `Ticket guardado pero aviso fallido: ${errMsg}`, {
      tenantId: tenant.id,
    });
  }

  return NextResponse.json({ ok: true, responseId: row.id, clickToken, kind: 'ticket', links });
}
