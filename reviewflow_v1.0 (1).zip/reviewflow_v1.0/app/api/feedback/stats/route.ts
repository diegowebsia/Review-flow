import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { rateLimitByTenant } from '@/lib/rate-limit';

export const dynamic = 'force-dynamic';

type FeedbackRow = {
  stars: number;
  kind: string;
  channel: string | null;
  status: string;
  campaign: string | null;
  created_at: string;
};

/**
 * Estadísticas del Flujo Neutral de Valoración para el panel (requiere membresía):
 * totales, media, reparto 1-5★, canales elegidos y tickets abiertos.
 */
export async function GET(req: Request) {
  const tenantId = new URL(req.url).searchParams.get('tenantId') ?? '';
  if (!tenantId) return NextResponse.json({ error: 'Falta tenantId.' }, { status: 400 });

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const rl = await rateLimitByTenant(tenantId, 'feedback:stats', 60, 60);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas consultas de estadísticas. Espera unos segundos.' },
      { status: 429, headers: { 'Retry-After': String(rl.retryAfter) } },
    );
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const { data: member } = await admin
    .from('memberships')
    .select('id')
    .eq('tenant_id', tenantId)
    .eq('user_id', user.id)
    .single();
  if (!member) return NextResponse.json({ error: 'Sin permiso en esta empresa.' }, { status: 403 });

  const { data: rows } = await admin
    .from('feedback_responses')
    .select('stars, kind, channel, status, campaign, created_at')
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: false })
    .limit(2000);

  const list = (rows ?? []) as FeedbackRow[];
  const byStars: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  const byChannel: Record<string, number> = { google: 0, trustpilot: 0, none: 0 };
  let sum = 0;
  let redirects = 0;
  let clicks = 0;
  let ticketsOpen = 0;
  let ticketsClosed = 0;
  const campaignMap = new Map<string, { campaign: string; votes: number; clicks: number; tickets: number }>();
  for (const r of list) {
    byStars[r.stars] = (byStars[r.stars] ?? 0) + 1;
    sum += r.stars;
    const campaign = r.campaign || 'sin-campana';
    const campaignStats = campaignMap.get(campaign) ?? { campaign, votes: 0, clicks: 0, tickets: 0 };
    campaignStats.votes += 1;
    if (r.channel) { campaignStats.clicks += 1; clicks += 1; }
    if (r.kind === 'ticket') campaignStats.tickets += 1;
    campaignMap.set(campaign, campaignStats);
    if (r.kind === 'redirect') {
      redirects += 1;
      byChannel[r.channel ?? 'none'] = (byChannel[r.channel ?? 'none'] ?? 0) + 1;
    } else if (r.status === 'closed') {
      ticketsClosed += 1;
    } else {
      ticketsOpen += 1;
    }
  }

  return NextResponse.json({
    ok: true,
    total: list.length,
    avgStars: list.length > 0 ? Math.round((sum / list.length) * 100) / 100 : null,
    promoters: (byStars[4] ?? 0) + (byStars[5] ?? 0),
    detractors: (byStars[1] ?? 0) + (byStars[2] ?? 0) + (byStars[3] ?? 0),
    redirects,
    clicks,
    ticketsOpen,
    ticketsClosed,
    byStars,
    byChannel,
    campaigns: Array.from(campaignMap.values()).sort((a, b) => b.votes - a.votes).slice(0, 20),
  });
}
