import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getStripe, priceIdFor } from '@/lib/stripe';
import { TRIAL_DAYS, planOf, resolvePlan, type PlanId } from '@/lib/plans';
import { resolvePublicUrl as resolveBaseUrl } from '@/lib/public-url';
import { getSessionUser } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';
import { consumeRateLimit } from '@/lib/rate-limit';
import { getFreeTrialEnabled } from '@/lib/system-settings';
import { captureException, correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';
import { errorMessage } from '@/lib/api-error';
import { hasUsedFreeTrial } from '@/lib/trial';

export const dynamic = 'force-dynamic';

const CheckoutInputSchema = z.object({
  plan: z.string().trim().max(64).optional(),
  /** Multipanel: contratar un plan para OTRA empresa de la misma cuenta. */
  newBusiness: z.boolean().optional(),
  businessName: z.string().trim().min(2).max(80).optional(),
  /** Reactivar una empresa concreta que ya existe y no tiene suscripción viva. */
  tenantId: z.string().uuid().optional(),
});

const LIVE_STATUSES = ['active', 'trialing', 'past_due', 'unpaid', 'paused'];

/**
 * Checkout de suscripción en Stripe.
 * Aplica los 7 días de prueba gratis solo si `getFreeTrialEnabled()` está activo;
 * cuando el Super-Admin lo desactiva, cobra la primera cuota de inmediato.
 */
async function handleCheckout(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const wantsJson =
    req.method === 'POST' || (req.headers.get('accept') ?? '').includes('application/json');

  const stripe = getStripe();
  if (!stripe) {
    return NextResponse.json(
      {
        error:
          'Falta configurar STRIPE_SECRET_KEY en tu archivo .env (usa tu clave de prueba sk_test_... de https://dashboard.stripe.com/test/apikeys y reinicia con npm run dev).',
        code: 'stripe_not_configured',
      },
      { status: 503 },
    );
  }

  const user = await getSessionUser();
  if (!user) {
    if (wantsJson) {
      return NextResponse.json(
        { error: 'Tu sesión ha expirado. Vuelve a iniciar sesión para continuar al pago.', loginUrl: '/login?redirect=/bienvenido' },
        { status: 401 },
      );
    }
    const login = new URL('/login', req.url);
    login.searchParams.set('redirect', '/bienvenido');
    return NextResponse.redirect(login);
  }

  const rate = await consumeRateLimit('stripe-checkout', user.id, 25, 600);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas solicitudes de checkout. Espera unos minutos antes de reintentar.' },
      { status: 429, headers: { 'Retry-After': String(rate.retryAfter) } },
    );
  }

  const url = new URL(req.url);
  let requested = url.searchParams.get('plan');
  let newBusiness = url.searchParams.get('nueva') === '1';
  let businessName = (url.searchParams.get('nombre') ?? '').trim().slice(0, 80);
  let requestedTenantId = url.searchParams.get('tenantId') ?? '';
  if (req.method === 'POST') {
    const rawBody: unknown = await req.json().catch(() => ({}));
    const parsedBody = CheckoutInputSchema.safeParse(rawBody);
    if (!parsedBody.success) {
      return NextResponse.json({ error: 'Datos no válidos (el nombre debe tener 2-80 caracteres).' }, { status: 400 });
    }
    if (!requested && parsedBody.data.plan) requested = parsedBody.data.plan;
    if (parsedBody.data.newBusiness) newBusiness = true;
    if (parsedBody.data.businessName) businessName = parsedBody.data.businessName;
    if (parsedBody.data.tenantId) requestedTenantId = parsedBody.data.tenantId;
  }
  if (!/^[0-9a-f-]{36}$/i.test(requestedTenantId)) requestedTenantId = '';
  if (newBusiness && businessName.length < 2) {
    return NextResponse.json(
      { error: 'Escribe el nombre de la nueva empresa (mínimo 2 letras).', code: 'missing_business_name' },
      { status: 400 },
    );
  }

  const plan: PlanId = resolvePlan(requested);
  const def = planOf(plan);
  const price = priceIdFor(plan);

  const line_items = price
    ? [{ price, quantity: 1 }]
    : [
        {
          quantity: 1,
          price_data: {
            currency: 'eur',
            unit_amount: def.priceCents,
            recurring: { interval: 'month' as const },
            product_data: {
              name: `ReviewFlow AI — ${def.name}`,
              description: `${def.pitch} (1 empresa / local)`,
              metadata: { plan },
            },
          },
        },
      ];

  const admin = createAdminClient();
  let existingCustomer: string | undefined;
  let tenantId = '';
  type OwnedRow = { id: string; stripe_customer_id: string | null; stripe_subscription_id: string | null };
  let owned: OwnedRow[] = [];
  if (admin) {
    const { data } = await admin
      .from('tenants')
      .select('id, stripe_customer_id, stripe_subscription_id')
      .eq('owner_id', user.id)
      .order('created_at', { ascending: true });
    owned = (data ?? []) as OwnedRow[];
    // Multipanel: todas las empresas de la cuenta comparten el mismo cliente de Stripe
    // (una sola ficha, una sola tarjeta, todas las facturas en el mismo portal).
    existingCustomer = owned.find((t) => t.stripe_customer_id)?.stripe_customer_id || undefined;
  }

  const isLive = async (subId: string | null): Promise<boolean> => {
    if (!subId) return false;
    try {
      const sub = await stripe.subscriptions.retrieve(subId);
      return LIVE_STATUSES.includes(sub.status);
    } catch {
      return false;
    }
  };

  const alreadySubscribed = (msg: string) =>
    wantsJson
      ? NextResponse.json({ error: msg, code: 'already_subscribed', redirect: '/dashboard?tab=facturacion' }, { status: 409 })
      : NextResponse.redirect(new URL('/dashboard?tab=facturacion', req.url), 303);

  if (!newBusiness) {
    if (requestedTenantId) {
      // Reactivar una empresa concreta: debe ser del usuario y no tener suscripción viva.
      const target = owned.find((t) => t.id === requestedTenantId);
      if (!target) {
        return NextResponse.json({ error: 'Esa empresa no es tuya.', code: 'forbidden' }, { status: 403 });
      }
      if (await isLive(target.stripe_subscription_id)) {
        return alreadySubscribed('Esta empresa ya tiene un plan. Cámbialo desde tu panel → Facturación.');
      }
      tenantId = target.id;
    } else if (owned.length > 0) {
      // Sin indicar empresa: reactiva la primera que esté sin plan; si todas tienen plan,
      // evitamos cobrar dos veces y llevamos a Facturación (para otra empresa → «Añadir empresa»).
      let free: OwnedRow | undefined;
      for (const t of owned) {
        if (!(await isLive(t.stripe_subscription_id))) {
          free = t;
          break;
        }
      }
      if (!free) {
        return alreadySubscribed(
          'Ya tienes un plan activo. Para otra empresa usa «Añadir empresa» en tu panel; para cambiar de plan, Facturación.',
        );
      }
      tenantId = free.id;
    }
  }

  // Prueba gratis: SOLO 1 vez por cuenta (y nunca para empresas adicionales).
  const hadSubscriptionBefore =
    newBusiness ||
    (await hasUsedFreeTrial(admin, stripe, { userId: user.id, email: user.email, customerId: existingCustomer }));

  const freeTrialEnabled = (await getFreeTrialEnabled()) && !hadSubscriptionBefore;
  const baseUrl = resolveBaseUrl(req);

  const buildParams = (customerId?: string) => ({
    mode: 'subscription' as const,
    ...(customerId ? { customer: customerId } : { customer_email: user.email ?? undefined }),
    client_reference_id: tenantId || user.id,
    // Códigos de descuento: se crean en Stripe (Productos → Cupones → Códigos promocionales).
    // Ponlo a «false» en STRIPE_ALLOW_PROMOTION_CODES para ocultar la casilla en el pago.
    allow_promotion_codes: process.env.STRIPE_ALLOW_PROMOTION_CODES !== 'false',
    payment_method_collection: 'always' as const,
    billing_address_collection: 'required' as const,
    ...(customerId ? { customer_update: { address: 'auto' as const, name: 'auto' as const } } : {}),
    line_items,
    subscription_data: {
      ...(freeTrialEnabled
        ? {
            trial_period_days: TRIAL_DAYS,
            trial_settings: {
              end_behavior: { missing_payment_method: 'pause' as const },
            },
          }
        : {}),
      metadata: {
        userId: user.id,
        plan,
        priceId: price || 'inline',
        tenantId,
        freeTrial: freeTrialEnabled ? 'true' : 'false',
        newBusiness: newBusiness ? 'true' : 'false',
        businessName: businessName || '',
      },
    },
    metadata: {
      tenantId,
      priceId: price || 'inline',
      userId: user.id,
      plan,
      freeTrial: freeTrialEnabled ? 'true' : 'false',
      newBusiness: newBusiness ? 'true' : 'false',
      businessName: businessName || '',
    },
    success_url: `${baseUrl}/bienvenido?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: newBusiness
      ? `${baseUrl}/dashboard?tab=empresa&nueva=cancelada`
      : `${baseUrl}/bienvenido?checkout=canceled&plan=${plan}`,
  });

  try {
    let session;
    const enableAutoTax = process.env.STRIPE_AUTOMATIC_TAX === 'true';
    try {
      session = await stripe.checkout.sessions.create({
        ...buildParams(existingCustomer),
        ...(enableAutoTax
          ? { automatic_tax: { enabled: true }, tax_id_collection: { enabled: true } }
          : {}),
      });
    } catch (firstErr: unknown) {
      // Si falló por cliente inexistente en otra cuenta de Stripe o por Stripe Tax no configurado,
      // reintenta limpiamente con customer_email y sin automatic_tax.
      session = await stripe.checkout.sessions.create(buildParams(undefined));
      await systemLog(
        'warn',
        'stripe.checkout',
        `Reintento limpio de checkout (${errorMessage(firstErr, 'fallback')})`,
      );
    }

    await systemLog(
      'info',
      'stripe.checkout',
      `Checkout ${plan} (${freeTrialEnabled ? `trial ${TRIAL_DAYS} días` : 'cobro inmediato sin prueba'})`,
      {
        user: user.email,
        session: session.id,
        freeTrialEnabled,
        correlationId,
      },
    );

    if (wantsJson) {
      return NextResponse.json(
        { ok: true, url: session.url, sessionId: session.id, correlationId },
        { headers: correlationHeaders(correlationId) },
      );
    }
    return NextResponse.redirect(session.url!, { status: 303, headers: correlationHeaders(correlationId) });
  } catch (e: unknown) {
    await captureException(e, {
      source: 'stripe.checkout',
      correlationId,
      userEmail: user.email ?? undefined,
      tenantId: tenantId || undefined,
    });
    return NextResponse.json(
      { error: errorMessage(e, 'No se pudo abrir el checkout de Stripe.'), code: 'stripe_error', correlationId },
      { status: 502, headers: correlationHeaders(correlationId) },
    );
  }
}

export async function GET(req: Request) {
  return handleCheckout(req);
}

export async function POST(req: Request) {
  return handleCheckout(req);
}
