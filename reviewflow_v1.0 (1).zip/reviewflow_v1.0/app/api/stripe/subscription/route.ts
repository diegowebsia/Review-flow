import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { requireRole } from '@/lib/authz';
import { getStripe, priceIdFor } from '@/lib/stripe';
import {
  annualPriceCentsOf,
  formatEur,
  planOf,
  resolvePlan,
  type PlanId,
} from '@/lib/plans';
import { systemLog } from '@/lib/logger';
import { canReactivate, periodEndDate, type CancellationState } from '@/lib/cancellation';
import { buildRetentionOffers, discountDurationLabel, getRetentionConfig, hasUsedRetentionDiscount } from '@/lib/retention-offers';
import { trackProductEvent } from '@/lib/business-metrics';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

export const dynamic = 'force-dynamic';

/**
 * Línea de precio para cambiar el plan de una suscripción existente.
 * Usa el Price ID configurado (mensual) o, si no existe o el cobro es anual,
 * un precio inline sobre el mismo producto de Stripe.
 */
function planItemUpdate(
  item: { id: string; price: { product: string | { id: string } } },
  plan: PlanId,
  interval: 'month' | 'year',
) {
  const priceId = priceIdFor(plan);
  if (priceId && interval === 'month') return { id: item.id, price: priceId };
  const product = typeof item.price.product === 'string' ? item.price.product : item.price.product.id;
  return {
    id: item.id,
    price_data: {
      currency: 'eur',
      product,
      unit_amount: interval === 'year' ? annualPriceCentsOf(plan) : planOf(plan).priceCents,
      recurring: { interval },
    },
  };
}

const ActionBody = z.discriminatedUnion('action', [
  z.object({
    action: z.literal('upgrade'),
    tenantId: z.string().uuid(),
    targetPlan: z.enum(['local_starter', 'ecommerce_starter', 'local_pro', 'ecommerce_pro', 'pro', 'business']),
    interval: z.enum(['month', 'year']).optional(),
  }),
  z.object({
    action: z.literal('downgrade'),
    tenantId: z.string().uuid(),
    targetPlan: z.enum(['local_starter', 'ecommerce_starter', 'local_pro', 'ecommerce_pro', 'pro', 'business']),
  }),
  z.object({
    action: z.literal('pause'),
    tenantId: z.string().uuid(),
    months: z.number().int().min(1).max(3).optional(),
    cancelReason: z.string().max(300).optional(),
  }),
  z.object({
    action: z.literal('cancel'),
    tenantId: z.string().uuid(),
    mode: z.enum(['period_end', 'now']),
    cancelReason: z.string().max(300).optional(),
  }),
  z.object({
    action: z.literal('reactivate'),
    tenantId: z.string().uuid(),
  }),
  z.object({
    action: z.literal('apply_retention_discount'),
    tenantId: z.string().uuid(),
    cancelReason: z.string().max(300).optional(),
  }),
  z.object({
    action: z.literal('apply_recovery_discount'),
    tenantId: z.string().uuid(),
  }),
  z.object({
    action: z.literal('tax_info'),
    tenantId: z.string().uuid(),
    taxId: z.string().trim().min(4).max(40),
    legalName: z.string().trim().min(2).max(140),
    country: z.string().trim().max(4).optional(),
  }),
  z.object({
    action: z.literal('add_location'),
    tenantId: z.string().uuid(),
    extraLocations: z.number().int().min(1).max(25),
  }),
]);

/**
 * GET /api/stripe/subscription?tenantId=...&targetPlan=...&interval=month|year
 * Devuelve:
 *  - Previsualización exacta de prorrateo (`stripe.invoices.createPreview` o cálculo determinista)
 *  - Facturas descargables del cliente en el propio panel
 *  - Datos fiscales guardados (NIF/CIF, razón social) y estado de pausa/gracia
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const tenantId = url.searchParams.get('tenantId') ?? '';
  const targetPlanRaw = url.searchParams.get('targetPlan');
  const interval = url.searchParams.get('interval') === 'year' ? 'year' : 'month';

  if (!tenantId) {
    return NextResponse.json({ error: 'Falta tenantId.' }, { status: 400 });
  }

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: 'Base de datos no disponible.' }, { status: 503 });
  }

  const auth = await requireRole(admin, tenantId, 'viewer');
  if (!auth.ok) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  const { data: rawTenant } = await admin
    .from('tenants')
    .select('*')
    .eq('id', tenantId)
    .single();

  if (!rawTenant) {
    return NextResponse.json({ error: 'Empresa no encontrada.' }, { status: 404 });
  }

  type SubscriptionTenantRow = {
    id: string;
    name: string;
    plan: string;
    stripe_subscription_id?: string | null;
    stripe_customer_id?: string | null;
    tax_id?: string | null;
    legal_name?: string | null;
    extra_locations?: number | null;
    grace_period_ends_at?: string | null;
    settings?: {
      tax_id?: string;
      legal_name?: string;
      tax_country?: string;
      extra_locations?: number;
      scheduled_downgrade_plan?: string | null;
      paused_until?: string | null;
      grace_period_ends_at?: string | null;
      [key: string]: unknown;
    } | null;
  };

  const tenant = rawTenant as SubscriptionTenantRow;
  const currentPlan = planOf(tenant.plan);
  const targetPlanId: PlanId = targetPlanRaw ? resolvePlan(targetPlanRaw) : currentPlan.id;
  const targetPlan = planOf(targetPlanId);

  const currentCents = currentPlan.priceCents;
  const targetCents =
    interval === 'year' ? annualPriceCentsOf(targetPlan) : targetPlan.priceCents;

  // Cálculo determinista de prorrateo (día actual del mes) + enriquecimiento con Stripe createPreview si hay suscripción activa
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const remainingFraction = Math.max(0.1, (daysInMonth - now.getDate() + 1) / daysInMonth);
  let proratedDueCents =
    interval === 'year'
      ? Math.max(0, targetCents - Math.round(currentCents * remainingFraction))
      : Math.max(0, Math.round((targetCents - currentCents) * remainingFraction));

  const invoices: Array<{
    id: string;
    number: string;
    date: string;
    amountCents: number;
    status: string;
    pdfUrl: string | null;
    hostedUrl: string | null;
  }> = [];

  const stripe = getStripe();
  const subId = tenant.stripe_subscription_id ?? null;
  const customerId = tenant.stripe_customer_id ?? null;

  if (stripe && customerId) {
    try {
      const invList = await stripe.invoices.list({ customer: customerId, limit: 12 });
      for (const inv of invList.data) {
        invoices.push({
          id: inv.id,
          number: inv.number || inv.id.slice(-8).toUpperCase(),
          date: new Date((inv.created || Date.now() / 1000) * 1000).toISOString(),
          amountCents: inv.amount_paid || inv.amount_due || 0,
          status: inv.status || 'paid',
          pdfUrl: inv.invoice_pdf ?? null,
          hostedUrl: inv.hosted_invoice_url ?? null,
        });
      }
    } catch {
      /* ignore Stripe invoice list error in preview */
    }
  }

  if (stripe && subId && targetPlanRaw) {
    const newPriceId = priceIdFor(targetPlanId);
    if (newPriceId) {
      try {
        const sub = await stripe.subscriptions.retrieve(subId);
        const itemId = sub.items.data[0]?.id;
        const invoicesWithPreview = stripe.invoices as unknown as {
          createPreview?: (params: Record<string, unknown>) => Promise<{ amount_due?: number }>;
        };
        if (itemId && typeof invoicesWithPreview.createPreview === 'function') {
          const preview = await invoicesWithPreview.createPreview({
            customer: customerId ?? undefined,
            subscription: subId,
            subscription_details: {
              items: [{ id: itemId, price: newPriceId }],
              proration_behavior: 'always_invoice',
            },
          });
          if (typeof preview?.amount_due === 'number') {
            proratedDueCents = Math.max(0, preview.amount_due);
          }
        }
      } catch {
        /* fallback al cálculo determinista de prorrateo */
      }
    }
  }

  const settings = tenant.settings ?? {};

  return NextResponse.json({
    ok: true,
    currentPlan: currentPlan.id,
    targetPlan: targetPlan.id,
    interval,
    prorationPreview: {
      proratedDueCents,
      proratedDueFormatted: formatEur(proratedDueCents),
      nextCycleCents: targetCents,
      nextCycleFormatted: formatEur(targetCents),
      annualSavingsFormatted: formatEur(targetPlan.priceCents * 2),
    },
    taxInfo: {
      taxId: tenant.tax_id ?? settings.tax_id ?? '',
      legalName: tenant.legal_name ?? settings.legal_name ?? tenant.name ?? '',
      country: settings.tax_country ?? 'ES',
    },
    extraLocations: Number(tenant.extra_locations ?? settings.extra_locations ?? 0),
    scheduledDowngradePlan: settings.scheduled_downgrade_plan ?? null,
    pausedUntil: settings.paused_until ?? null,
    cancellation: {
      mode: (settings.cancel_mode as string | null | undefined) ?? null,
      cancelAt: (settings.cancel_at as string | null | undefined) ?? null,
      canReactivate: canReactivate(settings as CancellationState),
    },
    retentionOffers: buildRetentionOffers(tenant.plan, settings as Record<string, unknown>),
    gracePeriodEndsAt: tenant.grace_period_ends_at ?? settings.grace_period_ends_at ?? null,
    invoices,
  });
}

/**
 * POST /api/stripe/subscription
 * Ejecuta cambios de suscripción in-app en 1 clic (bloqueado durante impersonación de soporte).
 */
export async function POST(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const raw = await req.json().catch(() => ({}));
  const parsed = ActionBody.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Solicitud de suscripción inválida.', correlationId },
      { status: 400, headers: correlationHeaders(correlationId) },
    );
  }

  const admin = createAdminClient();
  if (!admin) {
    return NextResponse.json({ error: 'Base de datos no configurada.' }, { status: 503 });
  }

  const body = parsed.data;
  const auth = await requireRole(admin, body.tenantId, 'owner', { forbidImpersonation: true });
  if (!auth.ok) {
    return NextResponse.json({ error: auth.error }, { status: auth.status });
  }

  const { data: rawTenant } = await admin
    .from('tenants')
    .select('*')
    .eq('id', body.tenantId)
    .single();
  if (!rawTenant) {
    return NextResponse.json({ error: 'Empresa no encontrada.' }, { status: 404 });
  }

  const tenant = rawTenant as {
    plan: string;
    stripe_subscription_id?: string | null;
    stripe_customer_id?: string | null;
    settings?: Record<string, unknown> | null;
  };
  const prevSettings = tenant.settings ?? {};
  const stripe = getStripe();
  const subId = tenant.stripe_subscription_id ?? null;
  const customerId = tenant.stripe_customer_id ?? null;

  if (body.action === 'upgrade') {
    const targetPlan = resolvePlan(body.targetPlan);
    const interval = body.interval ?? 'month';

    // El plan SOLO cambia si Stripe acepta el cambio (cobro prorrateado).
    // Sin suscripción activa hay que pasar por Checkout: nunca se regala un plan.
    if (!stripe || !subId) {
      return NextResponse.json(
        { error: 'No tienes una suscripción activa. Elige un plan para continuar.', code: 'no_subscription', checkoutUrl: `/api/stripe/checkout?plan=${targetPlan}`, correlationId },
        { status: 409, headers: correlationHeaders(correlationId) },
      );
    }
    try {
      const sub = await stripe.subscriptions.retrieve(subId);
      if (sub.status === 'canceled' || sub.status === 'incomplete_expired') {
        return NextResponse.json(
          { error: 'Tu suscripción está cancelada. Elige un plan para volver a activarla.', code: 'no_subscription', checkoutUrl: `/api/stripe/checkout?plan=${targetPlan}`, correlationId },
          { status: 409, headers: correlationHeaders(correlationId) },
        );
      }
      const item = sub.items.data[0];
      if (!item) throw new Error('Suscripción sin líneas');
      const meta: Record<string, string> = { ...(sub.metadata ?? {}), plan: targetPlan, billing_interval: interval };
      delete meta.pending_downgrade_plan;
      delete meta.pending_downgrade_until;
      await stripe.subscriptions.update(subId, {
        items: [planItemUpdate(item as never, targetPlan, interval)],
        proration_behavior: 'always_invoice',
        metadata: meta,
      });
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      await systemLog('warn', 'stripe.subscription.upgrade', `Stripe rechazó el cambio de plan: ${errMsg}`);
      return NextResponse.json(
        { error: 'No se pudo cambiar el plan en Stripe. Revisa tu método de pago e inténtalo de nuevo.', correlationId },
        { status: 502, headers: correlationHeaders(correlationId) },
      );
    }

    const nextSettings = {
      ...prevSettings,
      billing_interval: interval,
      scheduled_downgrade_plan: null,
    };

    const { error } = await admin
      .from('tenants')
      .update({
        plan: targetPlan,
        settings: nextSettings,
      })
      .eq('id', body.tenantId);

    if (error) {
      return NextResponse.json({ error: error.message, correlationId }, { status: 500, headers: correlationHeaders(correlationId) });
    }

    await trackProductEvent('plan_upgraded', {
      tenantId: body.tenantId,
      plan: targetPlan,
      previousPlan: tenant.plan,
      correlationId,
      meta: { interval },
    });

    return NextResponse.json({
      ok: true,
      correlationId,
      plan: targetPlan,
      interval,
      message: `Plan actualizado en 1 clic a ${planOf(targetPlan).name} (${interval === 'year' ? 'Anual · 2 meses gratis' : 'Mensual'}). Nuevas cuotas activas al instante.`,
    }, { headers: correlationHeaders(correlationId) });
  }

  if (body.action === 'downgrade') {
    const targetPlan = resolvePlan(body.targetPlan);
    if (!stripe || !subId) {
      return NextResponse.json(
        { error: 'No tienes una suscripción activa que cambiar.', code: 'no_subscription', correlationId },
        { status: 409, headers: correlationHeaders(correlationId) },
      );
    }
    // Stripe cobra el plan nuevo desde la próxima factura (sin prorrateo) y el
    // webhook aplica los nuevos límites al renovar (ver applyInvoicePaid).
    let effectiveAt = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString();
    try {
      const sub = await stripe.subscriptions.retrieve(subId);
      const item = sub.items.data[0];
      if (!item) throw new Error('Suscripción sin líneas');
      const interval = (item.price?.recurring?.interval === 'year' ? 'year' : 'month') as 'month' | 'year';
      const periodEnd = (sub as unknown as { current_period_end?: number }).current_period_end;
      if (periodEnd) effectiveAt = new Date(periodEnd * 1000).toISOString();
      await stripe.subscriptions.update(subId, {
        items: [planItemUpdate(item as never, targetPlan, interval)],
        proration_behavior: 'none',
        metadata: {
          ...(sub.metadata ?? {}),
          pending_downgrade_plan: targetPlan,
          pending_downgrade_until: String(periodEnd ?? ''),
        },
      });
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      await systemLog('warn', 'stripe.subscription.downgrade', `Stripe rechazó el cambio: ${errMsg}`);
      return NextResponse.json(
        { error: 'No se pudo programar el cambio de plan. Inténtalo de nuevo.', correlationId },
        { status: 502, headers: correlationHeaders(correlationId) },
      );
    }
    const nextSettings = {
      ...prevSettings,
      scheduled_downgrade_plan: targetPlan,
      scheduled_downgrade_at: effectiveAt,
    };

    await admin
      .from('tenants')
      .update({ settings: nextSettings })
      .eq('id', body.tenantId);

    await trackProductEvent('plan_downgraded', {
      tenantId: body.tenantId,
      plan: targetPlan,
      previousPlan: tenant.plan,
      correlationId,
    });

    return NextResponse.json({
      ok: true,
      correlationId,
      scheduledPlan: targetPlan,
      message: `Cambio a ${planOf(targetPlan).name} programado para final de ciclo. Conservas tus límites actuales hasta la próxima renovación.`,
    }, { headers: correlationHeaders(correlationId) });
  }

  if (body.action === 'pause') {
    const pauseCfg = getRetentionConfig().pause;
    if (!pauseCfg.enabled) {
      return NextResponse.json({ error: 'La pausa de suscripción no está disponible.', correlationId }, { status: 403, headers: correlationHeaders(correlationId) });
    }
    const months = Math.min(body.months ?? pauseCfg.months, pauseCfg.months);
    const resumeDate = new Date(Date.now() + months * 30 * 86_400_000);

    if (stripe && subId) {
      try {
        await stripe.subscriptions.update(subId, {
          pause_collection: {
            behavior: 'void',
            resumes_at: Math.floor(resumeDate.getTime() / 1000),
          },
        });
      } catch (err: unknown) {
        const errMsg = err instanceof Error ? err.message : String(err);
        await systemLog('warn', 'stripe.subscription.pause', `No se pudo pausar en Stripe: ${errMsg}`);
        return NextResponse.json({ error: 'No se pudo pausar la suscripción. Inténtalo de nuevo.', correlationId }, { status: 502, headers: correlationHeaders(correlationId) });
      }
    }

    const nextSettings = {
      ...prevSettings,
      paused_until: resumeDate.toISOString(),
      last_retention_reason: body.cancelReason ?? 'pausa_1_mes',
    };

    await admin
      .from('tenants')
      .update({ settings: nextSettings })
      .eq('id', body.tenantId);

    await trackProductEvent('subscription_paused', {
      tenantId: body.tenantId,
      plan: tenant.plan,
      correlationId,
      meta: { months, pausedUntil: resumeDate.toISOString() },
    });

    return NextResponse.json({
      ok: true,
      correlationId,
      pausedUntil: resumeDate.toISOString(),
      message: `Tu suscripción se ha pausado sin coste durante ${months} ${months === 1 ? 'mes' : 'meses'} (hasta el ${resumeDate.toLocaleDateString('es-ES')}). Tus reseñas e histórico quedan protegidos.`,
    }, { headers: correlationHeaders(correlationId) });
  }

  if (body.action === 'cancel') {
    const nowDate = new Date();
    let cancelAt = nowDate;

    if (body.mode === 'period_end') {
      let stripePeriodEnd: number | null = null;
      if (stripe && subId) {
        try {
          const sub = await stripe.subscriptions.update(subId, { cancel_at_period_end: true });
          const raw = sub as unknown as {
            current_period_end?: number;
            cancel_at?: number | null;
            items?: { data?: Array<{ current_period_end?: number }> };
          };
          stripePeriodEnd = raw.cancel_at ?? raw.items?.data?.[0]?.current_period_end ?? raw.current_period_end ?? null;
        } catch (err: unknown) {
          const errMsg = err instanceof Error ? err.message : String(err);
          await systemLog('warn', 'stripe.subscription.cancel', `No se pudo programar la baja en Stripe: ${errMsg}`);
          return NextResponse.json({ error: 'No se pudo programar la baja. Inténtalo de nuevo.', correlationId }, { status: 502, headers: correlationHeaders(correlationId) });
        }
      }
      cancelAt = periodEndDate(stripePeriodEnd, nowDate);
    } else if (stripe && subId) {
      try {
        await stripe.subscriptions.cancel(subId);
      } catch (err: unknown) {
        const errMsg = err instanceof Error ? err.message : String(err);
        await systemLog('warn', 'stripe.subscription.cancel', `No se pudo cancelar en Stripe: ${errMsg}`);
        return NextResponse.json({ error: 'No se pudo dar de baja. Inténtalo de nuevo.', correlationId }, { status: 502, headers: correlationHeaders(correlationId) });
      }
    }

    const nextSettings = {
      ...prevSettings,
      cancel_mode: body.mode,
      cancel_at: cancelAt.toISOString(),
      cancel_requested_at: nowDate.toISOString(),
      last_retention_reason: body.cancelReason ?? prevSettings.last_retention_reason ?? null,
    };

    await admin
      .from('tenants')
      .update(
        body.mode === 'now'
          ? { subscription_status: 'canceled', stripe_subscription_id: null, settings: nextSettings }
          : { settings: nextSettings },
      )
      .eq('id', body.tenantId);

    await trackProductEvent('subscription_churned', {
      tenantId: body.tenantId,
      plan: tenant.plan,
      correlationId,
      meta: { mode: body.mode, cancelAt: cancelAt.toISOString() },
    });

    return NextResponse.json({
      ok: true,
      correlationId,
      mode: body.mode,
      cancelAt: cancelAt.toISOString(),
      message:
        body.mode === 'now'
          ? 'Tu suscripción se ha dado de baja ahora mismo.'
          : `Baja programada para el ${cancelAt.toLocaleDateString('es-ES')}. Hasta entonces sigues con todo activo y puedes reactivarla cuando quieras.`,
    }, { headers: correlationHeaders(correlationId) });
  }

  if (body.action === 'reactivate') {
    if (!canReactivate(prevSettings as CancellationState)) {
      return NextResponse.json(
        { error: 'No hay ninguna baja programada que se pueda reactivar.', correlationId },
        { status: 409, headers: correlationHeaders(correlationId) },
      );
    }
    if (stripe && subId) {
      try {
        await stripe.subscriptions.update(subId, { cancel_at_period_end: false });
      } catch (err: unknown) {
        const errMsg = err instanceof Error ? err.message : String(err);
        await systemLog('warn', 'stripe.subscription.reactivate', `No se pudo reactivar en Stripe: ${errMsg}`);
        return NextResponse.json({ error: 'No se pudo reactivar. Inténtalo de nuevo.', correlationId }, { status: 502, headers: correlationHeaders(correlationId) });
      }
    }
    const nextSettings = { ...prevSettings, cancel_mode: null, cancel_at: null, cancel_requested_at: null };
    await admin.from('tenants').update({ settings: nextSettings }).eq('id', body.tenantId);

    return NextResponse.json({
      ok: true,
      correlationId,
      message: 'Suscripción reactivada. Se renovará con normalidad.',
    }, { headers: correlationHeaders(correlationId) });
  }

  if (body.action === 'apply_retention_discount') {
    const cfg = getRetentionConfig().discount;
    if (!cfg.enabled) {
      return NextResponse.json({ error: 'Esta oferta no está disponible ahora mismo.', correlationId }, { status: 403, headers: correlationHeaders(correlationId) });
    }

    // Una sola vez por empresa: se comprueba en la ficha de la empresa y también en el cliente de Stripe.
    let customerMeta: Record<string, string> | null = null;
    if (stripe && customerId) {
      try {
        const cust = await stripe.customers.retrieve(customerId);
        if (!('deleted' in cust && cust.deleted)) customerMeta = (cust as { metadata?: Record<string, string> }).metadata ?? null;
      } catch {
        /* si no se puede leer el cliente seguimos con la comprobación local */
      }
    }
    if (hasUsedRetentionDiscount(prevSettings, customerMeta)) {
      return NextResponse.json({ error: 'Esta empresa ya ha usado su descuento de permanencia.', correlationId }, { status: 409, headers: correlationHeaders(correlationId) });
    }

    // Reservamos el descuento antes de llamar a Stripe para evitar dobles clics.
    const usedAt = new Date().toISOString();
    const reservedSettings = { ...prevSettings, retention_discount_used_at: usedAt };
    await admin.from('tenants').update({ settings: reservedSettings }).eq('id', body.tenantId);

    let couponId: string | null = null;
    if (stripe && subId) {
      try {
        const coupon = await stripe.coupons.create(
          {
            percent_off: cfg.percent,
            duration: cfg.months === 1 ? 'once' : 'repeating',
            ...(cfg.months === 1 ? {} : { duration_in_months: cfg.months }),
            max_redemptions: 1,
            name: `Permanencia -${cfg.percent}% · ${cfg.months} ${cfg.months === 1 ? 'mes' : 'meses'}`,
            metadata: { tenant_id: body.tenantId, kind: 'retention' },
          },
          { idempotencyKey: `retention-coupon-${body.tenantId}` },
        );
        couponId = coupon.id;
        await stripe.subscriptions.update(
          subId,
          { discounts: [{ coupon: coupon.id }], cancel_at_period_end: false },
          { idempotencyKey: `retention-apply-${body.tenantId}` },
        );
        if (customerId) {
          await stripe.customers.update(customerId, {
            metadata: { ...(customerMeta ?? {}), retention_discount_used_at: usedAt, retention_coupon: coupon.id },
          });
        }
      } catch (err: unknown) {
        // Liberamos la reserva para que pueda intentarlo de nuevo.
        await admin.from('tenants').update({ settings: prevSettings }).eq('id', body.tenantId);
        const errMsg = err instanceof Error ? err.message : String(err);
        await systemLog('warn', 'stripe.subscription.retention_discount', `No se pudo aplicar el descuento: ${errMsg}`);
        return NextResponse.json({ error: 'No se pudo aplicar el descuento. Inténtalo de nuevo.', correlationId }, { status: 502, headers: correlationHeaders(correlationId) });
      }
    }

    // Aceptar la oferta anula cualquier baja programada.
    const nextSettings = {
      ...reservedSettings,
      retention_discount_pct: cfg.percent,
      retention_discount_months: cfg.months,
      retention_coupon_id: couponId,
      last_retention_reason: body.cancelReason ?? prevSettings.last_retention_reason ?? null,
      cancel_mode: null,
      cancel_at: null,
      cancel_requested_at: null,
    };
    await admin.from('tenants').update({ settings: nextSettings }).eq('id', body.tenantId);

    await trackProductEvent('retention_discount_accepted', {
      tenantId: body.tenantId,
      plan: tenant.plan,
      correlationId,
      meta: { percent: cfg.percent, months: cfg.months },
    });

    return NextResponse.json({
      ok: true,
      correlationId,
      discountPct: cfg.percent,
      months: cfg.months,
      message: `¡Hecho! Tendrás un ${cfg.percent} % de descuento ${discountDurationLabel(cfg.months)}. Tu suscripción sigue activa.`,
    }, { headers: correlationHeaders(correlationId) });
  }

  if (body.action === 'apply_recovery_discount') {
    // El descuento se aplica en Stripe; el acceso solo vuelve cuando Stripe cobra
    // (el webhook actualiza el estado). Nunca se reactiva sin pago.
    if (!stripe || !subId) {
      return NextResponse.json(
        { error: 'No hay una suscripción a la que aplicar el descuento.', code: 'no_subscription', correlationId },
        { status: 409, headers: correlationHeaders(correlationId) },
      );
    }
    if (prevSettings.recovery_discount_applied) {
      return NextResponse.json(
        { error: 'El descuento de recuperación ya se aplicó anteriormente.', correlationId },
        { status: 409, headers: correlationHeaders(correlationId) },
      );
    }
    try {
      const coupon = await stripe.coupons.create({ percent_off: 20, duration: 'once', name: 'RECOVERY20' });
      await stripe.subscriptions.update(subId, { discounts: [{ coupon: coupon.id }] });
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : String(err);
      await systemLog('warn', 'stripe.subscription.recovery', `No se pudo aplicar el descuento: ${errMsg}`);
      return NextResponse.json({ error: 'No se pudo aplicar el descuento. Inténtalo de nuevo.', correlationId }, { status: 502, headers: correlationHeaders(correlationId) });
    }
    const nextSettings = {
      ...prevSettings,
      recovery_discount_applied: 'RECOVERY20_FIRST_MONTH',
      recovery_discount_pct: 20,
      recovery_applied_at: new Date().toISOString(),
    };
    await admin.from('tenants').update({ settings: nextSettings }).eq('id', body.tenantId);

    return NextResponse.json({
      ok: true,
      discountPct: 20,
      couponCode: 'RECOVERY20',
      message: 'Descuento del 20 % aplicado a tu próxima factura. Actualiza tu método de pago para recuperar el acceso.',
    });
  }

  if (body.action === 'tax_info') {
    const nextSettings = {
      ...prevSettings,
      tax_id: body.taxId.toUpperCase(),
      legal_name: body.legalName,
      tax_country: (body.country || 'ES').toUpperCase(),
    };

    if (stripe && customerId) {
      try {
        await stripe.customers.update(customerId, {
          name: body.legalName,
          metadata: { tax_id: body.taxId.toUpperCase(), country: body.country || 'ES' },
        });
      } catch {
        /* ignore stripe customer update error */
      }
    }

    await admin
      .from('tenants')
      .update({ settings: nextSettings })
      .eq('id', body.tenantId);

    return NextResponse.json({
      ok: true,
      message: `Datos fiscales guardados (${body.legalName} · NIF/IVA ${body.taxId.toUpperCase()}). Se incluirán en todas tus próximas facturas.`,
    });
  }

  if (body.action === 'add_location') {
    // Las sedes extra se facturan y activan desde soporte (no hay cobro automático).
    return NextResponse.json(
      { error: 'Para añadir sedes adicionales, contacta con soporte desde /contacto.', correlationId },
      { status: 403, headers: correlationHeaders(correlationId) },
    );
  }

  return NextResponse.json({ error: 'Acción no reconocida.' }, { status: 400 });
}
