import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { getStripe } from '@/lib/stripe';
import { env } from '@/lib/env';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';
import { captureException, correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';
import { requireSuperAdmin } from '@/lib/auth';
import { payloadErrorResponse, readTextLimited } from '@/lib/request';
import {
  applyAddonPurchase,
  applyCheckoutCompleted,
  applyInvoicePaid,
  applyPaymentFailed,
  applySubscriptionChange,
  applyTrialWillEnd,
} from '@/lib/stripe-webhook-handlers';

export const dynamic = 'force-dynamic';

/**
 * ============================================================
 * Webhook de Stripe — FUENTE DE VERDAD del estado comercial
 * ============================================================
 * Modelo 100% DE PAGO v1.0 (4 planes, sin plan gratuito):
 *
 *   · checkout.session.completed  → alta de suscripción de cualquier plan
 *                                   (trial 7 días) o compra de una recarga.
 *   · invoice.payment_succeeded   → cobro correcto: refresca el estado de la
 *                                   suscripción y aplica las recargas facturadas.
 *   · customer.subscription.updated / deleted → cambio de plan y bajas.
 *                                   La baja marca INMEDIATAMENTE
 *                                   `subscription_status = 'inactive'`.
 *   · customer.subscription.trial_will_end    → aviso por email 3 días antes.
 *   · invoice.payment_failed      → `past_due` INMEDIATO: el middleware y cada
 *                                   API cortan el acceso (panel + 402).
 *
 * Ya NO existen suscripciones paralelas de add-ons, cuotas «ilimitadas» ni
 * packs de localización: las ampliaciones son SIEMPRE de pago único y suman
 * capacidad al ciclo en curso (`tenants.extra_*` + ledger `addons`).
 *
 * La lógica de cada evento vive en `lib/stripe-webhook-handlers.ts`.
 */

/** Eventos que el endpoint procesa (y que hay que activar en Stripe). */
const STRIPE_EVENTS = [
  'checkout.session.completed',
  'invoice.payment_succeeded',
  'invoice.paid',
  'invoice.payment_failed',
  'customer.subscription.created',
  'customer.subscription.updated',
  'customer.subscription.deleted',
  'customer.subscription.trial_will_end',
] as const;

/**
 * Diagnóstico del endpoint (uso interno, sin secretos).
 * Permite comprobar de un vistazo que el webhook está listo tras desplegar:
 *
 *   GET /api/stripe/webhook → { ok, configured, events: [...], prices: {...} }
 */
export async function GET() {
  const guard = await requireSuperAdmin();
  if (!guard.ok) return NextResponse.json({ error: 'Acceso denegado.' }, { status: guard.status });

  return NextResponse.json({
    ok: true,
    configured: Boolean(getStripe() && env.stripeWebhookSecret),
    signatureHeader: 'stripe-signature',
    mode: env.stripeSecretKey.startsWith('sk_live_') ? 'live' : env.stripeSecretKey ? 'test' : 'sin-clave',
    events: STRIPE_EVENTS,
    prices: {
      local_starter: Boolean(env.stripePriceLocalStarter),
      ecommerce_starter: Boolean(env.stripePriceEcommerceStarter),
      local_pro: Boolean(env.stripePriceLocalPro),
      ecommerce_pro: Boolean(env.stripePriceEcommercePro),
      addons: {
        requests: Boolean(env.stripePriceAddonRequests),
        reviews: Boolean(env.stripePriceAddonReviews),
        ai: Boolean(env.stripePriceAddonAi),
        syncs: Boolean(env.stripePriceAddonSyncs),
      },
    },
    hints: [
      'Stripe → Developers → Webhooks: la URL debe ser https://tu-dominio.com/api/stripe/webhook (HTTPS).',
      'El signing secret (whsec_…) de cada endpoint es DISTINTO en test y en live.',
      'Si el webhook falla con 400: firma inválida (secreto cambiado o body modificado por un proxy).',
      'Si el webhook falla con 500: revisa los logs del panel interno (fuente stripe.webhook).',
      'Un evento se puede reenviar desde Stripe → Webhooks → intentos; el proceso es idempotente.',
    ],
    generatedAt: new Date().toISOString(),
  });
}

export async function POST(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const stripe = getStripe();
  if (!stripe || !env.stripeWebhookSecret) {
    return NextResponse.json({ error: 'Stripe no configurado en el servidor.', correlationId }, { status: 503, headers: correlationHeaders(correlationId) });
  }

  const sig = req.headers.get('stripe-signature');
  if (!sig) return NextResponse.json({ error: 'Sin firma.', correlationId }, { status: 400, headers: correlationHeaders(correlationId) });

  let rawBody: string;
  try { rawBody = await readTextLimited(req, 1024 * 1024); } catch (error) {
    return payloadErrorResponse(error) ?? NextResponse.json({ error: 'Cuerpo inválido.', correlationId }, { status: 400, headers: correlationHeaders(correlationId) });
  }
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, env.stripeWebhookSecret);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'firma inválida';
    await systemLog('error', 'stripe.webhook', `Firma inválida: ${message}`, { correlationId });
    return NextResponse.json({ error: 'Firma inválida.', correlationId }, { status: 400, headers: correlationHeaders(correlationId) });
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Base de datos no configurada.', correlationId }, { status: 503, headers: correlationHeaders(correlationId) });
  const { data: claimed, error: claimError } = await admin.rpc('claim_webhook_event', {
    p_provider: 'stripe', p_event_id: event.id, p_event_type: event.type,
  });
  if (claimError) return NextResponse.json({ error: 'No se pudo reclamar el evento.', correlationId }, { status: 503, headers: correlationHeaders(correlationId) });
  if (!claimed) return NextResponse.json({ received: true, duplicate: true, correlationId }, { headers: correlationHeaders(correlationId) });

  await systemLog('info', 'stripe.webhook', `Evento recibido: ${event.type}`, { id: event.id, correlationId });

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        if (session.mode === 'payment' || session.metadata?.type === 'addon') {
          await applyAddonPurchase(session);
        } else {
          await applyCheckoutCompleted(stripe, session);
        }
        break;
      }
      case 'invoice.payment_succeeded':
      case 'invoice.paid': {
        await applyInvoicePaid(stripe, event.data.object as Stripe.Invoice);
        break;
      }
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await applySubscriptionChange(stripe, sub, event.type === 'customer.subscription.deleted');
        break;
      }
      case 'customer.subscription.trial_will_end': {
        await applyTrialWillEnd(event.data.object as Stripe.Subscription);
        break;
      }
      case 'invoice.payment_failed': {
        await applyPaymentFailed(event.data.object as Stripe.Invoice);
        break;
      }
      default:
        break;
    }
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'error desconocido';
    await admin.rpc('fail_webhook_event', { p_provider: 'stripe', p_event_id: event.id, p_error: message });
    await captureException(error, { source: 'stripe.webhook', correlationId, extra: { eventId: event.id, eventType: event.type } });
    return NextResponse.json({ error: 'Error interno procesando el evento.', correlationId }, { status: 500, headers: correlationHeaders(correlationId) });
  }

  const { error: finishError } = await admin.rpc('finish_webhook_event', {
    p_provider: 'stripe', p_event_id: event.id,
  });
  if (finishError) return NextResponse.json({ error: 'Evento procesado pero no finalizado.', correlationId }, { status: 500, headers: correlationHeaders(correlationId) });
  return NextResponse.json({ received: true, correlationId }, { headers: correlationHeaders(correlationId) });
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
