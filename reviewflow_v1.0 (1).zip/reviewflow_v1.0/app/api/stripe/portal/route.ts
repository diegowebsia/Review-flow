import { NextResponse } from 'next/server';
import { z } from 'zod';
import { getStripe } from '@/lib/stripe';
import { resolvePublicUrl as resolveBaseUrl } from '@/lib/public-url';
import { getSessionUser } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { errorMessage } from '@/lib/api-error';

export const dynamic = 'force-dynamic';

const PortalInputSchema = z.object({
  tenantId: z.string().trim().min(1).max(128).optional(),
});

async function handlePortalRequest(req: Request) {
  const stripe = getStripe();
  if (!stripe) {
    return NextResponse.json({ error: 'Stripe no configurado en el servidor.' }, { status: 503 });
  }

  const user = await getSessionUser();
  if (!user) {
    const isApi = req.headers.get('accept')?.includes('application/json') || req.method === 'POST';
    if (isApi) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });
    return NextResponse.redirect(new URL('/login?redirect=/dashboard', req.url));
  }

  const url = new URL(req.url);
  let tenantId = url.searchParams.get('tenantId');

  if (!tenantId && req.method === 'POST') {
    try {
      const rawBody: unknown = await req.json().catch(() => ({}));
      const parsedBody = PortalInputSchema.safeParse(rawBody);
      if (parsedBody.success && parsedBody.data.tenantId) {
        tenantId = parsedBody.data.tenantId;
      }
    } catch {
      /* ignore body parse error */
    }
  }

  const admin = createAdminClient();
  let customerId: string | null = null;
  let tenantRecord: { id: string; stripe_customer_id: string | null } | null = null;

  if (admin) {
    // Si viene tenantId, validar membresía
    if (tenantId) {
      const { data: member } = await admin
        .from('memberships')
        .select('tenant_id')
        .eq('tenant_id', tenantId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (member) {
        const { data: t } = await admin
          .from('tenants')
          .select('id, stripe_customer_id')
          .eq('id', tenantId)
          .maybeSingle();
        if (t) {
          tenantRecord = t;
          customerId = t.stripe_customer_id;
        }
      }
    }

    // Si no se encontró por tenantId, buscar el tenant del usuario
    if (!customerId) {
      const userEmail = user.email?.toLowerCase();
      const filterClause = userEmail
        ? `owner_id.eq.${user.id},owner_email.eq.${userEmail}`
        : `owner_id.eq.${user.id}`;

      const { data: tOwner } = await admin
        .from('tenants')
        .select('id, stripe_customer_id')
        .or(filterClause)
        .not('stripe_customer_id', 'is', null)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (tOwner?.stripe_customer_id) {
        tenantRecord = tOwner;
        customerId = tOwner.stripe_customer_id;
      }
    }
  }

  // Fallback: si no tenemos customerId en DB, buscar en Stripe por email
  if (!customerId && user.email) {
    try {
      const normalizedEmail = user.email.toLowerCase();
      const customerSearch = await stripe.customers.list({
        email: normalizedEmail,
        limit: 1,
      });
      if (customerSearch.data[0]?.id) {
        customerId = customerSearch.data[0].id;
        // Guardar para futuras llamadas si tenemos el tenant o buscarlo por owner_email
        if (admin) {
          if (tenantRecord?.id) {
            await admin
              .from('tenants')
              .update({ stripe_customer_id: customerId })
              .eq('id', tenantRecord.id);
          } else {
            await admin
              .from('tenants')
              .update({ stripe_customer_id: customerId })
              .eq('owner_email', normalizedEmail)
              .is('stripe_customer_id', null);
          }
        }
      }
    } catch {
      /* ignore lookup failure */
    }
  }

  const wantsJson = req.headers.get('accept')?.includes('application/json') || req.method === 'POST';

  if (!customerId) {
    if (wantsJson) {
      return NextResponse.json(
        {
          error: 'No se encontró suscripción de Stripe para este usuario.',
          portalUrl: null,
        },
        { status: 404 },
      );
    }
    return NextResponse.redirect(new URL('/dashboard?portal=nocustomer', req.url));
  }

  try {
    const baseUrl = resolveBaseUrl(req);
    const portal = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${baseUrl}/dashboard`,
    });

    if (wantsJson) {
      return NextResponse.json({ ok: true, url: portal.url });
    }

    return NextResponse.redirect(portal.url, { status: 303 });
  } catch (err: unknown) {
    if (wantsJson) {
      return NextResponse.json({ error: errorMessage(err, 'Error abriendo el portal') }, { status: 500 });
    }
    return NextResponse.redirect(new URL('/dashboard?portal=error', req.url));
  }
}

/** Redirección al Stripe Customer Portal para gestionar, cambiar plan o cancelar */
export async function GET(req: Request) {
  return handlePortalRequest(req);
}

/** Endpoint JSON para clientes que prefieren abrir el portal vía fetch */
export async function POST(req: Request) {
  return handlePortalRequest(req);
}
