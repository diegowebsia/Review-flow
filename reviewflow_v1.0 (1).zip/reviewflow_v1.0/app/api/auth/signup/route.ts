import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { requestIp } from '@/lib/security';
import { consumeRateLimit } from '@/lib/rate-limit';
import { verifyAntiBot } from '@/lib/antibot';
import { sendMail } from '@/lib/mail';
import { renderTransactionalEmail } from '@/lib/transactional-emails';
import { trackProductEvent } from '@/lib/business-metrics';
import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { env } from '@/lib/env';
import { signupRequiresEmailConfirmation } from '@/lib/reauth';
import { publicUrl } from '@/lib/public-url';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

export const dynamic = 'force-dynamic';

const SignupSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(8).max(72),
  locale: z.string().max(10).optional(),
  captchaToken: z.string().max(2048).optional(),
  website: z.string().max(200).optional(),
});

/**
 * POST /api/auth/signup
 * En producción (o con SIGNUP_EMAIL_CONFIRMATION=true) registra la cuenta con el flujo
 * normal de Supabase, que envía el correo de confirmación: nadie puede registrarse con
 * el email de otra persona. En localhost la cuenta se activa al instante para probar.
 */
export async function POST(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const ip = requestIp(req);
  const rate = await consumeRateLimit('auth-signup', ip, 20, 600);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: 'Demasiados intentos. Espera unos minutos antes de volver a intentarlo.', correlationId },
      { status: 429, headers: correlationHeaders(correlationId) },
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = SignupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: 'Introduce un email válido y una contraseña de al menos 8 caracteres.', correlationId },
      { status: 400, headers: correlationHeaders(correlationId) },
    );
  }

  const botCheck = await verifyAntiBot(req, {
    captchaToken: parsed.data.captchaToken,
    honeypot: parsed.data.website,
  });
  if (!botCheck.allowed) {
    return NextResponse.json(
      { error: 'Verificación anti-bot fallida. Por favor recarga e inténtalo de nuevo.', code: botCheck.reason, correlationId },
      { status: 403, headers: correlationHeaders(correlationId) },
    );
  }

  const email = parsed.data.email.toLowerCase();
  const password = parsed.data.password;
  const userLocale = parsed.data.locale || req.headers.get('accept-language')?.slice(0, 2) || 'es';

  const admin = createAdminClient();
  if (!admin) {
    await trackProductEvent('user_signup', { email, correlationId, meta: { fallbackClientSignup: true, locale: userLocale } });
    return NextResponse.json(
      { ok: true, fallbackClientSignup: true, correlationId },
      { headers: correlationHeaders(correlationId) },
    );
  }

  try {
    if (signupRequiresEmailConfirmation()) {
      const anon = createSupabaseClient(env.supabaseUrl, env.supabaseAnonKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      });
      const { data: su, error: suError } = await anon.auth.signUp({
        email,
        password,
        options: {
          data: { locale: userLocale },
          emailRedirectTo: publicUrl('/auth/callback?next=' + encodeURIComponent('/bienvenido'), req.headers),
        },
      });
      if (suError) {
        const msg = suError.message.toLowerCase();
        if (msg.includes('already') || msg.includes('exists') || msg.includes('registered')) {
          return NextResponse.json(
            { error: 'Este correo electrónico ya está registrado. Inicia sesión con tu contraseña.', code: 'email_already_registered', alreadyRegistered: true },
            { status: 409 },
          );
        }
        return NextResponse.json({ error: 'No se pudo crear la cuenta. Inténtalo de nuevo.' }, { status: 400 });
      }
      await trackProductEvent('user_signup', { userId: su.user?.id, email, correlationId, meta: { locale: userLocale, confirmationRequired: true } });
      return NextResponse.json({ ok: true, confirmationRequired: true, correlationId }, { headers: correlationHeaders(correlationId) });
    }

    const { data, error } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { locale: userLocale },
    });

    if (!error && data?.user) {
      await trackProductEvent('user_signup', {
        userId: data.user.id,
        email,
        correlationId,
        meta: { locale: userLocale },
      });
      const welcomeMail = renderTransactionalEmail({
        kind: 'welcome',
        locale: userLocale,
        tenantName: email.split('@')[0],
      });
      await sendMail({
        to: email,
        subject: welcomeMail.subject,
        html: welcomeMail.html,
        text: welcomeMail.text,
      }).catch(() => undefined);

      return NextResponse.json(
        { ok: true, userId: data.user.id, confirmed: true, correlationId },
        { headers: correlationHeaders(correlationId) },
      );
    }

    // Si el usuario ya existía, NO sobrescribimos su contraseña ni tomamos la cuenta:
    // exigimos iniciar sesión con su contraseña original o verificar su correo.
    if (error) {
      const msg = error.message.toLowerCase();
      if (msg.includes('already') || msg.includes('exists') || msg.includes('registered')) {
        return NextResponse.json(
          {
            error:
              'Este correo electrónico ya está registrado. Inicia sesión con tu contraseña o verifica tu bandeja de entrada si tienes la confirmación pendiente.',
            code: 'email_already_registered',
            alreadyRegistered: true,
          },
          { status: 409 },
        );
      }
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ ok: true });
  } catch (err: unknown) {
    return NextResponse.json(
      { error: err instanceof Error && err.message ? err.message : 'No se pudo crear el usuario.' },
      { status: 500 },
    );
  }
}
