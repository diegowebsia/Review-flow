import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import {
  env,
  isGeminiConfigured,
  isStripeConfigured,
  isStripeWebhookConfigured,
  isSupabaseAdminConfigured,
  isSupabaseConfigured,
} from '@/lib/env';
import { geminiStatus } from '@/lib/gemini';
import { APP_VERSION, SENTRY_RELEASE, correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';
import { verifyHealthKey } from '@/lib/security';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * Healthcheck (/api/health y /health):
 * - Versión pública (sin clave): responde únicamente `{ ok: true, status: 'operational', timestamp, correlationId }`.
 *   Nunca expone versiones, nombres de servicios internos ni mensajes de error.
 * - Versión detallada (`mode=ready`, `mode=detailed`, cabecera `Authorization: Bearer <HEALTH_KEY>` o `x-health-key`):
 *   protegida con `verifyHealthKey` (`crypto.timingSafeEqual`, comprobando longitud).
 *   Si `HEALTH_KEY` / `HEALTHCHECK_SECRET` no está configurada en el entorno, la versión detallada
 *   queda desactivada (nunca abierta).
 */
export async function GET(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  const url = new URL(req.url);
  const mode = url.searchParams.get('mode') ?? 'public';
  const auth = verifyHealthKey(req);

  // Si se intenta usar una clave o pedir modo detallado/ready sin autorización válida
  // (clave incorrecta, vacía o sin configurar en el entorno), denegar sin filtrar detalles internos.
  if (auth.provided && !auth.authorized) {
    return NextResponse.json(
      { ok: false, status: 'unauthorized', correlationId },
      { status: 401, headers: correlationHeaders(correlationId, { 'Cache-Control': 'no-store' }) },
    );
  }

  // Versión pública: sin versiones, sin nombres de servicios internos y sin mensajes de error.
  if (!auth.authorized) {
    return NextResponse.json(
      {
        ok: true,
        status: 'operational',
        timestamp: new Date().toISOString(),
        correlationId,
      },
      {
        status: 200,
        headers: correlationHeaders(correlationId, { 'Cache-Control': 'no-store' }),
      },
    );
  }

  // Versión detallada (solo accesible con clave configurada y verificada por timingSafeEqual)
  const startedAt = Date.now();
  let dbReachable = false;
  if (isSupabaseConfigured && isSupabaseAdminConfigured) {
    try {
      const admin = createAdminClient();
      const dbResult = admin ? await admin.from('tenants').select('id', { head: true, count: 'exact' }).limit(1) : null;
      dbReachable = Boolean(dbResult && !dbResult.error);
    } catch {
      dbReachable = false;
    }
  }
  const dbLatencyMs = Date.now() - startedAt;

  const databaseCheck = {
    status: dbReachable ? 'operational' : isSupabaseConfigured ? 'degraded' : 'unconfigured',
    configured: Boolean(isSupabaseConfigured && isSupabaseAdminConfigured),
    reachable: dbReachable,
    latencyMs: dbLatencyMs,
  };

  const paymentGatewayCheck = {
    status: isStripeConfigured ? 'operational' : 'unconfigured',
    configured: isStripeConfigured,
    webhookConfigured: isStripeWebhookConfigured,
    provider: 'stripe',
  };

  const aiInfo = geminiStatus();
  const aiServiceCheck = {
    status: isGeminiConfigured ? 'operational' : 'fallback_templates',
    configured: isGeminiConfigured,
    model: aiInfo.model,
    fallbackAvailable: true,
  };

  const configReady = Boolean(
    isSupabaseConfigured &&
      isSupabaseAdminConfigured &&
      isStripeConfigured &&
      isStripeWebhookConfigured &&
      env.appUrl &&
      !env.appUrl.includes('localhost'),
  );

  const readyOk = configReady && dbReachable;
  const statusHttp = mode === 'ready' ? (readyOk ? 200 : 503) : 200;

  return NextResponse.json(
    {
      ok: mode === 'ready' ? readyOk : true,
      status: readyOk ? 'operational' : 'degraded',
      service: 'reviewflow-ai',
      version: APP_VERSION,
      release: SENTRY_RELEASE,
      correlationId,
      timestamp: new Date().toISOString(),
      checks: {
        database: databaseCheck,
        payment_gateway: paymentGatewayCheck,
        ai_service: aiServiceCheck,
        configuration: configReady,
      },
    },
    {
      status: statusHttp,
      headers: correlationHeaders(correlationId, { 'Cache-Control': 'no-store' }),
    },
  );
}
