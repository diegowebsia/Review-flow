import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { ONBOARDING_STEPS } from '@/lib/onboarding';
import { requireRole } from '@/lib/authz';

const Body = z.object({
  tenantId: z.string().min(1),
  name: z.string().min(2).max(80).optional(),
  slug: z.string().min(2).max(60).optional(),
  tone: z.enum(['profesional', 'cercano', 'formal']).optional(),
  brand_instructions: z.string().max(600).optional(),
  brand_rules: z.array(z.string().max(160)).max(5).optional(),
  forbidden_words: z.array(z.string().max(80)).max(20).optional(),
  brand_signature: z.string().max(120).optional(),
  vertical_template: z.string().max(40).optional(),
  locale: z.enum(['es', 'en', 'ca', 'pt', 'fr', 'de', 'it']).optional(),
  customer_locale: z.enum(['es', 'en', 'ca', 'pt', 'fr', 'de', 'it']).optional(),
  slack_webhook_url: z.string().max(400).optional(),
  teams_webhook_url: z.string().max(400).optional(),
  outbound_webhook_url: z.string().max(400).optional(),
  place_id: z.string().max(120).optional(),
  trustpilot_url: z.string().max(300).optional(),
  funnel_enabled: z.boolean().optional(),
  auto_publish: z.boolean().optional(),
  auto_publish_min_rating: z.number().int().min(1).max(5).optional(),
  /** Pasos del checklist de activación marcados a mano. Antes Zod los descartaba y nunca se guardaban. */
  onboarding_steps: z
    .object(Object.fromEntries(ONBOARDING_STEPS.map((k) => [k, z.boolean().optional()])) as Record<(typeof ONBOARDING_STEPS)[number], z.ZodOptional<z.ZodBoolean>>)
    .strict()
    .optional(),
});

function slugify(s: string) {
  return s
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 60);
}

/** Guarda ajustes de la empresa (nombre, slug, tono IA, Place ID, URLs del embudo). */
export async function PATCH(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ error: 'Parámetros inválidos.' }, { status: 400 });
  const { tenantId, name, slug, onboarding_steps, ...patch } = parsed.data;

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'No autenticado.' }, { status: 401 });

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const auth = await requireRole(admin, tenantId, 'admin');
  if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

  const { data: tenant } = await admin
    .from('tenants')
    .select('name, slug, settings')
    .eq('id', tenantId)
    .single();

  const current = ((tenant?.settings as Record<string, unknown> | null) ?? {}) as Record<string, unknown>;
  const settings: Record<string, unknown> = { ...current, ...patch };
  if (onboarding_steps) {
    // Se FUSIONA con lo ya guardado (los pasos marcados por el servidor no se pierden).
    settings.onboarding_steps = {
      ...((current.onboarding_steps as Record<string, boolean> | undefined) ?? {}),
      ...onboarding_steps,
    };
  }
  const updatePayload: { settings: Record<string, unknown>; name?: string; slug?: string } = { settings };

  if (name && name.trim().length >= 2) {
    updatePayload.name = name.trim();
  }

  if (slug && slug.trim().length >= 2) {
    const cleanSlug = slugify(slug.trim());
    if (cleanSlug.length >= 2 && cleanSlug !== tenant?.slug) {
      const { data: conflict } = await admin
        .from('tenants')
        .select('id')
        .eq('slug', cleanSlug)
        .neq('id', tenantId)
        .maybeSingle();
      if (conflict) {
        return NextResponse.json(
          { error: `El enlace /valorar/${cleanSlug} ya está en uso. Prueba con otro identificador.` },
          { status: 409 },
        );
      }
      updatePayload.slug = cleanSlug;
    }
  }

  const { error } = await admin.from('tenants').update(updatePayload).eq('id', tenantId);
  if (error) return NextResponse.json({ error: 'No se pudo guardar.' }, { status: 500 });

  return NextResponse.json({
    ok: true,
    name: updatePayload.name ?? tenant?.name,
    slug: updatePayload.slug ?? tenant?.slug,
    settings,
  });
}
