import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { requireRole } from '@/lib/authz';
import { consumeRateLimit } from '@/lib/rate-limit';
import { getStripe } from '@/lib/stripe';
import { hashPersonalValue, signOpaqueId } from '@/lib/security';
import { systemLog } from '@/lib/logger';
import { verifyCurrentPassword } from '@/lib/reauth';

const DeleteSchema = z.object({
  tenantId: z.string().uuid(),
  confirmationText: z.literal('ELIMINAR'),
  password: z.string().min(1).max(128),
  reason: z.string().max(500).optional(),
  deleteAuthUser: z.boolean().default(false),
});

/**
 * DELETE / POST /api/tenants/delete — Derecho de Supresión RGPD (Art. 17 «Derecho al olvido»).
 * Exclusivo para el rol `owner` (y bloqueado durante sesiones de soporte / impersonación):
 *  1. Cancela de inmediato cualquier suscripción activa en Stripe.
 *  2. Purga las tablas vinculadas (`reviews`, `feedback_responses`, `integrations`,
 *     `usage_counters`, `quota_events`, `ai_interactions`, `whatsapp_optins`,
 *     `whatsapp_contacts`, `addons`, `memberships`, `tenants`).
 *  3. Emite un Certificado Criptográfico de Supresión RGPD firmado con HMAC-SHA256.
 */
export async function POST(req: Request) {
  return handleGdprErasure(req);
}

export async function DELETE(req: Request) {
  return handleGdprErasure(req);
}

async function handleGdprErasure(req: Request) {
  const body = await req.json().catch(() => ({}));
  const parsed = DeleteSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: 'Para confirmar el borrado definitivo RGPD debes enviar tenantId válido, confirmationText="ELIMINAR" y tu contraseña actual.',
      },
      { status: 400 },
    );
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  // Solo el propietario legítimo (owner) y nunca bajo sesión de soporte (impersonación)
  const auth = await requireRole(admin, parsed.data.tenantId, 'owner', { forbidImpersonation: true });
  if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

  const rate = await consumeRateLimit('tenant-gdpr-delete', auth.userId, 3, 3600);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas solicitudes de borrado.' },
      { status: 429, headers: { 'Retry-After': String(rate.retryAfter) } },
    );
  }

  // Re-autenticación: pedir la contraseña antes de un borrado irreversible.
  const { data: authUser } = await admin.auth.admin.getUserById(auth.userId);
  const passwordOk = await verifyCurrentPassword(authUser?.user?.email, parsed.data.password);
  if (!passwordOk) {
    return NextResponse.json({ error: 'La contraseña no es correcta.' }, { status: 400 });
  }

  const { data: tenant } = await admin
    .from('tenants')
    .select('id, name, slug, owner_email, stripe_subscription_id, stripe_customer_id')
    .eq('id', parsed.data.tenantId)
    .single();

  if (!tenant) {
    return NextResponse.json({ error: 'Empresa no encontrada.' }, { status: 404 });
  }

  // 1. Cancelar suscripción en Stripe si existe
  let stripeCanceled = false;
  const stripe = getStripe();
  if (stripe && tenant.stripe_subscription_id) {
    try {
      await stripe.subscriptions.cancel(tenant.stripe_subscription_id);
      stripeCanceled = true;
    } catch {
      /* ya cancelada o inexistente en Stripe */
    }
  }

  // 2. Contabilizar registros purgados para el certificado RGPD Art. 17
  const tablesToPurge = [
    'reviews',
    'feedback_responses',
    'integrations',
    'usage_counters',
    'quota_events',
    'ai_interactions',
    'whatsapp_optins',
    'whatsapp_contacts',
    'addons',
    'memberships',
  ];

  const purgedCounts: Record<string, number> = {};
  for (const table of tablesToPurge) {
    try {
      const { count } = await admin
        .from(table)
        .delete({ count: 'exact' })
        .eq('tenant_id', tenant.id);
      purgedCounts[table] = Number(count ?? 0);
    } catch {
      purgedCounts[table] = 0;
    }
  }

  // 3. Eliminar la fila maestra del tenant
  await admin.from('tenants').delete().eq('id', tenant.id);

  // 4. Opcional: eliminar también el usuario de Auth si no posee más empresas
  if (parsed.data.deleteAuthUser) {
    const { data: remaining } = await admin
      .from('memberships')
      .select('id')
      .eq('user_id', auth.userId)
      .limit(1);
    if (!remaining || remaining.length === 0) {
      try {
        await admin.auth.admin.deleteUser(auth.userId);
      } catch {
        /* best effort */
      }
    }
  }

  const deletedAt = new Date().toISOString();
  const subjectHash = hashPersonalValue(`${tenant.id}:${tenant.owner_email ?? auth.userId}`);
  const certificateId = `GDPR-ART17-${tenant.id.slice(0, 8).toUpperCase()}-${Date.now()}`;
  const signaturePayload = `${certificateId}|${subjectHash}|${deletedAt}`;
  const cryptographicSignature = signOpaqueId(signaturePayload);

  await systemLog('warn', 'gdpr.account_erased', 'Purga completa RGPD Art. 17 ejecutada con éxito', {
    certificateId,
    subjectHash,
    purgedCounts,
    stripeCanceled,
    reason: parsed.data.reason ?? 'user_requested',
  });

  return NextResponse.json({
    ok: true,
    certificate: {
      certificateId,
      regulation: 'RGPD (UE) 2016/679 — Artículo 17 (Derecho de supresión / Derecho al olvido)',
      tenantName: tenant.name,
      subjectHash,
      deletedAt,
      stripeSubscriptionCanceled: stripeCanceled,
      purgedTables: purgedCounts,
      cryptographicSignature,
      verificationNote:
        'Conserva este certificado JSON como comprobante fehaciente de la eliminación y purga definitiva de los datos de tu empresa.',
    },
  });
}
