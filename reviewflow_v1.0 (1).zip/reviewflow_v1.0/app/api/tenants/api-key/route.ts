import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createAdminClient } from '@/lib/supabase/admin';
import { requireRole } from '@/lib/authz';
import { consumeRateLimit } from '@/lib/rate-limit';
import { rotateTenantApiKey, revokeTenantApiKey } from '@/lib/api-keys';
import { systemLog } from '@/lib/logger';

const RotateSchema = z.object({
  tenantId: z.string().uuid(),
  overlapHours: z.number().min(0).max(72).default(24),
});

const RevokeSchema = z.object({
  tenantId: z.string().uuid(),
});

/**
 * POST /api/tenants/api-key — Rota la API key de la empresa con solape de 24 h (cero caídas).
 * DELETE /api/tenants/api-key — Revoca de inmediato la API key activa y la de solape.
 * Exige rol `admin` u `owner`.
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const parsed = RotateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Parámetros inválidos.' }, { status: 400 });
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const auth = await requireRole(admin, parsed.data.tenantId, 'admin', { forbidImpersonation: true });
  if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

  const rate = await consumeRateLimit('api-key-rotate', auth.userId, 10, 3600);
  if (!rate.allowed) {
    return NextResponse.json(
      { error: 'Demasiadas rotaciones de clave. Espera unos minutos.' },
      { status: 429, headers: { 'Retry-After': String(rate.retryAfter) } },
    );
  }

  const result = await rotateTenantApiKey(admin, parsed.data.tenantId, parsed.data.overlapHours);
  await systemLog('info', 'security.api_key_rotated', 'API key rotada con ventana de solape', {
    tenantId: parsed.data.tenantId,
    by: auth.userId,
    prefix: result.prefix,
    overlapExpiresAt: result.overlapExpiresAt,
  });

  return NextResponse.json({
    ok: true,
    apiKey: result.rawKey,
    prefix: result.prefix,
    overlapExpiresAt: result.overlapExpiresAt,
  });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const tenantId = url.searchParams.get('tenantId');
  const parsed = RevokeSchema.safeParse({ tenantId });
  if (!parsed.success) {
    return NextResponse.json({ error: 'tenantId inválido.' }, { status: 400 });
  }

  const admin = createAdminClient();
  if (!admin) return NextResponse.json({ error: 'Supabase no configurado.' }, { status: 503 });

  const auth = await requireRole(admin, parsed.data.tenantId, 'admin', { forbidImpersonation: true });
  if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status });

  await revokeTenantApiKey(admin, parsed.data.tenantId);
  await systemLog('warn', 'security.api_key_revoked', 'API key revocada manualmente desde el panel', {
    tenantId: parsed.data.tenantId,
    by: auth.userId,
  });

  return NextResponse.json({
    ok: true,
    revokedAt: new Date().toISOString(),
  });
}
