import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { isTrialExpired, resolvePlan, type PlanId } from '@/lib/plans';
import { checkQuota } from '@/lib/usage';
import { enqueue, processPendingJobs, MAX_QUEUE_BATCH_SIZE } from '@/lib/queue';
import { systemLog } from '@/lib/logger';
import { decryptCredentials } from '@/lib/credentials';
import { verifyCronSecret } from '@/lib/security';
import { apiError, errorMessage } from '@/lib/api-error';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * ============================================================
 * Sincronización automática de reseñas y procesamiento de cola (Cron)
 * ============================================================
 * `GET|POST /api/cron/sync-reviews` — programado cada hora:
 *   · Vercel Cron → `vercel.json` (Vercel envía `Authorization: Bearer
 *     CRON_SECRET` solo si la variable existe: créala en el proyecto).
 *   · Supabase Cron → pg_cron + pg_net con el mismo Bearer.
 *
 * El cron encola trabajos `sync.provider` como `pending` en la tabla `job_queue`
 * de Supabase y procesa un lote de máximo 5 tareas pendientes por ejecución
 * con hasta 3 reintentos.
 *
 * Cadencia por plan (sobre `integrations.last_sync_at`):
 *   · business → cada hora · pro → cada 6 horas.
 * Google: si hay OAuth se usa Business; si no, Places por `place_id`.
 */

type Provider = 'google' | 'places' | 'trustpilot';

type CronTenantRow = {
  id: string;
  name: string;
  plan: string;
  subscription_status: string;
  suspended: boolean;
  trial_ends_at: string | null;
  settings: { place_id?: string } | null;
};

type CronIntegrationRow = {
  tenant_id: string;
  provider: string;
  status: string;
  credentials: unknown;
  last_sync_at: string | null;
};

const CADENCE_MINUTES: Record<PlanId, number> = {
  ecommerce_pro: 60,
  business: 60,
  local_pro: 120,
  pro: 120,
  ecommerce_starter: 180,
  local_starter: 360,
};

type Skip = { tenantId: string; provider: Provider; reason: string };

export async function GET(req: Request) {
  return runCron(req);
}

export async function POST(req: Request) {
  return runCron(req);
}

async function runCron(req: Request) {
  const startedAt = Date.now();
  const correlationId = getOrCreateCorrelationId(req);
  if (!verifyCronSecret(req)) {
    return apiError(
      'No autorizado. Configura CRON_SECRET y llámame con `Authorization: Bearer …` (Vercel Cron lo envía solo) o `?secret=…`.',
      {
        status: process.env.CRON_SECRET ? 401 : 503,
        code: 'unauthorized',
        correlationId,
      },
    );
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  const { error: cleanupError } = await admin.rpc('cleanup_security_data');
  if (cleanupError) {
    await systemLog('warn', 'cron.cleanup', 'Limpieza de seguridad no disponible', {
      code: cleanupError.code,
      correlationId,
    });
  }

  const { data: tenants } = await admin
    .from('tenants')
    .select('id, name, plan, subscription_status, suspended, trial_ends_at, settings')
    .eq('suspended', false)
    .in('subscription_status', ['active', 'trialing']);

  const eligible = ((tenants ?? []) as CronTenantRow[]).filter(
    (t) => !isTrialExpired(t.subscription_status, t.trial_ends_at),
  );
  if (eligible.length === 0) {
    const queueBatch = await processPendingJobs(admin, MAX_QUEUE_BATCH_SIZE, { startedAt });
    return NextResponse.json(
      { ok: true, correlationId, tenants: 0, enqueued: 0, skipped: [], queue: queueBatch },
      { headers: correlationHeaders(correlationId) },
    );
  }

  const tenantIds = eligible.map((t) => t.id);
  const { data: integrations } = await admin
    .from('integrations')
    .select('tenant_id, provider, status, credentials, last_sync_at')
    .in('tenant_id', tenantIds)
    .eq('status', 'connected')
    .in('provider', ['google', 'trustpilot']);

  const byTenant = new Map<string, CronIntegrationRow[]>();
  for (const row of (integrations ?? []) as CronIntegrationRow[]) {
    const list = byTenant.get(row.tenant_id) ?? [];
    list.push(row);
    byTenant.set(row.tenant_id, list);
  }

  let enqueued = 0;
  let stagger = 0;
  const skipped: Skip[] = [];

  for (const tenant of eligible) {
    const plan = resolvePlan(tenant.plan);
    const cadenceMs = CADENCE_MINUTES[plan] * 60 * 1000;
    const rows = byTenant.get(tenant.id) ?? [];
    const settings = tenant.settings ?? {};

    // Candidatos: Google (OAuth→Business, si no→Places), Trustpilot.
    const googleRow = rows.find((r) => r.provider === 'google');
    const googleCreds = decryptCredentials<{ refresh_token?: string; access_token?: string }>(googleRow?.credentials);
    const hasGoogleOAuth = Boolean(googleCreds.refresh_token ?? googleCreds.access_token);
    const candidates: Provider[] = [];
    if (hasGoogleOAuth) candidates.push('google');
    else if (settings.place_id) candidates.push('places');
    if (rows.some((r) => r.provider === 'trustpilot')) candidates.push('trustpilot');

    // Una sola lectura de cuota por empresa y ejecución.
    const quota = await checkQuota(admin, tenant.id).catch(() => null);
    const syncsLeft = quota ? quota.metrics.syncs.quota - quota.metrics.syncs.used : 0;

    for (const provider of candidates) {
      const row = provider === 'places' ? googleRow : rows.find((r) => r.provider === provider);
      const lastSync = row?.last_sync_at ? new Date(row.last_sync_at).getTime() : 0;
      if (Date.now() - lastSync < cadenceMs) {
        skipped.push({ tenantId: tenant.id, provider, reason: 'cadence' });
        continue;
      }
      if (!quota?.hasAccess || syncsLeft <= 0) {
        skipped.push({ tenantId: tenant.id, provider, reason: !quota?.hasAccess ? 'no-access' : 'sync-quota' });
        continue;
      }
      try {
        await enqueue(
          { type: 'sync.provider', tenantId: tenant.id, provider, origin: 'cron' },
          { delaySeconds: Math.min(stagger, 300), admin },
        );
        enqueued += 1;
        stagger += 3; // escalona para no golpear a los proveedores a la vez
      } catch (e: unknown) {
        skipped.push({
          tenantId: tenant.id,
          provider,
          reason: `enqueue:${errorMessage(e, 'enqueue_error').slice(0, 60)}`,
        });
      }
    }
  }

  const queueBatch = await processPendingJobs(admin, MAX_QUEUE_BATCH_SIZE, { startedAt });

  await systemLog('info', 'cron.sync', `Cron: ${enqueued} syncs encolados (${eligible.length} empresas), ${queueBatch.processed} tareas procesadas`, {
    enqueued,
    skipped: skipped.length,
    queue: queueBatch,
    correlationId,
  }).catch(() => undefined);

  return NextResponse.json(
    { ok: true, correlationId, tenants: eligible.length, enqueued, skipped, queue: queueBatch },
    { headers: correlationHeaders(correlationId) },
  );
}
