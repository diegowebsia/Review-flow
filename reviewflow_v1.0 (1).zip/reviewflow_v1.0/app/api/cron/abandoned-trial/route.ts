import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { sendMail } from '@/lib/mail';
import {
  ABANDONED_TRIAL_ALLOWED_STATUSES,
  PAYMENT_FAILED_STATUSES,
  getReminderPeriodKey,
  hasReminderBeenSentInPeriod,
  isPaymentFailedStatus,
  recordReminderSend,
  renderTransactionalEmail,
  resolveSingleReminderForTenant,
  type EmailSendLogEntry,
  type ReminderTenantRecord,
  type TransactionalEmailKind,
} from '@/lib/transactional-emails';
import { correlationHeaders, getOrCreateCorrelationId, logStructured } from '@/lib/observability';
import { verifyCronSecret } from '@/lib/security';
import { apiError } from '@/lib/api-error';

export const dynamic = 'force-dynamic';

export const DEFAULT_REMINDER_BATCH_SIZE = 200;
export const DEFAULT_MAX_EXECUTION_MS = 25_000;
const CURSOR_SETTING_KEY = 'cron_abandoned_trial_cursor';

let memoryCursorFallback: string | null = null;

export function resetReminderCronCursorForTests(): void {
  memoryCursorFallback = null;
}

export function getReminderCronCursorForTests(): string | null {
  return memoryCursorFallback;
}

type AdminLike = {
  from: (table: string) => {
    select: (cols: string) => {
      in?: (col: string, vals: readonly string[]) => unknown;
      not?: (col: string, op: string, val: string) => unknown;
      gt?: (col: string, val: string) => unknown;
      order?: (col: string, opts: { ascending: boolean }) => unknown;
      limit?: (n: number) => unknown;
      eq?: (col: string, val: string) => {
        maybeSingle?: () => Promise<{ data?: { value?: { cursor?: string | null } } | null }>;
      };
    };
    update: (payload: Record<string, unknown>) => {
      eq: (col: string, val: string) => Promise<unknown>;
    };
    upsert?: (payload: Record<string, unknown>, opts?: { onConflict?: string }) => Promise<unknown>;
  };
};

async function loadSavedCursor(admin: AdminLike, explicitCursor?: string | null): Promise<string | null> {
  if (explicitCursor !== undefined) return explicitCursor;
  try {
    const table = admin.from('system_settings');
    if (table && typeof table.select === 'function') {
      const sel = table.select('value');
      if (sel && typeof sel.eq === 'function') {
        const eqRes = sel.eq('key', CURSOR_SETTING_KEY);
        if (eqRes && typeof eqRes.maybeSingle === 'function') {
          const { data } = await eqRes.maybeSingle();
          if (data?.value && typeof data.value.cursor === 'string' && data.value.cursor.length > 0) {
            return data.value.cursor;
          }
        }
      }
    }
  } catch {
    /* fallback to in-memory cursor */
  }
  return memoryCursorFallback;
}

async function persistCursor(admin: AdminLike, cursor: string | null): Promise<void> {
  memoryCursorFallback = cursor;
  try {
    const table = admin.from('system_settings');
    if (table && typeof table.upsert === 'function') {
      await table.upsert(
        {
          key: CURSOR_SETTING_KEY,
          value: { cursor, updated_at: new Date().toISOString() },
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'key' },
      );
    }
  } catch {
    /* ignore if system_settings is not available in test mock */
  }
}

export type ReminderBatchExecutionOptions = {
  admin: AdminLike;
  batchSize?: number;
  maxDurationMs?: number;
  nowMs?: number;
  nowFn?: () => number;
  initialCursor?: string | null;
  includePaymentFailedPriority?: boolean;
  sendEmailFn?: (msg: { to: string; subject: string; html: string; text: string; kind: TransactionalEmailKind; tenantId: string }) => Promise<unknown>;
};

export type ReminderBatchExecutionResult = {
  reviewedCount: number;
  empresasRevisadas: number;
  emailsSent: number;
  correosEnviados: number;
  hasMore: boolean;
  quedanPendientes: boolean;
  pending: boolean;
  nextCursor: string | null;
  batchesProcessed: number;
  sentDay3: number;
  sentDay6: number;
  sentTrialExpiring: number;
  sentPaymentFailed: number;
  sendLog: EmailSendLogEntry[];
};

/**
 * Ejecuta el procesamiento paginado de recordatorios por lotes (200 empresas por lote,
 * ordenadas por `id` ascendente), controlando el tiempo máximo de ejecución, guardando
 * cursor si queda trabajo pendiente y garantizando envío único e idempotente por periodo.
 */
export async function executePaginatedReminders(
  options: ReminderBatchExecutionOptions,
): Promise<ReminderBatchExecutionResult> {
  const {
    admin,
    batchSize = DEFAULT_REMINDER_BATCH_SIZE,
    maxDurationMs = DEFAULT_MAX_EXECUTION_MS,
    nowMs = Date.now(),
    nowFn = () => Date.now(),
    initialCursor,
    includePaymentFailedPriority = false,
    sendEmailFn,
  } = options;

  const startedAt = nowFn();
  const period = getReminderPeriodKey(nowMs);
  const nowIso = new Date(nowMs).toISOString();

  let cursor = await loadSavedCursor(admin, initialCursor);
  let reviewedCount = 0;
  let emailsSent = 0;
  let sentDay3 = 0;
  let sentDay6 = 0;
  let sentTrialExpiring = 0;
  let sentPaymentFailed = 0;
  let batchesProcessed = 0;
  let hasMore = false;
  const sendLog: EmailSendLogEntry[] = [];
  const processedTenantIdsInRun = new Set<string>();

  const deliverEmail =
    sendEmailFn ??
    (async (msg) => {
      await sendMail({ to: msg.to, subject: msg.subject, html: msg.html, text: msg.text });
    });

  while (true) {
    // Controlar tiempo máximo antes de abrir un nuevo lote (tras haber procesado al menos 1 lote o si el tiempo ya expiró)
    if (batchesProcessed > 0 && nowFn() - startedAt >= maxDurationMs) {
      hasMore = true;
      await persistCursor(admin, cursor);
      break;
    }

    // Consulta de "prueba sin convertir": excluye explícitamente past_due, unpaid e incomplete.
    const allowedStatuses = includePaymentFailedPriority
      ? [...ABANDONED_TRIAL_ALLOWED_STATUSES, ...PAYMENT_FAILED_STATUSES]
      : [...ABANDONED_TRIAL_ALLOWED_STATUSES];

    let query: Record<string, unknown> = admin
      .from('tenants')
      .select('id, name, owner_email, plan, subscription_status, created_at, trial_ends_at, settings, locale') as unknown as Record<string, unknown>;

    if (typeof query.in === 'function') {
      query = (query.in as (col: string, vals: readonly string[]) => Record<string, unknown>)(
        'subscription_status',
        allowedStatuses,
      );
    }
    if (!includePaymentFailedPriority && typeof query.not === 'function') {
      query = (query.not as (col: string, op: string, val: string) => Record<string, unknown>)(
        'subscription_status',
        'in',
        `(${PAYMENT_FAILED_STATUSES.join(',')})`,
      );
    }
    if (cursor && typeof query.gt === 'function') {
      query = (query.gt as (col: string, val: string) => Record<string, unknown>)('id', cursor);
    }
    if (typeof query.order === 'function') {
      query = (query.order as (col: string, opts: { ascending: boolean }) => Record<string, unknown>)('id', {
        ascending: true,
      });
    }
    if (typeof query.limit === 'function') {
      query = (query.limit as (n: number) => Record<string, unknown>)(batchSize);
    }

    const queryResult = (await (query as unknown as Promise<{ data?: ReminderTenantRecord[] | null }>)) ?? {};
    const rawRows = Array.isArray(queryResult.data) ? queryResult.data : [];

    // Ordenar por id y aplicar filtro de cursor y límite de lote también en memoria
    // para garantizar paginación exacta tanto contra PostgREST como contra mocks de test.
    const sortedFiltered = [...rawRows]
      .filter((r) => r && typeof r.id === 'string')
      .sort((a, b) => a.id.localeCompare(b.id))
      .filter((r) => (!cursor ? true : r.id > cursor));

    const batch = sortedFiltered.slice(0, batchSize);
    if (batch.length === 0) {
      hasMore = false;
      cursor = null;
      await persistCursor(admin, null);
      break;
    }

    batchesProcessed += 1;
    let timedOutInsideBatch = false;

    for (let i = 0; i < batch.length; i += 1) {
      const t = batch[i];
      if (processedTenantIdsInRun.has(t.id)) {
        cursor = t.id;
        continue;
      }

      // Si nos acercamos al límite de tiempo a mitad de tanda, guardamos cursor y salimos limpiamente.
      if (reviewedCount > 0 && nowFn() - startedAt >= maxDurationMs) {
        hasMore = true;
        timedOutInsideBatch = true;
        await persistCursor(admin, cursor);
        break;
      }

      processedTenantIdsInRun.add(t.id);
      reviewedCount += 1;
      cursor = t.id;

      // Defensa adicional: "prueba sin convertir" NUNCA se envía a past_due / unpaid / incomplete.
      if (!includePaymentFailedPriority && isPaymentFailedStatus(t.subscription_status)) {
        continue;
      }

      const kind = resolveSingleReminderForTenant(t, nowMs, period);
      if (!kind) continue;

      // Doble verificación de idempotencia en el periodo actual.
      if (hasReminderBeenSentInPeriod(t.settings, kind, period)) {
        continue;
      }

      const settings = t.settings ?? {};
      const locale = t.locale || settings.locale || 'es';
      const rendered = renderTransactionalEmail({
        kind,
        locale,
        tenantName: t.name,
        planName: t.plan ?? 'Pro',
        trialEndDate: t.trial_ends_at ?? undefined,
      });

      await deliverEmail({
        to: t.owner_email!,
        subject: rendered.subject,
        html: rendered.html,
        text: rendered.text,
        kind,
        tenantId: t.id,
      });

      const logEntry: EmailSendLogEntry = {
        tenantId: t.id,
        kind,
        sentAt: nowIso,
        period,
      };
      const updatedSettings = recordReminderSend(settings, logEntry);
      t.settings = updatedSettings;

      await admin
        .from('tenants')
        .update({ settings: updatedSettings })
        .eq('id', t.id);

      sendLog.push(logEntry);
      emailsSent += 1;
      if (kind === 'abandoned_trial_day3') sentDay3 += 1;
      else if (kind === 'abandoned_trial_day6') sentDay6 += 1;
      else if (kind === 'trial_expiring') sentTrialExpiring += 1;
      else if (kind === 'payment_failed') sentPaymentFailed += 1;
    }

    if (timedOutInsideBatch) {
      break;
    }

    // Si el lote devolvió menos de batchSize filas (y no quedan más en sortedFiltered), hemos terminado.
    if (batch.length < batchSize && sortedFiltered.length <= batch.length) {
      hasMore = false;
      cursor = null;
      await persistCursor(admin, null);
      break;
    }
  }

  return {
    reviewedCount,
    empresasRevisadas: reviewedCount,
    emailsSent,
    correosEnviados: emailsSent,
    hasMore,
    quedanPendientes: hasMore,
    pending: hasMore,
    nextCursor: hasMore ? cursor : null,
    batchesProcessed,
    sentDay3,
    sentDay6,
    sentTrialExpiring,
    sentPaymentFailed,
    sendLog,
  };
}

/**
 * GET /api/cron/abandoned-trial
 * Secuencia automática de recordatorios paginada en lotes de 200 empresas (ordenadas por `id`),
 * con exclusión de empresas con pago fallido (`past_due`, `unpaid`, `incomplete`),
 * prioridad estricta (`payment_failed` > `trial_expiring` > `abandoned_trial`),
 * control de tiempo máximo de ejecución con guardado de cursor e idempotencia por periodo.
 */
export async function GET(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  if (!verifyCronSecret(req)) {
    return apiError('No autorizado.', { status: 401, code: 'unauthorized', correlationId });
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  const url = new URL(req.url);
  const cursorParam = url.searchParams.get('cursor');
  const maxDurationParam = Number(url.searchParams.get('maxDurationMs') ?? '');
  const batchSizeParam = Number(url.searchParams.get('batchSize') ?? '');

  const result = await executePaginatedReminders({
    admin: admin as unknown as AdminLike,
    batchSize: Number.isFinite(batchSizeParam) && batchSizeParam > 0 ? Math.min(batchSizeParam, 500) : DEFAULT_REMINDER_BATCH_SIZE,
    maxDurationMs: Number.isFinite(maxDurationParam) && maxDurationParam > 0 ? maxDurationParam : DEFAULT_MAX_EXECUTION_MS,
    initialCursor: cursorParam !== null ? cursorParam : undefined,
  });

  await logStructured(
    'info',
    'cron.abandoned_trial',
    `Recordatorios procesados: revisadas=${result.reviewedCount}, enviados=${result.emailsSent}, pendientes=${result.hasMore}`,
    {
      correlationId,
      reviewedCount: result.reviewedCount,
      emailsSent: result.emailsSent,
      hasMore: result.hasMore,
      nextCursor: result.nextCursor,
      sentDay3: result.sentDay3,
      sentDay6: result.sentDay6,
      sentTrialExpiring: result.sentTrialExpiring,
      sentPaymentFailed: result.sentPaymentFailed,
    },
  );

  return NextResponse.json(
    {
      ok: true,
      correlationId,
      reviewedCount: result.reviewedCount,
      empresasRevisadas: result.reviewedCount,
      emailsSent: result.emailsSent,
      correosEnviados: result.emailsSent,
      hasMore: result.hasMore,
      quedanPendientes: result.hasMore,
      pending: result.hasMore,
      nextCursor: result.nextCursor,
      batchesProcessed: result.batchesProcessed,
      sentDay3: result.sentDay3,
      sentDay6: result.sentDay6,
    },
    { headers: correlationHeaders(correlationId) },
  );
}
