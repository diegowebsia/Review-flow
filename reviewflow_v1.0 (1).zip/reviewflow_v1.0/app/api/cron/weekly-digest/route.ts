import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { isTrialExpired, planOf, resolvePlan } from '@/lib/plans';
import { checkQuota } from '@/lib/usage';
import { sendMail } from '@/lib/mail';
import { systemLog } from '@/lib/logger';
import { resolvePublicUrlFromEnv as resolveAppUrlFromEnv } from '@/lib/public-url';
import { escapeHtml, verifyCronSecret } from '@/lib/security';
import { apiError, errorMessage } from '@/lib/api-error';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

type DigestTenantRow = {
  owner_id?: string | null;
  id: string;
  name: string;
  slug: string;
  owner_email: string | null;
  plan: string;
  subscription_status: string;
  suspended: boolean;
  trial_ends_at: string | null;
  settings: { weekly_digest?: boolean } | null;
};

export async function GET(req: Request) {
  return runWeeklyDigest(req);
}

export async function POST(req: Request) {
  return runWeeklyDigest(req);
}

async function runWeeklyDigest(req: Request) {
  const correlationId = getOrCreateCorrelationId(req);
  if (!verifyCronSecret(req)) {
    return apiError(
      'No autorizado. Configura CRON_SECRET y llámame con `Authorization: Bearer …` (Vercel Cron lo envía solo) o `?secret=…`.',
      {
        status: process.env.CRON_SECRET ? 401 : 503,
        code: 'unauthorized',
        correlationId,
      },
    );
  }

  const admin = createAdminClient();
  if (!admin) {
    return apiError('Supabase no configurado.', {
      status: 503,
      code: 'database_unavailable',
      correlationId,
    });
  }

  const { data: tenants } = await admin
    .from('tenants')
    .select('id, name, slug, owner_id, owner_email, plan, subscription_status, suspended, trial_ends_at, settings')
    .eq('suspended', false)
    .in('subscription_status', ['active', 'trialing']);

  const eligible = ((tenants ?? []) as DigestTenantRow[]).filter(
    (t) => Boolean(t.owner_email) && !isTrialExpired(t.subscription_status, t.trial_ends_at),
  );

  if (eligible.length === 0) {
    return NextResponse.json(
      { ok: true, correlationId, tenants: 0, sent: 0, skipped: [] },
      { headers: correlationHeaders(correlationId) },
    );
  }

  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const baseUrl = resolveAppUrlFromEnv();
  let sent = 0;
  const skipped: Array<{ tenantId: string; reason: string }> = [];

  for (const tenant of eligible) {
    const settings = (tenant.settings as { weekly_digest?: boolean } | null) ?? {};
    if (settings.weekly_digest === false) {
      skipped.push({ tenantId: tenant.id, reason: 'disabled_by_tenant' });
      continue;
    }

    // Preferencias personales del propietario (página «Mi cuenta» → Emails que recibes).
    if (tenant.owner_id) {
      const { data: ownerProfile } = await admin
        .from('user_profiles')
        .select('email_prefs')
        .eq('user_id', tenant.owner_id)
        .maybeSingle();
      const prefs = (ownerProfile?.email_prefs as { weekly_digest?: boolean } | null) ?? {};
      if (prefs.weekly_digest === false) {
        skipped.push({ tenantId: tenant.id, reason: 'disabled_by_owner' });
        continue;
      }
    }

    try {
      const { data: recentReviews } = await admin
        .from('reviews')
        .select('rating, reply_text, flagged_private')
        .eq('tenant_id', tenant.id)
        .gte('created_at', sevenDaysAgo);

      const list = recentReviews ?? [];
      const totalNew = list.length;
      const avgRating =
        totalNew > 0
          ? (list.reduce((acc: number, r) => acc + Number(r.rating ?? 0), 0) / totalNew).toFixed(1)
          : '—';
      const positiveCount = list.filter((r) => Number(r.rating ?? 0) >= 4).length;
      const privateComplaints = list.filter(
        (r) => Boolean(r.flagged_private) || Number(r.rating ?? 5) <= 3,
      ).length;
      const repliedCount = list.filter((r) => Boolean(r.reply_text)).length;

      const quota = await checkQuota(admin, tenant.id).catch(() => null);
      const planDef = planOf(resolvePlan(tenant.plan));
      const safeName = escapeHtml(String(tenant.name || 'tu negocio'));
      const dashboardUrl = `${baseUrl}/dashboard`;

      const quotaLine = quota
        ? `Peticiones: ${quota.metrics.requests.used}/${quota.metrics.requests.quota} · Opiniones: ${quota.metrics.reviews.used}/${quota.metrics.reviews.quota} · Respuestas IA: ${quota.metrics.ai.used}/${quota.metrics.ai.quota}`
        : `Plan activo: ${planDef.name}`;

      const subject = `Resumen semanal de reputación · ${tenant.name || 'ReviewFlow AI'}`;
      const text =
        `Hola,\n\n` +
        `Aquí tienes el informe semanal de reputación de ${tenant.name || 'tu negocio'} (últimos 7 días):\n\n` +
        `• Nuevas valoraciones: ${totalNew}\n` +
        `• Nota media semanal: ${avgRating} ★\n` +
        `• Reseñas positivas (4★–5★): ${positiveCount}\n` +
        `• Quejas retenidas en privado (≤3★): ${privateComplaints}\n` +
        `• Reseñas respondidas: ${repliedCount}\n\n` +
        `Consumo de tu plan (${planDef.name}):\n` +
        `${quotaLine}\n\n` +
        `Accede a tu panel para gestionar tus reseñas:\n${dashboardUrl}\n\n` +
        `Equipo de ReviewFlow AI`;

      const html =
        `<div style="font-family:sans-serif;max-width:560px;margin:0 auto;color:#0f172a;line-height:1.6;">` +
        `<h2 style="margin-bottom:8px;color:#1e293b;">Resumen semanal · ${safeName}</h2>` +
        `<p style="color:#475569;font-size:14px;margin-top:0;">Actividad de reputación de los últimos 7 días:</p>` +
        `<table style="width:100%;border-collapse:collapse;margin:16px 0;background:#f8fafc;border-radius:8px;overflow:hidden;">` +
        `<tr><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;">Nuevas valoraciones</td><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;font-weight:700;text-align:right;">${totalNew}</td></tr>` +
        `<tr><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;">Nota media semanal</td><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;font-weight:700;text-align:right;">${avgRating} ★</td></tr>` +
        `<tr><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;">Positivas (4★–5★)</td><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;font-weight:700;text-align:right;color:#059669;">${positiveCount}</td></tr>` +
        `<tr><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;">Quejas retenidas en privado (≤3★)</td><td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;font-weight:700;text-align:right;color:#d97706;">${privateComplaints}</td></tr>` +
        `<tr><td style="padding:10px 14px;">Respondidas</td><td style="padding:10px 14px;font-weight:700;text-align:right;">${repliedCount}</td></tr>` +
        `</table>` +
        `<p style="font-size:13px;color:#475569;background:#f1f5f9;padding:10px 14px;border-radius:6px;">` +
        `<strong>Cuota mensual (${escapeHtml(planDef.name)}):</strong><br/>${escapeHtml(quotaLine)}` +
        `</p>` +
        `<div style="margin:24px 0;">` +
        `<a href="${dashboardUrl}" style="background:#2563eb;color:#ffffff;text-decoration:none;padding:10px 20px;border-radius:6px;font-weight:600;display:inline-block;">Abrir mi panel →</a>` +
        `</div>` +
        `</div>`;

      const mailRes = await sendMail({
        to: String(tenant.owner_email),
        subject,
        text,
        html,
      });

      if (mailRes.sent) {
        sent += 1;
      } else {
        skipped.push({ tenantId: tenant.id, reason: mailRes.message || 'mail_not_sent' });
      }
    } catch (err: unknown) {
      skipped.push({ tenantId: tenant.id, reason: errorMessage(err, 'error').slice(0, 80) });
    }
  }

  await systemLog('info', 'cron.weekly-digest', `Resumen semanal procesado: ${sent}/${eligible.length} enviados`, {
    tenants: eligible.length,
    sent,
    skipped: skipped.length,
    correlationId,
  });

  return NextResponse.json(
    {
      ok: true,
      correlationId,
      tenants: eligible.length,
      sent,
      skipped,
    },
    { headers: correlationHeaders(correlationId) },
  );
}
