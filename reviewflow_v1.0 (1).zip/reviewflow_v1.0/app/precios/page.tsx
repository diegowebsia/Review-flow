import { pageMetadata } from '@/lib/seo';
import Link from 'next/link';
import { Check, ShieldCheck, Sparkles, ArrowRight } from 'lucide-react';
import { ADDON_CATALOG, PLAN_CATALOG, TRIAL_DAYS } from '@/lib/plans';
import { getFreeTrialEnabled } from '@/lib/system-settings';
import { Footer } from '@/components/Footer';

export const dynamic = 'force-dynamic';

export const metadata = pageMetadata('Precios y planes', 'Compara los cuatro planes de ReviewFlow AI para negocios locales y tiendas online, sus cuotas y ampliaciones. Cada empresa tiene su propio plan.', '/precios', true);

const COMPARISON_ROWS: Array<{
  feature: string;
  local_starter: string | boolean;
  local_pro: string | boolean;
  ecommerce_starter: string | boolean;
  ecommerce_pro: string | boolean;
}> = [
  {
    feature: 'Peticiones mensuales por email',
    local_starter: '250 / mes',
    local_pro: '1.500 / mes',
    ecommerce_starter: '800 / mes',
    ecommerce_pro: '4.000 / mes',
  },
  {
    feature: 'Opiniones importadas / mes',
    local_starter: '500 / mes',
    local_pro: '3.000 / mes',
    ecommerce_starter: '1.500 / mes',
    ecommerce_pro: '10.000 / mes',
  },
  {
    feature: 'Respuestas con IA (Google Gemini) / mes',
    local_starter: '200 / mes',
    local_pro: '1.000 / mes',
    ecommerce_starter: '500 / mes',
    ecommerce_pro: '2.500 / mes',
  },
  {
    feature: 'Presupuesto mensual de tokens IA',
    local_starter: '150.000 tokens',
    local_pro: '900.000 tokens',
    ecommerce_starter: '400.000 tokens',
    ecommerce_pro: '2.200.000 tokens',
  },
  {
    feature: 'Cartel QR físico imprimible y embudo privado (≤3★)',
    local_starter: true,
    local_pro: true,
    ecommerce_starter: true,
    ecommerce_pro: true,
  },
  {
    feature: 'Conexión Google Business y Trustpilot',
    local_starter: true,
    local_pro: true,
    ecommerce_starter: true,
    ecommerce_pro: true,
  },
  {
    feature: 'Alertas en tiempo real ante quejas (≤3★) por email, Slack o Teams',
    local_starter: false,
    local_pro: true,
    ecommerce_starter: true,
    ecommerce_pro: true,
  },
  {
    feature: 'Integración Shopify / WooCommerce post-entrega',
    local_starter: false,
    local_pro: false,
    ecommerce_starter: true,
    ecommerce_pro: true,
  },
  {
    feature: 'Roles de equipo (RBAC: owner, admin, agent, viewer)',
    local_starter: true,
    local_pro: true,
    ecommerce_starter: true,
    ecommerce_pro: true,
  },
];

function renderCell(val: string | boolean) {
  if (typeof val === 'boolean') {
    return val ? (
      <span className="inline-flex items-center gap-1 font-semibold text-emerald-300">
        <Check size={15} aria-hidden="true" /> Incluido
      </span>
    ) : (
      <span className="text-ink-500">—</span>
    );
  }
  return <span className="font-mono text-xs font-semibold text-ink-100">{val}</span>;
}

export default async function PreciosPage() {
  const freeTrialEnabled = await getFreeTrialEnabled();

  return (
    <div className="min-h-screen bg-ink-950 text-ink-100">
      <header className="border-b border-white/[0.06] bg-ink-950/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link href="/" className="text-lg font-extrabold tracking-tight text-white">
            ReviewFlow <span className="text-brand-300">AI</span>
          </Link>
          <nav aria-label="Navegación de precios" className="flex items-center gap-3">
            <Link href="/login" className="btn-quiet btn-sm">
              Iniciar sesión
            </Link>
            <Link href="/registro" className="btn-primary btn-sm">
              {freeTrialEnabled ? `Probar ${TRIAL_DAYS} días gratis` : 'Empezar ahora'}
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl space-y-14 px-6 py-14">
        {/* Hero con prueba gratuita visible */}
        <section className="mx-auto max-w-3xl text-center">
          {freeTrialEnabled && (
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-emerald-400/35 bg-emerald-500/10 px-4 py-1.5 text-xs font-semibold text-emerald-200">
              <Sparkles size={14} aria-hidden="true" />
              Prueba gratuita de {TRIAL_DAYS} días activa · 0,00 € hoy · Cancela en 1 clic
            </div>
          )}
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-5xl">
            Planes transparentes para cada tipo de negocio
          </h1>
          <p className="mt-4 text-base text-ink-300">
            <strong>1 Plan = 1 Negocio o Ubicación completa</strong> (incluye Google Business,
            Trustpilot, cartel QR y memoria de marca con IA). ¿Varios locales? Añade más empresas a la misma cuenta, cada una con su plan. Descuento del{' '}
            <strong className="text-emerald-300">20 % en facturación anual</strong>.
          </p>
        </section>

        {/* Tarjetas de planes */}
        <section aria-label="Catálogo de planes" className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {PLAN_CATALOG.map((plan) => {
            const isHighlighted = plan.id === 'local_pro' || plan.id === 'ecommerce_pro';
            const planBullets = [
              `${plan.limits.requestsPerMonth.toLocaleString('es-ES')} peticiones / mes`,
              `${plan.limits.reviewsPerMonth.toLocaleString('es-ES')} opiniones / mes`,
              `${plan.limits.aiRepliesPerMonth.toLocaleString('es-ES')} respuestas IA / mes`,
              `${(plan.limits.aiTokensPerMonth / 1000).toLocaleString('es-ES')}k tokens IA / mes`,
            ];
            return (
              <article
                key={plan.id}
                className={`card flex flex-col justify-between p-6 ${
                  isHighlighted ? 'border-brand-400/50 ring-1 ring-brand-400/30' : ''
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-brand-300">
                      {plan.category === 'ecommerce' ? 'E-commerce' : 'Negocio físico'}
                    </span>
                    {isHighlighted && (
                      <span className="rounded-md bg-brand-500/20 px-2 py-0.5 text-2xs font-semibold text-brand-200">
                        Recomendado
                      </span>
                    )}
                  </div>
                  <h2 className="mt-2 text-lg font-bold text-white">{plan.name}</h2>
                  <p className="mt-1 text-xs text-ink-300">{plan.pitch}</p>

                  <div className="mt-5 flex items-baseline gap-1">
                    <span className="font-mono text-3xl font-extrabold text-white tabular-nums">
                      {plan.price}
                    </span>
                    <span className="text-xs text-ink-400">/ mes + IVA</span>
                  </div>
                  {freeTrialEnabled && (
                    <p className="mt-1 text-2xs font-medium text-emerald-300">
                      Incluye {TRIAL_DAYS} días de prueba gratuita (0,00 € hoy)
                    </p>
                  )}

                  <ul className="mt-5 space-y-2 border-t border-white/[0.07] pt-4 text-xs text-ink-200">
                    {planBullets.map((bullet: string) => (
                      <li key={bullet} className="flex items-start gap-2">
                        <Check size={14} className="mt-0.5 shrink-0 text-emerald-400" aria-hidden="true" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <Link
                  href={`/registro?plan=${plan.id}`}
                  className={`mt-6 w-full justify-center ${
                    isHighlighted ? 'btn-primary' : 'btn-secondary'
                  }`}
                >
                  {freeTrialEnabled ? `Probar ${TRIAL_DAYS} días gratis` : 'Elegir plan'}
                  <ArrowRight size={14} aria-hidden="true" />
                </Link>
              </article>
            );
          })}
        </section>

        {/* Tabla comparativa de planes */}
        <section aria-labelledby="comparativa-heading" className="card overflow-hidden p-0">
          <div className="border-b border-white/[0.06] p-6">
            <h2 id="comparativa-heading" className="text-xl font-bold text-white">
              Comparativa detallada de planes
            </h2>
            <p className="mt-1 text-xs text-ink-300">
              Todas las cuotas se renuevan el día 1 de cada mes y pueden ampliarse con recargas puntuales.
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-white/[0.06] bg-white/[0.02] text-2xs uppercase tracking-wider text-ink-400">
                <tr>
                  <th className="px-5 py-3.5">Característica</th>
                  {(['local_starter', 'local_pro', 'ecommerce_starter', 'ecommerce_pro'] as const).map((id) => {
                    const def = PLAN_CATALOG.find((p) => p.id === id);
                    return (
                      <th key={id} className="px-5 py-3.5">
                        {def ? `${def.name} (${def.price})` : id}
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.05]">
                {COMPARISON_ROWS.map((row) => (
                  <tr key={row.feature} className="hover:bg-white/[0.02]">
                    <td className="px-5 py-3.5 font-medium text-white">{row.feature}</td>
                    <td className="px-5 py-3.5">{renderCell(row.local_starter)}</td>
                    <td className="px-5 py-3.5">{renderCell(row.local_pro)}</td>
                    <td className="px-5 py-3.5">{renderCell(row.ecommerce_starter)}</td>
                    <td className="px-5 py-3.5">{renderCell(row.ecommerce_pro)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Recargas puntuales */}
        <section aria-labelledby="addons-heading" className="space-y-4">
          <div>
            <h2 id="addons-heading" className="text-xl font-bold text-white">
              Recargas puntuales de pago único
            </h2>
            <p className="text-xs text-ink-300">
              Amplía cualquier métrica durante el mes en curso sin cambiar de plan fijo.
            </p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ADDON_CATALOG.map((addon) => (
              <div key={addon.id} className="card p-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{addon.name}</span>
                  <span className="font-mono text-sm font-extrabold text-brand-200">
                    {`${Math.round(addon.priceCents / 100)} €`}
                  </span>
                </div>
                <p className="mt-1.5 text-2xs text-ink-300">{addon.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Garantía y seguridad */}
        <section className="card flex flex-wrap items-center justify-between gap-4 border-emerald-400/25 p-6">
          <div className="flex items-start gap-3">
            <ShieldCheck size={22} className="mt-0.5 shrink-0 text-emerald-300" aria-hidden="true" />
            <div>
              <h2 className="text-sm font-bold text-white">
                Cumplimiento RGPD UE, aislamiento multi-empresa RLS y facturación oficial con Stripe
              </h2>
              <p className="mt-0.5 text-xs text-ink-300">
                Sin permanencia. Puedes cambiar de plan, pausar tu suscripción o cancelar desde el portal de cliente en cualquier momento.
              </p>
            </div>
          </div>
          <Link href="/registro" className="btn-primary btn-sm">
            {freeTrialEnabled ? `Empezar prueba de ${TRIAL_DAYS} días` : 'Crear cuenta'}
          </Link>
        </section>
      </main>

      <Footer />
    </div>
  );
}
