import { pageMetadata } from '@/lib/seo';
import { AboutClient } from './about-client';

export const metadata = pageMetadata('Sobre nosotros', 'Conoce ReviewFlow AI, su misión y su enfoque para gestionar la reputación de negocios y tiendas online.', '/sobre-nosotros', true);

export default function SobreNosotrosPage() {
  return <AboutClient />;
}
