import { pageMetadata } from '@/lib/seo';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getSessionUser } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { createClient } from '@/lib/supabase/server';
import { isSupabaseConfigured } from '@/lib/env';
import { currentCycle, hasAccess, resolvePlan, TRIAL_DAYS, type PlanId } from '@/lib/plans';
import { getStripe } from '@/lib/stripe';
import { getFreeTrialEnabled } from '@/lib/system-settings';
import { Aurora } from '@/components/Motion';
import { WelcomeClient } from './welcome-client';
import { hasUsedFreeTrial, recordFreeTrial } from '@/lib/trial';

export const dynamic = 'force-dynamic';
export const metadata = pageMetadata('Activa tu plan', 'Configura tu empresa y activa su suscripción de ReviewFlow AI.', undefined, false);

function slugify(s: string) {
  return (
    s
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '')
      .slice(0, 40) || 'negocio'
  );
}

function legacyPlanFallback(plan: PlanId): 'pro' | 'business' {
  return plan === 'ecommerce_starter' || plan === 'ecommerce_pro' ? 'business' : 'pro';
}

async function syncCheckoutSessionOnReturn(
  admin: NonNullable<ReturnType<typeof createAdminClient>>,
  user: NonNullable<Awaited<ReturnType<typeof getSessionUser>>>,
  sessionId: string,
  existingTenantId?: string,
): Promise<boolean> {
  const stripe = getStripe();
  if (!stripe) return false;
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    const sessionUserId = session.metadata?.userId || session.client_reference_id;
    const sessionEmail = (session.customer_details?.email || session.customer_email || '').toLowerCase();
    if (
      session.status !== 'complete' ||
      (sessionUserId !== user.id && (!user.email || sessionEmail !== user.email.toLowerCase()))
    ) {
      return false;
    }

    const plan = resolvePlan(session.metadata?.plan);
    const customerId = typeof session.customer === 'string' ? session.customer : null;
    const subscriptionId = typeof session.subscription === 'string' ? session.subscription : null;
    const createdMs = (session.created || 1_700_000_000) * 1000;

    let status: 'trialing' | 'active' =
      session.metadata?.freeTrial === 'false' ? 'active' : 'trialing';
    let trialEndsAt: string | null =
      status === 'trialing' ? new Date(createdMs + TRIAL_DAYS * 86_400_000).toISOString() : null;

    if (subscriptionId) {
      try {
        const sub = await stripe.subscriptions.retrieve(subscriptionId);
        const inTrial = sub.trial_end != null && sub.trial_end * 1000 > Date.now();
        status = inTrial ? 'trialing' : 'active';
        trialEndsAt = inTrial && sub.trial_end ? new Date(sub.trial_end * 1000).toISOString() : null;
      } catch {
        /* conservamos el cálculo a partir de la sesión */
      }
    }

    if (status === 'trialing') {
      await recordFreeTrial(admin, { userId: user.id, email: user.email ?? sessionEmail });
    }

    // Idempotencia: si el webhook ya dio de alta esta suscripción, no hay nada que hacer.
    if (subscriptionId) {
      const { data: done } = await admin
        .from('tenants')
        .select('id')
        .eq('stripe_subscription_id', subscriptionId)
        .maybeSingle();
      if (done?.id) return true;
    }

    // Multipanel: solo se reutiliza una empresa si el pago se hizo PARA ella.
    const hinted = session.metadata?.tenantId || '';
    const isNewBusiness = session.metadata?.newBusiness === 'true';
    if (isNewBusiness) existingTenantId = undefined;
    else if (hinted) existingTenantId = hinted;

    if (existingTenantId) {
      const { data: owns } = await admin
        .from('tenants')
        .select('id')
        .eq('id', existingTenantId)
        .eq('owner_id', user.id)
        .maybeSingle();
      if (!owns?.id) return false;
      const { data: prevTenant } = await admin
        .from('tenants')
        .select('stripe_subscription_id')
        .eq('id', existingTenantId)
        .maybeSingle();
      const prevSubId = (prevTenant?.stripe_subscription_id as string | null) ?? null;

      const { error: updateErr } = await admin
        .from('tenants')
        .update({
          plan,
          subscription_status: status,
          stripe_customer_id: customerId,
          stripe_subscription_id: subscriptionId,
          trial_ends_at: trialEndsAt,
          suspended: false,
        })
        .eq('id', existingTenantId);

      if (updateErr) {
        await admin
          .from('tenants')
          .update({
            plan: legacyPlanFallback(plan),
            subscription_status: status,
            stripe_customer_id: customerId,
            stripe_subscription_id: subscriptionId,
            trial_ends_at: trialEndsAt,
            suspended: false,
          })
          .eq('id', existingTenantId);
      }

      if (prevSubId && subscriptionId && prevSubId !== subscriptionId) {
        try {
          await stripe.subscriptions.cancel(prevSubId);
        } catch {
          /* ignore if already canceled */
        }
      }

      await admin
        .from('memberships')
        .upsert({ tenant_id: existingTenantId, user_id: user.id, role: 'owner' }, { onConflict: 'tenant_id,user_id' });
      return true;
    }

    const baseName = (user.email ?? 'negocio').split('@')[0] ?? 'negocio';
    const businessName =
      (session.metadata?.businessName || '').trim() || session.customer_details?.name || `Negocio de ${baseName}`;
    const suffix = session.id.slice(-6).toLowerCase().replace(/[^a-z0-9]/g, 'x');
    const slug = `${slugify(baseName)}-${suffix}`;

    const firstInsert = await admin
      .from('tenants')
      .insert({
        name: businessName,
        slug,
        owner_id: user.id,
        owner_email: user.email ?? sessionEmail,
        plan,
        subscription_status: status,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscriptionId,
        trial_ends_at: trialEndsAt,
      })
      .select('id')
      .single();
    let created = firstInsert.data;
    if (created?.id && subscriptionId) {
      try {
        await stripe.subscriptions.update(subscriptionId, { metadata: { tenantId: created.id } });
      } catch {
        /* ignore */
      }
    }
    const insertErr = firstInsert.error;

    if (insertErr || !created?.id) {
      const retry = await admin
        .from('tenants')
        .insert({
          name: businessName,
          slug: `${slug}-1`,
          owner_id: user.id,
          owner_email: user.email ?? sessionEmail,
          plan: legacyPlanFallback(plan),
          subscription_status: status,
          stripe_customer_id: customerId,
          stripe_subscription_id: subscriptionId,
          trial_ends_at: trialEndsAt,
        })
        .select('id')
        .single();
      created = retry.data;
    }

    if (created?.id) {
      await admin
        .from('memberships')
        .upsert({ tenant_id: created.id, user_id: user.id, role: 'owner' }, { onConflict: 'tenant_id,user_id' });
      await admin
        .from('usage_counters')
        .upsert(
          {
            tenant_id: created.id,
            cycle: currentCycle(),
            ai_responses: 0,
            whatsapp_sent: 0,
            reviews_ingested: 0,
            google_calls: 0,
          },
          { onConflict: 'tenant_id,cycle' },
        );
      return true;
    }
  } catch {
    /* Si falla la consulta puntual, el webhook terminará el alta */
  }
  return false;
}

export default async function BienvenidoPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string; checkout?: string; reason?: string; session_id?: string }>;
}) {
  const sp = await searchParams;
  const user = await getSessionUser();
  if (isSupabaseConfigured && !user) redirect('/login?redirect=/bienvenido');

  const preselected = sp.plan ? resolvePlan(sp.plan) : 'local_starter';
  const checkout = sp.checkout;

  let alreadyActive = false;
  const admin = createAdminClient();
  if (admin && user) {
    const { data } = await admin
      .from('tenants')
      .select('id, subscription_status, suspended')
      .eq('owner_id', user.id);
    const tenantRows = (data ?? []) as Array<{ id: string; subscription_status: string; suspended: boolean }>;
    alreadyActive = tenantRows.some((t) => hasAccess(t.subscription_status, t.suspended));

    if (checkout === 'success' && sp.session_id) {
      // Sin empresas → se crea; con empresas → solo se usa la que indique el propio pago.
      const fallback = tenantRows.length === 1 && !hasAccess(tenantRows[0].subscription_status, tenantRows[0].suspended)
        ? tenantRows[0].id
        : undefined;
      const synced = await syncCheckoutSessionOnReturn(admin, user, sp.session_id, fallback);
      if (synced) alreadyActive = true;
    }
  } else if (isSupabaseConfigured && user) {
    try {
      const supabase = await createClient();
      const { data } = await supabase
        .from('memberships')
        .select('tenants(id, subscription_status, suspended)')
        .eq('user_id', user.id);
      type JoinedMembership = {
        tenants?: { id: string; subscription_status: string; suspended: boolean } | null;
      };
      const list = ((data ?? []) as unknown as JoinedMembership[])
        .map((m) => m.tenants)
        .filter((t): t is NonNullable<typeof t> => Boolean(t));
      alreadyActive = list.some((t) => hasAccess(t.subscription_status, t.suspended));
    } catch {
      alreadyActive = false;
    }
  }

  if (checkout === 'success' && alreadyActive) redirect('/dashboard');

  let freeTrialEnabled = await getFreeTrialEnabled();
  if (freeTrialEnabled && user && admin) {
    // La prueba gratis solo se ofrece una vez por cuenta.
    freeTrialEnabled = !(await hasUsedFreeTrial(admin, getStripe(), { userId: user.id, email: user.email }));
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-ink-950 text-ink-50">
      <Aurora />
      <header className="nav-blur sticky top-0 z-50 w-full border-b border-white/10 bg-slate-900/80 backdrop-blur-md transition-all duration-300">
        <div className="mx-auto flex h-16 max-w-4xl items-center justify-between gap-4 px-4">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-sm text-ink-300 transition-colors hover:text-white"
          >
            <span aria-hidden>←</span> Volver a la web
          </Link>
          <p className="truncate text-sm text-ink-400">
            {user?.email ?? 'Bienvenido'}
            <span className="mx-2 text-ink-600">·</span>
            <span className="font-semibold text-white">
              Paso 2 de 2 · {freeTrialEnabled ? 'activa tu prueba' : 'activa tu plan'}
            </span>
          </p>
        </div>
      </header>
      <div className="relative z-10">
        <WelcomeClient
          email={user?.email ?? ''}
          preselected={preselected}
          checkout={checkout}
          reason={sp.reason}
          alreadyActive={alreadyActive}
          freeTrialEnabled={freeTrialEnabled}
        />
      </div>
    </div>
  );
}
