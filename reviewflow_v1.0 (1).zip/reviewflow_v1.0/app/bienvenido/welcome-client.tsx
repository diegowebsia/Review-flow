'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  BadgeCheck,
  Check,
  CreditCard,
  Loader2,
  Minus,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
} from 'lucide-react';
import { PLAN_CATALOG, PLANS, TRIAL_DAYS, formatEur, type PlanId } from '@/lib/plans';
import { EASE } from '@/components/Motion';
import { cn } from '@/lib/utils';

function buildReasons(freeTrialEnabled: boolean): Record<string, { title: string; body: string; tone: 'danger' | 'warn' | 'info' }> {
  return {
    'no-access': {
      title: 'Activa tu plan para entrar al panel',
      body: freeTrialEnabled
        ? `Elige el plan para tu negocio o tienda online y activa tus ${TRIAL_DAYS} días de prueba gratis con Stripe.`
        : 'Elige el plan para tu negocio o tienda online y activa tu suscripción con Stripe.',
      tone: 'info',
    },
    'trial-ended': {
      title: `Tu prueba de ${TRIAL_DAYS} días terminó`,
      body: 'No se completó el primer cobro, así que el acceso al panel quedó pausado. Reactívalo en 1 minuto: no pierdes ningún dato.',
      tone: 'danger',
    },
    'past-due': {
      title: 'Hay un pago pendiente',
      body: 'Stripe no pudo cobrar tu suscripción. Actualiza el método de pago o contrata de nuevo tu plan.',
      tone: 'warn',
    },
    canceled: {
      title: 'Plan cancelado',
      body: 'Puedes volver a activarlo cuando quieras; tus opiniones y ajustes siguen guardados.',
      tone: 'warn',
    },
    suspended: {
      title: 'Cuenta suspendida',
      body: 'Hemos pausado esta cuenta. Contacta con soporte para revisarlo.',
      tone: 'danger',
    },
  };
}

export function WelcomeClient({
  email,
  preselected,
  checkout,
  reason,
  alreadyActive,
  freeTrialEnabled = true,
}: {
  email: string;
  preselected: PlanId;
  checkout?: string;
  reason?: string;
  alreadyActive: boolean;
  freeTrialEnabled?: boolean;
}) {
  const [plan, setPlan] = useState<PlanId>(PLANS[preselected] ? preselected : 'local_starter');
  const [busy, setBusy] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const reasonsMap = buildReasons(freeTrialEnabled);
  const info = reason ? reasonsMap[reason] : null;

  const selected = PLANS[plan];

  async function start(targetPlan: PlanId = plan) {
    setPlan(targetPlan);
    setBusy(true);
    setCheckoutError(null);
    try {
      const res = await fetch(`/api/stripe/checkout?plan=${encodeURIComponent(targetPlan)}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ plan: targetPlan }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 401 && data?.loginUrl) {
          window.location.assign(data.loginUrl);
          return;
        }
        if (res.status === 409 && data?.redirect) {
          window.location.assign(data.redirect);
          return;
        }
        throw new Error(
          data?.error ??
            'No se pudo abrir la pasarela de pago de Stripe. Revisa STRIPE_SECRET_KEY en tu archivo .env.',
        );
      }
      if (data?.url) {
        window.location.assign(data.url);
        return;
      }
      window.location.assign(`/api/stripe/checkout?plan=${encodeURIComponent(targetPlan)}`);
    } catch (err: unknown) {
      setCheckoutError(
        err instanceof Error && err.message
          ? err.message
          : 'No se pudo abrir Stripe Checkout. Verifica tu clave STRIPE_SECRET_KEY en el archivo .env y reinicia npm run dev.',
      );
      setBusy(false);
    }
  }

  if (alreadyActive) {
    return (
      <main className="mx-auto max-w-xl px-4 py-20 text-center">
        <motion.div initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4, ease: EASE }}>
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl border border-emerald-400/30 bg-emerald-400/10 shadow-[0_0_40px_-16px_rgba(52,211,153,0.9)]">
            <BadgeCheck size={30} className="text-emerald-300" />
          </span>
          <h1 className="mt-6 text-balance text-3xl font-extrabold tracking-tighter text-white">
            ¡Tu cuenta ya está activa!
          </h1>
          <p className="mt-2 text-ink-300">
            Tu empresa está creada con la cuota de tu plan. Entra al panel y conecta Google para importar
            tus primeras opiniones.
          </p>
          <Link href="/dashboard" className="btn-primary btn-lg mt-7">
            Entrar al panel <ArrowRight size={17} />
          </Link>
        </motion.div>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-14">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: EASE }}
        className="text-center"
      >
        <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-sm text-ink-200">
          <Sparkles size={14} className="text-amber-300" />
          1 Plan = 1 Negocio o Local{freeTrialEnabled ? ` · ${TRIAL_DAYS} días de prueba gratis` : ' · Activación inmediata'}
        </span>
        <h1 className="mx-auto mt-5 max-w-2xl text-balance text-3xl font-extrabold tracking-tighter text-white sm:text-4xl">
          Elige tu plan{email ? `, ${email.split('@')[0]}` : ''}
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-ink-300">
          Cada suscripción cubre la gestión completa de 1 empresa o ubicación.{' '}
          {freeTrialEnabled
            ? `Prueba ${TRIAL_DAYS} días gratis y cancela en 1 clic sin permanencia.`
            : 'Sin permanencia: cancela en 1 clic cuando quieras.'}
        </p>
      </motion.div>

      {info && (
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn(
            'mx-auto mt-6 flex max-w-xl items-start gap-2.5 rounded-2xl border p-3.5 text-sm',
            info.tone === 'danger'
              ? 'border-rose-400/30 bg-rose-500/10 text-rose-100'
              : info.tone === 'warn'
                ? 'border-amber-400/30 bg-amber-400/10 text-amber-100'
                : 'border-brand-400/30 bg-brand-500/10 text-brand-100',
          )}
        >
          <TriangleAlert size={16} className="mt-0.5 shrink-0" />
          <span>
            <strong className="font-bold">{info.title}.</strong> {info.body}
          </span>
        </motion.p>
      )}

      {checkoutError && (
        <div
          role="alert"
          className="mx-auto mt-5 flex max-w-xl items-start gap-2.5 rounded-2xl border border-rose-400/35 bg-rose-500/10 p-4 text-sm text-rose-100"
        >
          <TriangleAlert size={17} className="mt-0.5 shrink-0 text-rose-300" />
          <div>
            <p className="font-bold text-white">No se pudo abrir la pasarela de pago</p>
            <p className="mt-0.5">{checkoutError}</p>
          </div>
        </div>
      )}

      {checkout === 'canceled' && (
        <p className="mx-auto mt-5 max-w-xl rounded-2xl border border-amber-400/25 bg-amber-400/10 p-3.5 text-center text-sm text-amber-100">
          Pago cancelado: no se ha creado ningún cargo. Elige plan cuando quieras.
        </p>
      )}
      {checkout === 'success' && !alreadyActive && (
        <p className="mx-auto mt-5 max-w-xl rounded-2xl border border-brand-400/35 bg-brand-500/10 p-3.5 text-center text-sm text-brand-100">
          Pago confirmado… estamos creando tu empresa (tarda unos segundos).{' '}
          <button onClick={() => window.location.reload()} className="font-bold underline underline-offset-2">
            Recargar
          </button>
        </p>
      )}

      <div className="mx-auto mt-9 grid max-w-4xl gap-4 lg:grid-cols-2">
        {PLAN_CATALOG.map((p) => {
          const active = plan === p.id;
          const featured = p.id === 'local_starter';
          return (
            <motion.div
              key={p.id}
              onClick={() => setPlan(p.id)}
              className={cn(
                'card relative flex cursor-pointer flex-col overflow-hidden p-6 text-left transition-all duration-300',
                active ? 'ring-gradient bg-brand-500/[0.09] shadow-glow' : 'hover:border-white/20',
              )}
            >
              {featured && (
                <span className="absolute right-4 top-4 rounded-full bg-[linear-gradient(120deg,#2563eb,#8b5cf6)] px-2.5 py-0.5 text-2xs font-bold uppercase tracking-wider text-white">
                  Recomendado
                </span>
              )}
              <div className={cn('flex flex-wrap items-center gap-2', featured && 'pr-28')}>
                <span className="badge-brand">{p.tier}</span>
                <span className="badge text-2xs">
                  {p.category === 'local' ? 'Negocio Físico' : 'Tienda Online'}
                </span>
                {freeTrialEnabled && (
                  <span className="badge-ok text-2xs">{TRIAL_DAYS} días gratis</span>
                )}
              </div>
              <p className="mt-3 text-base font-bold tracking-tightish text-white">{p.name}</p>
              <p className="mt-2 text-3xl font-extrabold tracking-tighter text-white">
                {formatEur(p.priceCents)}
                <span className="ml-1 text-sm font-medium text-ink-400">/mes</span>
              </p>
              <p className="mt-1 text-2xs font-semibold text-emerald-300/95">
                Incluye 1 negocio / ubicación completa
              </p>
              <p className="mt-1.5 text-xs text-ink-300">{p.pitch}</p>

              <ul className="mt-4 space-y-1.5 text-xs text-ink-300">
                <li className="flex items-center gap-2 font-semibold text-white">
                  <Check size={13} className="shrink-0 text-emerald-400" />
                  1 Negocio o Ubicación gestionada
                </li>
                <li className="flex items-center gap-2">
                  <Check size={13} className="shrink-0 text-emerald-400" />
                  {p.limits.requestsPerMonth.toLocaleString('es-ES')} peticiones/mes
                </li>
                <li className="flex items-center gap-2">
                  <Check size={13} className="shrink-0 text-emerald-400" />
                  {p.limits.reviewsPerMonth.toLocaleString('es-ES')} opiniones y{' '}
                  {p.limits.aiRepliesPerMonth.toLocaleString('es-ES')} respuestas IA/mes
                </li>
                <li className="flex items-center gap-2">
                  <Check size={13} className="shrink-0 text-emerald-400" />
                  {p.limits.reviewsStored.toLocaleString('es-ES')} opiniones guardadas
                </li>
                {[
                  ['googleBusiness', 'Google Business Profile'],
                  ['storeIntegration', 'Tienda (Shopify / Woo) al entregar'],
                  ['emailRequests', 'Email automático'],
                ].map(([key, label]) => {
                  const on = Boolean(p.features[key as keyof typeof p.features]);
                  return (
                    <li key={key} className="flex items-center gap-2">
                      {on ? (
                        <Check size={13} className="shrink-0 text-emerald-400" />
                      ) : (
                        <Minus size={13} className="shrink-0 text-ink-600" />
                      )}
                      <span className={on ? '' : 'text-ink-500'}>{label}</span>
                    </li>
                  );
                })}
              </ul>

              <button
                type="button"
                disabled={busy}
                onClick={(e) => {
                  e.stopPropagation();
                  start(p.id);
                }}
                className={cn(
                  'mt-5 w-full',
                  active ? 'btn-primary' : 'btn-secondary',
                )}
              >
                {busy && plan === p.id ? (
                  <>
                    <Loader2 size={15} className="animate-spin" /> Abriendo Stripe…
                  </>
                ) : (
                  <>
                    <CreditCard size={15} /> Contratar {p.tier}
                    {freeTrialEnabled ? ` (${TRIAL_DAYS} días gratis)` : ''}
                  </>
                )}
              </button>
            </motion.div>
          );
        })}
      </div>

      <div className="mx-auto mt-8 max-w-3xl text-center">
        <button onClick={() => start(plan)} disabled={busy} className="btn-primary btn-lg w-full sm:w-auto sm:px-14">
          {busy ? (
            <>
              <Loader2 size={17} className="animate-spin" /> Abriendo el pago seguro en Stripe…
            </>
          ) : (
            <>
              <CreditCard size={17} /> Continuar al pago en Stripe — {selected.name}
              {freeTrialEnabled ? ` (${TRIAL_DAYS} días gratis)` : ''}
            </>
          )}
        </button>
        <p className="mt-3.5 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-ink-400">
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck size={13} className="text-emerald-400" />
            {freeTrialEnabled
              ? `Pago seguro con Stripe · 0 € hoy durante los ${TRIAL_DAYS} días de prueba`
              : 'Pago seguro con Stripe · Activación inmediata y cancelación en 1 clic'}
          </span>
        </p>
      </div>
    </main>
  );
}
