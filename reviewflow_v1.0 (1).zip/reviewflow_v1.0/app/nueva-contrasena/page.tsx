import { pageMetadata } from '@/lib/seo';
import Link from 'next/link';
import { SetNewPasswordForm } from '@/components/auth/PasswordRecovery';
import { SITE } from '@/lib/site';

export const metadata = pageMetadata('Nueva contraseña', 'Establece una nueva contraseña para proteger tu cuenta de ReviewFlow AI.', undefined, false);

export default function Page() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-ink-950 px-4 text-ink-100">
      <div className="card w-full max-w-md p-6 sm:p-8">
        <Link href="/" className="text-sm font-bold text-white">{SITE.brand}</Link>
        <h1 className="mt-4 text-2xl font-extrabold text-white">Nueva contraseña</h1>
        <p className="mt-1 mb-6 text-sm text-ink-400">Elige una contraseña de al menos 8 caracteres.</p>
        <SetNewPasswordForm />
      </div>
    </main>
  );
}
