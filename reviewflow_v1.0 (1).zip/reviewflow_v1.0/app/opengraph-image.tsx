import { ImageResponse } from 'next/og';
import { SITE } from '@/lib/site';

export const runtime = 'nodejs';
export const alt = `${SITE.brand} — Gestiona y responde todas tus reseñas con IA`;
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          padding: '64px 72px',
          background: 'linear-gradient(135deg, #090D16 0%, #111827 55%, #1E1B4B 100%)',
          color: '#F8FAFC',
          fontFamily: 'sans-serif',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div
              style={{
                width: '54px',
                height: '54px',
                borderRadius: '16px',
                background: 'linear-gradient(135deg, #2563EB, #8B5CF6)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '22px',
                fontWeight: 800,
              }}
            >
              5.0
            </div>
            <span style={{ fontSize: '30px', fontWeight: 800, letterSpacing: '-0.02em' }}>
              {SITE.brand}
            </span>
          </div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              padding: '10px 20px',
              borderRadius: '999px',
              background: 'rgba(37, 99, 235, 0.22)',
              border: '1px solid rgba(96, 165, 250, 0.45)',
              color: '#93C5FD',
              fontSize: '18px',
              fontWeight: 700,
            }}
          >
            Google / Trustpilot / Shopify / WooCommerce
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px', maxWidth: '960px' }}>
          <div
            style={{
              fontSize: '64px',
              fontWeight: 900,
              lineHeight: 1.06,
              letterSpacing: '-0.03em',
            }}
          >
            Todas tus resenas respondidas con IA antes de que enfrien.
          </div>
          <div style={{ fontSize: '26px', color: '#CBD5E1', lineHeight: 1.4 }}>
            Memoria de marca, gestión privada de quejas, detector anti-spam y analitica frente a tu competencia.
          </div>
        </div>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderTop: '1px solid rgba(255,255,255,0.12)',
            paddingTop: '24px',
            fontSize: '20px',
            color: '#94A3B8',
          }}
        >
          <span>Datos alojados en la UE - RGPD Art. 15/17 - Dir. UE 2019/2161</span>
          <span style={{ color: '#34D399', fontWeight: 700 }}>7 dias de prueba - Sin permanencia</span>
        </div>
      </div>
    ),
    { ...size },
  );
}
