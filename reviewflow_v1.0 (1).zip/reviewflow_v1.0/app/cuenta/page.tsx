import { pageMetadata } from '@/lib/seo';
import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { BLOCKING_SUBSCRIPTION_STATUSES, normalizeEmailPrefs, type ActiveSubscription } from '@/lib/account';
import { resolveLocale } from '@/lib/i18n';
import { AccountClient } from './account-client';

export const dynamic = 'force-dynamic';
export const metadata = pageMetadata('Mi cuenta', 'Gestiona tu perfil y los ajustes privados de acceso a ReviewFlow AI.', undefined, false);

export default async function AccountPage({ searchParams }: { searchParams: Promise<{ email?: string }> }) {
  const user = await getSessionUser();
  if (!user) redirect('/login?redirect=/cuenta');
  const sp = await searchParams;

  const supabase = await createClient();
  const { data: profile } = await supabase
    .from('user_profiles')
    .select('full_name, phone, locale, email_prefs')
    .eq('user_id', user.id)
    .maybeSingle();

  const db = createAdminClient() ?? supabase;
  const { data: owned } = await db
    .from('tenants')
    .select('id, name, subscription_status')
    .eq('owner_id', user.id);

  const activeSubscriptions: ActiveSubscription[] = (owned ?? [])
    .filter((t) => BLOCKING_SUBSCRIPTION_STATUSES.includes(String(t.subscription_status)))
    .map((t) => ({ tenantId: t.id, name: t.name, status: t.subscription_status }));

  return (
    <AccountClient
      email={user.email ?? ''}
      pendingEmail={(user as { new_email?: string }).new_email ?? null}
      emailConfirmed={sp.email === 'confirmed'}
      initialProfile={{
        fullName: profile?.full_name ?? (user.user_metadata?.full_name as string | undefined) ?? '',
        phone: profile?.phone ?? '',
        locale: resolveLocale(profile?.locale),
        emailPrefs: normalizeEmailPrefs(profile?.email_prefs),
      }}
      activeSubscriptions={activeSubscriptions}
    />
  );
}
