'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, KeyRound, Mail, Bell, Trash2, UserRound } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { browserOrigin } from '@/lib/public-url';
import { SUPPORTED_LOCALES, type SupportedLocale } from '@/lib/i18n';
import type { ActiveSubscription, EmailPrefKey, EmailPrefs } from '@/lib/account';

type Profile = { fullName: string; phone: string; locale: SupportedLocale; emailPrefs: EmailPrefs };
type Msg = { kind: 'ok' | 'error'; text: string } | null;

const PREF_LABELS: Record<EmailPrefKey, { title: string; desc: string }> = {
  weekly_digest: { title: 'Resumen semanal', desc: 'Tus opiniones y respuestas de la última semana, cada lunes.' },
  review_alerts: { title: 'Avisos de opiniones nuevas', desc: 'Te avisamos cuando llega una opinión negativa o que necesita respuesta.' },
};

const STATUS_LABEL: Record<string, string> = {
  active: 'activa',
  trialing: 'en periodo de prueba',
  past_due: 'con pago pendiente',
  paused: 'en pausa',
};

function Notice({ msg }: { msg: Msg }) {
  if (!msg) return null;
  return (
    <p role="status" className={`mt-3 text-sm ${msg.kind === 'ok' ? 'text-emerald-400' : 'text-red-400'}`}>
      {msg.text}
    </p>
  );
}

function Section({ icon, title, desc, children, danger }: {
  icon: React.ReactNode; title: string; desc: string; children: React.ReactNode; danger?: boolean;
}) {
  return (
    <section className={`card p-6 sm:p-7 ${danger ? 'border-red-500/30' : ''}`}>
      <div className="mb-5 flex items-start gap-3">
        <span className={`mt-0.5 ${danger ? 'text-red-400' : 'text-brand-300'}`}>{icon}</span>
        <div>
          <h2 className="font-display text-lg font-bold text-white">{title}</h2>
          <p className="text-sm text-ink-400">{desc}</p>
        </div>
      </div>
      {children}
    </section>
  );
}

async function putProfile(p: Profile) {
  const res = await fetch('/api/account/profile', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(p),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? 'No se pudo guardar.');
}

export function AccountClient({ email, pendingEmail, emailConfirmed, initialProfile, activeSubscriptions }: {
  email: string;
  pendingEmail: string | null;
  emailConfirmed: boolean;
  initialProfile: Profile;
  activeSubscriptions: ActiveSubscription[];
}) {
  const [profile, setProfile] = useState<Profile>(initialProfile);
  const [profileMsg, setProfileMsg] = useState<Msg>(null);
  const [savingProfile, setSavingProfile] = useState(false);

  const [newEmail, setNewEmail] = useState('');
  const [emailMsg, setEmailMsg] = useState<Msg>(
    emailConfirmed ? { kind: 'ok', text: 'Email confirmado correctamente.' } : null,
  );
  const [sendingEmail, setSendingEmail] = useState(false);

  const [pw, setPw] = useState({ current: '', next: '', repeat: '' });
  const [pwMsg, setPwMsg] = useState<Msg>(null);
  const [savingPw, setSavingPw] = useState(false);

  const [prefsMsg, setPrefsMsg] = useState<Msg>(null);

  const [confirmText, setConfirmText] = useState('');
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteMsg, setDeleteMsg] = useState<Msg>(null);
  const [deleting, setDeleting] = useState(false);
  const [blocking, setBlocking] = useState<ActiveSubscription[]>(activeSubscriptions);

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    setSavingProfile(true);
    setProfileMsg(null);
    try {
      await putProfile(profile);
      setProfileMsg({ kind: 'ok', text: 'Perfil guardado.' });
      if (profile.locale !== initialProfile.locale) {
        const v = profile.locale === 'es' ? '' : `/es/${profile.locale}`;
        document.cookie = v ? `googtrans=${v}; path=/; max-age=31536000` : 'googtrans=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
        window.location.reload();
      }
    } catch (err) {
      setProfileMsg({ kind: 'error', text: (err as Error).message });
    } finally {
      setSavingProfile(false);
    }
  }

  async function changeEmail(e: React.FormEvent) {
    e.preventDefault();
    const target = newEmail.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(target)) {
      setEmailMsg({ kind: 'error', text: 'Escribe un email válido.' });
      return;
    }
    if (target === email.toLowerCase()) {
      setEmailMsg({ kind: 'error', text: 'Ese ya es tu email actual.' });
      return;
    }
    setSendingEmail(true);
    setEmailMsg(null);
    const supabase = createClient();
    const { error } = await supabase.auth.updateUser(
      { email: target },
      { emailRedirectTo: `${browserOrigin()}/auth/callback?next=${encodeURIComponent('/cuenta?email=confirmed')}` },
    );
    setSendingEmail(false);
    if (error) {
      setEmailMsg({ kind: 'error', text: 'No se pudo solicitar el cambio. Puede que ese email ya esté en uso.' });
      return;
    }
    setNewEmail('');
    setEmailMsg({
      kind: 'ok',
      text: `Te hemos enviado un correo de confirmación a ${target}. El cambio se aplicará cuando pulses el enlace.`,
    });
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pw.next.length < 8) return setPwMsg({ kind: 'error', text: 'La nueva contraseña debe tener al menos 8 caracteres.' });
    if (pw.next !== pw.repeat) return setPwMsg({ kind: 'error', text: 'Las contraseñas nuevas no coinciden.' });
    setSavingPw(true);
    setPwMsg(null);
    const res = await fetch('/api/account/password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPassword: pw.current, newPassword: pw.next }),
    });
    const data = await res.json().catch(() => ({}));
    setSavingPw(false);
    if (!res.ok) return setPwMsg({ kind: 'error', text: data.error ?? 'No se pudo cambiar la contraseña.' });
    setPw({ current: '', next: '', repeat: '' });
    setPwMsg({ kind: 'ok', text: 'Contraseña cambiada.' });
  }

  async function togglePref(key: EmailPrefKey) {
    const next = { ...profile, emailPrefs: { ...profile.emailPrefs, [key]: !profile.emailPrefs[key] } };
    const prev = profile;
    setProfile(next);
    setPrefsMsg(null);
    try {
      await putProfile(next);
      setPrefsMsg({ kind: 'ok', text: 'Preferencias guardadas.' });
    } catch (err) {
      setProfile(prev);
      setPrefsMsg({ kind: 'error', text: (err as Error).message });
    }
  }

  async function deleteAccount(e: React.FormEvent) {
    e.preventDefault();
    setDeleting(true);
    setDeleteMsg(null);
    const res = await fetch('/api/account/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ confirmationText: confirmText, password: deletePassword }),
    });
    const data = await res.json().catch(() => ({}));
    setDeleting(false);
    if (res.status === 409 && data.code === 'active_subscription') {
      setBlocking(data.subscriptions ?? []);
      return;
    }
    if (!res.ok) return setDeleteMsg({ kind: 'error', text: data.error ?? 'No se pudo eliminar la cuenta.' });
    window.location.href = '/?cuenta=eliminada';
  }

  return (
    <main className="min-h-screen bg-ink-950 px-4 py-10 text-ink-100">
      <div className="mx-auto max-w-2xl space-y-6">
        <div>
          <Link href="/dashboard" className="inline-flex items-center gap-1.5 text-sm text-ink-400 transition hover:text-white">
            <ArrowLeft size={14} /> Volver al panel
          </Link>
          <h1 className="mt-4 font-display text-3xl font-extrabold tracking-tightish text-white">Mi cuenta</h1>
          <p className="mt-1 text-sm text-ink-400">{email}</p>
        </div>

        <Section icon={<UserRound size={18} />} title="Perfil" desc="Tus datos personales y el idioma del panel.">
          <form onSubmit={saveProfile} className="space-y-4">
            <div>
              <label className="label" htmlFor="fullName">Nombre</label>
              <input id="fullName" className="input" maxLength={120} value={profile.fullName}
                onChange={(e) => setProfile({ ...profile, fullName: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="phone">Teléfono</label>
              <input id="phone" className="input" type="tel" maxLength={30} placeholder="+34 600 000 000" value={profile.phone}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })} />
            </div>
            <div>
              <label className="label" htmlFor="locale">Idioma</label>
              <select id="locale" className="input" value={profile.locale}
                onChange={(e) => setProfile({ ...profile, locale: e.target.value as SupportedLocale })}>
                {SUPPORTED_LOCALES.map((l) => (
                  <option key={l.code} value={l.code}>{l.nativeName}</option>
                ))}
              </select>
            </div>
            <button type="submit" className="btn-primary btn-sm" disabled={savingProfile}>
              {savingProfile ? 'Guardando…' : 'Guardar perfil'}
            </button>
            <Notice msg={profileMsg} />
          </form>
        </Section>

        <Section icon={<Mail size={18} />} title="Email" desc="Te enviaremos un correo al nuevo email para confirmar el cambio.">
          {pendingEmail && (
            <p className="mb-4 rounded-lg border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-sm text-amber-200">
              Cambio pendiente de confirmar: {pendingEmail}
            </p>
          )}
          <form onSubmit={changeEmail} className="space-y-4">
            <div>
              <label className="label" htmlFor="newEmail">Nuevo email</label>
              <input id="newEmail" className="input" type="email" autoComplete="email" required maxLength={255}
                value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
            </div>
            <button type="submit" className="btn-secondary btn-sm" disabled={sendingEmail}>
              {sendingEmail ? 'Enviando…' : 'Enviar correo de confirmación'}
            </button>
            <Notice msg={emailMsg} />
          </form>
        </Section>

        <Section icon={<KeyRound size={18} />} title="Contraseña" desc="Por seguridad, primero te pedimos la contraseña actual.">
          <form onSubmit={changePassword} className="space-y-4">
            <div>
              <label className="label" htmlFor="pwCurrent">Contraseña actual</label>
              <input id="pwCurrent" className="input" type="password" autoComplete="current-password" required
                value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label" htmlFor="pwNext">Nueva contraseña</label>
                <input id="pwNext" className="input" type="password" autoComplete="new-password" required minLength={8}
                  value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
              </div>
              <div>
                <label className="label" htmlFor="pwRepeat">Repite la nueva</label>
                <input id="pwRepeat" className="input" type="password" autoComplete="new-password" required minLength={8}
                  value={pw.repeat} onChange={(e) => setPw({ ...pw, repeat: e.target.value })} />
              </div>
            </div>
            <button type="submit" className="btn-secondary btn-sm" disabled={savingPw}>
              {savingPw ? 'Cambiando…' : 'Cambiar contraseña'}
            </button>
            <Notice msg={pwMsg} />
          </form>
        </Section>

        <Section icon={<Bell size={18} />} title="Emails que recibes" desc="Los correos de facturación y seguridad se envían siempre.">
          <ul className="divide-y divide-white/[0.06]">
            {(Object.keys(PREF_LABELS) as EmailPrefKey[]).map((key) => (
              <li key={key} className="flex items-center justify-between gap-4 py-3">
                <div>
                  <p className="text-sm font-semibold text-white">{PREF_LABELS[key].title}</p>
                  <p className="text-xs text-ink-400">{PREF_LABELS[key].desc}</p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={profile.emailPrefs[key]}
                  aria-label={PREF_LABELS[key].title}
                  onClick={() => togglePref(key)}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${profile.emailPrefs[key] ? 'bg-brand-500' : 'bg-white/15'}`}
                >
                  <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${profile.emailPrefs[key] ? 'left-[22px]' : 'left-0.5'}`} />
                </button>
              </li>
            ))}
          </ul>
          <Notice msg={prefsMsg} />
        </Section>

        <Section danger icon={<Trash2 size={18} />} title="Eliminar cuenta" desc="Se borrarán tu cuenta y los negocios de los que eres propietario. No se puede deshacer.">
          {blocking.length > 0 ? (
            <div className="space-y-4">
              <p className="text-sm text-ink-200">
                Todavía tienes una suscripción activa. Para eliminar la cuenta, primero tienes que darte de baja:
              </p>
              <ul className="list-disc space-y-1 pl-5 text-sm text-ink-300">
                {blocking.map((s) => (
                  <li key={s.tenantId}>
                    <strong className="text-white">{s.name}</strong> — suscripción {STATUS_LABEL[s.status] ?? s.status}
                  </li>
                ))}
              </ul>
              <Link href="/dashboard?tab=facturacion" className="btn-secondary btn-sm">
                Ir a Facturación para darme de baja
              </Link>
            </div>
          ) : (
            <form onSubmit={deleteAccount} className="space-y-4">
              <div>
                <label className="label" htmlFor="confirmDelete">Escribe ELIMINAR para confirmar</label>
                <input id="confirmDelete" className="input" autoComplete="off" value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)} />
              </div>
              <div>
                <label className="label" htmlFor="deletePassword">Tu contraseña actual</label>
                <input id="deletePassword" type="password" className="input" autoComplete="current-password"
                  value={deletePassword} onChange={(e) => setDeletePassword(e.target.value)} />
              </div>
              <button type="submit" className="btn-danger btn-sm" disabled={confirmText !== 'ELIMINAR' || !deletePassword || deleting}>
                {deleting ? 'Eliminando…' : 'Eliminar mi cuenta para siempre'}
              </button>
              <Notice msg={deleteMsg} />
            </form>
          )}
        </Section>
      </div>
    </main>
  );
}
