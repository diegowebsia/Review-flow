import { pageMetadata } from '@/lib/seo';
import { notFound } from 'next/navigation';
import { createAdminClient } from '@/lib/supabase/admin';
import { isTrialExpired } from '@/lib/plans';
import FunnelClient from './funnel-client';
import { normalizeCampaign } from '@/lib/campaign';

export const dynamic = 'force-dynamic';

/* Página privada de cada negocio para sus clientes: no debe salir en Google. */
export const metadata = pageMetadata('Valora tu experiencia', 'Comparte tu valoración con el negocio y consulta sus opciones de opinión y atención al cliente.', undefined, false);

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ campaign?: string }> };

/**
 * Flujo Neutral de Valoración (página pública del negocio).
 * Solo expone datos seguros (nombre + slug); los enlaces públicos salen
 * tras cualquier puntuación; los mensajes de soporte opcionales nunca se publican.
 */
export default async function ValorarPage({ params, searchParams }: Props) {
  const [{ slug }, query] = await Promise.all([params, searchParams]);
  const campaign = normalizeCampaign(query.campaign);

  const admin = createAdminClient();
  if (!admin) {
    notFound();
  }

  const { data: rawTenant } = await admin
    .from('tenants')
    .select('id, name, slug, plan, subscription_status, suspended, trial_ends_at, settings')
    .eq('slug', slug)
    .single();

  type ValorarTenantRow = {
    id: string;
    name: string;
    slug: string;
    plan: string;
    subscription_status: string;
    suspended?: boolean;
    trial_ends_at?: string | null;
    settings?: {
      funnel_enabled?: boolean;
      place_id?: string | null;
      tripadvisor_url?: string | null;
      trustpilot_url?: string | null;
    } | null;
  };

  const tenant = rawTenant as ValorarTenantRow | null;
  const settings = tenant?.settings ?? {};
  const usable =
    tenant &&
    !tenant.suspended &&
    (tenant.subscription_status === 'active' || tenant.subscription_status === 'trialing') &&
    !isTrialExpired(tenant.subscription_status, tenant.trial_ends_at) &&
    settings.funnel_enabled !== false;

  if (!usable || !tenant) notFound();

  return (
    <FunnelClient
      slug={tenant.slug}
      businessName={tenant.name}
      campaign={campaign}
      hasGoogle={Boolean(settings.place_id)}
      hasTripadvisor={Boolean(settings.tripadvisor_url)}
      hasTrustpilot={Boolean(settings.trustpilot_url)}
    />
  );
}
