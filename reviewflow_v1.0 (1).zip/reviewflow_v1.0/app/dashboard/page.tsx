import { pageMetadata } from '@/lib/seo';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { getSessionUser } from '@/lib/auth';
import { createAdminClient } from '@/lib/supabase/admin';
import { createClient } from '@/lib/supabase/server';
import { isSupabaseConfigured } from '@/lib/env';
import { currentCycle, hasAccess, isTrialExpired, resolveAddonPack, type AddonPack } from '@/lib/plans';
import { getStripe } from '@/lib/stripe';
import { normalizeRole } from '@/lib/authz';
import { getFreeTrialEnabled } from '@/lib/system-settings';
import { DashboardClient, type TenantInfo } from './dashboard-client';
import type { ReviewItem } from '@/components/dashboard/types';

export const dynamic = 'force-dynamic';
export const metadata = pageMetadata('Panel de opiniones', 'Panel privado de ReviewFlow AI para gestionar opiniones, respuestas y conexiones de tu empresa.', undefined, false);

async function syncAddonSessionOnReturn(
  admin: NonNullable<ReturnType<typeof createAdminClient>>,
  userId: string,
  sessionId: string,
): Promise<void> {
  const stripe = getStripe();
  if (!stripe || !sessionId) return;
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    if (session.payment_status !== 'paid') return;
    if (session.mode !== 'payment' && session.metadata?.type !== 'addon') return;

    const tenantId = session.metadata?.tenantId || session.client_reference_id;
    if (!tenantId) return;

    const { data: tenant } = await admin
      .from('tenants')
      .select('id, owner_id, extra_requests, extra_reviews, extra_ai, extra_syncs, extra_stored, extra_quota_cycle')
      .eq('id', tenantId)
      .maybeSingle();
    if (!tenant?.id) return;

    if (tenant.owner_id !== userId) {
      const { data: member } = await admin
        .from('memberships')
        .select('tenant_id')
        .eq('tenant_id', tenantId)
        .eq('user_id', userId)
        .maybeSingle();
      if (!member) return;
    }

    const items: Array<{ pack: AddonPack; quantity: number }> = [];
    try {
      const raw = session.metadata?.addons;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          for (const entry of parsed) {
            const pack = resolveAddonPack(entry?.key);
            const quantity = Math.max(1, Math.min(10, Number(entry?.quantity) || 1));
            if (pack) items.push({ pack, quantity });
          }
        }
      }
    } catch {
      /* ignore malformed metadata */
    }
    if (items.length === 0) return;

    const cycle = session.metadata?.cycle || currentCycle();
    const totals = { requests: 0, reviews: 0, ai: 0, syncs: 0, units: 0 };
    for (const { pack, quantity } of items) {
      totals.units += quantity;
      totals[pack.metric] += pack.amount * quantity;
    }

    const unitCents =
      session.amount_total && session.amount_total > 0 && totals.units > 0
        ? Math.round(session.amount_total / totals.units)
        : null;

    const rows = items.map(({ pack, quantity }) => ({
      pack: pack.id,
      events: pack.metric === 'syncs' ? pack.amount * quantity : 0,
      reviews: pack.metric === 'reviews' ? pack.amount * quantity : 0,
      ai: pack.metric === 'ai' ? pack.amount * quantity : 0,
      whatsapp: pack.metric === 'requests' ? pack.amount * quantity : 0,
      quantity,
    }));

    const { error: rpcError } = await admin.rpc('apply_addon_purchase', {
      p_tenant_id: tenantId,
      p_payment_id: session.id,
      p_invoice_id: (session.invoice as string | null) ?? null,
      p_cycle: cycle,
      p_total_cents: unitCents,
      p_items: rows,
      p_requests: totals.requests,
      p_reviews: totals.reviews,
      p_ai: totals.ai,
      p_syncs: totals.syncs,
    });

    if (rpcError) {
      // Fallback directo si la función RPC no está instalada en una BD antigua
      const sameCycle = tenant.extra_quota_cycle === cycle;
      await admin
        .from('tenants')
        .update({
          extra_requests: (sameCycle ? Number(tenant.extra_requests ?? 0) : 0) + totals.requests,
          extra_reviews: (sameCycle ? Number(tenant.extra_reviews ?? 0) : 0) + totals.reviews,
          extra_ai: (sameCycle ? Number(tenant.extra_ai ?? 0) : 0) + totals.ai,
          extra_syncs: (sameCycle ? Number(tenant.extra_syncs ?? 0) : 0) + totals.syncs,
          extra_stored: (sameCycle ? Number(tenant.extra_stored ?? 0) : 0) + totals.reviews,
          extra_quota_cycle: cycle,
        })
        .eq('id', tenantId);
    }
  } catch {
    /* Si falla la verificación puntual, el webhook lo procesará en segundo plano */
  }
}

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ tab?: string; addon?: string; pack?: string; session_id?: string; empresa?: string; nueva?: string }>;
}) {
  const sp = await searchParams;
  const tab =
    sp.tab === 'facturacion' || sp.tab === 'empresa' || sp.tab === 'embudo' || sp.tab === 'equipo'
      ? sp.tab
      : sp.addon
        ? 'facturacion'
        : 'bandeja';
  const addonResult =
    sp.addon === 'success' ? 'success' : sp.addon === 'canceled' ? 'canceled' : null;

  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-ink-950 px-4 text-ink-100">
        <div className="card max-w-lg space-y-4 p-8 text-center">
          <h1 className="text-2xl font-extrabold text-white">Base de datos pendiente de conexión</h1>
          <p className="text-sm text-ink-300">
            Configura <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-xs">NEXT_PUBLIC_SUPABASE_URL</code>,{' '}
            <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-xs">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> y{' '}
            <code className="rounded bg-white/10 px-1.5 py-0.5 font-mono text-xs">SUPABASE_SERVICE_ROLE_KEY</code> en tus variables
            de entorno siguiendo las guías del proyecto para acceder al panel.
          </p>
          <div className="pt-2">
            <Link href="/" className="btn-secondary btn-sm">
              Volver al inicio
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const user = await getSessionUser();
  if (!user) {
    redirect('/login?redirect=/dashboard');
  }

  let tenants: TenantInfo[] = [];
  let reviews: ReviewItem[] = [];
  let hasSubscriptionWithAccess = false;
  let hasAnyTenant = false;

  const admin = createAdminClient();
  const db = admin ?? (await createClient());

  if (admin && addonResult === 'success' && sp.session_id) {
    await syncAddonSessionOnReturn(admin, user.id, sp.session_id);
  }

  try {
    const { data: memberships } = await db
      .from('memberships')
      .select(
        'tenant_id, role, tenants(id, name, slug, owner_id, plan, subscription_status, suspended, trial_ends_at, grace_period_ends_at, settings, api_key)',
      )
      .eq('user_id', user.id);

    type DashboardTenantRow = {
      id: string;
      name: string;
      slug: string;
      plan: string;
      subscription_status: string;
      suspended: boolean;
      trial_ends_at: string | null;
      grace_period_ends_at?: string | null;
      settings: TenantInfo['settings'] | null;
      api_key: string | null;
      owner_id?: string | null;
      my_role?: string | null;
    };
    type DashboardMembershipRow = {
      tenant_id: string;
      role?: string | null;
      tenants?: DashboardTenantRow | null;
    };

    let list: DashboardTenantRow[] = ((memberships ?? []) as unknown as DashboardMembershipRow[])
      // Un empleado del equipo ve la empresa aunque no sea el dueño; su rol viaja con ella.
      .map((m): DashboardTenantRow | null => (m.tenants ? { ...m.tenants, my_role: m.role ?? null } : null))
      .filter((t): t is DashboardTenantRow => Boolean(t));

    // Si es propietario directo en `tenants` pero faltaba fila en `memberships`, lo recuperamos
    if (list.length === 0 && admin) {
      const { data: owned } = await admin
        .from('tenants')
        .select('id, name, slug, plan, subscription_status, suspended, trial_ends_at, grace_period_ends_at, settings, api_key, owner_id')
        .eq('owner_id', user.id);
      const ownedRows = (owned ?? []) as DashboardTenantRow[];
      if (ownedRows.length > 0) {
        list = ownedRows;
        for (const t of ownedRows) {
          await admin
            .from('memberships')
            .upsert({ tenant_id: t.id, user_id: user.id, role: 'owner' }, { onConflict: 'tenant_id,user_id' });
        }
      }
    }

    hasAnyTenant = list.length > 0;

    const integMap: Record<
      string,
      Array<{ provider: string; status: string; last_sync_at: string | null }>
    > = {};
    if (list.length > 0 && admin) {
      const { data: integs } = await admin
        .from('integrations')
        .select('tenant_id, provider, status, last_sync_at')
        .in(
          'tenant_id',
          list.map((t) => t.id),
        );
      for (const i of integs ?? []) {
        (integMap[i.tenant_id] ??= []).push({
          provider: i.provider,
          status: i.status,
          last_sync_at: i.last_sync_at,
        });
      }
    }

    tenants = list.map((t) => ({
      id: t.id,
      name: t.name,
      slug: t.slug,
      plan: t.plan,
      subscription_status: t.subscription_status,
      suspended: t.suspended,
      trial_ends_at: t.trial_ends_at,
      access:
        hasAccess(t.subscription_status, t.suspended, t.grace_period_ends_at ?? null) &&
        !isTrialExpired(t.subscription_status, t.trial_ends_at),
      settings: (t.settings as TenantInfo['settings']) ?? {},
      api_key: t.api_key ?? null,
      integrations: integMap[t.id] ?? [],
      my_role: t.owner_id === user.id ? 'owner' : normalizeRole(t.my_role),
    }));
    // Multipanel: la empresa elegida (?empresa=ID) va primero y todo el panel trabaja con ella.
    const chosen = tenants.find((t) => t.id === sp.empresa);
    if (chosen) tenants = [chosen, ...tenants.filter((t) => t.id !== chosen.id)];
    hasSubscriptionWithAccess = Boolean(tenants[0]?.access);

    const accessibleIds = tenants[0]?.access ? [tenants[0].id] : [];
    if (accessibleIds.length > 0) {
      type DashboardReviewRow = {
        id: string;
        tenant_id: string;
        author_name: string;
        rating: number;
        text: string;
        source: string;
        created_at: string;
        reply_text: string | null;
        is_verified: boolean | null;
        flagged_private: boolean | null;
        private_note: string | null;
        tenants?: { name?: string | null } | null;
      };
      const { data: revs } = await db
        .from('reviews')
        .select(
          'id, tenant_id, author_name, rating, text, source, created_at, reply_text, is_verified, flagged_private, private_note, tenants(name)',
        )
        .in('tenant_id', accessibleIds)
        .order('created_at', { ascending: false })
        .limit(50);
      reviews = ((revs ?? []) as unknown as DashboardReviewRow[]).map((r) => ({
        id: r.id,
        tenant: r.tenants?.name ?? tenants.find((t) => t.id === r.tenant_id)?.name ?? '',
        tenant_id: r.tenant_id,
        author: r.author_name,
        rating: r.rating,
        text: r.text,
        source: r.source as ReviewItem['source'],
        created_at: r.created_at,
        replied: Boolean(r.reply_text),
        verified: Boolean(r.is_verified),
        flagged_private: Boolean(r.flagged_private),
        private_note: r.private_note ?? null,
        reply: r.reply_text ?? null,
      }));
    }
  } catch {
    reviews = [];
  }

  // Regla comercial: si el usuario se acaba de registrar / iniciar sesión y todavía no tiene
  // empresa contratada, lo llevamos directamente a elegir y pagar su plan en /bienvenido.
  if (!hasAnyTenant) {
    redirect('/bienvenido?reason=no-access');
  }

  const freeTrialEnabled = await getFreeTrialEnabled();

  return (
    <DashboardClient
      tenants={tenants}
      reviews={reviews}
      userEmail={user.email ?? ''}
      hasAccess={hasSubscriptionWithAccess}
      hasAnyTenant={hasAnyTenant}
      tab={tab as 'bandeja' | 'empresa' | 'embudo' | 'equipo' | 'facturacion'}
      addonResult={addonResult}
      freeTrialEnabled={freeTrialEnabled}
      newBusinessResult={sp.nueva === 'cancelada' ? 'canceled' : null}
    />
  );
}
