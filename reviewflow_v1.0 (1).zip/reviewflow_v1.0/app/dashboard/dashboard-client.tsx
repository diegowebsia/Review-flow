'use client';

import dynamic from 'next/dynamic';
import Link from 'next/link';
import { AnimatePresence, motion } from 'framer-motion';
import {
  BarChart3,
  Building2,
  CreditCard,
  Filter,
  Inbox,
  Sparkles, Users,
} from 'lucide-react';
import { ReviewListSkeleton, StatSkeleton, TableSkeleton } from '@/components/Skeleton';
import { HelpCenter } from '@/components/HelpCenter';
import { EASE } from '@/components/Motion';
import {
  ContextualPaywallCard,
  OnboardingChecklist,
  SupportImpersonationBanner,
  TrialAndGraceBanner,
} from '@/components/dashboard/LifecycleAndAnalytics';
import { DashboardReviewsSection } from '@/components/dashboard/DashboardReviewsSection';
import { DashboardCompaniesSection } from '@/components/dashboard/DashboardCompaniesSection';
import { DashboardStepGuide } from '@/components/dashboard/DashboardStepGuide';
import {
  DashboardBottomNavAndFooter,
  DashboardSidebar,
  DashboardTopHeader,
} from '@/components/dashboard/DashboardHeaderAndNav';
import {
  useDashboardState,
  type DashboardTabId,
} from '@/components/dashboard/use-dashboard-state';
import type { ReviewItem, TenantInfo } from '@/components/dashboard/types';
import { TRIAL_DAYS } from '@/lib/plans';
import { SupportChat } from '@/components/dashboard/SupportChat';
const AnalyticsAndCompetitorsPanel = dynamic(
  () =>
    import('@/components/dashboard/LifecycleAndAnalytics').then(
      (m) => m.AnalyticsAndCompetitorsPanel,
    ),
  { ssr: false, loading: () => <TableSkeleton rows={4} cols={3} /> },
);
const FunnelPanel = dynamic(
  () => import('@/components/dashboard/FunnelPanel').then((m) => m.FunnelPanel),
  { ssr: false, loading: () => <TableSkeleton rows={3} cols={2} /> },
);
const TeamPanel = dynamic(() => import('@/components/dashboard/TeamPanel').then((m) => m.TeamPanel), { ssr: false });
const BillingPanel = dynamic(
  () => import('@/components/dashboard/BillingPanel').then((m) => m.BillingPanel),
  { ssr: false, loading: () => <TableSkeleton rows={4} cols={3} /> },
);
export type { TenantInfo };
type TabId = DashboardTabId;
export function DashboardClient({
  tenants,
  reviews: initialReviews,
  userEmail,
  hasAccess,
  hasAnyTenant,
  tab: initialTab = 'bandeja',
  addonResult,
  freeTrialEnabled = true,
  newBusinessResult = null,
}: {
  tenants: TenantInfo[];
  reviews: ReviewItem[];
  userEmail: string;
  hasAccess: boolean;
  hasAnyTenant: boolean;
  tab?: TabId;
  addonResult?: 'success' | 'canceled' | null;
  freeTrialEnabled?: boolean;
  newBusinessResult?: 'canceled' | null;
}) {

  const {
    tab, setTab, reviews, filter, setFilter, onlyPending, setOnlyPending,
    filtered, paginatedReviews, reviewPage, setReviewPage, reviewTotalPages,
    flagged, stats, drafts, setDrafts, publishedIds, setPublishedIds,
    showWizard, setShowWizard, syncing, hydrated, helpOpen, setHelpOpen,
    showAddReview, setShowAddReview, newAuthor, setNewAuthor, newRating,
    setNewRating, newSource, setNewSource, newText, setNewText, creatingReview,
    toneFor, loadSampleReviews, handleCreateReview, sync,
  } = useDashboardState({ tenants, initialReviews, initialTab, addonResult });

  const TABS: Array<{ id: TabId; label: string; icon: React.ReactNode }> = [
    { id: 'bandeja', label: "Bandeja", icon: <Inbox size={15} /> },
    { id: 'analitica', label: "Analítica y Competencia", icon: <BarChart3 size={15} /> },
    { id: 'empresa', label: "Empresa y conexiones", icon: <Building2 size={15} /> },
    { id: 'embudo', label: "Embudo", icon: <Filter size={15} /> },
    { id: 'equipo', label: "Equipo", icon: <Users size={15} /> },
    { id: 'facturacion', label: "Facturación y cuota", icon: <CreditCard size={15} /> },
  ];
  const primaryTenant = tenants[0];

  return (
    <div className="relative min-h-screen bg-ink-950 pb-20 text-ink-100 md:pb-0 md:pl-60">
      <DashboardSidebar tab={tab} setTab={setTab} tabs={TABS} />
      <DashboardTopHeader
        userEmail={userEmail}
        primaryTenant={primaryTenant}
        tenants={tenants}
        onOpenHelp={() => setHelpOpen(true)}
        onOpenConnections={() => setTab('empresa')}
      />

      <main className="relative mx-auto max-w-5xl space-y-5 px-4 py-8 sm:px-6">
        <div
          className="pointer-events-none absolute inset-x-0 -top-8 -z-10 h-64 bg-[radial-gradient(50%_60%_at_50%_0%,rgba(37,99,235,0.12),transparent_70%)]"
          aria-hidden="true"
        />

        {/* Sin suscripción y sin empresa → activar prueba */}
        {!hasAccess && !hasAnyTenant && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="card ring-gradient relative overflow-hidden p-9 text-center"
          >
            <div
              className="pointer-events-none absolute -top-24 left-1/2 h-56 w-[34rem] -translate-x-1/2 rounded-full bg-brand-600/25 blur-[100px]"
              aria-hidden="true"
            />
            <div className="relative">
              <span className="mx-auto inline-flex items-center gap-1.5 text-xs font-semibold text-brand-300">
                <Sparkles size={12} /> Paso 2 de 2
              </span>
              <h1 className="mt-4 text-balance text-3xl font-extrabold tracking-tighter text-white">
                Elige tu plan y empieza
              </h1>
              <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-ink-300">
                {freeTrialEnabled
                  ? `Tu cuenta ya está creada. Elige tu plan con ${TRIAL_DAYS} días de prueba gratis: tu empresa se activa al instante.`
                  : 'Tu cuenta ya está creada. Elige el plan para tu negocio o tienda online: tu empresa se activa al instante tras el pago.'}
              </p>
              <Link href="/bienvenido" className="btn-primary btn-lg mt-6">
                <CreditCard size={17} /> Elegir plan y empezar
              </Link>
            </div>
          </motion.div>
        )}

        {/* Banner de Impersonación de Soporte y Banner de Trial / Gracia 3 días */}
        <SupportImpersonationBanner tenant={primaryTenant} />
        <TrialAndGraceBanner
          tenant={primaryTenant}
          reviewsCount={reviews.length}
          onOpenBilling={() => setTab('facturacion')}
        />

        {/* Guía inicial paso a paso con barra de progreso */}
        {hasAccess && primaryTenant && (
          <DashboardStepGuide
            tenant={primaryTenant}
            reviews={reviews}
            publishedCount={publishedIds.size}
            draftsCount={Object.keys(drafts).length}
            onSelectTab={setTab}
          />
        )}

        {/* Checklist persistente de Onboarding (5 pasos + TTFV < 10 min) */}
        {hasAccess && primaryTenant && (
          <OnboardingChecklist
            tenant={primaryTenant}
            reviews={reviews}
            onGoTab={(next) => setTab(next)}
            onLoadSamples={loadSampleReviews}
            onSync={sync}
          />
        )}

        {/* Con empresa pero sin acceso → Paywall Contextual */}
        {!hasAccess && hasAnyTenant && (
          <ContextualPaywallCard
            tenant={primaryTenant}
            reviews={reviews}
            onOpenBilling={() => setTab('facturacion')}
          />
        )}

        <HelpCenter open={helpOpen} onClose={() => setHelpOpen(false)} />
        <SupportChat tenantId={primaryTenant?.id} />

        <AnimatePresence mode="wait">
          {tab === 'bandeja' && (
            <DashboardReviewsSection
              hydrated={hydrated} hasAccess={hasAccess} primaryTenant={primaryTenant}
              reviews={reviews} filteredCount={filtered.length} paginatedReviews={paginatedReviews}
              reviewPage={reviewPage} reviewTotalPages={reviewTotalPages} onPageChange={setReviewPage}
              flagged={flagged} stats={stats} filter={filter} onFilterChange={setFilter}
              onlyPending={onlyPending} onOnlyPendingChange={setOnlyPending} drafts={drafts}
              onDraftChange={(id, value) => setDrafts((d) => ({ ...d, [id]: value }))}
              publishedIds={publishedIds} onPublished={(id) => setPublishedIds((s) => new Set(s).add(id))}
              toneFor={toneFor} showAddReview={showAddReview} setShowAddReview={setShowAddReview}
              newAuthor={newAuthor} setNewAuthor={setNewAuthor} newRating={newRating}
              setNewRating={setNewRating} newSource={newSource} setNewSource={setNewSource}
              newText={newText} setNewText={setNewText} creatingReview={creatingReview}
              onCreateReview={handleCreateReview} onLoadSamples={loadSampleReviews} onSelectTab={setTab}
            />
          )}

          {tab === 'analitica' && (
            <motion.div
              key="analitica"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: EASE }}
            >
              <AnalyticsAndCompetitorsPanel tenant={primaryTenant} reviews={reviews} />
            </motion.div>
          )}

          {tab === 'empresa' && (
            <DashboardCompaniesSection
              tenants={tenants}
              hasAccess={hasAccess}
              canAddCompany
              showWizard={showWizard}
              setShowWizard={setShowWizard}
              newBusinessResult={newBusinessResult}
              syncing={syncing}
              onSync={sync}
            />
          )}

          {tab === 'embudo' && (
            <motion.div
              key="embudo"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="space-y-4"
            >
              <div>
                <h2 className="flex items-center gap-2 text-base font-bold tracking-tightish text-white">
                  <Filter size={16} className="text-brand-300" /> Flujo Neutral de Valoración
                </h2>
                <p className="mt-1 text-sm text-ink-300">
                  Tu enlace ofrece las mismas plataformas a todas las puntuaciones y añade soporte
                  privado opcional para quien quiera atención directa.
                </p>
              </div>
              {tenants.length === 0 && (
                <div className="card p-10 text-center" role="status">
                  <p className="font-bold text-white">Crea tu empresa para activar el embudo</p>
                  <p className="mx-auto mt-1 max-w-md text-sm text-ink-300">
                    El enlace público aparece aquí en cuanto actives tu suscripción.
                  </p>
                </div>
              )}
              {tenants.map((t) => (
                <FunnelPanel key={t.id} tenant={t} />
              ))}
            </motion.div>
          )}

          {tab === 'equipo' && <TeamPanel key="equipo" tenant={primaryTenant} />}

          {tab === 'facturacion' && (
            <motion.div
              key="facturacion"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: EASE }}
            >
              <BillingPanel tenant={primaryTenant} addonResult={addonResult} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <DashboardBottomNavAndFooter tab={tab} setTab={setTab} tabs={TABS} />
    </div>
  );
}

/** Esqueleto de página completa (Suspense fallback del servidor). */
export function DashboardLoading() {
  return (
    <div className="min-h-screen bg-ink-950 p-6">
      <div className="mx-auto max-w-6xl space-y-5">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <StatSkeleton key={i} />
          ))}
        </div>
        <ReviewListSkeleton rows={3} />
      </div>
    </div>
  );
}
