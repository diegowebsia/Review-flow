export const dynamic = 'force-dynamic';

/**
 * Alias público documentado de `/api/health`.
 * Se mantiene para compatibilidad con balanceadores de carga, UptimeRobot/BetterStack y Cloud Run probes
 * que consultan `/health` en la raíz, reexportando directamente `app/api/health/route.ts`.
 */
export { GET } from '@/app/api/health/route';

