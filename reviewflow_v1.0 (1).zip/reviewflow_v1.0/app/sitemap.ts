import type { MetadataRoute } from 'next';
import { SITE } from '@/lib/site';

/**
 * Solo páginas que queremos que salgan en Google.
 * Registro, login, estado, paneles y las páginas de cada negocio (/valorar, /cartel)
 * llevan "noindex" y no se incluyen aquí.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = SITE.url.replace(/\/$/, '');
  if (baseUrl === 'https://invalid.example') return [];

  const publicPaths: Array<{ path: string; priority: number; changeFrequency: 'weekly' | 'monthly' }> = [
    { path: '/', priority: 1.0, changeFrequency: 'weekly' },
    { path: '/precios', priority: 0.9, changeFrequency: 'weekly' },
    { path: '/sobre-nosotros', priority: 0.6, changeFrequency: 'monthly' },
    { path: '/contacto', priority: 0.6, changeFrequency: 'monthly' },
    { path: '/dpa', priority: 0.3, changeFrequency: 'monthly' },
    { path: '/privacidad', priority: 0.3, changeFrequency: 'monthly' },
    { path: '/terminos', priority: 0.3, changeFrequency: 'monthly' },
    { path: '/cookies', priority: 0.3, changeFrequency: 'monthly' },
    { path: '/aviso-legal', priority: 0.3, changeFrequency: 'monthly' },
  ];

  return publicPaths.map(({ path, priority, changeFrequency }) => ({
    url: `${baseUrl}${path}`,
    changeFrequency,
    priority,
  }));
}
