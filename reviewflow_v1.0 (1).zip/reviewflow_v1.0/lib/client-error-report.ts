'use client';

/**
 * Envía un fallo del navegador a `/api/client-errors`, que lo guarda en el
 * registro del servidor. Nunca lanza errores ni bloquea la página.
 */
type ClientErrorReport = {
  source: string;
  message: string;
  stack?: string;
  digest?: string;
  filename?: string;
  lineno?: number;
  colno?: number;
};

const MAX_REPORTS_PER_PAGE = 10;
let sent = 0;
const seen = new Set<string>();

export function reportClientError(report: ClientErrorReport): void {
  try {
    if (typeof window === 'undefined') return;
    const key = `${report.source}|${report.message}`;
    if (seen.has(key) || sent >= MAX_REPORTS_PER_PAGE) return;
    seen.add(key);
    sent += 1;
    const body = JSON.stringify({
      ...report,
      message: (report.message || 'Error desconocido').slice(0, 1000),
      stack: report.stack?.slice(0, 4000),
      url: window.location.href.split('?')[0]?.slice(0, 500),
    });
    const blob = new Blob([body], { type: 'application/json' });
    if (typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function' && navigator.sendBeacon('/api/client-errors', blob)) {
      return;
    }
    void fetch('/api/client-errors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      keepalive: true,
    }).catch(() => undefined);
  } catch {
    /* nunca romper la página por informar de un error */
  }
}

export function errorToReport(source: string, error: unknown, digest?: string): ClientErrorReport {
  const err = error instanceof Error ? error : null;
  return {
    source,
    message: err?.message || String(error ?? 'Error desconocido'),
    stack: err?.stack,
    digest,
  };
}
