/**
 * ============================================================
 * Gestor de colas en segundo plano (Supabase `job_queue`)
 * ============================================================
 * Los trabajos pesados o limitados por rate-limit se encolan en la tabla
 * `job_queue` de Supabase como `pending` y el cron los procesa en lotes
 * de máximo 5 por ejecución con hasta 3 reintentos:
 *
 *   · `store.delivered`  → pedido entregado → email al cliente.
 *   · `sync.provider`    → sincronización Google/Places/Trustpilot.
 *   · `ai.generate`      → borrador IA (Google Gemini) con resultado consultable.
 *   · `notify.owner`     → aviso interno al dueño (email).
 */

import { z } from 'zod';
import type { AdminLike } from '@/lib/usage';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';
import { recordServiceOutcome } from '@/lib/observability';
import { sendMail } from '@/lib/mail';
import { generateReplyForTenant } from '@/lib/ai';
import { handleDeliveredOrder, type DeliveredOrder } from '@/lib/store';
import { syncGoogleBusinessForTenant, syncGooglePlacesForTenant } from '@/lib/google';
import { syncTrustpilotForTenant } from '@/lib/trustpilot';
import { decryptCredentials } from '@/lib/credentials';
import { env } from '@/lib/env';
import { DEFAULT_AI_MODEL } from '@/lib/plans';

/** Tareas máximas por ronda (ajustable con QUEUE_BATCH_SIZE, tope 50). */
export const MAX_QUEUE_BATCH_SIZE = Math.max(1, Math.min(50, Number(process.env.QUEUE_BATCH_SIZE) || 10));
/** Cuántas tareas se ejecutan a la vez (QUEUE_CONCURRENCY, por defecto 4, tope 10). */
function queueConcurrency(): number {
  return Math.max(1, Math.min(10, Number(process.env.QUEUE_CONCURRENCY) || 4));
}
/** Por empresa, como mucho 1 tarea en marcha por ronda: ninguna acapara el servicio. */
const MAX_IN_FLIGHT_PER_TENANT = 1;
/** Candidatas leídas por ronda para poder repartir entre empresas. */
const QUEUE_CANDIDATE_WINDOW = 100;

function tenantOf(row: JobQueueRow): string | null {
  const p = row.payload as { tenantId?: unknown } | null;
  return p && typeof p.tenantId === 'string' ? p.tenantId : null;
}

/**
 * Reparto justo: intercala las tareas por empresa (1ª de cada una, luego la
 * 2ª…) y, dentro de cada vuelta, primero los avisos rápidos y lo que pidió una
 * persona; las respuestas automáticas (las más lentas) van detrás.
 */
export function fairOrder(rows: JobQueueRow[]): JobQueueRow[] {
  const weight = (r: JobQueueRow): number => {
    const p = r.payload as { type?: string; autoPublish?: boolean; origin?: string } | null;
    if (!p) return 9;
    if (p.type === 'notify.owner' || p.type === 'store.delivered') return 0;
    if (p.type === 'ai.generate' && p.autoPublish !== true) return 1; // lo pidió una persona
    if (p.type === 'sync.provider' && p.origin === 'manual') return 1;
    if (p.type === 'sync.provider') return 2;
    return 3; // piloto automático
  };
  const byTenant = new Map<string, JobQueueRow[]>();
  for (const r of rows) {
    const k = tenantOf(r) ?? `_${r.id}`;
    const list = byTenant.get(k) ?? [];
    list.push(r);
    byTenant.set(k, list);
  }
  const out: JobQueueRow[] = [];
  for (let round = 0; ; round += 1) {
    const layer: JobQueueRow[] = [];
    for (const list of byTenant.values()) if (list[round]) layer.push(list[round]!);
    if (layer.length === 0) break;
    layer.sort((x, y) => weight(x) - weight(y) || x.created_at.localeCompare(y.created_at));
    out.push(...layer);
  }
  return out;
}
const MAX_JOB_ATTEMPTS = 3;

/* ------------------------------------------------------------------ */
/* Tipos de trabajo                                                    */
/* ------------------------------------------------------------------ */

export const QueueJobSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('store.delivered'),
    tenantId: z.string().uuid(),
    order: z.object({
      orderId: z.string().min(1).max(100),
      customerName: z.string().min(1).max(120),
      customerPhone: z.string().min(5).max(25).optional(),
      customerEmail: z.string().email().max(150).optional(),
      provider: z.enum(['shopify', 'woocommerce', 'store']),
      optin: z.boolean().optional(),
      optinText: z.string().max(500).optional(),
    }),
  }),
  z.object({
    type: z.literal('sync.provider'),
    tenantId: z.string().uuid(),
    provider: z.enum(['google', 'places', 'trustpilot']),
    /** Origen (auditoría): 'cron' | 'manual'. */
    origin: z.string().max(20).default('cron'),
  }),
  z.object({
    type: z.literal('ai.generate'),
    tenantId: z.string().uuid(),
    /** Identificador para `GET /api/ai/result?jobId=`. */
    jobId: z.string().min(8).max(80),
    businessName: z.string().min(1).max(120),
    authorName: z.string().min(1).max(120),
    rating: z.number().min(1).max(5),
    reviewText: z.string().min(1).max(4000),
    tone: z.enum(['profesional', 'cercano', 'formal']).optional(),
    private: z.boolean().optional(),
    reviewId: z.string().min(1).max(80).optional(),
    /** Piloto automático: publica la respuesta y avisa al dueño. */
    autoPublish: z.boolean().optional(),
  }),
  z.object({
    type: z.literal('notify.owner'),
    tenantId: z.string().uuid(),
    subject: z.string().min(1).max(140),
    html: z.string().min(1).max(20000),
    text: z.string().max(20000).optional(),
  }),
]);

type QueueJob = z.infer<typeof QueueJobSchema>;

type JobResult = {
  ok: boolean;
  /** true → la tarea puede reintentarse hasta MAX_JOB_ATTEMPTS (3). */
  retryable: boolean;
  detail?: string;
};

export type JobQueueRow = {
  id: string;
  type: string;
  payload: unknown;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  attempts: number;
  created_at: string;
  processed_at: string | null;
  locked_at?: string | null;
};

/* ------------------------------------------------------------------ */
/* Publicar en `job_queue`                                             */
/* ------------------------------------------------------------------ */

type EnqueueResult = { queued: boolean; jobId: string };

/**
 * Inserta una tarea como `pending` en la tabla `job_queue` de Supabase.
 * Si la inserción falla se reintenta una vez; si vuelve a fallar NO se
 * ejecuta en el momento (eso bloqueaba la petición que encolaba y podía
 * superar el tiempo máximo del servidor). Se registra el fallo y la tarea
 * se deja para más tarde: la siguiente ronda del cron la vuelve a generar.
 */
export async function enqueue(
  job: QueueJob,
  opts: { delaySeconds?: number; admin?: AdminLike | null } = {},
): Promise<EnqueueResult> {
  const parsed = QueueJobSchema.parse(job);
  const admin = opts.admin !== undefined ? opts.admin : createAdminClient();
  if (!admin) throw new Error('Supabase no configurado.');

  let lastError = 'job_queue_insert_failed';
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const { data, error } = await admin
        .from('job_queue')
        .insert({ type: parsed.type, payload: parsed, status: 'pending', attempts: 0 })
        .select('id')
        .single();
      if (error) throw new Error(error.message ?? 'job_queue_insert_failed');
      const insertedId =
        data && typeof data === 'object' && 'id' in data && typeof (data as { id?: unknown }).id === 'string'
          ? (data as { id: string }).id
          : `job-${Date.now().toString(36)}`;
      return { queued: true, jobId: insertedId };
    } catch (e: unknown) {
      lastError = e instanceof Error ? e.message : String(e);
    }
  }
  await systemLog('warn', 'queue.publish', `No se pudo apuntar en job_queue; se deja para más tarde: ${lastError}`, {
    type: parsed.type,
    tenantId: 'tenantId' in parsed ? parsed.tenantId : undefined,
  }).catch(() => undefined);
  return { queued: false, jobId: `deferred-${Date.now().toString(36)}` };
}

/* ------------------------------------------------------------------ */
/* Presupuesto de tiempo y reserva de tareas                           */
/* ------------------------------------------------------------------ */

/** Límite duro del servidor (maxDuration de las rutas que procesan la cola). */
const SERVER_MAX_DURATION_MS = 60_000;
/** Margen de seguridad para responder y guardar el estado antes del corte. */
const SAFETY_MARGIN_MS = 5_000;
/** Una tarea `processing` sin terminar en este tiempo se considera abandonada. */
const STALE_LOCK_MS = 10 * 60 * 1000;

/** Duración estimada en el peor caso de cada tipo de tarea. */
export function estimateJobMs(job: QueueJob): number {
  switch (job.type) {
    case 'ai.generate':
      // IA + publicación en Google: hasta ~50 s en el peor caso.
      return job.autoPublish === true ? 50_000 : 30_000;
    case 'sync.provider':
      return 25_000;
    case 'store.delivered':
    case 'notify.owner':
      return 10_000;
  }
}

/**
 * Procesa tareas de `job_queue` (máx. 5) con estas garantías:
 *  · Solo empieza una tarea si le da tiempo a terminarla antes del corte del
 *    servidor; las demás esperan a la siguiente ronda.
 *  · Cada tarea se reserva de forma atómica antes de empezar (update
 *    condicional sobre estado + intentos): dos procesos nunca cogen la misma.
 *  · Una tarea reservada por un proceso que se cortó se recupera a los 10 min.
 */
export async function processPendingJobs(
  admin: AdminLike,
  batchSize: number = MAX_QUEUE_BATCH_SIZE,
  opts: { startedAt?: number; maxDurationMs?: number; now?: () => number } = {},
): Promise<{
  processed: number;
  succeeded: number;
  retried: number;
  failed: number;
  deferred: number;
}> {
  const now = opts.now ?? Date.now;
  const startedAt = opts.startedAt ?? now();
  const deadline = startedAt + (opts.maxDurationMs ?? SERVER_MAX_DURATION_MS) - SAFETY_MARGIN_MS;
  const effectiveBatchSize = Math.max(1, Math.min(MAX_QUEUE_BATCH_SIZE, batchSize));
  const empty = { processed: 0, succeeded: 0, retried: 0, failed: 0, deferred: 0 };

  const staleIso = new Date(now() - STALE_LOCK_MS).toISOString();

  // Tareas abandonadas que ya agotaron sus intentos → failed (no se quedan colgadas).
  try {
    await admin
      .from('job_queue')
      .update({ status: 'failed', processed_at: new Date(now()).toISOString(), locked_at: null })
      .eq('status', 'processing')
      .lt('locked_at', staleIso)
      .gte('attempts', MAX_JOB_ATTEMPTS);
  } catch {
    /* best-effort */
  }

  const { data: rows, error } = await admin
    .from('job_queue')
    .select('id, type, payload, status, attempts, created_at, processed_at, locked_at')
    .or(`status.eq.pending,and(status.eq.processing,locked_at.lt.${staleIso})`)
    .lt('attempts', MAX_JOB_ATTEMPTS)
    .order('created_at', { ascending: true })
    // Ventana amplia para poder repartir de forma justa entre empresas.
    .limit(QUEUE_CANDIDATE_WINDOW);

  if (error || !rows || !Array.isArray(rows) || rows.length === 0) return empty;

  const result = { ...empty };
  const ordered = fairOrder(rows as JobQueueRow[]);
  const concurrency = queueConcurrency();
  let cursor = 0;
  let started = 0;
  /** Tareas en marcha por empresa dentro de esta ronda (máx. 1 → reparto justo). */
  const inFlightByTenant = new Map<string, number>();

  const runOne = async (rawRow: JobQueueRow): Promise<void> => {
    const parsed = QueueJobSchema.safeParse(rawRow.payload);
    const nextAttempts = Number(rawRow.attempts ?? 0) + 1;
    const finish = (status: 'completed' | 'pending' | 'failed') =>
      admin
        .from('job_queue')
        .update(
          status === 'pending'
            ? { status, locked_at: null }
            : { status, locked_at: null, processed_at: new Date(now()).toISOString() },
        )
        .eq('id', rawRow.id);

    if (!parsed.success) {
      result.failed += 1;
      await finish('failed');
      return;
    }
    const maxAttemptsForJob = parsed.data.type === 'notify.owner' ? 1 : MAX_JOB_ATTEMPTS;
    try {
      const jobResult = await dispatchJob(admin, parsed.data);
      if (jobResult.ok) {
        result.succeeded += 1;
        await finish('completed');
      } else if (jobResult.retryable && nextAttempts < maxAttemptsForJob) {
        result.retried += 1;
        await finish('pending');
      } else {
        result.failed += 1;
        await finish('failed');
      }
    } catch {
      if (nextAttempts < maxAttemptsForJob) {
        result.retried += 1;
        await finish('pending');
      } else {
        result.failed += 1;
        await finish('failed');
      }
    }
  };

  /** Coge la siguiente tarea que quepa en tiempo, no sea de una empresa ya ocupada y se pueda reservar. */
  const takeNext = async (): Promise<JobQueueRow | null> => {
    while (cursor < ordered.length && started < effectiveBatchSize) {
      const row = ordered[cursor++]!;
      const parsed = QueueJobSchema.safeParse(row.payload);
      const tenant = tenantOf(row);
      if (parsed.success && now() + estimateJobMs(parsed.data) > deadline) {
        result.deferred += 1; // no le da tiempo: siguiente ronda
        continue;
      }
      if (tenant && (inFlightByTenant.get(tenant) ?? 0) >= MAX_IN_FLIGHT_PER_TENANT) {
        result.deferred += 1; // otra empresa tiene prioridad en esta ronda
        continue;
      }
      // Reserva atómica: solo gana quien vea el mismo estado e intentos.
      const { data: claimed } = await admin
        .from('job_queue')
        .update({
          status: 'processing',
          attempts: Number(row.attempts ?? 0) + 1,
          locked_at: new Date(now()).toISOString(),
        })
        .eq('id', row.id)
        .eq('status', row.status)
        .eq('attempts', Number(row.attempts ?? 0))
        .select('id');
      if (!Array.isArray(claimed) || claimed.length === 0) continue; // otro proceso la cogió
      started += 1;
      result.processed += 1;
      if (tenant) inFlightByTenant.set(tenant, (inFlightByTenant.get(tenant) ?? 0) + 1);
      return row;
    }
    return null;
  };

  // Varias tareas a la vez (casi todo es esperar a la IA o a Google), cada
  // "carril" va cogiendo la siguiente mientras quede tiempo.
  const lane = async (): Promise<void> => {
    for (;;) {
      const row = await takeNext();
      if (!row) return;
      await runOne(row);
      const tenant = tenantOf(row);
      if (tenant) inFlightByTenant.set(tenant, Math.max(0, (inFlightByTenant.get(tenant) ?? 1) - 1));
    }
  };
  await Promise.all(Array.from({ length: concurrency }, () => lane()));

  return result;
}

/* ------------------------------------------------------------------ */
/* Despachador (lo usan el worker HTTP y el modo inline)               */
/* ------------------------------------------------------------------ */

async function touchIntegration(
  admin: AdminLike,
  tenantId: string,
  provider: string,
  ok: boolean,
  error?: string,
): Promise<void> {
  try {
    await admin
      .from('integrations')
      .update(
        ok
          ? { status: 'connected', last_sync_at: new Date().toISOString(), last_error: null }
          : { status: 'error', last_error: (error ?? 'sync fallido').slice(0, 300) },
      )
      .eq('tenant_id', tenantId)
      .eq('provider', provider);
  } catch {
    /* best-effort */
  }
}

async function handleStoreDelivered(
  admin: AdminLike,
  job: Extract<QueueJob, { type: 'store.delivered' }>,
): Promise<JobResult> {
  const { data: tenant } = await admin
    .from('tenants')
    .select('id, name, slug, plan, subscription_status, suspended, settings')
    .eq('id', job.tenantId)
    .single();
  if (!tenant) return { ok: false, retryable: false, detail: 'tenant no encontrado' };
  const result = await handleDeliveredOrder(
    admin,
    tenant as Parameters<typeof handleDeliveredOrder>[1],
    job.order as DeliveredOrder,
  );
  const bodyObj = result.body as { skipped?: string } | null | undefined;
  const skipped = bodyObj?.skipped;
  if (result.ok || skipped) return { ok: true, retryable: false, detail: skipped ?? 'enviado' };
  return {
    ok: false,
    retryable: result.status >= 500,
    detail: JSON.stringify(result.body).slice(0, 300),
  };
}

async function handleSyncProvider(
  admin: AdminLike,
  job: Extract<QueueJob, { type: 'sync.provider' }>,
): Promise<JobResult> {
  const { data: tenant } = await admin
    .from('tenants')
    .select('id, settings')
    .eq('id', job.tenantId)
    .single();
  if (!tenant) return { ok: false, retryable: false, detail: 'tenant no encontrado' };
  const settings = (tenant.settings as { place_id?: string } | null) ?? {};

  const { data: integ } = await admin
    .from('integrations')
    .select('credentials')
    .eq('tenant_id', job.tenantId)
    .eq('provider', job.provider === 'places' ? 'google' : job.provider)
    .single();
  const creds = decryptCredentials<{
    refresh_token?: string;
    access_token?: string;
    apiKey?: string;
    businessUnitId?: string;
  }>(integ?.credentials);
  const ctx = { admin, tenantId: job.tenantId };

  const synced =
    job.provider === 'google'
      ? await syncGoogleBusinessForTenant(ctx, {
          refresh_token: creds.refresh_token,
          access_token: creds.access_token,
        })
      : job.provider === 'places'
        ? await syncGooglePlacesForTenant(ctx, settings.place_id ?? '')
        : await syncTrustpilotForTenant(ctx, { apiKey: creds.apiKey, businessUnitId: creds.businessUnitId });

  if (synced.ok) {
    await touchIntegration(admin, job.tenantId, job.provider === 'places' ? 'google' : job.provider, true);
    await recordServiceOutcome('review_sync', true, `importadas ${synced.result.imported}`, {
      tenantId: job.tenantId,
      tags: { provider: job.provider },
    });
    return { ok: true, retryable: false, detail: `importadas ${synced.result.imported}` };
  }
  // 402/403/429/400/507 no reintentan; 5xx del proveedor sí.
  const retryable = synced.status >= 500 && synced.status !== 507;
  if (!retryable || synced.status === 400) {
    await touchIntegration(admin, job.tenantId, job.provider === 'places' ? 'google' : job.provider, false, synced.error);
  }
  await recordServiceOutcome('review_sync', false, `${job.provider}: ${synced.error}`, {
    tenantId: job.tenantId,
    tags: { provider: job.provider, code: synced.code },
  });
  await systemLog('warn', 'queue.sync', `${job.provider}: ${synced.error}`, {
    tenantId: job.tenantId,
    code: synced.code,
    origin: job.origin,
  });
  return { ok: false, retryable, detail: `${synced.code}: ${synced.error}`.slice(0, 300) };
}

async function handleAiGenerate(admin: AdminLike, job: Extract<QueueJob, { type: 'ai.generate' }>): Promise<JobResult> {
  const result = await generateReplyForTenant(
    { admin, tenantId: job.tenantId },
    {
      businessName: job.businessName,
      authorName: job.authorName,
      rating: job.rating,
      reviewText: job.reviewText,
      tone: job.tone,
      privateMessage: job.private === true,
    },
    { feature: 'aiReplies', asyncJob: { jobId: job.jobId } },
  );
  if (!result.ok) {
    const retryable = result.status >= 500;
    // Deja constancia del fallo definitivo para `GET /api/ai/result`.
    if (!retryable) {
      try {
        const bodyCode =
          result.body && typeof result.body === 'object' && 'code' in result.body
            ? String((result.body as { code?: unknown }).code ?? 'gate')
            : 'gate';
        await admin.from('ai_interactions').insert({
          tenant_id: job.tenantId,
          model: env.geminiModel || DEFAULT_AI_MODEL,
          purpose: 'respond.async',
          job_id: job.jobId,
          result_status: 'error',
          error_code: bodyCode,
          ok: false,
        });
      } catch {
        /* best-effort */
      }
    }
    return { ok: false, retryable, detail: JSON.stringify(result.body).slice(0, 300) };
  }
  if (job.reviewId && job.autoPublish === true && job.private !== true) {
    return finishAutoPublish(admin, job, result.reply, `${result.provider} · ${result.usage.totalTokens} tokens`);
  }
  if (job.reviewId) {
    try {
      await admin
        .from('reviews')
        .update(
          job.private === true
            ? { private_note: result.reply }
            : { reply_text: result.reply, replied_at: new Date().toISOString() },
        )
        .eq('id', job.reviewId)
        .eq('tenant_id', job.tenantId);
    } catch {
      /* la respuesta al cliente no se bloquea por un fallo de persistencia */
    }
  }
  return { ok: true, retryable: false, detail: `${result.provider} · ${result.usage.totalTokens} tokens` };
}

async function finishAutoPublish(
  admin: AdminLike,
  job: Extract<QueueJob, { type: 'ai.generate' }>,
  reply: string,
  detail: string,
): Promise<JobResult> {
  const { autoPublishConfigOf, shouldAutoPublish, pushReplyToGoogle, autoPublishNotice } = await import('@/lib/auto-publish');
  // El dueño pudo apagar el piloto mientras la tarea esperaba en cola.
  const { data: tenant } = await admin.from('tenants').select('settings').eq('id', job.tenantId).single();
  if (!shouldAutoPublish(autoPublishConfigOf(tenant?.settings), job.rating)) {
    return { ok: true, retryable: false, detail: 'piloto automático desactivado: no se publica' };
  }
  // 1) Nunca se pisa una respuesta escrita por una persona.
  const { data: current } = await admin
    .from('reviews')
    .select('id, tenant_id, source, external_id, reply_text')
    .eq('id', job.reviewId!)
    .eq('tenant_id', job.tenantId)
    .single();
  if (!current) return { ok: true, retryable: false, detail: 'reseña no encontrada' };
  if (current.reply_text) return { ok: true, retryable: false, detail: 'ya respondida: no se publica' };

  // 2) Primero se publica en Google (publicar de nuevo solo reemplaza la
  //    respuesta, así que repetir es seguro). Si falla, NO se guarda nada y
  //    la tarea se reintenta: nunca queda "en el panel pero no en Google".
  const review = {
    id: String(current.id),
    tenant_id: String(current.tenant_id),
    source: current.source as string | null,
    external_id: current.external_id as string | null,
  };
  const pushed = await pushReplyToGoogle(admin, review, reply, 'reviews.autopublish');
  if (pushed.googleError) {
    return { ok: false, retryable: true, detail: `google: ${pushed.googleError}`.slice(0, 300) };
  }

  // 3) Después se guarda, solo si sigue sin respuesta humana.
  const { data: saved } = await admin
    .from('reviews')
    .update({ reply_text: reply, replied_at: new Date().toISOString() })
    .eq('id', review.id)
    .eq('tenant_id', job.tenantId)
    .is('reply_text', null)
    .select('id');
  if (!Array.isArray(saved) || saved.length === 0) {
    await systemLog('warn', 'reviews.autopublish', `Una persona respondió durante la publicación de ${review.id}; se respeta su respuesta`, {
      tenantId: job.tenantId,
    });
    return { ok: true, retryable: false, detail: 'respondida por una persona durante la publicación' };
  }
  await systemLog('info', 'reviews.autopublish', `Respuesta automática en reseña ${review.id}`, {
    tenantId: job.tenantId,
    pushedToGoogle: pushed.pushedToGoogle,
  });
  const notice = autoPublishNotice({
    authorName: job.authorName,
    rating: job.rating,
    reviewText: job.reviewText,
    reply,
    pushedToGoogle: pushed.pushedToGoogle,
  });
  await enqueue({ type: 'notify.owner', tenantId: job.tenantId, ...notice }, { admin }).catch(() => undefined);
  return { ok: true, retryable: false, detail: `auto · ${detail}` };
}

async function handleNotifyOwner(
  admin: AdminLike,
  job: Extract<QueueJob, { type: 'notify.owner' }>,
): Promise<JobResult> {
  const { data: tenant } = await admin
    .from('tenants')
    .select('id, name, owner_id, owner_email, settings')
    .eq('id', job.tenantId)
    .single();
  if (!tenant) return { ok: false, retryable: false, detail: 'tenant no encontrado' };
  // Respeta «Emails que recibes → Avisos de reseñas» de /cuenta (por defecto, activado).
  if (tenant.owner_id) {
    const { data: profile } = await admin
      .from('user_profiles')
      .select('email_prefs')
      .eq('user_id', tenant.owner_id)
      .maybeSingle();
    const prefs = (profile?.email_prefs as { review_alerts?: boolean } | null) ?? {};
    if (prefs.review_alerts === false) {
      return { ok: true, retryable: false, detail: 'disabled_by_owner' };
    }
  }
  const mail = await sendMail({
    to: tenant.owner_email,
    subject: job.subject,
    html: job.html,
    text: job.text,
  }).catch((e: unknown) => ({ sent: false, message: e instanceof Error ? e.message : String(e) }));

  await systemLog('info', 'queue.notify', `Aviso al dueño (${mail.sent ? 'email ok' : mail.message})`, {
    tenantId: job.tenantId,
  });
  // Nunca reintenta: un aviso duplicado al dueño es peor que uno perdido
  // (el ticket queda guardado y visible en el panel de todos modos).
  return { ok: true, retryable: false, detail: mail.sent ? 'email ok' : 'email no enviado' };
}

export async function dispatchJob(admin: AdminLike, job: QueueJob): Promise<JobResult> {
  switch (job.type) {
    case 'store.delivered':
      return handleStoreDelivered(admin, job);
    case 'sync.provider':
      return handleSyncProvider(admin, job);
    case 'ai.generate':
      return handleAiGenerate(admin, job);
    case 'notify.owner':
      return handleNotifyOwner(admin, job);
  }
}
