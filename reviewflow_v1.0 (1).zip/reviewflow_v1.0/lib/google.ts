import { z } from 'zod';
import { googleOAuthRedirectUri } from '@/lib/public-url';
import { fetchWithTimeout } from '@/lib/http';
import { errorMessage } from '@/lib/api-error';

/**
 * Google Business Profile (reseñas reales de Google).
 * Flujo: OAuth (connect) → callback guarda tokens → sync importa reseñas.
 * Requiere en Google Cloud Console (APIs & Services → Credentials):
 *   - OAuth client ID (tipo Web) con redirect:
 *     https://TU-DOMINIO/api/integrations/google/callback
 *   - Scope: https://www.googleapis.com/auth/business.manage
 */

const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const GBP_API = 'https://mybusinessbusinessinformation.googleapis.com/v1';
const GBP_ACCOUNTS_API = 'https://mybusinessaccountmanagement.googleapis.com/v1';
/** Reseñas y respuestas siguen en la API v4 de Google My Business. */
const GBP_REVIEWS_API = 'https://mybusiness.googleapis.com/v4';
const SCOPE = 'https://www.googleapis.com/auth/business.manage';

export function isGoogleConfigured(): boolean {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

function redirectUri(): string {
  return googleOAuthRedirectUri();
}

export function getGoogleOAuthUrl(state: string, codeChallenge: string): string {
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID ?? '',
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: SCOPE,
    access_type: 'offline',
    prompt: 'consent',
    state,
    code_challenge: codeChallenge,
    code_challenge_method: 'S256',
  });
  return `${AUTH_URL}?${params.toString()}`;
}

export async function exchangeGoogleCode(code: string, codeVerifier: string): Promise<{
  access_token: string;
  refresh_token?: string;
  expires_in: number;
}> {
  const res = await fetchWithTimeout(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      code,
      code_verifier: codeVerifier,
      client_id: process.env.GOOGLE_CLIENT_ID ?? '',
      client_secret: process.env.GOOGLE_CLIENT_SECRET ?? '',
      redirect_uri: redirectUri(),
      grant_type: 'authorization_code',
    }),
  });
  if (!res.ok) throw new Error(`Google token error (${res.status})`);
  return res.json();
}

async function refreshGoogleToken(refreshToken: string): Promise<string> {
  const res = await fetchWithTimeout(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      refresh_token: refreshToken,
      client_id: process.env.GOOGLE_CLIENT_ID ?? '',
      client_secret: process.env.GOOGLE_CLIENT_SECRET ?? '',
      grant_type: 'refresh_token',
    }),
  });
  if (!res.ok) throw new Error(`Google refresh error (${res.status})`);
  const data = await res.json();
  return data.access_token as string;
}

type GoogleReview = {
  externalId: string;
  author: string;
  rating: number; // 1-5
  text: string;
  createdAt: string;
  verified: boolean;
};

const STAR_MAP: Record<string, number> = { ONE: 1, TWO: 2, THREE: 3, FOUR: 4, FIVE: 5 };

const RawGoogleBusinessReviewSchema = z
  .object({
    name: z.string().optional(),
    reviewId: z.string().optional(),
    reviewer: z.object({ displayName: z.string().optional() }).passthrough().optional(),
    starRating: z.union([z.string(), z.number()]).optional(),
    comment: z.string().optional(),
    createTime: z.string().optional(),
  })
  .passthrough();

export function normalizeGoogleReview(
  raw: unknown,
  locationName = 'locations/default',
): GoogleReview {
  const parsed = RawGoogleBusinessReviewSchema.safeParse(raw);
  const r = parsed.success ? parsed.data : {};
  const starRating =
    typeof r.starRating === 'number'
      ? Math.min(5, Math.max(1, Math.round(r.starRating)))
      : (STAR_MAP[String(r.starRating ?? '')] ?? 5);
  return {
    externalId: r.name ?? `${locationName}/${r.reviewId ?? Date.now()}`,
    author: r.reviewer?.displayName ?? 'Cliente de Google',
    rating: starRating,
    text: r.comment ?? '',
    createdAt: r.createTime ?? new Date().toISOString(),
    verified: true,
  };
}

/** Recorre cuentas → ubicaciones → reseñas. */
async function fetchGoogleReviews(accessToken: string): Promise<GoogleReview[]> {
  const headers = { Authorization: `Bearer ${accessToken}` };
  const out: GoogleReview[] = [];

  const accRes = await fetchWithTimeout(`${GBP_ACCOUNTS_API}/accounts`, { headers });
  if (!accRes.ok) throw new Error(`Google accounts error (${accRes.status})`);
  const accountsData = (await accRes.json()) as { accounts?: Array<{ name: string }> };
  const accounts: Array<{ name: string }> = accountsData.accounts ?? [];

  for (const acc of accounts) {
    const locRes = await fetchWithTimeout(`${GBP_API}/${acc.name}/locations?readMask=name,title`, { headers });
    if (!locRes.ok) continue;
    const locData = (await locRes.json()) as { locations?: Array<{ name: string }> };
    const locations: Array<{ name: string }> = locData.locations ?? [];
    for (const loc of locations) {
      // Business Information devuelve `locations/{id}`; v4 exige `accounts/{a}/locations/{id}`.
      const locPath = `${acc.name}/${loc.name}`;
      let pageToken: string | undefined;
      let pages = 0;
      do {
        const qs = new URLSearchParams({ pageSize: '50' });
        if (pageToken) qs.set('pageToken', pageToken);
        const revRes = await fetchWithTimeout(`${GBP_REVIEWS_API}/${locPath}/reviews?${qs}`, { headers });
        if (!revRes.ok) {
          console.error(`Google reviews error [${revRes.status}]: ${await revRes.text()}`);
          break;
        }
        const revData = (await revRes.json()) as { reviews?: unknown[]; nextPageToken?: string };
        for (const r of revData.reviews ?? []) out.push(normalizeGoogleReview(r, locPath));
        pageToken = revData.nextPageToken;
        pages++;
      } while (pageToken && pages < 20);
    }
  }
  return out;
}

/** Publica la respuesta en Google (externalId = accounts/…/locations/…/reviews/…). */
async function replyGoogleReview(
  accessToken: string,
  externalId: string,
  replyText: string,
): Promise<void> {
  const res = await fetchWithTimeout(`${GBP_REVIEWS_API}/${externalId}/reply`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ comment: replyText }),
  });
  if (!res.ok) throw new Error(`Google reply error (${res.status})`);
}

/* ================================================================== */
/* Google Places API (New) — sincronización por Place ID + API key     */
/* ================================================================== */

const PLACES_API = 'https://places.googleapis.com/v1';
const LEGACY_PLACES_API = 'https://maps.googleapis.com/maps/api/place/details/json';

function isGooglePlacesConfigured(): boolean {
  return Boolean(process.env.GOOGLE_PLACES_API_KEY);
}

type PlacesReview = {
  externalId: string;
  author: string;
  rating: number;
  text: string;
  createdAt: string;
  verified: boolean;
};

type PlacesSummary = {
  placeId: string;
  name: string;
  rating: number | null;
  userRatingCount: number | null;
  reviews: PlacesReview[];
  provider: 'places-v1' | 'places-legacy';
};

const ModernPlaceReviewSchema = z
  .object({
    name: z.string().optional(),
    publishTime: z.string().optional(),
    authorAttribution: z.object({ displayName: z.string().optional() }).passthrough().optional(),
    rating: z.union([z.number(), z.string()]).optional(),
    text: z.union([z.object({ text: z.string().optional() }).passthrough(), z.string()]).optional(),
    originalText: z.union([z.object({ text: z.string().optional() }).passthrough(), z.string()]).optional(),
  })
  .passthrough();

const ModernPlaceResponseSchema = z
  .object({
    displayName: z.union([z.string(), z.object({ text: z.string().optional() }).passthrough()]).optional(),
    rating: z.number().optional(),
    userRatingCount: z.number().optional(),
    reviews: z.array(ModernPlaceReviewSchema).optional(),
  })
  .passthrough();

const LegacyPlaceReviewSchema = z
  .object({
    author_name: z.string().optional(),
    rating: z.union([z.number(), z.string()]).optional(),
    text: z.string().optional(),
    time: z.number().optional(),
  })
  .passthrough();

const LegacyPlaceResponseSchema = z
  .object({
    result: z
      .object({
        name: z.string().optional(),
        rating: z.number().optional(),
        user_ratings_total: z.number().optional(),
        reviews: z.array(LegacyPlaceReviewSchema).optional(),
      })
      .passthrough()
      .optional(),
  })
  .passthrough();

export function normalizePlaceReview(raw: unknown, index = 0, placeId = 'default'): PlacesReview {
  const modern = ModernPlaceReviewSchema.safeParse(raw);
  if (modern.success && (modern.data.authorAttribution || modern.data.publishTime || modern.data.name)) {
    const r = modern.data;
    const textVal =
      typeof r.text === 'object' && r.text !== null
        ? r.text.text
        : typeof r.text === 'string'
          ? r.text
          : typeof r.originalText === 'object' && r.originalText !== null
            ? r.originalText.text
            : typeof r.originalText === 'string'
              ? r.originalText
              : '';
    return {
      externalId: r.name ? `places:${r.name}` : `places:${placeId}:${index}:${r.publishTime ?? ''}`,
      author: r.authorAttribution?.displayName ?? 'Cliente de Google',
      rating: Number(r.rating ?? 5),
      text: textVal ?? '',
      createdAt: r.publishTime ?? new Date().toISOString(),
      verified: true,
    };
  }
  const legacy = LegacyPlaceReviewSchema.safeParse(raw);
  const r = legacy.success ? legacy.data : {};
  return {
    externalId: `places:${placeId}:${r.author_name ?? ''}:${r.time ?? index}`,
    author: r.author_name ?? 'Cliente de Google',
    rating: Number(r.rating ?? 5),
    text: r.text ?? '',
    createdAt: r.time ? new Date(r.time * 1000).toISOString() : new Date().toISOString(),
    verified: true,
  };
}

/**
 * Detalle + reseñas de una ficha por Place ID.
 * 1º Places API (New, `places.googleapis.com/v1`) y, si el proyecto aún usa
 * la key clásica, cae al endpoint legacy `maps/api/place/details`.
 * La Places API pública devuelve las 5 reseñas más recientes y más útiles.
 */
async function fetchPlaceReviews(placeId: string): Promise<PlacesSummary> {
  const key = process.env.GOOGLE_PLACES_API_KEY;
  if (!key) throw new Error('Falta GOOGLE_PLACES_API_KEY en el servidor.');

  const modern = await fetchWithTimeout(
    `${PLACES_API}/places/${encodeURIComponent(placeId)}` +
      `?fields=id,displayName,rating,userRatingCount,reviews,googleMapsUri`,
    { headers: { 'X-Goog-Api-Key': key, 'Content-Type': 'application/json' } },
  );

  if (modern.ok) {
    const rawData: unknown = await modern.json();
    const parsed = ModernPlaceResponseSchema.safeParse(rawData);
    const data = parsed.success ? parsed.data : {};
    const reviews: PlacesReview[] = (data.reviews ?? []).map((r, i) => normalizePlaceReview(r, i, placeId));
    const displayName =
      typeof data.displayName === 'string'
        ? data.displayName
        : data.displayName?.text ?? placeId;
    return {
      placeId,
      name: displayName,
      rating: typeof data.rating === 'number' ? data.rating : null,
      userRatingCount: typeof data.userRatingCount === 'number' ? data.userRatingCount : null,
      reviews,
      provider: 'places-v1',
    };
  }

  const legacy = await fetchWithTimeout(
    `${LEGACY_PLACES_API}?place_id=${encodeURIComponent(placeId)}` +
      `&fields=name,rating,user_ratings_total,reviews&key=${encodeURIComponent(key)}`,
  );
  if (!legacy.ok) {
    throw new Error(`Google Places error (${modern.status}/${legacy.status}): revisa la API key y el Place ID.`);
  }
  const rawLegacy: unknown = await legacy.json();
  const parsedLegacy = LegacyPlaceResponseSchema.safeParse(rawLegacy);
  const result = parsedLegacy.success ? (parsedLegacy.data.result ?? {}) : {};
  const reviews: PlacesReview[] = (result.reviews ?? []).map((r, i) => normalizePlaceReview(r, i, placeId));
  return {
    placeId,
    name: result.name ?? placeId,
    rating: typeof result.rating === 'number' ? result.rating : null,
    userRatingCount: typeof result.user_ratings_total === 'number' ? result.user_ratings_total : null,
    reviews,
    provider: 'places-legacy',
  };
}

/* ================================================================== */
/* Capa de negocio: Google conectado al contador de cuota              */
/* ================================================================== */

import type { PlanFeatures } from '@/lib/plans';
import type { AdminLike, GateBlocked } from '@/lib/usage';
import { checkQuota, enforce, logGoogleCall, publicQuota } from '@/lib/usage';
import { ingestReviews, type IngestResult } from '@/lib/ingest';
import { systemLog } from '@/lib/logger';

type GoogleContext = { admin: AdminLike; tenantId: string };

type GoogleSyncOk = {
  ok: true;
  status: 200;
  result: IngestResult;
  provider: 'google-business' | 'places';
  placeName?: string;
  rating?: number | null;
  userRatingCount?: number | null;
  quota: ReturnType<typeof publicQuota>;
};

type GoogleSyncBlocked = {
  ok: false;
  status: number;
  code: string;
  error: string;
  headers: Record<string, string>;
  body: Record<string, unknown>;
};

type GoogleSyncResult = GoogleSyncOk | GoogleSyncBlocked;

function gateBlocked(gate: GateBlocked): GoogleSyncBlocked {
  return {
    ok: false,
    status: gate.status,
    code: gate.code,
    error: gate.error,
    headers: gate.headers,
    body: gate.body,
  };
}

async function providerError(
  ctx: GoogleContext,
  message: string,
  status = 502,
  code = 'provider_error',
): Promise<GoogleSyncBlocked> {
  const check = await checkQuota(ctx.admin, ctx.tenantId).catch(() => null);
  return {
    ok: false,
    status,
    code,
    error: message,
    headers: {},
    body: { error: message, code, quota: check ? publicQuota(check) : undefined },
  };
}

/** Un importe cortado por el tope de filas/almacenamiento del plan → 507. */
function storageCutBlocked(ctx: GoogleContext, result: IngestResult): Promise<GoogleSyncBlocked> {
  return providerError(
    ctx,
    result.errors[0] ?? 'Tope de opiniones guardadas del plan alcanzado.',
    507,
    'storage_limit',
  );
}

/** Protege la cuota diaria/mensual de llamadas a Google (evita facturas sorpresa). */
async function assertGoogleSyncBudget(ctx: GoogleContext, _feature: keyof PlanFeatures): Promise<{
  gate: GoogleSyncBlocked | null;
  check: Awaited<ReturnType<typeof checkQuota>> | null;
}> {
  const check = await checkQuota(ctx.admin, ctx.tenantId);
  if (!check.hasAccess) {
    return {
      check,
      gate: {
        ok: false,
        status: 402,
        code: 'no_subscription',
        error: 'Suscripción sin acceso. Reactívala para sincronizar reseñas.',
        headers: { 'Retry-After': String(check.retryAfterSeconds) },
        body: { error: 'Suscripción sin acceso.', code: 'no_subscription', quota: publicQuota(check) },
      },
    };
  }
  if (check.metrics.syncs.used >= check.metrics.syncs.quota) {
    return {
      check,
      gate: {
        ok: false,
        status: 429,
        code: 'quota_exhausted',
        error:
          `Has alcanzado el límite de sincronizaciones automáticas de tu plan ` +
          `(${check.metrics.syncs.used}/${check.metrics.syncs.quota} este ciclo). ` +
          `El contador se reinicia el ${check.renewalLabel} o puedes ampliarlo con una recarga.`,
        headers: { 'Retry-After': String(check.retryAfterSeconds) },
        body: { error: 'Límite de sincronizaciones alcanzado.', code: 'quota_exhausted', quota: publicQuota(check) },
      },
    };
  }
  return { check, gate: null };
}

/**
 * Sincroniza reseñas de Google Business Profile (OAuth) respetando la cuota.
 * Cada sincronización cuenta 1 `google_call`; cada reseña importada, 1 evento.
 */
export async function syncGoogleBusinessForTenant(
  ctx: GoogleContext,
  credentials: { refresh_token?: string; access_token?: string },
): Promise<GoogleSyncResult> {
  const { gate } = await assertGoogleSyncBudget(ctx, 'googleBusiness');
  if (gate) return gate;

  const canUse = await enforce(ctx.admin, ctx.tenantId, {
    metric: 'reviews',
    feature: 'googleBusiness',
    action: 'Sincronizar Google Business',
  });
  if (!canUse.ok) return gateBlocked(canUse);

  if (!credentials.refresh_token && !credentials.access_token) {
    return providerError(ctx, 'Google no conectado. Pulsa «Conectar Google» primero.', 400);
  }

  try {
    const accessToken = credentials.refresh_token
      ? await refreshGoogleToken(credentials.refresh_token)
      : (credentials.access_token as string);
    const reviews = await fetchGoogleReviews(accessToken);
    await logGoogleCall(ctx.admin, ctx.tenantId, 1);
    const result = await ingestReviews(ctx.admin, ctx.tenantId, reviews, 'google');
    if (result.storageCut) return storageCutBlocked(ctx, result);
    return {
      ok: true,
      status: 200,
      result,
      provider: 'google-business',
      quota: publicQuota(await checkQuota(ctx.admin, ctx.tenantId)),
    };
  } catch (e: unknown) {
    return providerError(ctx, errorMessage(e, 'Sincronización con Google fallida.'));
  }
}

/** Sincroniza reseñas vía Google Places API usando el Place ID de la empresa. */
export async function syncGooglePlacesForTenant(
  ctx: GoogleContext,
  placeId: string,
): Promise<GoogleSyncResult> {
  const { gate } = await assertGoogleSyncBudget(ctx, 'googlePlaces');
  if (gate) return gate;

  const canUse = await enforce(ctx.admin, ctx.tenantId, {
    metric: 'reviews',
    feature: 'googlePlaces',
    action: 'Sincronizar Google Places',
  });
  if (!canUse.ok) return gateBlocked(canUse);

  if (!placeId) return providerError(ctx, 'Falta el Place ID en los ajustes de la empresa.', 400);
  if (!isGooglePlacesConfigured()) {
    return providerError(ctx, 'Falta GOOGLE_PLACES_API_KEY en el servidor.', 503);
  }

  try {
    const summary = await fetchPlaceReviews(placeId);
    await logGoogleCall(ctx.admin, ctx.tenantId, 1);
    const result = await ingestReviews(ctx.admin, ctx.tenantId, summary.reviews, 'places');
    if (result.storageCut) return storageCutBlocked(ctx, result);
    await systemLog('info', 'integrations.places', `${result.imported} reseñas de Places`, {
      tenantId: ctx.tenantId,
      placeId,
    });
    return {
      ok: true,
      status: 200,
      result,
      provider: 'places',
      placeName: summary.name,
      rating: summary.rating,
      userRatingCount: summary.userRatingCount,
      quota: publicQuota(await checkQuota(ctx.admin, ctx.tenantId)),
    };
  } catch (e: unknown) {
    return providerError(ctx, errorMessage(e, 'Sincronización con Places fallida.'));
  }
}

/**
 * Publica una respuesta EN Google con control de cuota.
 * Publicar no consume eventos de reseña, pero sí cuenta la llamada a Google
 * y exige la feature `publishToGoogle` del plan.
 */
export async function publishGoogleReplyForTenant(
  ctx: GoogleContext,
  payload: { externalId: string; reply: string; credentials: { refresh_token?: string; access_token?: string } },
): Promise<{ ok: true; quota: ReturnType<typeof publicQuota> } | GoogleSyncBlocked> {
  const canUse = await enforce(ctx.admin, ctx.tenantId, {
    metric: 'ai',
    feature: 'publishToGoogle',
    amount: 0,
    action: 'Publicar respuesta en Google',
  });
  if (!canUse.ok) return gateBlocked(canUse);

  try {
    const token = payload.credentials.refresh_token
      ? await refreshGoogleToken(payload.credentials.refresh_token)
      : (payload.credentials.access_token as string);
    await replyGoogleReview(token, payload.externalId, payload.reply);
    await logGoogleCall(ctx.admin, ctx.tenantId, 1);
    return { ok: true, quota: publicQuota(await checkQuota(ctx.admin, ctx.tenantId)) };
  } catch (e: unknown) {
    return providerError(ctx, errorMessage(e, 'No se pudo publicar en Google.'));
  }
}

/** Re-export para comodidad de las rutas. */
