import { createClient } from '@/lib/supabase/server';
import type { TypedSupabaseClient } from '@/lib/database.types';

type AdminLike = TypedSupabaseClient;

export type TenantRole = 'owner' | 'admin' | 'agent' | 'viewer';

const ROLE_WEIGHT: Record<TenantRole, number> = {
  viewer: 1,
  agent: 2,
  admin: 3,
  owner: 4,
};

export function normalizeRole(raw: string | null | undefined): TenantRole {
  const clean = (raw ?? '').toLowerCase().trim();
  if (clean === 'owner') return 'owner';
  if (clean === 'admin') return 'admin';
  if (clean === 'agent' || clean === 'member') return 'agent';
  if (clean === 'viewer' || clean === 'readonly') return 'viewer';
  // Rol desconocido: mínimo privilegio (fail-safe).
  return 'viewer';
}

export function hasRoleLevel(actual: TenantRole, minRole: TenantRole): boolean {
  return ROLE_WEIGHT[actual] >= ROLE_WEIGHT[minRole];
}

type AuthzOk = {
  ok: true;
  userId: string;
  role: TenantRole;
  isImpersonated?: boolean;
};
type AuthzFail = { ok: false; error: string; status: number };
type Authz = AuthzOk | AuthzFail;

/**
 * Verifica sesión + pertenencia del usuario a la empresa con control de rol RBAC:
 *   - `owner`: control total (borrado de cuenta, facturación, transferencia).
 *   - `admin`: gestión de integraciones, exportación RGPD, configuración y equipo.
 *   - `agent`: responder reseñas, usar IA, enviar solicitudes y gestionar tickets.
 *   - `viewer`: solo lectura del panel y analítica.
 *
 * Por defecto `requireOwner` exige al menos `admin` (o `owner` en operaciones críticas)
 * y comprueba también si el usuario es `owner_id` directo en `tenants`.
 */
export async function requireRole(
  admin: AdminLike,
  tenantId: string,
  minRole: TenantRole = 'agent',
  options: { forbidImpersonation?: boolean; injectedUser?: { id: string; user_metadata?: Record<string, unknown> } | null } = {},
): Promise<Authz> {
  let user: { id: string; user_metadata?: Record<string, unknown> } | null = options.injectedUser ?? null;
  if (!user && options.injectedUser === undefined) {
    try {
      const supabase = await createClient();
      const { data } = await supabase.auth.getUser();
      user = data.user;
    } catch {
      user = null;
    }
  }
  if (!user) return { ok: false, error: 'No autenticado.', status: 401 };

  const isImpersonated = Boolean(
    user.user_metadata?.impersonated_by &&
      Number(user.user_metadata?.impersonation_exp ?? 0) > Date.now(),
  );

  if (options.forbidImpersonation && isImpersonated) {
    return {
      ok: false,
      error: 'Las operaciones de pago, facturación o borrado están bloqueadas durante una sesión de soporte (impersonación).',
      status: 403,
    };
  }

  const { data: member } = await admin
    .from('memberships')
    .select('id, role')
    .eq('tenant_id', tenantId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (!member) {
    // Fallback por si es propietario directo en tenants.owner_id
    const { data: tenantOwner } = await admin
      .from('tenants')
      .select('owner_id')
      .eq('id', tenantId)
      .maybeSingle();
    if (tenantOwner?.owner_id === user.id) {
      return { ok: true, userId: user.id, role: 'owner', isImpersonated };
    }
    return { ok: false, error: 'Sin permiso en esta empresa.', status: 403 };
  }

  const role = normalizeRole((member as { role?: string | null }).role);
  if (!hasRoleLevel(role, minRole)) {
    return {
      ok: false,
      error: `Permiso insuficiente: tu rol actual es «${role}» y esta acción requiere al menos «${minRole}».`,
      status: 403,
    };
  }

  return { ok: true, userId: user.id, role, isImpersonated };
}

/**
 * Mantiene compatibilidad con todas las rutas existentes exigiendo por defecto
 * un rol con permisos de administración (`admin` u `owner`), o el rol mínimo indicado.
 */
export async function requireOwner(
  admin: AdminLike,
  tenantId: string,
  minRole: TenantRole = 'admin',
): Promise<Authz> {
  return requireRole(admin, tenantId, minRole);
}
