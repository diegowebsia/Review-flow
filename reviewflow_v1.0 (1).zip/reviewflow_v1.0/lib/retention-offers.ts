import { PLAN_CATALOG, planOf, type PlanDefinition, type PlanId } from '@/lib/plans';

/**
 * Ofertas que se muestran ANTES de confirmar una baja.
 * Todo se configura desde el archivo de claves (.env):
 *
 *   RETENTION_DISCOUNT_ENABLED=true     # activar/desactivar el descuento
 *   RETENTION_DISCOUNT_PERCENT=30       # porcentaje (1-100)
 *   RETENTION_DISCOUNT_MONTHS=3         # meses que dura (1-24)
 *   RETENTION_PAUSE_ENABLED=true        # activar/desactivar la pausa
 *   RETENTION_PAUSE_MONTHS=1            # meses de pausa (1-3)
 *   RETENTION_DOWNGRADE_ENABLED=true    # ofrecer un plan más barato
 *
 * El descuento es real (cupón de Stripe aplicado a la suscripción) y solo
 * se puede usar UNA vez por empresa.
 */

interface RetentionConfig {
  discount: { enabled: boolean; percent: number; months: number };
  pause: { enabled: boolean; months: number };
  downgrade: { enabled: boolean };
}

function clean(raw?: string): string {
  return (raw ?? '').trim().replace(/^["']|["']$/g, '').trim();
}

function flag(raw: string | undefined, fallback: boolean): boolean {
  const v = clean(raw).toLowerCase();
  if (!v) return fallback;
  if (['false', '0', 'no', 'off'].includes(v)) return false;
  if (['true', '1', 'si', 'sí', 'yes', 'on'].includes(v)) return true;
  return fallback;
}

function int(raw: string | undefined, fallback: number, min: number, max: number): number {
  const n = Number.parseInt(clean(raw).replace('%', ''), 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

export function getRetentionConfig(envObj: NodeJS.ProcessEnv = process.env): RetentionConfig {
  return {
    discount: {
      enabled: flag(envObj.RETENTION_DISCOUNT_ENABLED, true),
      percent: int(envObj.RETENTION_DISCOUNT_PERCENT, 30, 1, 100),
      months: int(envObj.RETENTION_DISCOUNT_MONTHS, 3, 1, 24),
    },
    pause: {
      enabled: flag(envObj.RETENTION_PAUSE_ENABLED, true),
      months: int(envObj.RETENTION_PAUSE_MONTHS, 1, 1, 3),
    },
    downgrade: {
      enabled: flag(envObj.RETENTION_DOWNGRADE_ENABLED, true),
    },
  };
}

/** Plan más barato de la misma categoría (local / ecommerce), o null si ya está en el más barato. */
export function cheaperPlanFor(currentPlan: string | null | undefined): PlanDefinition | null {
  const current = planOf(currentPlan);
  const candidates = PLAN_CATALOG.filter(
    (p) => p.category === current.category && p.priceCents < current.priceCents,
  ).sort((a, b) => b.priceCents - a.priceCents);
  return candidates[0] ?? null;
}

/** ¿Esta empresa ya gastó su descuento de retención? (una sola vez por empresa) */
export function hasUsedRetentionDiscount(
  settings: Record<string, unknown> | null | undefined,
  stripeCustomerMetadata?: Record<string, string> | null,
): boolean {
  if (settings && settings.retention_discount_used_at) return true;
  if (stripeCustomerMetadata && stripeCustomerMetadata.retention_discount_used_at) return true;
  return false;
}

export interface RetentionOffersView {
  discount: { enabled: boolean; percent: number; months: number; alreadyUsed: boolean; available: boolean };
  pause: { enabled: boolean; months: number; available: boolean };
  downgrade: {
    enabled: boolean;
    available: boolean;
    targetPlan: PlanId | null;
    targetName: string | null;
    targetPrice: string | null;
  };
}

export function buildRetentionOffers(
  plan: string | null | undefined,
  settings: Record<string, unknown> | null | undefined,
  config: RetentionConfig = getRetentionConfig(),
): RetentionOffersView {
  const alreadyUsed = hasUsedRetentionDiscount(settings);
  const cheaper = cheaperPlanFor(plan);
  const pausedUntil = settings?.paused_until ? new Date(String(settings.paused_until)).getTime() : 0;
  const isPaused = Number.isFinite(pausedUntil) && pausedUntil > Date.now();
  return {
    discount: {
      ...config.discount,
      alreadyUsed,
      available: config.discount.enabled && !alreadyUsed,
    },
    pause: { ...config.pause, available: config.pause.enabled && !isPaused },
    downgrade: {
      enabled: config.downgrade.enabled,
      available: config.downgrade.enabled && Boolean(cheaper),
      targetPlan: cheaper?.id ?? null,
      targetName: cheaper?.name ?? null,
      targetPrice: cheaper?.price ?? null,
    },
  };
}

/** Texto corto de la duración del descuento: «el próximo mes» / «los próximos 3 meses». */
export function discountDurationLabel(months: number): string {
  return months === 1 ? 'el próximo mes' : `los próximos ${months} meses`;
}
