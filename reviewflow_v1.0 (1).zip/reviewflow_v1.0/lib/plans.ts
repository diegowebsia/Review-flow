/**
 * ============================================================
 * ReviewFlow AI — Catálogo comercial de planes (v1.0)
 * ============================================================
 * 100% client-safe: este fichero NO importa nada de Node ni de Supabase,
 * por lo que puede usarse en la landing, el dashboard y el servidor.
 *
 * MODELO 100% DE PAGO — 4 planes (sin plan gratuito):
 *
 *   · `local_starter`     → Local Básico      · 19 €/mes (IVA no incluido)
 *   · `ecommerce_starter` → E-commerce Básico · 29 €/mes
 *   · `local_pro`         → Local Pro         · 39 €/mes
 *   · `ecommerce_pro`     → E-commerce Scale  · 69 €/mes
 *   (`pro`/`business` = alias heredados)
 *
 * Todos los planes de pago incluyen {TRIAL_DAYS} días de prueba gratis con
 * tarjeta (`trial_period_days: 7` en Stripe Checkout). Sin suscripción activa
 * (o con la prueba caducada) la plataforma responde 402 (Payment Required).
 *
 * Cada plan define 3 cosas fáciles de explicar a un cliente:
 *   1. LÍMITES MENSUALES (`limits.*PerMonth`): peticiones de opiniones
 *      (email), opiniones importadas, respuestas con IA y
 *      sincronizaciones automáticas con Google/Trustpilot.
 *   2. TOPES DE BASE DE DATOS (`limits.reviewsStored`, `auditRows`,
 *      `integrations`, `logRetentionDays`): cuántas filas puede retener
 *      cada empresa para que PostgreSQL/Supabase nunca se desborde.
 *   3. FEATURES (`features`): qué integraciones están habilitadas.
 *
 * Los planes antiguos (`free`, `trial`, `resenas`, `completo`, `starter`,
 * `enterprise`) siguen resolviéndose por compatibilidad con las filas ya
 * guardadas en la base de datos, siempre hacia un plan DE PAGO:
 *   free/trial/gratis → pro · starter/standard/resenas → pro ·
 *   enterprise/completo/ecommerce → business.
 */

export type PlanId =
  | 'local_starter'
  | 'ecommerce_starter'
  | 'local_pro'
  | 'ecommerce_pro'
  | 'pro'
  | 'business';

/** Métricas medibles contra `usage_counters` (una columna física por métrica). */
export type UsageMetric = 'requests' | 'reviews' | 'ai' | 'syncs';

/** Nombre corto de la métrica para mensajes de error y cabeceras. */
export const METRIC_LABEL: Record<UsageMetric, string> = {
  requests: 'peticiones de opiniones',
  reviews: 'opiniones importadas',
  ai: 'respuestas con IA',
  syncs: 'sincronizaciones automáticas',
};

/** Categoría principal del negocio. */
export type PlanCategory = 'local' | 'ecommerce';

/**
 * Días de prueba gratuita con tarjeta para los planes de pago.
 * Se aplica como `trial_period_days: 7` en Stripe Checkout
 * (ver `app/api/stripe/checkout/route.ts`).
 */
export const TRIAL_DAYS = 7;

/**
 * Días de periodo de gracia (dunning) ante fallo puntual de tarjeta (`invoice.payment_failed`).
 * Evita bajas involuntarias: el cliente conserva acceso durante 3 días mientras recibe
 * 3 avisos escalonados y un banner en el panel para actualizar su método de pago.
 */
export const GRACE_PERIOD_DAYS = 3;

/** Precio anual con 2 meses gratis (10 mensualidades = ~17% de ahorro). */
export function annualPriceCentsOf(plan: string | PlanDefinition | null | undefined): number {
  const def = typeof plan === 'object' && plan && 'priceCents' in plan ? plan : planOf(plan as string);
  return def.priceCents * 10;
}

/** Equivalente mensual facturado anualmente (en céntimos). */
export function annualMonthlyEquivalentCents(plan: string | PlanDefinition | null | undefined): number {
  return Math.round(annualPriceCentsOf(plan) / 12);
}

/* ------------------------------------------------------------------ */
/* Límites por plan                                                    */
/* ------------------------------------------------------------------ */

/**
 * Estimación de peso por fila en PostgreSQL (usada para el medidor de
 * «almacenamiento activo» del panel y para las guías técnicas).
 * Son medias conservadoras sobre el esquema de `supabase/schema.sql`.
 */
/** Modelo de IA por defecto (motor Google Gemini 2.5 Flash). */
export const DEFAULT_AI_MODEL = 'gemini-2.5-flash';

/**
 * Precio de referencia del proveedor de IA (USD por 1M tokens) para ESTIMAR el coste
 * en el panel interno. Con Google Gemini en AI Studio, la cuota base es 100% gratuita ($0).
 */
const AI_MODEL_PRICING: Record<string, { input: number; output: number }> = {
  'gemini-2.5-flash': { input: 0.10, output: 0.40 },
  'gemini-1.5-flash': { input: 0.075, output: 0.30 },
  'gemini-1.5-pro': { input: 1.25, output: 5.0 },
  'gemini-2.5-flash-lite': { input: 0.10, output: 0.40 },
  'gemini-2.5-pro': { input: 1.25, output: 10.0 },
  'gemini-3-pro-preview': { input: 2.0, output: 12.0 },
  'gpt-4.1-mini': { input: 0.40, output: 1.60 },
  'gpt-4.1': { input: 2.0, output: 8.0 },
  'gpt-5-mini': { input: 0.25, output: 2.0 },
  'gpt-5': { input: 1.25, output: 10.0 },
  'claude-haiku-4-5': { input: 1.0, output: 5.0 },
  'claude-sonnet-4-5': { input: 3.0, output: 15.0 },
  // Añade aquí cualquier otro modelo: si no está, se estima con el precio del modelo por defecto.
};

/** Precio de referencia del modelo (USD por 1M tokens). */
export function aiModelPricing(model: string = DEFAULT_AI_MODEL) {
  return AI_MODEL_PRICING[model] ?? AI_MODEL_PRICING[DEFAULT_AI_MODEL];
}

/** Coste estimado en USD de una llamada de IA (redondeado a 6 decimales). */
export function estimateCostUsd(
  promptTokens: number,
  completionTokens: number,
  model: string = DEFAULT_AI_MODEL,
): number {
  const price = aiModelPricing(model);
  const usd = (promptTokens / 1_000_000) * price.input + (completionTokens / 1_000_000) * price.output;
  return Math.round(usd * 1_000_000) / 1_000_000;
}

export const ROW_KB = {
  /** 1 fila de `reviews` (texto + respuesta + índices). */
  review: 6,
  /** 1 fila de `quota_events` (ledger/auditoría de consumo). */
  audit: 0.4,
  /** 1 fila de `integrations` (credenciales OAuth en jsonb). */
  integration: 2,
  /** 1 fila de `ai_interactions` (tokens, modelo, latencia y estado). */
  aiInteraction: 1.2,
} as const;

export type PlanFeatures = {
  /** Peticiones de opiniones por email. */
  emailRequests: boolean;
  /** Sincronización de opiniones de Google Business Profile (OAuth). */
  googleBusiness: boolean;
  /** Sincronización vía Google Places API (key de servidor). */
  googlePlaces: boolean;
  /** Sincronización de Trustpilot Business API. */
  trustpilot: boolean;
  /** Flujo Neutral de Valoración (/valorar/[slug]). */
  feedbackFunnel: boolean;
  /** Borradores de respuesta con IA (Google Gemini o plantilla local). */
  aiReplies: boolean;
  /** Triaje privado de quejas ≤3★ + inspección IA de la reclamación. */
  privateFilter: boolean;
  /** Publicación de la respuesta directamente en Google. */
  publishToGoogle: boolean;
  /** Enlaces «déjanos una opinión» de Google Maps por Place ID. */
  mapsLinks: boolean;
  /** Conexión con tienda (Shopify / WooCommerce / TPV genérico). */
  storeIntegration: boolean;
  /** API pública de ingesta con la api_key de la empresa. */
  publicApi: boolean;
  /** Nivel de soporte comercial. */
  support: 'comunidad' | 'email' | 'prioritario';
};

/** Límites simples: 4 cuotas mensuales + 4 topes de base de datos. */
export type PlanLimits = {
  /** Peticiones de opiniones enviadas (email) por ciclo. */
  requestsPerMonth: number;
  /** Opiniones importadas/creadas por ciclo. */
  reviewsPerMonth: number;
  /** Respuestas generadas con IA por ciclo (créditos facturables). */
  aiRepliesPerMonth: number;
  /**
   * Presupuesto de TOKENS de IA por ciclo (entrada + salida).
   * Es el freno de coste real: aunque queden créditos de IA, si se agota el
   * presupuesto de tokens la API responde 429 hasta el siguiente ciclo.
   * Dimensionado para cubrir con holgura las respuestas del plan usando
   * `gemini-2.5-flash`.
   */
  aiTokensPerMonth: number;
  /** Sincronizaciones automáticas con Google/Trustpilot por ciclo. */
  syncsPerMonth: number;
  /** Empresas (tenants) incluidas. */
  tenants: number;
  /** Sedes / tiendas incluidas. */
  locations: number;

  /* ----- Topes de base de datos (por empresa) ----- */
  /** Máximo de opiniones retenidas en `reviews` (purga automática del resto). */
  reviewsStored: number;
  /** Máximo de registros de auditoría en `quota_events` por empresa. */
  auditRows: number;
  /** Máximo de conexiones simultáneas en `integrations`. */
  integrations: number;
  /** Máximo de filas de interacciones de IA retenidas (`ai_interactions`). */
  aiRows: number;
  /** Días de historial de actividad por empresa (`quota_events`) antes de podarse. */
  logRetentionDays: number;
  /** Cuota de almacenamiento activo asignada en la instancia (MB). */
  storageMb: number;
};

export type PlanDefinition = {
  id: PlanId;
  /** Nombre interno (BD/Stripe). */
  label: string;
  /** Nombre comercial. */
  name: string;
  /** Alias corto de marketing. */
  tier: string;
  /** Categoría del plan (local o ecommerce). */
  category: PlanCategory;
  /** Precio formateado («29 €»). */
  price: string;
  /** Precio en céntimos (EUR). */
  priceCents: number;
  /** Frase comercial de una línea. */
  pitch: string;
  /** Límites mensuales + topes de base de datos. */
  limits: PlanLimits;
  features: PlanFeatures;
};

const SUPPORT_FULL: PlanFeatures = {
  emailRequests: true,
  googleBusiness: true,
  googlePlaces: true,
  trustpilot: true,
  feedbackFunnel: true,
  aiReplies: true,
  privateFilter: true,
  publishToGoogle: true,
  mapsLinks: true,
  storeIntegration: true,
  publicApi: true,
  support: 'prioritario',
};

export const PLANS: Record<PlanId, PlanDefinition> = {
  /* ---------------------- 1. LOCAL BÁSICO (SIN TIENDA) ---------------------- */
  local_starter: {
    id: 'local_starter',
    label: 'Local Básico',
    name: 'Local Básico',
    tier: 'Local AI',
    category: 'local',
    price: '19 €',
    priceCents: 1900,
    pitch:
      'Para negocios físicos sin tienda online: analizador de reseñas con IA, respuestas automáticas, QR para mostrador y embudo neutral.',
    limits: {
      requestsPerMonth: 250,
      reviewsPerMonth: 500,
      aiRepliesPerMonth: 200,
      aiTokensPerMonth: 150_000,
      syncsPerMonth: 60,
      tenants: 1,
      locations: 1,
      reviewsStored: 2_500,
      auditRows: 5_000,
      integrations: 4,
      aiRows: 10_000,
      logRetentionDays: 90,
      storageMb: 1_024,
    },
    features: {
      ...SUPPORT_FULL,
      storeIntegration: false,
      publicApi: false,
      support: 'email',
    },
  },

  /* ------------------- 2. E-COMMERCE BÁSICO (CON TIENDA) ------------------- */
  ecommerce_starter: {
    id: 'ecommerce_starter',
    label: 'E-commerce Básico',
    name: 'E-commerce Básico',
    tier: 'E-commerce AI',
    category: 'ecommerce',
    price: '29 €',
    priceCents: 2900,
    pitch:
      'Se conecta a tu tienda online (Shopify/WooCommerce), capta pedidos entregados y escribe al cliente por email + Analizador de reseñas con IA.',
    limits: {
      requestsPerMonth: 800,
      reviewsPerMonth: 1_500,
      aiRepliesPerMonth: 500,
      aiTokensPerMonth: 400_000,
      syncsPerMonth: 180,
      tenants: 1,
      locations: 1,
      reviewsStored: 7_500,
      auditRows: 15_000,
      integrations: 8,
      aiRows: 30_000,
      logRetentionDays: 180,
      storageMb: 3_072,
    },
    features: {
      ...SUPPORT_FULL,
      storeIntegration: true,
          publicApi: true,
      support: 'email',
    },
  },

  /* ---------------- 3. LOCAL PRO (AUMENTO LÍMITES LOCAL) ---------------- */
  local_pro: {
    id: 'local_pro',
    label: 'Local Pro',
    name: 'Local Pro',
    tier: 'Local Pro',
    category: 'local',
    price: '39 €',
    priceCents: 3900,
    pitch:
      'Límites ampliados para un negocio local con alta afluencia: 1.500 peticiones/mes, 1 local/ubicación completa, IA intensiva y sincronización cada 2 h.',
    limits: {
      requestsPerMonth: 1_500,
      reviewsPerMonth: 3_000,
      aiRepliesPerMonth: 1_000,
      aiTokensPerMonth: 900_000,
      syncsPerMonth: 360,
      tenants: 1,
      locations: 1,
      reviewsStored: 15_000,
      auditRows: 30_000,
      integrations: 12,
      aiRows: 60_000,
      logRetentionDays: 365,
      storageMb: 6_144,
    },
    features: {
      ...SUPPORT_FULL,
      storeIntegration: false,
      publicApi: true,
      support: 'prioritario',
    },
  },

  /* --------------- 4. E-COMMERCE SCALE (AUMENTO LÍMITES TIENDA) --------------- */
  ecommerce_pro: {
    id: 'ecommerce_pro',
    label: 'E-commerce Scale',
    name: 'E-commerce Scale',
    tier: 'E-commerce Scale',
    category: 'ecommerce',
    price: '69 €',
    priceCents: 6900,
    pitch:
      'Límites ampliados para una tienda online de gran volumen: 4.000 peticiones/mes, 1 tienda/marca completa, sincronización continua y soporte prioritario.',
    limits: {
      requestsPerMonth: 4_000,
      reviewsPerMonth: 10_000,
      aiRepliesPerMonth: 2_500,
      aiTokensPerMonth: 2_200_000,
      syncsPerMonth: 1_000,
      tenants: 1,
      locations: 1,
      reviewsStored: 35_000,
      auditRows: 75_000,
      integrations: 25,
      aiRows: 150_000,
      logRetentionDays: 730,
      storageMb: 15_360,
    },
    features: {
      ...SUPPORT_FULL,
      storeIntegration: true,
          publicApi: true,
      support: 'prioritario',
    },
  },

  /* --- ALIASES DE RETROCOMPATIBILIDAD --- */
  pro: {
    id: 'pro',
    label: 'Pro',
    name: 'Pro',
    tier: 'Pro',
    category: 'local',
    price: '29 €',
    priceCents: 2900,
    pitch: 'Para negocios con reseñas cada semana: email, IA y sincronización cada 6 h.',
    limits: {
      requestsPerMonth: 500,
      reviewsPerMonth: 1_000,
      aiRepliesPerMonth: 300,
      aiTokensPerMonth: 250_000,
      syncsPerMonth: 120,
      tenants: 1,
      locations: 1,
      reviewsStored: 5_000,
      auditRows: 10_000,
      integrations: 6,
      aiRows: 20000,
      logRetentionDays: 180,
      storageMb: 2_048,
    },
    features: {
      ...SUPPORT_FULL,
      storeIntegration: false,
      support: 'email',
    },
  },

  business: {
    id: 'business',
    label: 'Business',
    name: 'Business',
    tier: 'Business',
    category: 'ecommerce',
    price: '79 €',
    priceCents: 7900,
    pitch: 'Para tiendas de alto volumen: pedidos + email automático, 1 tienda completa y soporte prioritario.',
    limits: {
      requestsPerMonth: 2_000,
      reviewsPerMonth: 5_000,
      aiRepliesPerMonth: 1_500,
      aiTokensPerMonth: 1_200_000,
      syncsPerMonth: 720,
      tenants: 1,
      locations: 1,
      reviewsStored: 25_000,
      auditRows: 50_000,
      integrations: 20,
      aiRows: 100000,
      logRetentionDays: 365,
      storageMb: 10_240,
    },
    features: SUPPORT_FULL,
  },
};

/** Catálogo oficial de 4 planes: 2 básicos + 2 aumentos de límites. */
export const PLAN_CATALOG: PlanDefinition[] = [
  PLANS.local_starter,
  PLANS.ecommerce_starter,
  PLANS.local_pro,
  PLANS.ecommerce_pro,
];

/** Planes para negocios físicos y locales (sin tienda online). */
export const LOCAL_PLANS: PlanDefinition[] = [PLANS.local_starter, PLANS.local_pro];

/** Planes para tiendas online (conexión con pedidos entregados + email). */
export const ECOMMERCE_PLANS: PlanDefinition[] = [PLANS.ecommerce_starter, PLANS.ecommerce_pro];

/**
 * Normaliza cualquier string de BD a un PlanId válido (defensivo).
 * NO existe plan gratuito: cualquier valor desconocido o legacy de tipo
 * gratuito (`free`, `trial`, `gratis`) resuelve al plan de pago más barato
 * (`pro`) para que el acceso exija siempre una suscripción de pago.
 */
export function resolvePlan(plan: string | null | undefined): PlanId {
  const value = (plan ?? '').trim().toLowerCase();
  if (
    value === 'local_starter' ||
    value === 'ecommerce_starter' ||
    value === 'local_pro' ||
    value === 'ecommerce_pro'
  ) {
    return value;
  }
  // Retrocompatibilidad con nombres legacy
  if (
    value === 'business' ||
    value === 'completo' ||
    value === 'completo-ecommerce' ||
    value === 'ecommerce_scale' ||
    value === 'enterprise'
  ) {
    return 'ecommerce_pro';
  }
  if (value === 'pro' || value === 'standard') {
    return 'local_pro';
  }
  if (
    value === 'ecommerce' ||
    value === 'tienda' ||
    value === 'shop' ||
    value === 'shopify' ||
    value === 'woocommerce'
  ) {
    return 'ecommerce_starter';
  }
  // `free`, `trial`, `gratis`, `starter`, `local`, `resenas` y cualquier otro valor
  return 'local_starter';
}

export function planOf(plan: string | null | undefined): PlanDefinition {
  return PLANS[resolvePlan(plan)];
}

/** ¿El plan habilita esta feature? */
export function planHasFeature(plan: string | null | undefined, feature: keyof PlanFeatures): boolean {
  return Boolean(planOf(plan).features[feature]);
}

/** ¿Está la suscripción dentro del periodo de gracia de 3 días tras un fallo de tarjeta? */
export function isInGracePeriod(
  status: string,
  gracePeriodEndsAt?: string | null,
  now = new Date(),
): boolean {
  if (status !== 'past_due' || !gracePeriodEndsAt) return false;
  const end = new Date(gracePeriodEndsAt).getTime();
  return Number.isFinite(end) && end > now.getTime();
}

/** ¿La suscripción da acceso al panel? (trialing/active, o past_due dentro de los 3 días de gracia, y no suspendida) */
export function hasAccess(
  status: string,
  suspended: boolean,
  gracePeriodEndsAt?: string | null,
): boolean {
  if (suspended) return false;
  if (status === 'active' || status === 'trialing') return true;
  if (status === 'past_due' && isInGracePeriod(status, gracePeriodEndsAt)) return true;
  return false;
}

/** ¿La prueba ha caducado? (día 8 sin pago → corte de acceso) */
export function isTrialExpired(
  status: string,
  trialEndsAt: string | null | undefined,
  now = new Date(),
): boolean {
  if (status !== 'trialing' || !trialEndsAt) return false;
  const end = new Date(trialEndsAt).getTime();
  return Number.isFinite(end) && end <= now.getTime();
}

/* ------------------------------------------------------------------ */
/* Ciclos de facturación                                               */
/* ------------------------------------------------------------------ */

/** Ciclo de facturación actual: YYYY-MM. */
export function currentCycle(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/** Primer instante del ciclo siguiente (renovación de cuota). */
export function nextCycleStart(d = new Date()): Date {
  return new Date(d.getFullYear(), d.getMonth() + 1, 1, 0, 0, 0, 0);
}

/** Etiqueta legible de la renovación: «1 de octubre de 2026». */
export function renewalLabel(d = new Date()): string {
  return nextCycleStart(d).toLocaleDateString('es-ES', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

/** Segundos hasta la renovación (para la cabecera `Retry-After` del 429). */
export function secondsUntilRenewal(d = new Date()): number {
  return Math.max(60, Math.round((nextCycleStart(d).getTime() - d.getTime()) / 1000));
}

/* ------------------------------------------------------------------ */
/* Ampliaciones puntuales (add-ons)                                    */
/* ------------------------------------------------------------------ */

/**
 * Modelo simplificado: SOLO recargas de pago único que suman capacidad al
 * ciclo en curso (una por métrica). Sin cuotas ilimitadas ni suscripciones
 * paralelas: menos casos límite, menos sobrecostes.
 */
export type AddonPackId = 'extra_requests_1000' | 'extra_reviews_2000' | 'extra_ai_500' | 'extra_syncs_500';

export type AddonPack = {
  id: AddonPackId;
  /** Nombre comercial corto. */
  name: string;
  /** Descripción para el Checkout y la tabla de precios. */
  description: string;
  /** Precio en céntimos (EUR). */
  priceCents: number;
  /** Variable de entorno con el Price ID de Stripe (si se prefiere catálogo). */
  priceEnv: string;
  /** Etiqueta de marketing opcional («Más vendido»). */
  badge?: string;
  /** Métrica que amplía. */
  metric: UsageMetric;
  /** Capacidad añadida al ciclo en curso. */
  amount: number;
};

/**
 * Precios en céntimos fijos en el código: este catálogo se renderiza también
 * en el navegador y las variables de entorno sin prefijo NEXT_PUBLIC_ no
 * existen allí (provocaban precios distintos en servidor y navegador).
 * Para cambiar un precio, edítalo aquí y en tu catálogo de Stripe.
 */
export const ADDON_PACKS: Record<AddonPackId, AddonPack> = {
  extra_requests_1000: {
    id: 'extra_requests_1000',
    name: '+1.000 peticiones',
    description: '1.000 peticiones de opiniones más (email) para este ciclo.',
    priceCents: 900,
    priceEnv: 'STRIPE_PRICE_ADDON_REQUESTS',
    badge: 'Más vendido',
    metric: 'requests',
    amount: 1_000,
  },
  extra_reviews_2000: {
    id: 'extra_reviews_2000',
    name: '+2.000 opiniones',
    description: '2.000 opiniones más este ciclo y 2.000 plazas extra de almacenamiento.',
    priceCents: 1200,
    priceEnv: 'STRIPE_PRICE_ADDON_REVIEWS',
    metric: 'reviews',
    amount: 2_000,
  },
  extra_ai_500: {
    id: 'extra_ai_500',
    name: '+500 respuestas IA',
    description: '500 borradores de IA adicionales (respuestas públicas y mensajes privados).',
    priceCents: 1500,
    priceEnv: 'STRIPE_PRICE_ADDON_AI',
    metric: 'ai',
    amount: 500,
  },
  extra_syncs_500: {
    id: 'extra_syncs_500',
    name: '+500 sincronizaciones',
    description: '500 sincronizaciones automáticas más (Google Business, Places y Trustpilot).',
    priceCents: 600,
    priceEnv: 'STRIPE_PRICE_ADDON_SYNCS',
    metric: 'syncs',
    amount: 500,
  },
};

/** Catálogo de ampliaciones (todas de pago único, se consumen en el ciclo). */
export const ADDON_CATALOG: AddonPack[] = Object.values(ADDON_PACKS);


export function resolveAddonPack(id: string | null | undefined): AddonPack | null {
  if (!id) return null;
  const key = id.trim().toLowerCase() as AddonPackId;
  return ADDON_PACKS[key] ?? null;
}

export function formatEur(cents: number): string {
  return `${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2).replace('.', ',')} €`;
}

/* ------------------------------------------------------------------ */
/* Almacenamiento activo                                               */
/* ------------------------------------------------------------------ */

type StorageUsageInput = {
  reviewsStored: number;
  auditRows: number;
  integrations: number;
  /** Filas de `ai_interactions` retenidas (contabilidad de tokens). */
  aiRows?: number;
};

/** Estimación de MB activos de una empresa a partir de sus filas reales. */
export function estimateStorageMb(input: StorageUsageInput): number {
  const kb =
    input.reviewsStored * ROW_KB.review +
    input.auditRows * ROW_KB.audit +
    input.integrations * ROW_KB.integration +
    (input.aiRows ?? 0) * ROW_KB.aiInteraction;
  return Math.max(0, Math.round((kb / 1024) * 10) / 10);
}

