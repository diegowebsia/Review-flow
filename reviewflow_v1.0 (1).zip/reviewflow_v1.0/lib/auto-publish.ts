import type { AdminLike } from '@/lib/usage';
import { publishGoogleReplyForTenant } from '@/lib/google';
import { decryptCredentials } from '@/lib/credentials';
import { systemLog } from '@/lib/logger';

/**
 * Piloto automático de respuestas.
 *
 * Por defecto un humano revisa y pulsa "Publicar". Si la empresa activa
 * `settings.auto_publish`, cada reseña NUEVA (sin respuesta) con nota
 * >= `auto_publish_min_rating` se responde con IA y se publica sola, y
 * se avisa al dueño por email. Las reseñas por debajo de esa nota siguen
 * esperando revisión humana.
 */
const DEFAULT_AUTO_PUBLISH_MIN_RATING = 4;
/** Máximo de respuestas automáticas encoladas por cada importación. */
export const MAX_AUTO_PUBLISH_PER_INGEST = 20;

type AutoPublishConfig = { enabled: boolean; minRating: number };

export function autoPublishConfigOf(settings: unknown): AutoPublishConfig {
  const s = (settings && typeof settings === 'object' ? settings : {}) as {
    auto_publish?: unknown;
    auto_publish_min_rating?: unknown;
  };
  const raw = Number(s.auto_publish_min_rating);
  const minRating = Number.isInteger(raw) && raw >= 1 && raw <= 5 ? raw : DEFAULT_AUTO_PUBLISH_MIN_RATING;
  return { enabled: s.auto_publish === true, minRating };
}

export function shouldAutoPublish(cfg: AutoPublishConfig, rating: number): boolean {
  return cfg.enabled && rating >= cfg.minRating;
}

/**
 * Sube la respuesta a Google si la reseña es de Google y hay integración.
 * Compartido por la publicación manual y la automática.
 */
export async function pushReplyToGoogle(
  admin: AdminLike,
  review: { id: string; tenant_id: string; source: string | null; external_id: string | null },
  reply: string,
  logScope = 'reviews.publish',
): Promise<{ pushedToGoogle: boolean; googleError: string | null }> {
  if (review.source !== 'google' || !review.external_id) return { pushedToGoogle: false, googleError: null };
  try {
    const { data: integ } = await admin
      .from('integrations')
      .select('credentials')
      .eq('tenant_id', review.tenant_id)
      .eq('provider', 'google')
      .single();
    const creds = decryptCredentials<{ refresh_token?: string; access_token?: string }>(integ?.credentials);
    if (!creds.refresh_token && !creds.access_token) return { pushedToGoogle: false, googleError: null };
    const published = await publishGoogleReplyForTenant(
      { admin, tenantId: String(review.tenant_id) },
      { externalId: review.external_id, reply, credentials: creds },
    );
    if (published.ok) return { pushedToGoogle: true, googleError: null };
    await systemLog('warn', logScope, `Guardada pero no publicada en Google: ${published.error}`, {
      reviewId: review.id,
      code: published.code,
    });
    return { pushedToGoogle: false, googleError: published.error };
  } catch (e: unknown) {
    const msg = e instanceof Error && e.message ? e.message : 'Error desconocido publicando en Google';
    await systemLog('warn', logScope, `Guardada pero no publicada en Google: ${msg}`, { reviewId: review.id });
    return { pushedToGoogle: false, googleError: msg };
  }
}

function esc(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

/** Email de aviso al dueño tras una respuesta automática. */
export function autoPublishNotice(input: {
  authorName: string;
  rating: number;
  reviewText: string;
  reply: string;
  pushedToGoogle: boolean;
}): { subject: string; html: string; text: string } {
  const where = input.pushedToGoogle ? 'publicada en Google' : 'guardada en tu panel';
  const subject = `Respuesta automática ${where} · ${input.authorName} (${input.rating}★)`.slice(0, 140);
  const text =
    `El piloto automático ha respondido a una reseña nueva (${where}).\n\n` +
    `Reseña de ${input.authorName} (${input.rating}★):\n${input.reviewText}\n\n` +
    `Respuesta:\n${input.reply}\n\n` +
    `Puedes editarla o desactivar el piloto automático desde tu panel.`;
  const html =
    `<div style="font-family:sans-serif;max-width:560px;margin:0 auto;color:#0f172a;line-height:1.6;">` +
    `<p>El piloto automático ha respondido a una reseña nueva (<b>${where}</b>).</p>` +
    `<p><b>${esc(input.authorName)}</b> · ${input.rating}★<br/>${esc(input.reviewText.slice(0, 1500))}</p>` +
    `<p><b>Respuesta:</b><br/>${esc(input.reply)}</p>` +
    `<p style="color:#64748b;font-size:13px">Puedes editarla o desactivar el piloto automático desde tu panel.</p></div>`;
  return { subject, html: html.slice(0, 20000), text: text.slice(0, 20000) };
}
