/**
 * Lógica de negocio del webhook de Stripe (altas, cobros, cambios de plan,
 * recargas, fin de prueba e impagos). La ruta `app/api/stripe/webhook/route.ts`
 * solo verifica la firma, reclama el evento y delega aquí.
 */
import Stripe from 'stripe';
import { addonPackFromPriceId, planFromPriceId } from '@/lib/stripe';
import { currentCycle, planOf, resolveAddonPack, resolvePlan, type AddonPack, type PlanId } from '@/lib/plans';
import { env } from '@/lib/env';
import { createAdminClient } from '@/lib/supabase/admin';
import { systemLog } from '@/lib/logger';
import { sendMail } from '@/lib/mail';
import { renderTransactionalEmail } from '@/lib/transactional-emails';
import { trackProductEvent } from '@/lib/business-metrics';
import { recordFreeTrial } from '@/lib/trial';

type AdminClient = NonNullable<ReturnType<typeof createAdminClient>>;

function slugify(s: string) {
  return (
    s
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '')
      .slice(0, 40) || 'negocio'
  );
}

/**
 * Mapea el estado de Stripe al campo `subscription_status` del tenant.
 * Valores con acceso: solo `active` y `trialing` (vigente).
 * Sin acceso: `past_due` (impago), `inactive` (cancelada/finalizada),
 * `paused` (pausada por Stripe al fallar el cobro del día 8), `none`.
 */
function mapStripeStatus(s: Stripe.Subscription.Status): string {
  if (s === 'active') return 'active';
  if (s === 'trialing') return 'trialing';
  if (s === 'past_due') return 'past_due';
  if (s === 'incomplete') return 'past_due';
  if (s === 'paused') return 'paused';
  if (s === 'canceled' || s === 'unpaid' || s === 'incomplete_expired') return 'inactive';
  return 'none';
}

/** Plan de una suscripción o sesión de Checkout. */
function resolveSubPlan(priceId?: string | null, metaPlan?: string | null): PlanId {
  const byPrice = planFromPriceId(priceId);
  if (byPrice) return byPrice;
  if (metaPlan) return resolvePlan(metaPlan);
  return 'local_starter';
}

/* ------------------------------------------------------------------ */
/* Ampliaciones (pago único por ciclo)                                 */
/* ------------------------------------------------------------------ */

type AddonItem = { pack: AddonPack; quantity: number };

type PriceLike = { id?: string | null; product?: { metadata?: { addon?: string } } | string | null };

/** Extrae el key de la ampliación desde el metadata del producto (price_data inline). */
function productMetaAddon(price: PriceLike | Stripe.Price | null | undefined): string | null {
  if (!price || typeof price !== 'object') return null;
  const product = price.product;
  if (typeof product === 'object' && product && 'metadata' in product) {
    return (product as { metadata?: { addon?: string } }).metadata?.addon ?? null;
  }
  return null;
}

/** Mapea una línea de Checkout/factura a un pack del catálogo. */
function packFromLine(line: {
  price?: Stripe.Price | PriceLike | null | string;
}): AddonPack | null {
  const price = line.price;
  if (!price || typeof price !== 'object') return null;
  if (typeof price.id === 'string' && addonPackFromPriceId(price.id)) return addonPackFromPriceId(price.id)!;
  const metaAddon = productMetaAddon(price);
  return metaAddon ? (resolveAddonPack(metaAddon) ?? null) : null;
}

/** Líneas de ampliación compradas en una sesión de Checkout. */
function sessionAddonItems(session: Stripe.Checkout.Session): AddonItem[] {
  let metaItems: Array<{ key: string; quantity: number }> = [];
  try {
    const raw = (session.metadata as Record<string, string> | null)?.addons;
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        metaItems = parsed
          .filter(
            (x: unknown): x is { key: string; quantity?: unknown } =>
              Boolean(x) && typeof x === 'object' && typeof (x as { key?: unknown }).key === 'string',
          )
          .map((x) => ({
            key: String(x.key),
            quantity: Math.max(1, Math.min(10, Number(x.quantity) || 1)),
          }));
      }
    }
  } catch {
    /* metadata corrupta → nos apoyamos en el catálogo */
  }

  const items: AddonItem[] = [];
  for (const m of metaItems) {
    const pack = resolveAddonPack(m.key);
    if (pack) items.push({ pack, quantity: m.quantity });
  }

  // Fallback: sesiones creadas sin metadata (o reintentos antiguos).
  if (items.length === 0) {
    const lines = (
      session as unknown as {
        display_items?: Array<{ quantity?: number | null; price?: Stripe.Price | PriceLike | null | string }>;
      }
    ).display_items;
    for (const line of lines ?? []) {
      const pack = packFromLine(line);
      if (!pack) continue;
      items.push({ pack, quantity: Math.max(1, Math.min(10, Number(line.quantity ?? 1) || 1)) });
    }
  }
  return items;
}

/** Líneas de ampliación de una factura (compatibilidad con Stripe Billing). */
function invoiceAddonItems(invoice: Stripe.Invoice): AddonItem[] {
  const out: AddonItem[] = [];
  for (const line of (invoice.lines?.data ?? []) as Array<{ quantity?: number | null; price?: PriceLike | null }>) {
    const pack = packFromLine(line);
    if (!pack) continue;
    out.push({ pack, quantity: Math.max(1, Math.min(10, Number(line.quantity ?? 1) || 1)) });
  }
  return out;
}

/** Capacidad total aportada por un grupo de líneas. */
function aggregateAddonItems(items: AddonItem[]) {
  const totals = { requests: 0, reviews: 0, ai: 0, syncs: 0, units: 0 };
  for (const { pack, quantity } of items) {
    totals.units += quantity;
    totals[pack.metric] += pack.amount * quantity;
  }
  return totals;
}

/* ------------------------------------------------------------------ */
/* Suscripción base (trial 7 días con tarjeta)                         */
/* ------------------------------------------------------------------ */

export async function applyCheckoutCompleted(stripe: Stripe, session: Stripe.Checkout.Session) {
  const admin = createAdminClient();
  if (!admin) return;

  let userId = (session.metadata?.userId as string | undefined) ?? session.client_reference_id ?? null;
  const email = (session.customer_details?.email ?? session.customer_email)?.trim().toLowerCase() ?? null;
  const customerId = (session.customer as string) ?? null;
  const subscriptionId = (session.subscription as string) ?? null;
  if (!email) return;

  // Auto-aprovisionamiento Zero-Touch: si el comprador no viene con userId, buscar o crear su cuenta en Supabase Auth
  if (!userId) {
    try {
      let existing: { id: string } | undefined;
      const perPage = 1000;
      for (let page = 1; page <= 20; page += 1) {
        const { data: userList, error: listErr } = await (
          admin.auth.admin.listUsers as (params?: {
            page?: number;
            perPage?: number;
            email?: string;
          }) => Promise<{ data: { users: Array<{ id: string; email?: string }> } | null; error: unknown }>
        )({ page, perPage, email });
        if (listErr) break;
        const users = userList?.users ?? [];
        existing = users.find((u) => u.email?.toLowerCase() === email);
        if (existing || users.length < perPage) break;
      }

      if (existing) {
        userId = existing.id;
      } else {
        const fullName =
          session.customer_details?.name ||
          (session.metadata?.businessName as string | undefined) ||
          email.split('@')[0];
        const { data: newUser, error: createErr } = await admin.auth.admin.createUser({
          email,
          email_confirm: true,
          user_metadata: { full_name: fullName },
        });
        if (!createErr && newUser?.user) {
          userId = newUser.user.id;
          try {
            await admin.auth.admin.generateLink({ type: 'magiclink', email });
          } catch {
            /* ignore magiclink failure */
          }
        }
      }
    } catch (authErr: unknown) {
      const msg = authErr instanceof Error ? authErr.message : String(authErr);
      await systemLog('warn', 'stripe.webhook', `Auto-creación Auth fallback: ${msg}`, { email });
    }
  }

  let plan = resolveSubPlan(session.metadata?.priceId, session.metadata?.plan);
  let status = 'active';
  let trialEndsAt: string | null = null;

  if (subscriptionId) {
    try {
      const sub = await stripe.subscriptions.retrieve(subscriptionId);
      plan = resolveSubPlan(sub.items.data[0]?.price?.id, (sub.metadata?.plan as string) ?? null);
      const inTrial = sub.trial_end != null && sub.trial_end * 1000 > Date.now();
      status = inTrial ? 'trialing' : mapStripeStatus(sub.status);
      trialEndsAt = sub.trial_end ? new Date(sub.trial_end * 1000).toISOString() : null;
    } catch {
      /* seguimos con los valores por defecto */
    }
  }

  const tenantHint = (session.metadata?.tenantId as string | undefined) || null;
  const isNewBusiness = session.metadata?.newBusiness === 'true';
  const tenant = await findTenant(admin, tenantHint, userId, email, subscriptionId, isNewBusiness);
  if (status === 'trialing') {
    await recordFreeTrial(admin, { userId, email, tenantId: tenant?.id ?? null });
  }

  if (tenant) {
    const { error: updateErr } = await admin
      .from('tenants')
      .update({
        stripe_customer_id: customerId,
        stripe_subscription_id: subscriptionId,
        plan,
        subscription_status: status,
        trial_ends_at: trialEndsAt,
        suspended: false,
        ...(userId ? { owner_id: userId } : {}),
      })
      .eq('id', tenant.id);

    if (updateErr) {
      const legacyPlan = plan === 'ecommerce_starter' || plan === 'ecommerce_pro' ? 'business' : 'pro';
      await systemLog('error', 'stripe.webhook', `Plan ${plan} rechazado por la base de datos; guardado como ${legacyPlan}. Revisa las migraciones.`, {
        tenantId: tenant.id,
        error: updateErr.message,
      });
      await admin
        .from('tenants')
        .update({
          stripe_customer_id: customerId,
          stripe_subscription_id: subscriptionId,
          plan: legacyPlan,
          subscription_status: status,
          trial_ends_at: trialEndsAt,
          suspended: false,
          ...(userId ? { owner_id: userId } : {}),
        })
        .eq('id', tenant.id);
    }
    if (userId) {
      await admin
        .from('memberships')
        .upsert(
          { tenant_id: tenant.id, user_id: userId, role: 'owner' },
          { onConflict: 'tenant_id,user_id' },
        );
    }
    // Asegurar contadores del ciclo actual inicializados
    const cycle = currentCycle();
    await admin.from('usage_counters').upsert(
      {
        tenant_id: tenant.id,
        cycle,
        ai_responses: 0,
        whatsapp_sent: 0,
        reviews_ingested: 0,
        google_calls: 0,
      },
      { onConflict: 'tenant_id,cycle' },
    );

    await trackProductEvent('tenant_activated', {
      tenantId: tenant.id,
      userId: userId ?? undefined,
      email,
      plan,
      meta: { status },
    });

    const rendered = renderTransactionalEmail({
      kind: 'payment_confirmed',
      locale: (session.metadata?.locale as string) || 'es',
      tenantName: (session.metadata?.businessName as string) || email.split('@')[0],
      planName: planOf(plan).name,
      amountCents: session.amount_total ?? planOf(plan).priceCents,
    });
    await sendMail({
      to: email,
      subject: rendered.subject,
      html: rendered.html,
      text: rendered.text,
    }).catch(() => undefined);

    await systemLog('info', 'stripe.webhook', `Tenant actualizado a ${plan}/${status}`, {
      tenantId: tenant.id,
    });
    return;
  }

  const baseName = email.split('@')[0] ?? 'Mi negocio';
  const businessName =
    ((session.metadata?.businessName as string | undefined) || '').trim() ||
    session.customer_details?.name ||
    `Negocio de ${baseName}`;

  const slug = `${slugify(baseName)}-${Date.now().toString(36)}`;
  let { data: created, error } = await admin
    .from('tenants')
    .insert({
      name: businessName,
      slug,
      owner_id: userId,
      owner_email: email,
      plan,
      subscription_status: status,
      stripe_customer_id: customerId,
      stripe_subscription_id: subscriptionId,
      trial_ends_at: trialEndsAt,
    })
    .select('id')
    .single();

  if (error || !created) {
    const legacyPlan = plan === 'ecommerce_starter' || plan === 'ecommerce_pro' ? 'business' : 'pro';
    await systemLog('error', 'stripe.webhook', `Alta con plan ${plan} rechazada; reintento como ${legacyPlan}. Revisa las migraciones.`, {
      email,
      error: error?.message ?? 'sin datos',
    });
    const retry = await admin
      .from('tenants')
      .insert({
        name: businessName,
        slug: `${slug}-1`,
        owner_id: userId,
        owner_email: email,
        plan: legacyPlan,
        subscription_status: status,
        stripe_customer_id: customerId,
        stripe_subscription_id: subscriptionId,
        trial_ends_at: trialEndsAt,
      })
      .select('id')
      .single();
    created = retry.data;
    error = retry.error;
  }
  if (error || !created) throw new Error(`No se pudo crear el tenant: ${error?.message}`);

  // Multipanel: la suscripción queda atada a ESTA empresa para siempre.
  if (subscriptionId) {
    try {
      await stripe.subscriptions.update(subscriptionId, { metadata: { tenantId: created.id } });
    } catch {
      /* el vínculo por stripe_subscription_id ya basta */
    }
  }

  if (userId) {
    await admin.from('memberships').upsert(
      { tenant_id: created.id, user_id: userId, role: 'owner' },
      { onConflict: 'tenant_id,user_id' },
    );
  }

  // Inicializar contadores de consumo del ciclo actual para que la empresa esté 100% operativa
  const cycle = currentCycle();
  await admin.from('usage_counters').upsert(
    {
      tenant_id: created.id,
      cycle,
      ai_responses: 0,
      whatsapp_sent: 0,
      reviews_ingested: 0,
      google_calls: 0,
    },
    { onConflict: 'tenant_id,cycle' },
  );

  await trackProductEvent('tenant_activated', {
    tenantId: created.id,
    userId: userId ?? undefined,
    email,
    plan,
    meta: { status, autoCreated: true },
  });

  const rendered = renderTransactionalEmail({
    kind: 'payment_confirmed',
    locale: (session.metadata?.locale as string) || 'es',
    tenantName: businessName,
    planName: planOf(plan).name,
    amountCents: session.amount_total ?? planOf(plan).priceCents,
  });
  await sendMail({
    to: email,
    subject: rendered.subject,
    html: rendered.html,
    text: rendered.text,
  }).catch(() => undefined);

  await systemLog('info', 'stripe.webhook', `Tenant auto-creado para ${email} (${plan}/${status})`, {
    tenantId: created.id,
  });
}

async function findTenant(
  admin: AdminClient,
  tenantIdHint: string | null,
  userId: string | null,
  email: string,
  subscriptionId: string | null = null,
  isNewBusiness = false,
): Promise<{ id: string } | null> {
  // Idempotencia: si el webhook se reintenta, la empresa ya tiene esta suscripción.
  if (subscriptionId) {
    const { data } = await admin
      .from('tenants')
      .select('id')
      .eq('stripe_subscription_id', subscriptionId)
      .limit(1)
      .maybeSingle();
    if (data?.id) return { id: data.id as string };
  }
  if (tenantIdHint) {
    const { data } = await admin
      .from('tenants')
      .select('id')
      .eq('id', tenantIdHint)
      .limit(1)
      .maybeSingle();
    if (data?.id) return { id: data.id as string };
  }
  // Empresa adicional del multipanel: siempre se crea una nueva.
  if (isNewBusiness) return null;
  if (userId) {
    const { data: owned } = await admin
      .from('tenants')
      .select('id, stripe_subscription_id, subscription_status')
      .eq('owner_id', userId)
      .order('created_at', { ascending: true });
    const rows = (owned ?? []) as Array<{ id: string; stripe_subscription_id: string | null; subscription_status: string | null }>;
    if (rows.length === 1) return { id: rows[0].id };
    if (rows.length > 1) {
      // Multipanel sin tenantId: nunca reasignar una suscripción viva de otra
      // empresa. Solo se elige automáticamente si hay UNA empresa sin suscripción activa.
      const free = rows.filter(
        (t) => !t.stripe_subscription_id || ['canceled', 'inactive', 'incomplete_expired'].includes(t.subscription_status ?? ''),
      );
      const pick = free.length === 1 ? free[0] : (free[0] ?? null);
      await systemLog(free.length === 1 ? 'warn' : 'error', 'stripe.webhook', 'Suscripción sin tenantId en cuenta multipanel', {
        userId,
        subscriptionId,
        candidates: rows.length,
        chosen: pick?.id ?? null,
      });
      if (pick) return { id: pick.id };
      throw new Error('Cuenta multipanel sin tenantId y sin empresa libre: asignación manual necesaria.');
    }
  }
  const { data } = await admin
    .from('tenants')
    .select('id')
    .eq('owner_email', email)
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();
  return data?.id ? { id: data.id as string } : null;
}

/* ------------------------------------------------------------------ */
/* Recargas de cuota (pago único)                                      */
/* ------------------------------------------------------------------ */

export async function applyAddonPurchase(session: Stripe.Checkout.Session) {
  const admin = createAdminClient();
  if (!admin) return;

  const tenantId = session.metadata?.tenantId ?? session.client_reference_id ?? null;
  if (!tenantId) {
    await systemLog('warn', 'stripe.addon', 'Checkout de recarga sin tenantId en metadata', {
      session: session.id,
    });
    return;
  }

  const items = sessionAddonItems(session);
  if (items.length === 0) {
    await systemLog('warn', 'stripe.addon', 'Checkout de recarga sin líneas reconocibles', {
      session: session.id,
    });
    return;
  }

  await grantAddon(admin, {
    tenantId,
    items,
    paymentId: session.id,
    invoiceId: (session.invoice as string | null) ?? null,
    cycle: session.metadata?.cycle ?? currentCycle(),
    totalCents: session.amount_total ?? null,
  });
}

/** Factura pagada: aplica recargas facturadas y refresca el estado de la suscripción. */
export async function applyInvoicePaid(stripe: Stripe, invoice: Stripe.Invoice) {
  const admin = createAdminClient();
  if (!admin) return;

  const items = invoiceAddonItems(invoice);
  if (items.length > 0) {
    const tenantId = await tenantIdFromInvoice(admin, stripe, invoice);
    if (tenantId) {
      await grantAddon(admin, {
        tenantId,
        items,
        paymentId: (invoice.payment_intent as string | null) ?? invoice.id,
        invoiceId: invoice.id,
        cycle: currentCycle(),
        totalCents: invoice.amount_paid ?? null,
      });
    } else {
      await systemLog('warn', 'stripe.addon', 'Factura de recarga sin empresa asociada', {
        invoice: invoice.id,
      });
    }
  }

  const subscriptionId =
    typeof invoice.subscription === 'string' ? invoice.subscription : (invoice.subscription?.id ?? null);

  if (subscriptionId) {
    try {
      let sub = await stripe.subscriptions.retrieve(subscriptionId);
      // Renovación: se aplica la bajada de plan programada.
      const pendingPlan = sub.metadata?.pending_downgrade_plan as string | undefined;
      if (pendingPlan && invoice.billing_reason === 'subscription_cycle') {
        const meta: Record<string, string> = { ...(sub.metadata ?? {}), plan: resolvePlan(pendingPlan) };
        meta.pending_downgrade_plan = '';
        meta.pending_downgrade_until = '';
        sub = await stripe.subscriptions.update(subscriptionId, { metadata: meta });
        const { data: rows } = await admin
          .from('tenants')
          .select('id, settings')
          .eq('stripe_subscription_id', subscriptionId);
        for (const row of rows ?? []) {
          const settings = { ...((row.settings as Record<string, unknown> | null) ?? {}) };
          settings.scheduled_downgrade_plan = null;
          settings.scheduled_downgrade_at = null;
          await admin.from('tenants').update({ plan: resolvePlan(pendingPlan), settings }).eq('id', row.id);
        }
      }
      await applySubscriptionChange(stripe, sub, false);
    } catch {
      // Multipanel: solo se reactiva la empresa de ESTA suscripción, nunca todas las del cliente.
      await admin
        .from('tenants')
        .update({ subscription_status: 'active', suspended: false })
        .eq('stripe_subscription_id', subscriptionId);
    }
  }
}

async function tenantIdFromInvoice(
  admin: AdminClient,
  stripe: Stripe,
  invoice: Stripe.Invoice,
): Promise<string | null> {
  const metaTenant = (invoice.metadata as Record<string, string> | null)?.tenantId;
  if (metaTenant) return metaTenant;

  const subscriptionId =
    typeof invoice.subscription === 'string' ? invoice.subscription : (invoice.subscription?.id ?? null);
  if (subscriptionId) {
    const { data } = await admin
      .from('tenants')
      .select('id')
      .eq('stripe_subscription_id', subscriptionId)
      .limit(1)
      .maybeSingle();
    if (data?.id) return data.id as string;
  }
  const customerId = (invoice.customer as string | null) ?? null;
  if (customerId) {
    const only = await soleTenantOfCustomer(admin, customerId);
    if (only) return only;
  }
  if (typeof invoice.payment_intent === 'string' && invoice.payment_intent) {
    try {
      const pi = await stripe.paymentIntents.retrieve(invoice.payment_intent);
      const t = pi.metadata?.tenantId;
      if (t) return t;
    } catch {
      /* ignore */
    }
  }
  return null;
}

/**
 * Suma la capacidad comprada al ciclo en curso:
 *  · Ledger `addons` (una fila por línea, auditable e idempotente).
 *  · Campos rápidos `tenants.extra_*` (los lee `lib/usage.ts`).
 * Mapeo de columnas del ledger (compatibilidad con v1.0):
 *   requests → `whatsapp` · syncs → `events` · reviews → `reviews` · ai → `ai`.
 */
async function grantAddon(
  admin: AdminClient,
  input: {
    tenantId: string;
    items: AddonItem[];
    paymentId: string;
    invoiceId: string | null;
    cycle: string;
    totalCents: number | null;
  },
) {
  const { tenantId, items, paymentId, invoiceId, cycle, totalCents } = input;

  const totals = aggregateAddonItems(items);
  const unitCents = totalCents && totalCents > 0 && totals.units > 0 ? Math.round(totalCents / totals.units) : null;
  const rows = Array.from(new Map(items.map((item) => [item.pack.id, item])).values()).map(({ pack, quantity }) => ({
    pack: pack.id,
    events: pack.metric === 'syncs' ? pack.amount * quantity : 0,
    reviews: pack.metric === 'reviews' ? pack.amount * quantity : 0,
    ai: pack.metric === 'ai' ? pack.amount * quantity : 0,
    whatsapp: pack.metric === 'requests' ? pack.amount * quantity : 0,
    quantity,
  }));
  const { data: applied, error: grantError } = await admin.rpc('apply_addon_purchase', {
    p_tenant_id: tenantId, p_payment_id: paymentId, p_invoice_id: invoiceId,
    p_cycle: cycle, p_total_cents: unitCents, p_items: rows,
    p_requests: totals.requests, p_reviews: totals.reviews, p_ai: totals.ai, p_syncs: totals.syncs,
  });
  if (grantError) throw new Error(`No se pudo aplicar la recarga: ${grantError.message}`);
  if (!applied) {
    await systemLog('info', 'stripe.addon', 'Recarga ya aplicada (evento reintentado)', { tenantId, paymentId });
    return;
  }
  const { data: tenant, error: tenantError } = await admin.from('tenants')
    .select('owner_email, name').eq('id', tenantId).single();
  if (tenantError) throw tenantError;

  const label = items.map((i) => `${i.pack.name}×${i.quantity}`).join(' + ');
  await systemLog('info', 'stripe.addon', `Recarga aplicada: ${label} · ciclo ${cycle}`, {
    tenantId,
    paymentId,
  });

  if (tenant?.owner_email) {
    const summary = [
      totals.requests > 0 ? `+${totals.requests.toLocaleString('es-ES')} peticiones` : '',
      totals.reviews > 0 ? `+${totals.reviews.toLocaleString('es-ES')} opiniones` : '',
      totals.ai > 0 ? `+${totals.ai.toLocaleString('es-ES')} respuestas IA` : '',
      totals.syncs > 0 ? `+${totals.syncs.toLocaleString('es-ES')} sincronizaciones` : '',
    ]
      .filter(Boolean)
      .join(' · ');
    await sendMail({
      to: tenant.owner_email,
      subject: `Ampliación confirmada · ${label}`,
      text:
        `Hola,\n\nHemos recibido tu pago: ${label} para ${tenant.name ?? 'tu empresa'}.\n` +
        `Capacidad activada: ${summary}. Ya está disponible en tu panel.\n\n` +
        `Puedes ver el consumo actualizado en tu panel → «Facturación y cuota».\n\n` +
        `Gracias por confiar en ReviewFlow AI.`,
      html:
        `<p>Hola,</p><p>Hemos recibido tu pago: <strong>${label}</strong> para ` +
        `<strong>${tenant.name ?? 'tu empresa'}</strong>.</p>` +
        `<p>Capacidad activada: <strong>${summary}</strong>. Ya está disponible en tu panel.</p>` +
        `<p>Puedes ver el consumo actualizado en tu panel → <em>Facturación y cuota</em>.</p>` +
        `<p>Gracias por confiar en ReviewFlow AI.</p>`,
    }).catch(() => ({ sent: false, message: 'mail failed' }));
  }
}

/* ------------------------------------------------------------------ */
/* Cambios de suscripción y cortes de acceso                           */
/* ------------------------------------------------------------------ */

export async function applySubscriptionChange(stripe: Stripe, sub: Stripe.Subscription, deleted: boolean) {
  const admin = createAdminClient();
  if (!admin) return;

  const priceIds = sub.items.data.map((i) => i.price?.id).filter(Boolean) as string[];
  const basePrice = priceIds.find((id) => !addonPackFromPriceId(id)) ?? priceIds[0];
  const inTrial = !deleted && sub.trial_end != null && sub.trial_end * 1000 > Date.now();
  // CORTE INMEDIATO: la baja marca `inactive` en el acto (sin acceso).
  const status = deleted ? 'inactive' : inTrial ? 'trialing' : mapStripeStatus(sub.status);

  const patch: Record<string, unknown> = {
    subscription_status: status,
    trial_ends_at: sub.trial_end ? new Date(sub.trial_end * 1000).toISOString() : null,
  };

  // El plan solo se cambia si la línea base es un plan conocido. Si ya no hay
  // suscripción de pago (baja), se CONSERVA el último plan de pago contratado
  // (no hay plan gratuito al que volver): al reactivar se restaura tal cual.
  const plan = resolveSubPlan(basePrice, (sub.metadata?.plan as string) ?? null);
  if (deleted || status === 'inactive') {
    patch.stripe_subscription_id = null;
  } else {
    // Bajada programada: se mantiene el plan actual hasta la renovación.
    const pendingPlan = sub.metadata?.pending_downgrade_plan as string | undefined;
    const pendingUntil = Number(sub.metadata?.pending_downgrade_until ?? 0);
    const downgradePending = Boolean(pendingPlan) && pendingUntil * 1000 > Date.now();
    const knownPlan = (basePrice && planFromPriceId(basePrice)) || sub.metadata?.plan;
    if (knownPlan && !downgradePending) patch.plan = plan;
  }

  const { data: updatedBySub, error } = await admin
    .from('tenants')
    .update(patch)
    .eq('stripe_subscription_id', sub.id)
    .select('id');

  if (error || !updatedBySub || updatedBySub.length === 0) {
    if (error) {
      await systemLog('error', 'stripe.webhook', `No se pudo actualizar ${sub.id}: ${error.message}`);
    }
    // Fallback por customer id (cuando no hubo match por stripe_subscription_id o la suscripción se recreó).
    // Multipanel: varias empresas comparten cliente, así que solo usamos el tenantId de la
    // suscripción o, si el cliente tiene UNA sola empresa, esa.
    const customerId = typeof sub.customer === 'string' ? sub.customer : (sub.customer?.id ?? null);
    const metaTenant = (sub.metadata?.tenantId as string | undefined) || null;
    const targetId = metaTenant || (customerId ? await soleTenantOfCustomer(admin, customerId) : null);
    if (targetId && !deleted && status !== 'inactive') {
      const fallbackPatch: Record<string, unknown> = { ...patch, stripe_subscription_id: sub.id };
      await admin.from('tenants').update(fallbackPatch).eq('id', targetId);
    }
  }

  if (deleted || status === 'past_due' || status === 'inactive' || status === 'paused') {
    await systemLog('warn', 'stripe.webhook', `Acceso cortado (${status})`, { subscription: sub.id });
  } else {
    await systemLog('info', 'stripe.webhook', `Suscripción ${sub.id} → ${status}`, {
      subscription: sub.id,
    });
  }
}

/** Recordatorio antes del fin del trial con resumen de valor generado (reseñas gestionadas y horas ahorradas) en el idioma del tenant. */
export async function applyTrialWillEnd(sub: Stripe.Subscription) {
  const admin = createAdminClient();
  if (!admin) return;
  const { data } = await admin
    .from('tenants')
    .select('id, owner_email, name, plan, locale, settings')
    .eq('stripe_subscription_id', sub.id)
    .single();
  if (!data?.owner_email) return;

  const { count: reviewsCount } = await admin
    .from('reviews')
    .select('id', { count: 'exact', head: true })
    .eq('tenant_id', data.id);
  const managedReviews = Math.max(1, reviewsCount ?? 0);
  const hoursSaved = Math.max(1, Math.round(((managedReviews * 7) / 60) * 10) / 10);

  const tenantRow = data as {
    id: string;
    owner_email?: string | null;
    name: string;
    plan: string;
    locale?: string | null;
    settings?: { locale?: string } | null;
  };
  const settings = tenantRow.settings ?? {};
  const tenantLocale = (tenantRow.locale || settings.locale || 'es') as Parameters<
    typeof renderTransactionalEmail
  >[0]['locale'];
  const rendered = renderTransactionalEmail({
    kind: 'trial_expiring',
    locale: tenantLocale,
    tenantName: tenantRow.name,
    planName: planOf(tenantRow.plan).name,
    amountCents: planOf(tenantRow.plan).priceCents,
    trialEndDate: sub.trial_end ? new Date(sub.trial_end * 1000) : new Date(Date.now() + 3 * 86_400_000),
    reviewsCount: managedReviews,
    hoursSaved,
  });

  await sendMail({
    to: data.owner_email,
    subject: rendered.subject,
    text: rendered.text,
    html: rendered.html,
  }).catch(() => ({ sent: false, message: 'mail failed' }));
}

/**
 * Pago fallido → `past_due` con **3 días de periodo de gracia (dunning)** (`grace_period_ends_at`).
 * Evita bajas involuntarias: no corta el acceso en el primer intento fallido, activa un banner en
 * el panel y lanza secuencia de 3 avisos escalonados + Stripe Smart Retries.
 */
export async function applyPaymentFailed(invoice: Stripe.Invoice) {
  const admin = createAdminClient();
  if (!admin) return;
  const customerId = invoice.customer as string | null;
  const subscriptionId =
    typeof invoice.subscription === 'string'
      ? invoice.subscription
      : ((invoice.subscription as { id?: string } | null)?.id ?? null);
  if (!customerId && !subscriptionId) return;

  let tenantId: string | null = null;
  if (subscriptionId) {
    const { data } = await admin
      .from('tenants')
      .select('id')
      .eq('stripe_subscription_id', subscriptionId)
      .limit(1)
      .maybeSingle();
    tenantId = (data?.id as string) ?? null;
  }
  if (!tenantId && customerId) {
    tenantId = await soleTenantOfCustomer(admin, customerId);
  }
  if (!tenantId) {
    await systemLog('warn', 'stripe.webhook', 'Pago fallido sin empresa asociada', {
      customer: customerId,
      invoice: invoice.id,
    });
    return;
  }

  const gracePeriodEndsAt = new Date(Date.now() + 3 * 86_400_000).toISOString();
  const attemptCount = Math.max(1, Number(invoice.attempt_count ?? 1));

  // Intentamos guardar grace_period_ends_at (con fallback limpio si la migración aún no se ejecutó en BD)
  const { error } = await admin
    .from('tenants')
    .update({
      subscription_status: 'past_due',
      grace_period_ends_at: gracePeriodEndsAt,
    } as Record<string, unknown>)
    .eq('id', tenantId);

  if (error) {
    const { error: fallbackErr } = await admin
      .from('tenants')
      .update({ subscription_status: 'past_due' })
      .eq('id', tenantId);
    if (fallbackErr) {
      await systemLog('error', 'stripe.webhook', `No se pudo marcar past_due: ${fallbackErr.message}`, {
        tenantId,
      });
      return;
    }
  }
  await systemLog('warn', 'stripe.webhook', `Pago fallido → past_due con 3 días de gracia (intento ${attemptCount}/3)`, {
    tenantId,
    customer: customerId,
    invoice: invoice.id,
    gracePeriodEndsAt,
  });

  // Notificar inmediatamente al cliente en su idioma (Secuencia Dunning 1/3, 2/3 o 3/3) con enlace para SCA / 3DS o cambio de tarjeta
  const { data: rawTenantData } = await admin
    .from('tenants')
    .select('owner_email, name, locale, settings')
    .eq('id', tenantId)
    .single();
  const tenantData = rawTenantData as {
    owner_email?: string | null;
    name?: string | null;
    locale?: string | null;
    settings?: { locale?: string } | null;
  } | null;

  if (tenantData?.owner_email) {
    const hostedUrl = invoice.hosted_invoice_url || `${env.appUrl}/api/stripe/portal`;
    const businessName = tenantData.name || 'tu empresa';
    const settings = tenantData.settings ?? {};
    const tenantLocale = (tenantData.locale || settings.locale || 'es') as Parameters<
      typeof renderTransactionalEmail
    >[0]['locale'];
    const rendered = renderTransactionalEmail({
      kind: 'payment_failed',
      locale: tenantLocale,
      tenantName: businessName,
      amountCents: invoice.amount_due || undefined,
      attemptCount,
      graceEndDate: gracePeriodEndsAt,
      invoiceUrl: hostedUrl,
    });

    await sendMail({
      to: tenantData.owner_email,
      subject: rendered.subject,
      text: rendered.text,
      html: rendered.html,
    }).catch((err) => {
      systemLog('error', 'stripe.webhook', `Error enviando email de pago fallido: ${err?.message}`);
    });
  }
}


/** Devuelve la empresa del cliente de Stripe solo si es la ÚNICA (evita tocar otras empresas del multipanel). */
async function soleTenantOfCustomer(admin: AdminClient, customerId: string): Promise<string | null> {
  const { data } = await admin.from('tenants').select('id').eq('stripe_customer_id', customerId).limit(2);
  const rows = (data ?? []) as Array<{ id: string }>;
  return rows.length === 1 ? rows[0].id : null;
}
