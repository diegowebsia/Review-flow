/**
 * ============================================================
 * Programador interno (sustituye a Vercel Cron en cualquier host)
 * ============================================================
 * Si ENABLE_INTERNAL_CRON=true, el propio servidor Node llama a sus
 * endpoints /api/cron/* con `Authorization: Bearer CRON_SECRET`.
 * Así no dependes de Vercel, QStash ni de un cron externo de pago.
 *
 * Desactívalo (false) en Vercel o si usas varias réplicas: en ese caso
 * usa vercel.json, pg_cron o un cron externo gratuito (cron-job.org).
 */

type Job = { path: string; matches: (d: Date) => boolean };

const JOBS: Job[] = [
  // Cada hora en el minuto 7 (igual que vercel.json)
  { path: '/api/cron/sync-reviews', matches: (d) => d.getUTCMinutes() === 7 },
  // Lunes 08:00 UTC
  {
    path: '/api/cron/weekly-digest',
    matches: (d) => d.getUTCDay() === 1 && d.getUTCHours() === 8 && d.getUTCMinutes() === 0,
  },
  // Diario 09:30 UTC
  {
    path: '/api/cron/abandoned-trial',
    matches: (d) => d.getUTCHours() === 9 && d.getUTCMinutes() === 30,
  },
];

let started = false;

export function startInternalCron(): void {
  if (started) return;
  if (process.env.ENABLE_INTERNAL_CRON !== 'true') return;
  const secret = process.env.CRON_SECRET?.trim();
  if (!secret) {
    console.warn('[cron] ENABLE_INTERNAL_CRON=true pero falta CRON_SECRET; programador desactivado.');
    return;
  }
  started = true;
  const port = process.env.PORT || '3000';
  const base = `http://127.0.0.1:${port}`;
  let lastMinute = -1;

  const tick = async () => {
    const now = new Date();
    const minuteKey = Math.floor(now.getTime() / 60000);
    if (minuteKey === lastMinute) return;
    lastMinute = minuteKey;
    for (const job of JOBS) {
      if (!job.matches(now)) continue;
      try {
        const res = await fetch(base + job.path, {
          method: 'GET',
          headers: { Authorization: `Bearer ${secret}` },
          signal: AbortSignal.timeout(120_000),
        });
        console.log(`[cron] ${job.path} -> ${res.status}`);
      } catch (err) {
        console.error(`[cron] ${job.path} falló:`, err instanceof Error ? err.message : err);
      }
    }
  };

  const timer = setInterval(() => void tick(), 20_000);
  timer.unref?.();
  console.log('[cron] Programador interno activo (sync horario, digest semanal, trials diarios).');
}
