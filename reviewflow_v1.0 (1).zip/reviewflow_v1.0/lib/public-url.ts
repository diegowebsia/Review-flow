/**
 * ÚNICA fuente de verdad para la URL pública de ReviewFlow.
 *
 * Todo enlace absoluto (QR, carteles, emails, OAuth de Google, Stripe
 * success/cancel/portal, webhooks salientes, sitemap, robots, metadata)
 * DEBE construirse con `publicUrl()` / `resolvePublicUrl()`.
 * El test `tests/public-url.test.ts` falla si alguien vuelve a leer
 * `NEXT_PUBLIC_APP_URL` o cabeceras `x-forwarded-*` fuera de este archivo.
 *
 * Orden de prioridad (el primero válido y no-localhost gana):
 *   1. PUBLIC_APP_URL            (configuración en ejecución, sin reconstruir)
 *   2. NEXT_PUBLIC_APP_URL / APP_URL
 *   3. NEXT_PUBLIC_DOMAIN        (→ https://dominio)
 *   4. Plataforma: VERCEL_PROJECT_PRODUCTION_URL, VERCEL_URL, RENDER_EXTERNAL_URL,
 *      RAILWAY_PUBLIC_DOMAIN, FLY_APP_NAME (.fly.dev), URL (Netlify), COOLIFY_URL
 *   5. Cabeceras de la petición (proxy inverso / Cloud Run / preview),
 *      solo si no hay URL configurada y filtradas por ALLOWED_HOSTS si existe.
 *   6. http://localhost:3000
 */

type EnvLike = Record<string, string | undefined>;
type HeaderSource = Request | Headers | { get(name: string): string | null } | null | undefined;

/**
 * Next.js solo inyecta NEXT_PUBLIC_* en el navegador con lecturas estáticas,
 * así que el entorno por defecto las referencia explícitamente.
 */
function defaultEnv(): EnvLike {
  return {
    ...(typeof process !== 'undefined' ? process.env : {}),
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    NEXT_PUBLIC_DOMAIN: process.env.NEXT_PUBLIC_DOMAIN,
  };
}

const LOCAL_FALLBACK = 'http://localhost:3000';
const LOCAL_HOST_RE = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\])(:\d+)?$/i;
const HOST_RE = /^[a-z0-9.-]+(:\d{1,5})?$/i;

function clean(raw?: string): string {
  if (!raw) return '';
  const v = raw.trim().replace(/^["']|["']$/g, '').trim();
  if (!v || v.includes('[') || v.includes('placeholder') || v === 'https://invalid.example') return '';
  return v;
}

/** Normaliza "dominio.com", "https://dominio.com/", "http://x:3000/path" → origen sin barra final. */
export function normalizeOrigin(raw?: string, defaultProto = 'https'): string {
  const v = clean(raw);
  if (!v) return '';
  try {
    const u = new URL(/^https?:\/\//i.test(v) ? v : `${defaultProto}://${v}`);
    if (!HOST_RE.test(u.host)) return '';
    return u.origin;
  } catch {
    return '';
  }
}

function isLocalOrigin(origin: string): boolean {
  try {
    return LOCAL_HOST_RE.test(new URL(origin).host);
  } catch {
    return false;
  }
}

function platformOrigin(env: EnvLike): string {
  const candidates = [
    env.VERCEL_PROJECT_PRODUCTION_URL,
    env.VERCEL_URL,
    env.RENDER_EXTERNAL_URL,
    env.RAILWAY_PUBLIC_DOMAIN,
    env.FLY_APP_NAME ? `${env.FLY_APP_NAME}.fly.dev` : undefined,
    env.URL, // Netlify
    env.COOLIFY_URL?.split(',')[0],
  ];
  for (const c of candidates) {
    const o = normalizeOrigin(c);
    if (o && !isLocalOrigin(o)) return o;
  }
  return '';
}

/** URL configurada (env + plataforma). Devuelve '' si solo hay localhost. */
export function configuredPublicUrl(env: EnvLike = defaultEnv()): string {
  for (const raw of [env.PUBLIC_APP_URL, env.NEXT_PUBLIC_APP_URL, env.APP_URL, env.NEXT_PUBLIC_DOMAIN]) {
    const o = normalizeOrigin(raw);
    if (o && !isLocalOrigin(o)) return o;
  }
  return platformOrigin(env);
}

/** URL pública sin petición (crons, emails, workers, sitemap). */
export function resolvePublicUrlFromEnv(env: EnvLike = defaultEnv()): string {
  return (
    configuredPublicUrl(env) ||
    normalizeOrigin(env.PUBLIC_APP_URL, 'http') ||
    normalizeOrigin(env.NEXT_PUBLIC_APP_URL, 'http') ||
    normalizeOrigin(env.APP_URL, 'http') ||
    LOCAL_FALLBACK
  );
}

function allowedHosts(env: EnvLike): string[] {
  return clean(env.ALLOWED_HOSTS)
    .split(',')
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
}

function hostAllowed(host: string, env: EnvLike): boolean {
  if (!HOST_RE.test(host) || LOCAL_HOST_RE.test(host)) return false;
  const list = allowedHosts(env);
  if (list.length === 0) return true;
  const bare = host.toLowerCase().replace(/:\d+$/, '');
  return list.some((h) => h === bare || h === host.toLowerCase() || (h.startsWith('*.') && bare.endsWith(h.slice(1))));
}

function getHeaders(src: HeaderSource): { get(name: string): string | null } | null {
  if (!src) return null;
  if (typeof Request !== 'undefined' && src instanceof Request) return src.headers;
  return src as { get(name: string): string | null };
}

/**
 * URL pública para una petición concreta. Si hay URL configurada, SIEMPRE
 * gana (evita inyección de cabecera Host en enlaces de pago/OAuth/emails).
 */
export function resolvePublicUrl(src?: HeaderSource, env: EnvLike = defaultEnv()): string {
  const configured = configuredPublicUrl(env);
  if (configured) return configured;

  const h = getHeaders(src);
  if (h) {
    const first = (name: string) => h.get(name)?.split(',')[0]?.trim() ?? '';
    const forwarded = first('forwarded'); // RFC 7239: host=...;proto=...
    const fHost = /host="?([^;",]+)/i.exec(forwarded)?.[1] ?? '';
    const fProto = /proto="?(https?)/i.exec(forwarded)?.[1] ?? '';
    const proto = (first('x-forwarded-proto') || fProto || 'https').toLowerCase() === 'http' ? 'http' : 'https';
    for (const host of [first('x-forwarded-host'), fHost, first('host')]) {
      if (host && hostAllowed(host, env)) return `${proto}://${host.toLowerCase()}`;
    }
  }
  if (typeof Request !== 'undefined' && src instanceof Request) {
    try {
      const o = new URL(src.url).origin;
      if (o !== 'null' && !isLocalOrigin(o) && hostAllowed(new URL(o).host, env)) return o;
    } catch {
      /* ignore */
    }
  }
  return resolvePublicUrlFromEnv(env);
}

/** Construye una URL absoluta pública: publicUrl('/valorar/x', req). */
export function publicUrl(path = '/', src?: HeaderSource, env: EnvLike = defaultEnv()): string {
  const base = src == null ? resolvePublicUrlFromEnv(env) : resolvePublicUrl(src, env);
  return new URL(path.startsWith('/') ? path : `/${path}`, `${base}/`).toString();
}

/** Redirect URI fija de Google OAuth (debe coincidir con Google Cloud Console). */
export function googleOAuthRedirectUri(env: EnvLike = defaultEnv()): string {
  return publicUrl('/api/integrations/google/callback', undefined, env);
}

/**
 * Origen en el navegador. Usa el origen real de la pestaña (preview, dominio
 * temporal o definitivo) y cae en la URL configurada en SSR.
 */
export function browserOrigin(): string {
  if (typeof window !== 'undefined' && window.location?.origin) return window.location.origin;
  return resolvePublicUrlFromEnv();
}
