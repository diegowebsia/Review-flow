import crypto from 'node:crypto';
import nodemailer from 'nodemailer';
import { z } from 'zod';
import { env, isSmtpConfigured } from '@/lib/env';
import { errorMessage } from '@/lib/api-error';

export const SendMailInputSchema = z.object({
  to: z.string().trim().min(3),
  subject: z.string().trim().min(1),
  html: z.string().min(1),
  text: z.string().optional(),
  replyTo: z.string().optional(),
});

type SendMailInput = z.infer<typeof SendMailInputSchema>;

/**
 * Convierte HTML básico en texto plano limpio para evitar penalizaciones por falta de multipart/alternative.
 */
function stripHtmlToText(html: string): string {
  return html
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<a\s+(?:[^>]*?\s+)?href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '$2 ($1)')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<\/div>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Extrae el dominio de remitente para generar Message-ID conforme a RFC 5322.
 */
function extractDomain(fromStr: string): string {
  const match = fromStr.match(/@([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  if (match) return match[1];
  try {
    return new URL(env.appUrl).hostname;
  } catch {
    return 'reviewflow.ai';
  }
}

/**
 * Envío SMTP con cabeceras anti-spam (RFC 5322, List-Unsubscribe, Reply-To garantizado,
 * cuerpo dual HTML + PlainText y formato estándar).
 */
export async function sendMail(input: SendMailInput): Promise<{ sent: boolean; message: string; messageId?: string }> {
  const plainText = input.text?.trim() || stripHtmlToText(input.html);
  const fromDomain = extractDomain(env.smtpFrom);
  const messageId = `<${Date.now()}.${crypto.randomBytes(8).toString('hex')}@${fromDomain}>`;
  const replyTo = input.replyTo || env.smtpFrom;

  if (!isSmtpConfigured) {
    return {
      sent: false,
      message: 'Servicio de correo pendiente de configuración (define RESEND_API_KEY o SMTP_PASS en .env). El registro se ha guardado correctamente.',
      messageId,
    };
  }

  // Si se proporciona RESEND_API_KEY directamente, usamos la API HTTPS oficial de Resend
  if (env.resendApiKey) {
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${env.resendApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: env.smtpFrom,
          to: [input.to],
          subject: input.subject,
          html: input.html,
          text: plainText,
          reply_to: replyTo,
          headers: {
            'X-Entity-Ref-ID': messageId,
            'List-Unsubscribe': `<mailto:${replyTo}?subject=Unsubscribe>`,
          },
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
      if (!res.ok) {
        return {
          sent: false,
          message: `El proveedor de email no pudo entregar el correo (${data?.message ?? `HTTP ${res.status}`}).`,
          messageId,
        };
      }
      return {
        sent: true,
        message: 'Email enviado correctamente vía Resend.',
        messageId: data.id || messageId,
      };
    } catch (err: unknown) {
      return {
        sent: false,
        message: `No se pudo conectar con el servicio de email (${errorMessage(err, 'error de red')}).`,
        messageId,
      };
    }
  }

  try {
    const transporter = nodemailer.createTransport({
      host: env.smtpHost,
      port: env.smtpPort,
      secure: env.smtpPort === 465,
      auth: { user: env.smtpUser, pass: env.smtpPass },
    });

    const info = await transporter.sendMail({
      from: env.smtpFrom,
      to: input.to,
      subject: input.subject,
      html: input.html,
      text: plainText,
      replyTo,
      messageId,
      headers: {
        'X-Mailer': 'ReviewFlow AI Mailer 3.13 (EU RGPD Compliant)',
        'List-Unsubscribe': `<mailto:${replyTo}?subject=Unsubscribe>`,
        'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
      },
    });

    return {
      sent: true,
      message: 'Email enviado con trazabilidad anti-spam.',
      messageId: info.messageId || messageId,
    };
  } catch (err: unknown) {
    return {
      sent: false,
      message: `El servidor SMTP no pudo enviar el correo (${errorMessage(err, 'revisa credenciales o saldo SMTP')}).`,
      messageId,
    };
  }
}
