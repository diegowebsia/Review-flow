/**
 * Google Maps — enlaces reales de «déjanos una reseña» por empresa.
 * La empresa pega su Place ID (ver GUIA_1_PROBAR_EN_LOCALHOST.md)
 * y el panel genera el enlace directo de valoración.
 */

/** Enlace directo a escribir reseña (requiere Place ID). */
export function googleReviewLink(placeId: string): string {
  return `https://search.google.com/local/writereview?placeid=${encodeURIComponent(placeId)}`;
}

