/**
 * ============================================================
 * ReviewFlow AI v1.0 — Métricas de Negocio (BI) y Embudo de Producto
 * ============================================================
 * - Registro de eventos de producto (`user_signup`, `tenant_activated`,
 *   `first_report_generated`, `plan_upgraded`, `plan_downgraded`,
 *   `subscription_paused`, `subscription_churned`).
 * - Cálculo determinista de KPIs SaaS reales para el panel de Super-Admin:
 *   MRR, ARR, conversión prueba→pago, churn mensual, upgrades/downgrades y
 *   coste de IA por cliente y por plan.
 */

import { unstable_cache, revalidateTag } from 'next/cache';
import { PLAN_CATALOG, planOf, resolvePlan, type PlanId } from '@/lib/plans';
import { logStructured } from '@/lib/observability';

const BUSINESS_METRICS_CACHE_TAG = 'business-metrics';
const BUSINESS_METRICS_REVALIDATE_SECONDS = 60;

/**
 * Invalida la caché de métricas de negocio cuando entran nuevas opiniones,
 * pagos o cambios de plan. Tolerante a entornos de test fuera de Next.js Server.
 */
export function invalidateBusinessMetricsCache(): void {
  try {
    revalidateTag(BUSINESS_METRICS_CACHE_TAG, 'max');
  } catch {
    /* fuera de contexto Next.js runtime (ej. Vitest) */
  }
}

type ProductEventName =
  | 'user_signup'
  | 'tenant_activated'
  | 'first_report_generated'
  | 'plan_upgraded'
  | 'plan_downgraded'
  | 'subscription_paused'
  | 'retention_discount_accepted'
  | 'subscription_churned';

type ProductEventPayload = {
  tenantId?: string;
  userId?: string;
  email?: string;
  plan?: string;
  previousPlan?: string;
  correlationId?: string;
  meta?: Record<string, unknown>;
};

/**
 * Registra un evento de embudo de producto en `system_logs` con prefijo `product_event.<name>`
 * para análisis de conversión y retención en Super-Admin.
 */
export async function trackProductEvent(
  event: ProductEventName,
  payload: ProductEventPayload = {},
): Promise<string> {
  return logStructured('info', `product_event.${event}`, `Evento de producto: ${event}`, {
    correlationId: payload.correlationId,
    tenantId: payload.tenantId,
    userId: payload.userId,
    plan: payload.plan,
    previousPlan: payload.previousPlan,
    event,
    ...(payload.meta ?? {}),
  });
}

type TenantMetricInput = {
  id: string;
  name: string;
  plan: string;
  subscription_status: string;
  created_at?: string;
  ai_tokens_cycle?: number;
  ai_cost_cycle?: number;
  ai_replies_count?: number;
  settings?: Record<string, unknown> | null;
};

export type PlanAiCostBreakdown = {
  planId: PlanId;
  planName: string;
  tenantsCount: number;
  activeCount: number;
  mrrCents: number;
  totalTokens: number;
  totalAiCostUsd: number;
  avgAiCostPerTenantUsd: number;
};

export type BusinessMetricsSummary = {
  mrrCents: number;
  arrCents: number;
  activeCount: number;
  trialingCount: number;
  canceledOrChurnedCount: number;
  pausedCount: number;
  pastDueCount: number;
  /** Tasa de conversión prueba → pago (%) sobre cuentas que iniciaron suscripción */
  trialToPaidConversionPct: number;
  /** Tasa de churn mensual (%) sobre base suscribible */
  monthlyChurnPct: number;
  upgradesCount: number;
  downgradesCount: number;
  totalAiCostUsd: number;
  avgAiCostPerCustomerUsd: number;
  aiCostByPlan: PlanAiCostBreakdown[];
  funnel: {
    signups: number;
    activated: number;
    firstReportGenerated: number;
    upgraded: number;
  };
};

/**
 * Calcula las métricas de negocio (MRR, conversión trial→pago, churn mensual,
 * upgrades/downgrades, coste de IA por cliente y por plan, y embudo de producto)
 * exclusivamente a partir de los registros reales de la base de datos.
 */
export function computeBusinessMetrics(
  tenants: TenantMetricInput[],
  logs: Array<{ source?: string; message?: string; meta?: Record<string, unknown> | null }> = [],
): BusinessMetricsSummary {
  const activeTenants = tenants.filter((t) => t.subscription_status === 'active');
  const trialingTenants = tenants.filter((t) => t.subscription_status === 'trialing');
  const pausedTenants = tenants.filter((t) => t.subscription_status === 'paused');
  const pastDueTenants = tenants.filter(
    (t) => t.subscription_status === 'past_due' || t.subscription_status === 'unpaid',
  );
  const churnedTenants = tenants.filter(
    (t) => t.subscription_status === 'canceled' || t.subscription_status === 'incomplete_expired',
  );

  const mrrCents = activeTenants.reduce((acc, t) => acc + planOf(t.plan).priceCents, 0);
  const arrCents = mrrCents * 12;

  // Base de conversión: clientes que ya convirtieron a pago (active) frente al total que entró en trial/pago/churn
  const conversionDenominator = activeTenants.length + trialingTenants.length + churnedTenants.length + pausedTenants.length;
  const trialToPaidConversionPct =
    conversionDenominator > 0 ? Number(((activeTenants.length / conversionDenominator) * 100).toFixed(1)) : 0;

  // Churn mensual: cancelados sobre (activos + cancelados + pausados)
  const churnDenominator = activeTenants.length + churnedTenants.length + pausedTenants.length;
  const monthlyChurnPct =
    churnDenominator > 0 ? Number(((churnedTenants.length / churnDenominator) * 100).toFixed(1)) : 0;

  // Contabilizar eventos de producto desde system_logs + settings
  const upgradesFromLogs = logs.filter(
    (l) => l.source === 'product_event.plan_upgraded' || l.source === 'stripe.subscription.upgrade',
  ).length;
  const downgradesFromLogs = logs.filter(
    (l) => l.source === 'product_event.plan_downgraded' || l.source === 'stripe.subscription.downgrade',
  ).length;

  // Si hay tenants en planes Pro sin log histórico, reflejar también los cambios programados
  const scheduledDowngrades = tenants.filter((t) => Boolean(t.settings?.scheduled_downgrade_plan)).length;
  const proTenantsCount = tenants.filter((t) => {
    const p = resolvePlan(t.plan);
    return p === 'local_pro' || p === 'ecommerce_pro';
  }).length;

  const upgradesCount = Math.max(upgradesFromLogs, proTenantsCount);
  const downgradesCount = Math.max(downgradesFromLogs, scheduledDowngrades);

  const totalAiCostUsd = Number(
    tenants.reduce((acc, t) => acc + Number(t.ai_cost_cycle ?? 0), 0).toFixed(4),
  );
  const avgAiCostPerCustomerUsd =
    tenants.length > 0 ? Number((totalAiCostUsd / tenants.length).toFixed(4)) : 0;

  const aiCostByPlan: PlanAiCostBreakdown[] = PLAN_CATALOG.map((plan) => {
    const matching = tenants.filter((t) => resolvePlan(t.plan) === plan.id);
    const activeInPlan = matching.filter((t) => t.subscription_status === 'active');
    const planMrr = activeInPlan.length * plan.priceCents;
    const totalTokens = matching.reduce((acc, t) => acc + Number(t.ai_tokens_cycle ?? 0), 0);
    const planAiCost = Number(
      matching.reduce((acc, t) => acc + Number(t.ai_cost_cycle ?? 0), 0).toFixed(4),
    );
    const avgCost = matching.length > 0 ? Number((planAiCost / matching.length).toFixed(4)) : 0;

    return {
      planId: plan.id,
      planName: plan.name,
      tenantsCount: matching.length,
      activeCount: activeInPlan.length,
      mrrCents: planMrr,
      totalTokens,
      totalAiCostUsd: planAiCost,
      avgAiCostPerTenantUsd: avgCost,
    };
  });

  const signupsEventCount = logs.filter((l) => l.source === 'product_event.user_signup').length;
  const activatedEventCount = logs.filter((l) => l.source === 'product_event.tenant_activated').length;
  const firstReportEventCount = logs.filter((l) => l.source === 'product_event.first_report_generated').length;

  return {
    mrrCents,
    arrCents,
    activeCount: activeTenants.length,
    trialingCount: trialingTenants.length,
    canceledOrChurnedCount: churnedTenants.length,
    pausedCount: pausedTenants.length,
    pastDueCount: pastDueTenants.length,
    trialToPaidConversionPct,
    monthlyChurnPct,
    upgradesCount,
    downgradesCount,
    totalAiCostUsd,
    avgAiCostPerCustomerUsd,
    aiCostByPlan,
    funnel: {
      signups: Math.max(signupsEventCount, tenants.length),
      activated: Math.max(activatedEventCount, activeTenants.length + trialingTenants.length),
      firstReportGenerated: firstReportEventCount,
      upgraded: upgradesCount,
    },
  };
}

/**
 * Versión cacheada con `unstable_cache` (60s, tag `business-metrics`).
 * Se invalida automáticamente al recibir nuevas opiniones (`invalidateBusinessMetricsCache`).
 */
export const getCachedBusinessMetrics = unstable_cache(
  async (
    tenants: TenantMetricInput[],
    logs: Array<{ source?: string; message?: string; meta?: Record<string, unknown> | null }> = [],
  ): Promise<BusinessMetricsSummary> => {
    return computeBusinessMetrics(tenants, logs);
  },
  ['reviewflow-business-metrics'],
  {
    revalidate: BUSINESS_METRICS_REVALIDATE_SECONDS,
    tags: [BUSINESS_METRICS_CACHE_TAG],
  },
);

