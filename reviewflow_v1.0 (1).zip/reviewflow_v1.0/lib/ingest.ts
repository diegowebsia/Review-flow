import type { PlanFeatures } from '@/lib/plans';
import {
  consume,
  enforce,
  enforceTableCap,
  type AdminLike,
} from '@/lib/usage';
import { systemLog } from '@/lib/logger';

type PlanFeaturesKey = keyof PlanFeatures;

/**
 * ============================================================
 * Ingesta unificada de reseñas externas
 * ============================================================
 * Google Business, Google Places, Trustpilot y la API pública
 * comparten este único camino para que el corte de cuota sea idéntico en todos:
 * cada reseña importada consume 1 evento de la métrica `reviews`.
 */

type IncomingReview = {
  externalId: string;
  author: string;
  rating: number;
  text: string;
  createdAt?: string;
  verified?: boolean;
};

export type IngestResult = {
  imported: number;
  skipped: number;
  /** true si el proceso se detuvo por falta de cuota mensual. */
  quotaCut: boolean;
  /** true si el proceso se detuvo por el tope de filas/almacenamiento. */
  storageCut?: boolean;
  remaining: number;
  used: number;
  limit: number;
  errors: string[];
};

/**
 * Importa un lote de reseñas respetando la cuota restante del ciclo.
 * - Si no queda cuota, no importa nada y devuelve `quotaCut: true`.
 * - Si la cuota se agota a mitad del lote, corta y devuelve lo importado.
 * - El contador se incrementa UNA sola vez con el total (1 escritura).
 */
export async function ingestReviews(
  admin: AdminLike,
  tenantId: string,
  reviews: IncomingReview[],
  source: 'google' | 'trustpilot' | 'facebook' | 'manual' | 'places',
): Promise<IngestResult> {
  const result: IngestResult = {
    imported: 0,
    skipped: 0,
    quotaCut: false,
    remaining: 0,
    used: 0,
    limit: 0,
    errors: [],
  };

  const featureBySource: Record<typeof source, PlanFeaturesKey | undefined> = {
    google: 'googleBusiness',
    places: 'googlePlaces',
    trustpilot: 'trustpilot',
    facebook: undefined,
    manual: undefined,
  };

  const gate = await enforce(admin, tenantId, {
    metric: 'reviews',
    feature: featureBySource[source],
    amount: 1,
    action: `Importar reseñas de ${source}`,
  });
  if (!gate.ok) {
    result.quotaCut = gate.status === 429;
    result.errors.push(gate.error);
    result.limit = gate.check.metrics.reviews.quota;
    result.used = gate.check.metrics.reviews.used;
    result.remaining = gate.check.metrics.reviews.remaining;
    return result;
  }

  // TOPE DE BASE DE DATOS: purga lo antiguo y comprueba cuántas filas caben
  // en `reviews` según el plan (protege el tamaño de Supabase/PostgreSQL).
  const storage = await enforceTableCap(admin, tenantId, 'reviews');
  if (!storage.ok) {
    result.storageCut = true;
    result.errors.push(storage.error);
    result.limit = gate.check.metrics.reviews.quota;
    result.used = gate.check.metrics.reviews.used;
    result.remaining = 0;
    return result;
  }

  // Cuántas caben realmente: cuota mensual + espacio libre en la tabla.
  const room = Math.min(
    gate.check.metrics.reviews.remaining,
    storage.storage.reviews.remaining,
  );
  result.limit = gate.check.metrics.reviews.quota;
  result.used = gate.check.metrics.reviews.used;
  result.remaining = room;

  if (room <= 0) {
    result.quotaCut = true;
    return result;
  }

  const batch = reviews.slice(0, room);
  if (reviews.length > batch.length) {
    result.quotaCut = true;
    result.skipped = reviews.length - batch.length;
  }

  // Solo las reseñas que ACABAN de llegar pueden responderse solas: las que ya
  // estaban guardadas (aunque sigan sin respuesta) no se vuelven a encolar.
  const dbSource = source === 'places' ? 'google' : source;
  const existingIds = new Set<string>();
  const ids = batch.map((r) => r.externalId).filter(Boolean);
  for (let i = 0; i < ids.length; i += 200) {
    const { data: existing } = await admin
      .from('reviews')
      .select('external_id')
      .eq('tenant_id', tenantId)
      .eq('source', dbSource)
      .in('external_id', ids.slice(i, i + 200));
    for (const e of (existing ?? []) as Array<{ external_id: string | null }>) {
      if (e.external_id) existingIds.add(String(e.external_id));
    }
  }

  const autoCandidates: Array<{ id: string; author: string; rating: number; text: string }> = [];
  for (const r of batch) {
    const isNew = !existingIds.has(r.externalId);
    const { data: saved, error } = await admin.from('reviews').upsert(
      {
        tenant_id: tenantId,
        source: source === 'places' ? 'google' : source,
        external_id: r.externalId,
        author_name: r.author,
        rating: Math.min(5, Math.max(1, Math.round(r.rating || 5))),
        text: r.text ?? '',
        is_verified: Boolean(r.verified),
        // Filtro privado: las malas experiencias (≤3★) entran en la cola de triaje.
        flagged_private: (r.rating ?? 5) <= 3,
      },
      { onConflict: 'tenant_id,source,external_id' },
    ).select('id, reply_text, rating, author_name, text');
    if (error) {
      result.errors.push(String(error.message ?? error).slice(0, 180));
      continue;
    }
    result.imported += 1;
    const row = Array.isArray(saved) ? saved[0] : null;
    if (isNew && row && !row.reply_text && String(row.text ?? '').trim()) {
      autoCandidates.push({ id: String(row.id), author: String(row.author_name ?? 'Cliente'), rating: Number(row.rating), text: String(row.text) });
    }
  }

  if (autoCandidates.length > 0) {
    await queueAutoReplies(admin, tenantId, autoCandidates).catch((e: unknown) =>
      systemLog('warn', 'reviews.autopublish', `No se pudieron encolar respuestas automáticas: ${e instanceof Error ? e.message : String(e)}`, { tenantId }),
    );
  }

  if (result.imported > 0) {
    await consume(admin, tenantId, 'reviews', result.imported);
  }
  result.remaining = Math.max(0, room - result.imported);
  result.used = gate.check.metrics.reviews.used + result.imported;

  await systemLog('info', 'reviews.ingest', `${result.imported} reseñas de ${source}`, {
    tenantId,
    skipped: result.skipped,
    quotaCut: result.quotaCut,
  });

  return result;
}


/** Piloto automático: encola respuesta IA + publicación para reseñas nuevas (máx. por lote). */
async function queueAutoReplies(
  admin: AdminLike,
  tenantId: string,
  candidates: Array<{ id: string; author: string; rating: number; text: string }>,
): Promise<void> {
  const { autoPublishConfigOf, shouldAutoPublish, MAX_AUTO_PUBLISH_PER_INGEST } = await import('@/lib/auto-publish');
  const { data: tenant } = await admin.from('tenants').select('name, settings').eq('id', tenantId).single();
  const cfg = autoPublishConfigOf(tenant?.settings);
  if (!cfg.enabled) return;
  const tone = (tenant?.settings as { tone?: string } | null)?.tone;
  const { enqueue } = await import('@/lib/queue');
  const { randomUUID } = await import('crypto');
  const picked = candidates.filter((c) => shouldAutoPublish(cfg, c.rating)).slice(0, MAX_AUTO_PUBLISH_PER_INGEST);
  for (const c of picked) {
    await enqueue(
      {
        type: 'ai.generate',
        tenantId,
        jobId: randomUUID(),
        businessName: String(tenant?.name ?? 'Nuestro negocio').slice(0, 120),
        authorName: c.author.slice(0, 120) || 'Cliente',
        rating: Math.min(5, Math.max(1, c.rating)),
        reviewText: c.text.slice(0, 4000),
        tone: tone === 'cercano' || tone === 'formal' || tone === 'profesional' ? tone : undefined,
        reviewId: c.id,
        autoPublish: true,
      },
      { admin },
    );
  }
}

/** Re-export cómodo para las rutas de sincronización. */
