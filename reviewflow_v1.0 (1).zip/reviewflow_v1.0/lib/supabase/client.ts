'use client';

import { createBrowserClient } from '@supabase/ssr';
import { env } from '@/lib/env';

/**
 * Cliente Supabase para Componentes de Cliente.
 * Usa valores placeholder si no hay claves para no romper el build;
 * las páginas detectan `isSupabaseConfigured` y muestran modo demo.
 */
const unquote = (v?: string) => (v || '').trim().replace(/^["']|["']$/g, '').trim().replace(/\/+$/, '');

export function createClient() {
  const url =
    unquote(process.env.NEXT_PUBLIC_SUPABASE_URL) ||
    env.supabaseUrl ||
    'https://placeholder.supabase.co';
  const anonKey =
    unquote(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) ||
    env.supabaseAnonKey ||
    'placeholder-anon-key';

  return createBrowserClient(url, anonKey);
}
