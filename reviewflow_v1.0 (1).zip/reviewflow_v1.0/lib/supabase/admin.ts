import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { env, isSupabaseAdminConfigured } from '@/lib/env';

/**
 * Cliente `service_role` de Supabase (SOLO servidor, bypassa RLS).
 *
 * USOS AUTORIZADOS Y AUDITADOS:
 *   1. `/api/admin/*` y `/admin` → Operaciones de Super-Admin tras verificar `requireSuperAdmin()`.
 *   2. `/api/cron/*`             → Tareas programadas protegidas con `CRON_SECRET` (`timingSafeEqual`).
 *   3. `/api/stripe/webhook`, `/api/queue/worker` e ingesta firmada → Webhooks y workers verificados criptográficamente.
 *   4. RPCs internas de contabilidad y seguridad (`consume_quota`, `consume_ai_tokens`, `consume_rate_limit`,
 *      `system_logs` e `integrations` cifradas con AES-256-GCM) que tienen `REVOKE ALL FROM authenticated`
 *      por diseño de seguridad para impedir lecturas o manipulaciones desde el navegador.
 *
 * NUNCA debe exponerse al cliente ni emplearse sin validar previamente sesión/membresía (`tenant_id`),
 * firma de webhook o `CRON_SECRET`.
 */
export function createAdminClient() {
  if (!isSupabaseAdminConfigured) return null;
  return createSupabaseClient(env.supabaseUrl, env.supabaseServiceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}

