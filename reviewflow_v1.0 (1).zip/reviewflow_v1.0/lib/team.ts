import { escapeHtml } from '@/lib/security';
import { SITE } from '@/lib/site';
import type { TenantRole } from '@/lib/authz';

/** Personas que caben por empresa si no se ha configurado otra cifra (dueño incluido). */
const DEFAULT_MAX_MEMBERS = 10;

/** Roles que se pueden asignar desde la pestaña «Equipo» (el dueño no se asigna, se tiene). */
export const ASSIGNABLE_ROLES = ['admin', 'agent', 'viewer'] as const;

const ROLE_LABEL_ES: Record<TenantRole, string> = {
  owner: 'Dueño',
  admin: 'Administrar',
  agent: 'Responder reseñas',
  viewer: 'Solo mirar',
};

/**
 * Límite general de personas por equipo: `TEAM_MAX_MEMBERS` si está puesto
 * (número mayor que 0); si no, `DEFAULT_MAX_MEMBERS`.
 */
function defaultMaxMembers(envObj: NodeJS.ProcessEnv = process.env): number {
  const n = Number(envObj.TEAM_MAX_MEMBERS);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : DEFAULT_MAX_MEMBERS;
}

/**
 * Límite de una empresa. La columna `tenants.max_members` vale 10 por defecto,
 * así que 10 (o vacío) significa «sin cifra propia» y se usa el límite general
 * (`TEAM_MAX_MEMBERS`). Cualquier otra cifra puesta a mano en una empresa manda.
 */
export function maxMembersOf(raw: number | null | undefined, envObj: NodeJS.ProcessEnv = process.env): number {
  const n = Number(raw);
  if (!Number.isFinite(n) || n <= 0 || Math.floor(n) === DEFAULT_MAX_MEMBERS) return defaultMaxMembers(envObj);
  return Math.floor(n);
}

function layout(title: string, bodyHtml: string, cta?: { href: string; label: string }) {
  const button = cta
    ? `<p style="margin:28px 0"><a href="${escapeHtml(cta.href)}" style="background:#2563eb;color:#ffffff;padding:12px 22px;border-radius:10px;text-decoration:none;font-weight:600;display:inline-block">${escapeHtml(cta.label)}</a></p>`
    : '';
  return `<!doctype html><html lang="es"><body style="margin:0;background:#ffffff;font-family:Arial,Helvetica,sans-serif;color:#0f172a">
<div style="max-width:560px;margin:0 auto;padding:32px 24px">
<p style="font-weight:700;font-size:15px;color:#2563eb;margin:0 0 20px">${escapeHtml(SITE.brand)}</p>
<h1 style="font-size:22px;margin:0 0 16px">${escapeHtml(title)}</h1>
${bodyHtml}${button}
<p style="font-size:12px;color:#64748b;margin-top:32px">Si no esperabas este mensaje, puedes ignorarlo.</p>
</div></body></html>`;
}

/** Email para quien NO tenía cuenta: enlace para crear su contraseña. */
export function renderTeamInviteNewUser(input: {
  tenantName: string;
  inviterEmail: string;
  role: TenantRole;
  link: string;
}) {
  const role = ROLE_LABEL_ES[input.role];
  const subject = `Te han invitado al equipo de ${input.tenantName}`;
  const html = layout(
    subject,
    `<p style="font-size:15px;line-height:1.6">${escapeHtml(input.inviterEmail)} te ha invitado a entrar en el panel de <strong>${escapeHtml(input.tenantName)}</strong> en ${escapeHtml(SITE.brand)}.</p>
<p style="font-size:15px;line-height:1.6">Tu permiso: <strong>${escapeHtml(role)}</strong>.</p>
<p style="font-size:15px;line-height:1.6">Pulsa el botón para crear tu contraseña y entrar. El enlace caduca en 24 horas.</p>`,
    { href: input.link, label: 'Crear mi contraseña' },
  );
  const text = `${input.inviterEmail} te ha invitado al equipo de ${input.tenantName} (permiso: ${role}).\nCrea tu contraseña aquí (caduca en 24 h): ${input.link}`;
  return { subject, html, text };
}

/** Aviso para quien YA tenía cuenta: ya puede entrar con su contraseña de siempre. */
export function renderTeamInviteExistingUser(input: {
  tenantName: string;
  inviterEmail: string;
  role: TenantRole;
  loginUrl: string;
}) {
  const role = ROLE_LABEL_ES[input.role];
  const subject = `Ya formas parte del equipo de ${input.tenantName}`;
  const html = layout(
    subject,
    `<p style="font-size:15px;line-height:1.6">${escapeHtml(input.inviterEmail)} te ha añadido al equipo de <strong>${escapeHtml(input.tenantName)}</strong>.</p>
<p style="font-size:15px;line-height:1.6">Tu permiso: <strong>${escapeHtml(role)}</strong>. Entra con tu email y tu contraseña de siempre.</p>`,
    { href: input.loginUrl, label: 'Entrar al panel' },
  );
  const text = `${input.inviterEmail} te ha añadido al equipo de ${input.tenantName} (permiso: ${role}). Entra con tu contraseña de siempre: ${input.loginUrl}`;
  return { subject, html, text };
}
