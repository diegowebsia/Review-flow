/**
 * ============================================================
 * Detector de Reseñas Falsas / Spam + Programación Humanizada
 * ============================================================
 * 1. `detectFakeOrSpamReview()`: identifica enlaces promocionales, ataques de
 *    competidores, cuentas bot y reseñas de 1★ vacías o con conflicto de interés,
 *    y genera el informe listo para reportar a Google Business Profile.
 * 2. `computeHumanizedPublishTime()`: evita publicar respuestas a las 03:00 AM
 *    programándolas en horario humano diurno (09:10–20:30).
 */

type SpamAnalysisResult = {
  isSuspicious: boolean;
  confidenceScore: number; // 0..100
  reasons: string[];
  googlePolicyViolation:
    | 'spam_and_fake_content'
    | 'conflict_of_interest'
    | 'off_topic'
    | 'profanity_or_harassment'
    | 'none';
  googlePolicyLabel: string;
  reportDossier: string;
};

export function detectFakeOrSpamReview(review: {
  authorName: string;
  rating: number;
  text: string;
  isVerified?: boolean;
}): SpamAnalysisResult {
  const text = (review.text ?? '').trim();
  const lower = text.toLowerCase();
  const author = (review.authorName ?? '').trim();
  const reasons: string[] = [];
  let score = 0;
  let violation: SpamAnalysisResult['googlePolicyViolation'] = 'none';

  // 1. Enlaces externos, URLs o spam promocional
  if (/https?:\/\/|www\.|\.(xyz|top|click|ru|cn)\b|telegram|whatsapp\s+\+?\d{7,}/i.test(text)) {
    score += 65;
    reasons.push('Incluye enlaces web externos o spam promocional prohibido por las políticas de Google.');
    violation = 'spam_and_fake_content';
  }

  // 2. Desvío explícito a competidores (Conflicto de intereses)
  if (/mejor\s+(id|comprad|ir)\s+a|competencia|comprad\s+en|no\s+vay[aá]is\s+aqu[ií]/i.test(lower)) {
    score += 45;
    reasons.push('Desvía clientes explícitamente hacia un competidor (Conflicto de intereses).');
    if (violation === 'none') violation = 'conflict_of_interest';
  }

  // 3. Patrón de nombre de bot / cuenta automatizada
  if (/^(user|usuario|anon|bot|test)[0-9_]{3,}/i.test(author) || /[0-9]{5,}/.test(author)) {
    score += 30;
    reasons.push(`Nombre de autor con patrón automatizado («${author}»).`);
    if (violation === 'none') violation = 'spam_and_fake_content';
  }

  // 4. Reseña extrema (1★) sin experiencia real verificada o con insultos/mayúsculas masivas
  if (review.rating === 1 && !review.isVerified && text.length < 15) {
    score += 35;
    reasons.push('Puntuación mínima (1★) sin compra/visita verificada ni descripción de una experiencia real.');
    if (violation === 'none') violation = 'off_topic';
  }

  if (text.length > 25 && text === text.toUpperCase() && /[A-ZÁÉÍÓÚ]{6,}/.test(text)) {
    score += 25;
    reasons.push('Uso masivo de mayúsculas y signos de exclamación propio de ataque coordinado.');
  }

  const confidenceScore = Math.min(100, score);
  const isSuspicious = confidenceScore >= 40;

  const policyLabels: Record<SpamAnalysisResult['googlePolicyViolation'], string> = {
    spam_and_fake_content: 'Spam y contenido falso (Política de contenido de Google Maps)',
    conflict_of_interest: 'Conflicto de intereses / Promoción de competidor',
    off_topic: 'Contenido irrelevante sin experiencia real de cliente',
    profanity_or_harassment: 'Lenguaje inapropiado o acoso',
    none: 'Sin infracción evidente',
  };

  const reportDossier = isSuspicious
    ? `SOLICITUD FORMAL DE RETIRADA DE RESEÑA — GOOGLE BUSINESS PROFILE\n` +
      `Autor reportado: ${author}\n` +
      `Valoración: ${review.rating}★\n` +
      `Categoría infringida: ${policyLabels[violation]}\n` +
      `Índice de sospecha técnica: ${confidenceScore}/100\n` +
      `Motivos detectados:\n${reasons.map((r) => `- ${r}`).join('\n')}\n` +
      `Justificación para moderación: La reseña incumple las Políticas de Contenido de Usuarios de Google Maps al no reflejar una experiencia genuina de consumidor verificable.`
    : '';

  return {
    isSuspicious,
    confidenceScore,
    reasons,
    googlePolicyViolation: violation,
    googlePolicyLabel: policyLabels[violation],
    reportDossier,
  };
}

/**
 * Si se aprueba una respuesta en horario nocturno (21:00 a 08:59 UTC/local),
 * programa su publicación para la mañana siguiente (entre las 09:14 y las 10:28)
 * para humanizar la comunicación y no publicar respuestas a las 03:00 de la madrugada.
 */
export function computeHumanizedPublishTime(now: Date = new Date(), forceImmediate = false): {
  immediate: boolean;
  scheduledFor: string;
  humanLabel: string;
} {
  if (forceImmediate) {
    return {
      immediate: true,
      scheduledFor: now.toISOString(),
      humanLabel: 'Publicada en el acto',
    };
  }

  const hour = now.getHours();
  if (hour >= 9 && hour <= 20) {
    // Pequeño retardo natural de 8 a 18 minutos en horario laboral
    const naturalDelayMs = (8 + (now.getMinutes() % 11)) * 60_000;
    const target = new Date(now.getTime() + naturalDelayMs);
    return {
      immediate: false,
      scheduledFor: target.toISOString(),
      humanLabel: `Programada hoy a las ${target.toTimeString().slice(0, 5)} (cadencia humana)`,
    };
  }

  // Horario nocturno: programar para las 09:18 de la mañana siguiente
  const nextMorning = new Date(now);
  if (hour >= 21) {
    nextMorning.setDate(nextMorning.getDate() + 1);
  }
  nextMorning.setHours(9, 14 + (now.getSeconds() % 35), 0, 0);

  return {
    immediate: false,
    scheduledFor: nextMorning.toISOString(),
    humanLabel: `Programada para las ${nextMorning.toTimeString().slice(0, 5)} (evita publicar de madrugada)`,
  };
}
