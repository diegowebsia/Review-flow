import { createHmac } from 'crypto';
import { resolvePublicUrlFromEnv as resolveAppUrlFromEnv } from '@/lib/public-url';

type OutboundWebhookEvent =
  | 'review.created'
  | 'review.negative_alert'
  | 'review.reply_published'
  | 'feedback.private_ticket';

type OutboundAlertPayload = {
  event: OutboundWebhookEvent;
  tenantId: string;
  businessName: string;
  reviewId?: string;
  authorName: string;
  rating: number;
  text: string;
  source: string;
  suggestedReply?: string;
  createdAt: string;
};

/**
 * Envía alertas en tiempo real de reseñas negativas (≤ 2★) o eventos de reputación a:
 *  1. Slack Incoming Webhook (`settings.slack_webhook_url`) con botón directo para responder.
 *  2. Microsoft Teams Webhook (`settings.teams_webhook_url`) con tarjeta Adaptive Card.
 *  3. Webhook saliente genérico para Zapier / Make / n8n (`settings.outbound_webhook_url`)
 *     firmado con `X-ReviewFlow-Signature` (HMAC-SHA256).
 */
export async function dispatchRealtimeAlerts(
  settings: Record<string, unknown> | null | undefined,
  payload: OutboundAlertPayload,
): Promise<{ slackSent: boolean; teamsSent: boolean; webhookSent: boolean }> {
  const cfg = settings ?? {};
  const baseUrl = resolveAppUrlFromEnv();
  const actionUrl = `${baseUrl}/dashboard?tab=bandeja${payload.reviewId ? `&reviewId=${encodeURIComponent(payload.reviewId)}` : ''}`;
  const starsEmoji = '★'.repeat(Math.max(1, Math.min(5, payload.rating))) + '☆'.repeat(5 - Math.max(1, Math.min(5, payload.rating)));

  let slackSent = false;
  let teamsSent = false;
  let webhookSent = false;

  // 1. Slack Incoming Webhook (con botón interactivo de respuesta rápida)
  if (typeof cfg.slack_webhook_url === 'string' && cfg.slack_webhook_url.startsWith('https://')) {
    try {
      const slackBody = {
        text: `🚨 *Alerta de reseña (${payload.rating}★)* en *${payload.businessName}* (${payload.source})`,
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: `*${payload.businessName}* · Nueva valoración *${starsEmoji}* (${payload.rating}/5) en *${payload.source.toUpperCase()}*\n*Autor:* ${payload.authorName}\n> ${payload.text || '(Sin texto)'}`,
            },
          },
          ...(payload.suggestedReply
            ? [
                {
                  type: 'section',
                  text: {
                    type: 'mrkdwn',
                    text: `*Borrador IA listo para aprobar:*\n_${payload.suggestedReply}_`,
                  },
                },
              ]
            : []),
          {
            type: 'actions',
            elements: [
              {
                type: 'button',
                text: { type: 'plain_text', text: '⚡ Responder desde ReviewFlow' },
                style: payload.rating <= 2 ? 'danger' : 'primary',
                url: actionUrl,
              },
            ],
          },
        ],
      };
      const r = await fetch(cfg.slack_webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(slackBody),
        signal: AbortSignal.timeout(5_000),
      });
      slackSent = r.ok;
    } catch {
      slackSent = false;
    }
  }

  // 2. Microsoft Teams Incoming Webhook (MessageCard con botón PotentialAction)
  if (typeof cfg.teams_webhook_url === 'string' && cfg.teams_webhook_url.startsWith('https://')) {
    try {
      const teamsBody = {
        '@type': 'MessageCard',
        '@context': 'http://schema.org/extensions',
        themeColor: payload.rating <= 2 ? 'E11D48' : '2563EB',
        summary: `Nueva reseña ${payload.rating}★ en ${payload.businessName}`,
        sections: [
          {
            activityTitle: `🚨 Reseña ${starsEmoji} (${payload.rating}/5) — ${payload.businessName}`,
            activitySubtitle: `Canal: ${payload.source.toUpperCase()} · Autor: ${payload.authorName}`,
            text: payload.text || '(Sin comentario)',
          },
        ],
        potentialAction: [
          {
            '@type': 'OpenUri',
            name: 'Aprobar respuesta IA en el panel',
            targets: [{ os: 'default', uri: actionUrl }],
          },
        ],
      };
      const r = await fetch(cfg.teams_webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(teamsBody),
        signal: AbortSignal.timeout(5_000),
      });
      teamsSent = r.ok;
    } catch {
      teamsSent = false;
    }
  }

  // 3. Webhook saliente para Zapier / Make / CRM propio firmado con HMAC-SHA256
  if (typeof cfg.outbound_webhook_url === 'string' && cfg.outbound_webhook_url.startsWith('https://')) {
    try {
      const rawJson = JSON.stringify({
        ...payload,
        actionUrl,
      });
      const secret = (cfg.outbound_webhook_secret as string) || process.env.APP_SIGNING_SECRET || 'reviewflow-webhook';
      const signature = createHmac('sha256', secret).update(rawJson).digest('hex');
      const r = await fetch(cfg.outbound_webhook_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-ReviewFlow-Event': payload.event,
          'X-ReviewFlow-Signature': `sha256=${signature}`,
        },
        body: rawJson,
        signal: AbortSignal.timeout(5_000),
      });
      webhookSent = r.ok;
    } catch {
      webhookSent = false;
    }
  }

  return { slackSent, teamsSent, webhookSent };
}
