import { resolvePublicUrlFromEnv } from '@/lib/public-url';
import crypto from 'crypto';
import { consume, enforce } from '@/lib/usage';
import { sendMail } from '@/lib/mail';
import { googleReviewLink } from '@/lib/maps';
import { systemLog } from '@/lib/logger';
import { verifyAndResolveTenantByApiKey } from '@/lib/api-keys';
import { markOnboardingStep } from '@/lib/onboarding';
import type { TenantSettingsJson, TypedSupabaseClient } from '@/lib/database.types';

type AdminLike = TypedSupabaseClient;

export function verifyShopifyHmac(rawBody: string, secret: string, hmacHeader: string | null): boolean {
  if (!secret || !hmacHeader) return false;
  const digest = crypto.createHmac('sha256', secret).update(rawBody, 'utf8').digest('base64');
  try {
    // Comparación estricta de la firma base64 (sin decodificar: evita aceptar
    // caracteres sobrantes que el decodificador base64 ignoraría).
    const a = Buffer.from(digest, 'utf8');
    const b = Buffer.from(hmacHeader.trim(), 'utf8');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export function verifyWooHmac(rawBody: string, secret: string, sig: string | null): boolean {
  return verifyShopifyHmac(rawBody, secret, sig); // mismo esquema HMAC-SHA256/base64
}

export type DeliveredOrder = {
  orderId: string;
  customerName: string;
  /** Ignorado: WhatsApp desactivado. Se mantiene por compatibilidad con webhooks. */
  customerPhone?: string;
  customerEmail?: string;
  provider: 'shopify' | 'woocommerce' | 'store';
  /** Ignorado: consentimiento del antiguo canal WhatsApp (compatibilidad). */
  optin?: boolean;
  /** Texto del checkbox aceptado (auditoría RGPD). */
  optinText?: string;
};

/** Plantilla HTML responsive para email post-entrega */
export function orderDeliveredEmailHtml(businessName: string, customerName: string, link: string, orderId: string): string {
  return `
    <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; padding: 28px 20px; color: #1e293b; background-color: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0;">
      <h2 style="color: #0f172a; margin-top: 0; font-size: 22px; font-weight: 800; letter-spacing: -0.02em;">¡Tu pedido #${orderId} ha sido entregado!</h2>
      <p style="font-size: 15px; line-height: 1.6; color: #334155;">Hola ${customerName},</p>
      <p style="font-size: 15px; line-height: 1.6; color: #334155;">
        Nos consta que tu pedido en <strong>${businessName}</strong> ya te ha llegado. Esperamos que todo esté exactamente a tu gusto.
      </p>
      <p style="font-size: 15px; line-height: 1.6; color: #334155;">
        Tu opinión es muy valiosa para nosotros y para otros clientes. ¿Nos dedicas 30 segundos para contarnos cómo ha ido?
      </p>
      <div style="margin: 32px 0; text-align: center;">
        <a href="${link}" style="background-color: #2563eb; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 700; font-size: 15px; display: inline-block;">
          ⭐ Dejar mi opinión
        </a>
      </div>
      <p style="font-size: 12px; color: #64748b; margin-top: 36px; border-top: 1px solid #f1f5f9; padding-top: 16px;">
        Mensaje enviado automáticamente tras la entrega del pedido #${orderId} por ${businessName}.
      </p>
    </div>
  `;
}

/**
 * Pedido entregado → Email automático al CLIENTE pidiendo valoración.
 * Requisitos: plan con storeIntegration + suscripción con acceso + cuota.
 * Descuenta 1 unidad de requests. El enlace dirige al flujo neutral (/valorar/[slug]).
 */
export async function handleDeliveredOrder(
  admin: AdminLike,
  tenant: {
    id: string;
    name: string;
    slug?: string;
    plan: string;
    subscription_status: string;
    suspended: boolean;
    settings: TenantSettingsJson | Record<string, unknown> | null;
  },
  order: DeliveredOrder,
): Promise<{ ok: boolean; status: number; body: Record<string, unknown>; headers?: Record<string, string> }> {
  // 1) Feature del plan: la conexión con tienda está disponible en planes con storeIntegration
  const featureGate = await enforce(admin, tenant.id, {
    metric: 'requests',
    feature: 'storeIntegration',
    amount: 0,
    action: 'Conexión con tienda',
  });
  if (!featureGate.ok) {
    return {
      ok: false,
      status: featureGate.status,
      body: featureGate.body,
    };
  }

  const email = (order.customerEmail ?? '').trim();
  const hasValidEmail = email.includes('@') && email.includes('.');

  if (!hasValidEmail) {
    await systemLog('warn', 'store.webhook', `Pedido ${order.orderId} sin email válido`, {
      tenantId: tenant.id,
    });
    return { ok: false, status: 200, body: { ok: true, skipped: 'no-customer-contact' } };
  }

  const base = resolvePublicUrlFromEnv();
  const placeId = tenant.settings?.place_id as string | undefined;
  const link = tenant.slug
    ? `${base}/valorar/${tenant.slug}`
    : placeId
      ? googleReviewLink(placeId)
      : `${base}/`;

  // Reclamo atómico por tenant/proveedor/pedido para evitar envíos duplicados
  const marker = `order:${order.provider}:${order.orderId}`;
  const { error: claimError } = await admin.from('processed_events').insert({
    provider: order.provider,
    tenant_scope: tenant.id,
    event_id: order.orderId,
  });
  if (claimError?.code === '23505') {
    return { ok: true, status: 200, body: { ok: true, skipped: 'duplicate' } };
  }
  if (claimError) throw claimError;
  const releaseClaim = () => admin.from('processed_events').delete()
    .eq('provider', order.provider).eq('tenant_scope', tenant.id).eq('event_id', order.orderId);

  // Canal único: EMAIL (WhatsApp desactivado para abaratar costes)
  if (hasValidEmail) {
    const emailQuotaGate = await enforce(admin, tenant.id, {
      metric: 'requests', feature: 'emailRequests', amount: 1, action: 'Email post-venta',
    });
    if (!emailQuotaGate.ok) {
      await releaseClaim();
      return { ok: false, status: emailQuotaGate.status, body: emailQuotaGate.body, headers: emailQuotaGate.headers };
    }

    const emailHtml = orderDeliveredEmailHtml(tenant.name, order.customerName, link, order.orderId);
    const emailRes = await sendMail({
      to: email,
      subject: `¿Qué tal tu pedido #${order.orderId}? - ${tenant.name}`,
      html: emailHtml,
      text: `Hola ${order.customerName},\n\nTu pedido #${order.orderId} en ${tenant.name} ha sido entregado.\n\nPor favor déjanos tu valoración aquí: ${link}\n\n¡Gracias!`,
    });

    if (emailRes.sent) {
      await consume(admin, tenant.id, 'requests', 1);
      await markOnboardingStep(admin, tenant.id, 'send_first_request');
    } else {
      // Sin envío real no se cobra cuota y se libera el pedido para reintentarlo.
      await releaseClaim();
    }
    await systemLog('info', 'store.review-request', `${marker} enviado vía Email (${email})`, {
      tenantId: tenant.id,
      provider: order.provider,
      sent: emailRes.sent,
    });

    return { ok: true, status: 200, body: { ok: true, channel: 'email', sent: emailRes.sent } };
  }

  await releaseClaim();
  return { ok: false, status: 200, body: { ok: true, skipped: 'no-valid-channel' } };
}

/** Localiza empresa por su API key (hash SHA-256, solape de rotación 24h y registro de último uso). */
export async function tenantByApiKey(admin: AdminLike, apiKey: string | null) {
  return verifyAndResolveTenantByApiKey(admin, apiKey);
}
