import { type GeminiChatOutcome } from '@/lib/gemini';
// Capa genérica: cualquier proveedor/modelo configurado por variables de entorno (ver lib/llm.ts).
import { generateWithLlm as generateWithGemini, isLlmConfigured as isGeminiConfigured } from '@/lib/llm';
import { aiLanguageNameFor, detectReviewLocale, type SupportedLocale } from '@/lib/i18n';

type RespondInput = {
  businessName: string;
  authorName: string;
  rating: number; // 1-5
  reviewText: string;
  language?: string;
  /** Idioma detectado automáticamente de la reseña (`reviews.detected_locale`). */
  detectedLocale?: SupportedLocale;
  tone?: 'profesional' | 'cercano' | 'formal';
  /** Mensaje PRIVADO conciliador (filtro de malas experiencias), no respuesta pública. */
  privateMessage?: boolean;
  /** Contexto del negocio e instrucciones de estilo para la IA. */
  brandInstructions?: string;
  /** Reglas fijas de marca (ej: "Mencionar aparcamiento gratuito"). */
  brandRules?: string[];
  /** Memoria de marca: palabras o expresiones prohibidas que la IA nunca debe emplear. */
  forbiddenWords?: string[];
  /** Memoria de marca: firma personalizada al final de cada respuesta. */
  brandSignature?: string;
  /** Memoria de marca: ejemplos de respuestas previamente editadas y aprobadas por el cliente. */
  approvedExamples?: Array<{ review: string; reply: string }>;
};

/** Contabilidad de tokens/coste que devuelve cada generación. */
type AiUsage = {
  model: string;
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  costUsd: number;
  latencyMs: number;
  attempts: number;
  provider: 'gemini' | 'local-template' | 'local-heuristic' | 'unavailable';
  /** Motivo del fallback cuando no se pudo usar el modelo. */
  errorCode?: string | null;
};

/** Convierte el resultado de Google Gemini en contabilidad de negocio. */
function usageFromGemini(outcome: GeminiChatOutcome): AiUsage {
  return {
    model: outcome.model,
    promptTokens: outcome.tokens.prompt,
    completionTokens: outcome.tokens.completion,
    totalTokens: outcome.tokens.total,
    costUsd: outcome.costUsd,
    latencyMs: outcome.latencyMs,
    attempts: outcome.attempts,
    provider: 'gemini',
    errorCode: outcome.ok ? null : (outcome.code ?? 'gemini_error'),
  };
}

function localUsage(provider: AiUsage['provider'], errorCode: string = 'model_unavailable'): AiUsage {
  return {
    model: 'local-engine',
    promptTokens: 0,
    completionTokens: 0,
    totalTokens: 0,
    costUsd: 0,
    latencyMs: 1,
    attempts: 1,
    provider,
    errorCode,
  };
}

/**
 * Genera una respuesta a una opinión con Google Gemini (ultrarrápido y gratuito/económico)
 * y respaldo de plantilla local si no hay clave o falla la conexión.
 */
export async function generateReviewReply(input: RespondInput): Promise<{
  reply: string;
  provider: 'gemini' | 'local-template';
  usage: AiUsage;
  detectedLocale: SupportedLocale;
}> {
  const tone = input.tone ?? 'profesional';
  const detectedLocale = input.detectedLocale ?? detectReviewLocale(input.reviewText, 'es');
  const lang = input.language ?? aiLanguageNameFor(detectedLocale);

  let brandContext = '';
  if (input.brandInstructions?.trim()) {
    brandContext += `\nContexto e identidad del negocio: "${input.brandInstructions.trim()}".`;
  }
  if (input.brandRules && input.brandRules.length > 0) {
    brandContext += `\nReglas fijas de la marca obligatorias a seguir e integrar con naturalidad:\n${input.brandRules.map((r) => `- ${r}`).join('\n')}`;
  }
  if (input.forbiddenWords && input.forbiddenWords.length > 0) {
    brandContext += `\nExpresiones PROHIBIDAS (nunca las uses en la respuesta): ${input.forbiddenWords.join(', ')}.`;
  }
  if (input.brandSignature?.trim()) {
    brandContext += `\nFirma obligatoria al cierre: "${input.brandSignature.trim()}".`;
  }
  if (input.approvedExamples && input.approvedExamples.length > 0) {
    const sampleBlock = input.approvedExamples
      .slice(0, 3)
      .map((ex, i) => `Ejemplo aprobado ${i + 1}:\nReseña: "${ex.review}"\nRespuesta del cliente: "${ex.reply}"`)
      .join('\n\n');
    brandContext += `\nAprende e imita el estilo real de estas respuestas ya aprobadas por el negocio:\n${sampleBlock}`;
  }

  const system = input.privateMessage
    ? `Eres el responsable de atención al cliente de "${input.businessName}". Redactas un MENSAJE PRIVADO (no público) en el idioma de la reseña (${lang}) con tono ${tone} para reconducir una mala experiencia de ${input.authorName} (${input.rating}/5). Breve (máx. 80 palabras), empático, pide disculpas, propone una solución concreta y un canal de contacto directo. Sin comillas envolventes.${brandContext}`
    : `Eres el community manager de "${input.businessName}". Respondes reseñas de clientes siempre en el idioma de la reseña (${lang}) con tono ${tone}. Respuestas breves (máx. 80 palabras), sin comillas envolventes, firmadas con ${input.brandSignature?.trim() || 'el nombre del negocio'}. Si la reseña es negativa (<=3 estrellas), empatiza, pide disculpas y ofrece una solución/contacto sin sonar robótico.${brandContext}`;

  const userPrompt = `Reseña de ${input.authorName} (${input.rating}/5 estrellas, idioma detectado: ${detectedLocale}):\n${input.reviewText}`;

  if (isGeminiConfigured()) {
    const geminiOutcome = await generateWithGemini({
      systemPrompt: system,
      userPrompt,
      temperature: 0.7,
      maxOutputTokens: 250,
    });
    if (geminiOutcome.ok && geminiOutcome.text) {
      return {
        reply: geminiOutcome.text,
        provider: 'gemini',
        usage: usageFromGemini(geminiOutcome),
        detectedLocale,
      };
    }
  }

  const reply = input.privateMessage ? localPrivateReply(input) : localTemplateReply(input, tone);
  return {
    reply,
    provider: 'local-template',
    usage: localUsage('local-template', isGeminiConfigured() ? 'gemini_fallback' : 'gemini_not_configured'),
    detectedLocale,
  };
}

function formatBrandRules(rules: string[] | undefined, tone: string): string {
  if (!rules || rules.length === 0) return '';
  const cleaned = rules.map((r) => r.trim()).filter((r) => r.length > 0);
  if (cleaned.length === 0) return '';

  const prefix =
    tone === 'cercano'
      ? 'Por cierto, queremos recordarte que '
      : tone === 'formal'
        ? 'Asimismo, nos complace informarle que '
        : 'Aprovechamos para informarle que ';

  if (cleaned.length === 1) {
    const r = cleaned[0].replace(/\.+$/, '');
    return `${prefix}${r.charAt(0).toLowerCase() + r.slice(1)}.`;
  }

  const formatted = cleaned.map((r) => r.replace(/\.+$/, '')).join(', y ');
  return `${prefix}${formatted.charAt(0).toLowerCase() + formatted.slice(1)}.`;
}

function detectTopic(text: string): string | null {
  const lower = (text || '').toLowerCase();
  if (/comida|plato|carta|sabor|vino|postre|ingrediente|delicioso|rico|cena|almuerzo/.test(lower)) {
    return 'gastronómica';
  }
  if (/atenci[oó]n|trato|camarer|personal|amabilidad|servicio|equipo/.test(lower)) {
    return 'de atención y servicio';
  }
  if (/env[ií]o|reparto|entrega|paquete|tiempo|demora|pedido/.test(lower)) {
    return 'logística y de entrega';
  }
  if (/calidad|precio|caro|barato|valor/.test(lower)) {
    return 'en relación a la calidad ofrecida';
  }
  return null;
}

function localPrivateReply(input: RespondInput): string {
  const { businessName, authorName, rating, reviewText, brandRules, tone = 'profesional' } = input;
  const greeting =
    tone === 'formal' ? `Estimado/a ${authorName}:` : tone === 'cercano' ? `¡Hola ${authorName}!` : `Hola ${authorName},`;
  const brandRulesText = formatBrandRules(brandRules, tone);
  const topic = detectTopic(reviewText);
  const topicPhrase = topic ? ` respecto al aspecto ${topic}` : '';
  const rulesInsert = brandRulesText ? ` ${brandRulesText}` : '';

  return (
    `${greeting} soy responsable en ${businessName}. Hemos leído con la máxima atención tu valoración (${rating}/5 estrellas)${topicPhrase} ` +
    `y lamentamos profundamente no haber estado a la altura de lo que mereces.${rulesInsert} ` +
    `Para nosotros resolver este incidente contigo es la máxima prioridad: ¿nos puedes facilitar un teléfono o email de contacto ` +
    `para comunicarnos directamente hoy mismo y encontrar una solución personalizada? Muchas gracias por tu tiempo y por darnos la oportunidad de compensarte. — ${businessName}`
  );
}

function localTemplateReply(input: RespondInput, tone: string): string {
  const { businessName, authorName, rating, reviewText, brandRules, brandInstructions } = input;
  const greeting =
    tone === 'formal'
      ? `Estimado/a ${authorName}:`
      : tone === 'cercano'
        ? `¡Hola ${authorName}! 😊`
        : `Hola ${authorName},`;

  const topic = detectTopic(reviewText);
  const brandRulesText = formatBrandRules(brandRules, tone);
  const contextNote = brandInstructions ? `En ${businessName} trabajamos día a día con el compromiso de ofrecer lo mejor.` : '';

  let body = '';
  let signoff = '';

  if (rating >= 4) {
    const thankPhrase =
      tone === 'cercano'
        ? `muchísimas gracias por tu reseña de ${rating} estrellas y por compartir tu experiencia con nosotros.`
        : tone === 'formal'
          ? `le agradecemos sinceramente su valoración de ${rating} estrellas.`
          : `muchas gracias por tu reseña de ${rating} estrellas.`;

    const topicPhrase = topic
      ? tone === 'formal'
        ? ` Nos complace saber que su experiencia ${topic} estuvo a la altura de sus expectativas.`
        : ` Nos llena de alegría saber que disfrutaste de la experiencia ${topic}.`
      : ' Nos alegra enormemente saber que quedaste satisfecho con nuestro servicio.';

    signoff =
      tone === 'cercano'
        ? `¡Te esperamos muy pronto con los brazos abiertos! — El equipo de ${businessName}`
        : tone === 'formal'
          ? `Quedamos a su entera disposición y esperamos recibirle nuevamente. Atentamente, ${businessName}`
          : `¡Esperamos verte de nuevo muy pronto! — ${businessName}`;

    body = `${greeting} ${thankPhrase}${topicPhrase}`;
  } else if (rating === 3) {
    const ackPhrase =
      tone === 'formal'
        ? `agradecemos sinceramente sus comentarios. Lamentamos no haber alcanzado la excelencia esperada en su visita.`
        : tone === 'cercano'
          ? `gracias por tu reseña sincera. Sentimos no haber alcanzado las 5 estrellas esta vez.`
          : `gracias por compartir tu experiencia. Lamentamos no haber cumplido todas tus expectativas esta vez.`;

    const topicPhrase = topic
      ? ` Tomamos muy en cuenta tu valoración sobre el aspecto ${topic} para seguir optimizándolo.`
      : ' Tu valoración es fundamental para ayudarnos a detectar áreas de mejora continua.';

    signoff =
      tone === 'cercano'
        ? `¿Nos cuentas por privado qué podemos hacer aún mejor en tu próxima visita? Un saludo de ${businessName}`
        : tone === 'formal'
          ? `Agradecemos su tiempo y quedamos a su disposición para cualquier aclaración. Atentamente, ${businessName}`
          : `Esperamos tener la oportunidad de sorprenderte positivamente en tu próxima visita. — ${businessName}`;

    body = `${greeting} ${ackPhrase}${topicPhrase}`;
  } else {
    // 1-2 estrellas
    const apolPhrase =
      tone === 'formal'
        ? `lamentamos profundamente que su experiencia no haya sido satisfactoria.`
        : tone === 'cercano'
          ? `sentimos de corazón que tu experiencia no haya sido positiva.`
          : `sentimos mucho que tu experiencia no fuera la esperada.`;

    const topicPhrase = topic
      ? ` Lo ocurrido con la parte ${topic} no refleja en absoluto el estándar de calidad que nos exigimos.`
      : ' Lo que nos comentas no refleja los estándares de servicio y calidad que nos esforzamos en ofrecer cada día.';

    const contactInvite =
      tone === 'formal'
        ? `Le rogamos que nos contacte directamente para poder atender su caso con la máxima prioridad y ofrecerle una solución adecuada.`
        : tone === 'cercano'
          ? `Por favor, escríbenos o llámanos directamente; queremos escucharte y solucionarlo personalmente contigo cuanto antes.`
          : `Por favor, ponte en contacto con nosotros directamente para que podamos resolver tu caso de forma prioritaria.`;

    signoff =
      tone === 'formal'
        ? `Reiterándole nuestras disculpas, le saluda atentamente el equipo de ${businessName}`
        : tone === 'cercano'
          ? `Gracias por darnos la oportunidad de mejorar. — ${businessName}`
          : `Gracias por darnos la oportunidad de compensarte y mejorar. — ${businessName}`;

    body = `${greeting} ${apolPhrase}${topicPhrase} ${contactInvite}`;
  }

  const parts = [body];
  if (brandRulesText) parts.push(brandRulesText);
  if (contextNote && rating >= 3) parts.push(contextNote);
  parts.push(signoff);

  return parts.join(' ');
}

/* ================================================================== */
/* Capa de negocio: IA conectada al contador de cuota (usage_counters) */
/* ================================================================== */

import type { AdminLike, GateBlocked, PlanFeaturesKey, QuotaCheck } from '@/lib/usage';
import { consume, enforceAi, publicQuota, recordAiUsage } from '@/lib/usage';
import { systemLog } from '@/lib/logger';

type AiContext = { admin: AdminLike; tenantId: string };

type AiOk<T> = {
  ok: true;
  status: 200;
  quota: ReturnType<typeof publicQuota>;
} & T;

type AiBlocked = {
  ok: false;
  status: number;
  code: string;
  error: string;
  headers: Record<string, string>;
  body: Record<string, unknown>;
};

type AiResult<T> = AiOk<T> | AiBlocked;

function blockedResult(gate: GateBlocked): AiBlocked {
  return {
    ok: false,
    status: gate.status,
    code: gate.code,
    error: gate.error,
    headers: gate.headers,
    body: gate.body,
  };
}

function quotaOf(check: QuotaCheck, consumed: number) {
  const q = publicQuota(check);
  return { ...q, used: q.used + consumed, remaining: Math.max(0, q.remaining - consumed) };
}

/**
 * Genera una respuesta de reseña CON control de cuota.
 * Flujo real: enforce() (402/403/429) → Gemini/plantilla local → consume('ai').
 * Solo se descuenta crédito si el borrador llega a generarse.
 */
export async function generateReplyForTenant(
  ctx: AiContext,
  input: RespondInput,
  options: { feature?: PlanFeaturesKey; asyncJob?: { jobId: string } } = {},
): Promise<AiResult<{ reply: string; provider: 'gemini' | 'local-template'; usage: AiUsage }>> {
  // Puerta de IA: suscripción + feature + créditos + presupuesto de TOKENS.
  const gate = await enforceAi(ctx.admin, ctx.tenantId, {
    feature: options.feature ?? 'aiReplies',
    action: input.privateMessage ? 'Mensaje privado IA' : 'Respuesta IA',
  });
  if (!gate.ok) {
    await systemLog('warn', 'ai.quota', gate.error, { tenantId: ctx.tenantId, code: gate.code });
    return blockedResult(gate);
  }

  const { reply, provider, usage } = await generateReviewReply(input);

  // Contabilidad REAL: crédito del plan + tokens/coste del proveedor.
  await consume(ctx.admin, ctx.tenantId, 'ai', 1);
  await recordAiUsage(ctx.admin, ctx.tenantId, {
    ...usage,
    model: usage.model,
    purpose: options.asyncJob ? 'respond.async' : input.privateMessage ? 'respond.private' : 'respond.public',
    jobId: options.asyncJob?.jobId,
    resultText: reply,
    resultStatus: 'ready',
    ok: usage.provider === 'gemini',
    latencyMs: usage.latencyMs,
    costUsd: usage.costUsd,
    promptTokens: usage.promptTokens,
    completionTokens: usage.completionTokens,
  });

  await systemLog('info', 'ai.responder', `Borrador generado (${provider}) · ${usage.totalTokens} tokens`, {
    tenantId: ctx.tenantId,
    private: Boolean(input.privateMessage),
    costUsd: usage.costUsd,
  });

  return {
    ok: true,
    status: 200,
    reply,
    provider,
    usage,
    quota: quotaOf(gate.check, 1),
  };
}

/* ------------------------------------------------------------------ */
/* Inspección de quejas (triaje privado ≤3★)                           */
/* ------------------------------------------------------------------ */

type ComplaintSeverity = 'baja' | 'media' | 'alta' | 'critica';

/** Triaje sin contabilidad (lo que devuelve el modelo o la heurística local). */
type ComplaintAnalysis = {
  severity: ComplaintSeverity;
  category: string;
  legalRisk: boolean;
  suggestedChannel: 'privado' | 'telefono' | 'publico';
  summary: string;
  actionPlan: string[];
  provider: 'gemini' | 'local-heuristic';
};

/** Triaje + tokens/coste estimado de la llamada (contabilidad por empresa). */
type ComplaintInspection = ComplaintAnalysis & { usage: AiUsage };

const COMPLAINT_SCHEMA_HINT =
  'Responde SOLO con JSON válido sin markdown con estas claves: ' +
  'severity ("baja"|"media"|"alta"|"critica"), category (string corta en español), ' +
  'legalRisk (boolean), suggestedChannel ("privado"|"telefono"|"publico"), ' +
  'summary (máx. 200 caracteres), actionPlan (array de 2-4 strings imperativos).';

/**
 * Inspecciona una queja y devuelve un triaje accionable usando Google Gemini o heurística local.
 */
export async function inspectComplaint(input: {
  businessName: string;
  authorName: string;
  rating: number;
  reviewText: string;
  language?: string;
}): Promise<ComplaintInspection> {
  const lang = input.language ?? 'español';
  const systemPrompt = `Eres el responsable de calidad de "${input.businessName}". Analizas quejas de clientes en ${lang} y priorizas su resolución. ${COMPLAINT_SCHEMA_HINT}`;
  const userPrompt = `Queja de ${input.authorName} (${input.rating}/5):\n${input.reviewText}`;

  // Intento con Google Gemini
  if (isGeminiConfigured()) {
    const outcome = await generateWithGemini({
      systemPrompt,
      userPrompt,
      temperature: 0.2,
      maxOutputTokens: 400,
    });
    if (outcome.ok && outcome.text) {
      try {
        const cleaned = outcome.text.replace(/```json/g, '').replace(/```/g, '').trim();
        const parsed = JSON.parse(cleaned);
        return { ...normalizeInspection(parsed, input), provider: 'gemini', usage: usageFromGemini(outcome) };
      } catch {
        /* fallback si el JSON de Gemini no es parseable */
      }
    }
  }

  return {
    ...localComplaintInspection(input),
    provider: 'local-heuristic',
    usage: localUsage('local-heuristic', isGeminiConfigured() ? 'gemini_fallback' : 'gemini_not_configured'),
  };
}

/* ------------------------------------------------------------------ */
/* Inteligencia de Reputación y Análisis de Sentimiento               */
/* ------------------------------------------------------------------ */

type ReviewIntelligence = {
  sentiment: 'muy_positivo' | 'positivo' | 'neutral' | 'negativo' | 'critico';
  score: number; // 0-100
  language: string;
  churnRisk: 'bajo' | 'medio' | 'alto';
  topics: string[];
  keyInsight: string;
  recommendedAction: string;
  suggestedReplyVariant: {
    standard: string;
    short: string;
    loyaltyRecovery: string;
  };
  provider: 'gemini' | 'local-intelligence';
};

export async function analyzeReviewIntelligence(input: {
  businessName: string;
  authorName: string;
  rating: number;
  reviewText: string;
  tone?: 'profesional' | 'cercano' | 'formal';
}): Promise<ReviewIntelligence> {
  const { businessName, authorName, rating, reviewText } = input;
  const lower = (reviewText || '').toLowerCase();

  // Heurística base
  const sentiment: ReviewIntelligence['sentiment'] =
    rating >= 5 ? 'muy_positivo' : rating === 4 ? 'positivo' : rating === 3 ? 'neutral' : rating === 2 ? 'negativo' : 'critico';
  const churnRisk: ReviewIntelligence['churnRisk'] = rating <= 2 ? 'alto' : rating === 3 ? 'medio' : 'bajo';
  const score = rating === 5 ? 95 : rating === 4 ? 80 : rating === 3 ? 50 : rating === 2 ? 30 : 10;

  const topics: string[] = [];
  if (lower.includes('trato') || lower.includes('atencion') || lower.includes('atención') || lower.includes('camarer') || lower.includes('personal') || lower.includes('chico')) {
    topics.push('Atención al cliente');
  }
  if (lower.includes('espera') || lower.includes('tard') || lower.includes('rapido') || lower.includes('rápido') || lower.includes('retraso')) {
    topics.push('Tiempo y velocidad');
  }
  if (lower.includes('precio') || lower.includes('caro') || lower.includes('barato') || lower.includes('cuenta') || lower.includes('cobro')) {
    topics.push('Relación calidad-precio');
  }
  if (lower.includes('comida') || lower.includes('plato') || lower.includes('producto') || lower.includes('pedido') || lower.includes('calidad')) {
    topics.push('Calidad de producto');
  }
  if (lower.includes('limpio') || lower.includes('limpieza') || lower.includes('sucio') || lower.includes('local') || lower.includes('ambiente')) {
    topics.push('Ambiente e instalaciones');
  }
  if (topics.length === 0) {
    topics.push('Experiencia general');
  }

  // Detección simple de idioma
  let lang = 'es';
  if (/\b(the|is|and|great|good|bad|service|food|place|recommend)\b/i.test(lower)) lang = 'en';
  else if (/\b(le|la|très|bon|mauvais|merci|service)\b/i.test(lower)) lang = 'fr';
  else if (/\b(sehr|gut|nicht|danke|schlecht)\b/i.test(lower)) lang = 'de';

  const keyInsight = rating >= 4
    ? `Cliente muy satisfecho con ${topics.join(' y ')}. Oportunidad de fidelización continua.`
    : `Fricción identificada en ${topics.join(', ')}. Conviene responder antes de 24h para neutralizar el impacto.`;

  const recommendedAction = rating >= 4
    ? 'Agradecer públicamente e invitar a su próxima visita.'
    : rating === 3
      ? 'Agradecer el apunte y solicitar detalle constructivo por privado.'
      : 'Ofrecer contacto directo de gerencia y solución compensatoria inmediata.';

  const standard = rating >= 4
    ? `¡Hola ${authorName}! Muchísimas gracias por tus amables palabras y tu valoración de ${rating} estrellas sobre ${businessName}. Nos alegra enormemente que disfrutaras de tu experiencia con nosotros. ¡Esperamos verte de nuevo muy pronto!`
    : `Hola ${authorName}, lamentamos sinceramente que tu experiencia no haya alcanzado las expectativas en ${businessName}. Tu opinión es fundamental para nosotros. ¿Podrías escribirnos por privado para poder revisar lo ocurrido y darte una solución personalizada? Gracias por ayudarnos a mejorar.`;

  const short = rating >= 4
    ? `¡Mil gracias por tu valoración de 5 estrellas, ${authorName}! Un placer recibirte en ${businessName}. ¡Hasta pronto!`
    : `Sentimos lo ocurrido, ${authorName}. Queremos compensarte: por favor contáctanos para solucionarlo hoy mismo. — ${businessName}`;

  const loyaltyRecovery = rating >= 4
    ? `¡Hola ${authorName}! Gracias por ser parte de la familia de ${businessName}. En tu próxima visita, no dudes en saludarnos, ¡te guardamos lo mejor!`
    : `Estimado/a ${authorName}, en ${businessName} nuestro compromiso es tu satisfacción al 100%. Te invitamos a comunicarte directamente con nuestra dirección para revisar tu caso y garantizar que tu próxima visita sea perfecta.`;

  return {
    sentiment,
    score,
    language: lang,
    churnRisk,
    topics,
    keyInsight,
    recommendedAction,
    suggestedReplyVariant: {
      standard,
      short,
      loyaltyRecovery,
    },
    provider: 'local-intelligence',
  };
}

/** Inspección de queja CON control de cuota (1 evento `ai`). */
export async function inspectComplaintForTenant(
  ctx: AiContext,
  input: { businessName: string; authorName: string; rating: number; reviewText: string; language?: string },
): Promise<AiResult<{ inspection: ComplaintInspection }>> {
  // Misma puerta de IA que las respuestas, con la feature del triaje privado.
  const gate = await enforceAi(ctx.admin, ctx.tenantId, {
    feature: 'privateFilter',
    action: 'Inspección de queja',
  });
  if (!gate.ok) {
    await systemLog('warn', 'ai.quota', gate.error, { tenantId: ctx.tenantId, code: gate.code });
    return blockedResult(gate);
  }

  const inspection = await inspectComplaint(input);
  await consume(ctx.admin, ctx.tenantId, 'ai', 1);
  await recordAiUsage(ctx.admin, ctx.tenantId, {
    ...inspection.usage,
    purpose: 'triage.inspect',
    ok: inspection.usage.provider === 'gemini',
  });
  await systemLog('info', 'ai.triage', `Queja inspeccionada (${inspection.severity}/${inspection.category})`, {
    tenantId: ctx.tenantId,
    provider: inspection.provider,
    costUsd: inspection.usage.costUsd,
  });

  return { ok: true, status: 200, inspection, quota: quotaOf(gate.check, 1) };
}

const LEGAL_HINTS = [
  'denuncia', 'demanda', 'consumo', 'omic', 'sanidad', 'intoxic', 'lesion', 'lesión',
  'estafa', 'fraude', 'publicidad engañosa', 'hoja de reclamaciones', 'abogado', 'demandar',
];

function localComplaintInspection(input: {
  businessName: string;
  authorName: string;
  rating: number;
  reviewText: string;
}): ComplaintAnalysis {
  const text = (input.reviewText ?? '').toLowerCase();
  const legalRisk = LEGAL_HINTS.some((h) => text.includes(h));
  const severity: ComplaintSeverity = legalRisk
    ? 'critica'
    : input.rating <= 1
      ? 'alta'
      : input.rating === 2
        ? 'media'
        : 'baja';
  const category = text.includes('retras') || text.includes('tard')
    ? 'Retraso en el servicio'
    : text.includes('trato') || text.includes('atencion') || text.includes('atención')
      ? 'Trato al cliente'
      : text.includes('precio') || text.includes('cobr') || text.includes('factur')
        ? 'Precio o facturación'
        : text.includes('producto') || text.includes('pedido') || text.includes('calidad')
          ? 'Producto o pedido'
          : 'Experiencia general';

  return {
    severity,
    category,
    legalRisk,
    suggestedChannel: severity === 'critica' || severity === 'alta' ? 'telefono' : 'privado',
    summary: text.slice(0, 197) || 'Queja sin texto.',
    actionPlan: [
      `Contactar a ${input.authorName} en menos de 24 h por el canal sugerido.`,
      'Escuchar el caso y reconocer el fallo sin justificarse.',
      'Ofrecer una compensación proporcional y dejarla por escrito.',
      legalRisk
        ? 'Escalar a dirección: posible reclamación formal.'
        : 'Anotar el seguimiento en la nota privada de la reseña.',
    ],
    provider: 'local-heuristic',
  };
}

function normalizeInspection(
  raw: Record<string, unknown> | null | undefined,
  input: { authorName: string; rating: number; reviewText: string },
): ComplaintAnalysis {
  const fallback = localComplaintInspection({
    businessName: '',
    authorName: input.authorName,
    rating: input.rating,
    reviewText: input.reviewText,
  });
  const rawSeverity = typeof raw?.severity === 'string' ? raw.severity : '';
  const rawChannel = typeof raw?.suggestedChannel === 'string' ? raw.suggestedChannel : '';
  const sev = ['baja', 'media', 'alta', 'critica'].includes(rawSeverity) ? rawSeverity : fallback.severity;
  const channel = ['privado', 'telefono', 'publico'].includes(rawChannel)
    ? rawChannel
    : fallback.suggestedChannel;
  const plan = Array.isArray(raw?.actionPlan)
    ? raw.actionPlan.filter((x: unknown): x is string => typeof x === 'string').slice(0, 4)
    : fallback.actionPlan;
  return {
    severity: sev as ComplaintSeverity,
    category: typeof raw?.category === 'string' && raw.category.trim() ? raw.category.trim() : fallback.category,
    legalRisk: typeof raw?.legalRisk === 'boolean' ? raw.legalRisk : fallback.legalRisk,
    suggestedChannel: channel as ComplaintInspection['suggestedChannel'],
    summary: typeof raw?.summary === 'string' ? raw.summary.slice(0, 200) : fallback.summary,
    actionPlan: plan.length > 0 ? plan : fallback.actionPlan,
    provider: 'gemini',
  };
}
