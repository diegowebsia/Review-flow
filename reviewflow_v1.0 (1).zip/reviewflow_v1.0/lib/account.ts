import { z } from 'zod';

export const EMAIL_PREF_KEYS = ['weekly_digest', 'review_alerts'] as const;
export type EmailPrefKey = (typeof EMAIL_PREF_KEYS)[number];
export type EmailPrefs = Record<EmailPrefKey, boolean>;

const DEFAULT_EMAIL_PREFS: EmailPrefs = {
  weekly_digest: true,
  review_alerts: true,
};

export function normalizeEmailPrefs(raw: unknown): EmailPrefs {
  const src = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const out = { ...DEFAULT_EMAIL_PREFS };
  for (const k of EMAIL_PREF_KEYS) if (typeof src[k] === 'boolean') out[k] = src[k] as boolean;
  return out;
}

export const ProfileSchema = z.object({
  fullName: z.string().trim().max(120),
  phone: z
    .string()
    .trim()
    .max(30)
    .regex(/^[+0-9 ()-]*$/, 'Teléfono no válido'),
  locale: z.enum(['es', 'en', 'ca', 'pt', 'fr', 'de', 'it']),
  emailPrefs: z.object({
    weekly_digest: z.boolean(),
    review_alerts: z.boolean(),
  }).optional(),
});

/** Estados que cuentan como «suscripción todavía activa» (bloquean el borrado de la cuenta). */
export const BLOCKING_SUBSCRIPTION_STATUSES = ['active', 'trialing', 'past_due', 'paused'];

export type ActiveSubscription = { tenantId: string; name: string; status: string };
