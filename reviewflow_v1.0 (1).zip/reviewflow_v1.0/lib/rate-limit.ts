import { createAdminClient } from '@/lib/supabase/admin';
import { hashPersonalValue, requestIp } from '@/lib/security';
import type { AdminDatabaseClient } from '@/lib/database.types';

const devTestMemoryStore = new Map<string, { count: number; resetAt: number }>();

type RateLimitOptions = {
  admin?: AdminDatabaseClient | null;
  warnFn?: (message: string, meta?: Record<string, unknown>) => void;
};

/**
 * Comprueba si existe un backend persistente (Supabase PostgreSQL)
 * configurado para el límite de peticiones distribuido.
 */
export function isPersistentRateLimitConfigured(envObj: NodeJS.ProcessEnv = process.env): boolean {
  return Boolean(
    envObj.NEXT_PUBLIC_SUPABASE_URL?.trim() && envObj.SUPABASE_SERVICE_ROLE_KEY?.trim(),
  );
}

/**
 * Registra un aviso claro en los logs si en producción no está configurado
 * ningún backend persistente de rate-limit en base de datos.
 */
export function warnIfPersistentRateLimitUnconfigured(
  envObj: NodeJS.ProcessEnv = process.env,
  warnFn: (message: string) => void = (msg) => console.warn(msg),
): { configured: boolean; backend: 'database' | 'memory'; warning: string | null } {
  const hasSupabase = Boolean(
    envObj.NEXT_PUBLIC_SUPABASE_URL?.trim() && envObj.SUPABASE_SERVICE_ROLE_KEY?.trim(),
  );
  if (hasSupabase) {
    return { configured: true, backend: 'database', warning: null };
  }

  if (envObj.NODE_ENV === 'production') {
    const warning =
      '[RateLimit] Aviso en producción: No hay límite de peticiones persistente configurado (falta SUPABASE_SERVICE_ROLE_KEY).';
    warnFn(warning);
    return { configured: false, backend: 'memory', warning };
  }

  return { configured: false, backend: 'memory', warning: null };
}

/**
 * Límite de peticiones persistente (multi-instancia / serverless) mediante Supabase:
 * 1. Tabla `api_rate_limits` / RPC `consume_rate_limit` en base de datos PostgreSQL (Supabase).
 * 2. Si no está configurado en producción, registra un aviso claro en los logs y aplica fail-closed.
 */
export async function consumeRateLimit(
  scope: string,
  identity: string,
  limit: number,
  windowSeconds: number,
  options?: RateLimitOptions,
): Promise<{ allowed: boolean; retryAfter: number }> {
  const key = hashPersonalValue(`${scope}:${identity}`);

  // 1. Base de datos PostgreSQL persistente (RPC `consume_rate_limit` o tabla `api_rate_limits`)
  const admin = options?.admin !== undefined ? options.admin : createAdminClient();
  if (admin) {
    if (typeof admin.rpc === 'function') {
      const { data, error } = await admin.rpc('consume_rate_limit', {
        p_key: key,
        p_limit: limit,
        p_window_seconds: windowSeconds,
      });
      if (!error && data !== undefined && data !== null) {
        const row = (Array.isArray(data) ? data[0] : data) as
          | { allowed?: boolean; retry_after?: number }
          | undefined;
        return {
          allowed: Boolean(row?.allowed),
          retryAfter: Number(row?.retry_after ?? (row?.allowed ? 0 : windowSeconds)),
        };
      }
      if (error && typeof admin.from !== 'function') {
        console.error('rate_limit_backend_error', { scope, code: error.code });
        return { allowed: false, retryAfter: windowSeconds };
      }
      if (error) {
        console.error('rate_limit_backend_error', { scope, code: error.code });
        return { allowed: false, retryAfter: windowSeconds };
      }
    }

    // Soporte directo contra tabla `api_rate_limits` cuando se inyecta adaptador tabular
    if (typeof admin.from === 'function') {
      try {
        const now = Date.now();
        const { data: existing } = await admin
          .from('api_rate_limits')
          .select('key_hash, count, reset_at')
          .eq('key_hash', key)
          .maybeSingle();

        const typedExisting = existing as { key_hash: string; count: number; reset_at: string } | null;
        const resetMs = typedExisting?.reset_at ? new Date(typedExisting.reset_at).getTime() : 0;

        if (!typedExisting || Number.isNaN(resetMs) || resetMs <= now) {
          const nextResetIso = new Date(now + windowSeconds * 1000).toISOString();
          await admin.from('api_rate_limits').upsert({
            key_hash: key,
            count: 1,
            reset_at: nextResetIso,
          });
          return { allowed: 1 <= limit, retryAfter: 1 <= limit ? 0 : windowSeconds };
        }

        const nextCount = Number(typedExisting.count ?? 0) + 1;
        await admin
          .from('api_rate_limits')
          .update({ count: nextCount })
          .eq('key_hash', key);
        const retryAfter = Math.max(1, Math.ceil((resetMs - now) / 1000));
        return {
          allowed: nextCount <= limit,
          retryAfter: nextCount <= limit ? 0 : retryAfter,
        };
      } catch (dbErr) {
        console.error('rate_limit_table_error', {
          scope,
          error: dbErr instanceof Error ? dbErr.message : 'db_error',
        });
        return { allowed: false, retryAfter: windowSeconds };
      }
    }
  }

  // 2. Si no hay BD en producción: registrar aviso claro en logs y bloquear (fail-closed)
  if (process.env.NODE_ENV === 'production') {
    const warnMessage =
      '[RateLimit] Aviso en producción: Límite de peticiones persistente (tabla api_rate_limits en base de datos) no configurado. Petición bloqueada por seguridad.';
    if (options?.warnFn) {
      options.warnFn(warnMessage, { scope });
    } else {
      console.warn(warnMessage, { scope });
    }
    return { allowed: false, retryAfter: windowSeconds };
  }

  // 4. Almacenamiento efímero únicamente para entorno local de desarrollo o pruebas unitarias sin BD
  const now = Date.now();
  const current = devTestMemoryStore.get(key);
  if (!current || current.resetAt <= now) {
    devTestMemoryStore.set(key, { count: 1, resetAt: now + windowSeconds * 1000 });
    return { allowed: true, retryAfter: 0 };
  }
  current.count += 1;
  return {
    allowed: current.count <= limit,
    retryAfter: current.count <= limit ? 0 : Math.ceil((current.resetAt - now) / 1000),
  };
}

/** Rate limit por IP de la petición */
export async function rateLimitByIp(
  req: Request,
  scope: string,
  limit: number,
  windowSeconds: number,
  options?: RateLimitOptions,
): Promise<{ allowed: boolean; retryAfter: number; ip: string }> {
  const ip = requestIp(req);
  const result = await consumeRateLimit(scope, ip, limit, windowSeconds, options);
  return { ...result, ip };
}

/** Rate limit por Empresa (Tenant) para prevenir abuso de cuotas compartidas o saturación de Gemini */
export async function rateLimitByTenant(
  tenantId: string,
  scope: string,
  limit: number,
  windowSeconds: number,
  options?: RateLimitOptions,
): Promise<{ allowed: boolean; retryAfter: number }> {
  return consumeRateLimit(`${scope}:tenant`, tenantId, limit, windowSeconds, options);
}
