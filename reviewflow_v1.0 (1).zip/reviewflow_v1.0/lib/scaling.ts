/**
 * Umbrales de escalado: cuándo contratar / pagar cada servicio.
 * Es la versión "ejecutable" de los umbrales de escalado en GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md: el panel de admin
 * compara el uso real con estas cifras y te avisa del siguiente paso.
 * Ajusta las cifras aquí si cambian los precios de los proveedores.
 */
export type ScalingMetric = 'tenants' | 'reviewsPerHour' | 'aiCallsPerHour' | 'aiCostMonthUsd' | 'dbMb' | 'dbConnections';

type ScalingStep = {
  metric: ScalingMetric;
  /** A partir de este valor toca dar el paso. */
  threshold: number;
  service: string;
  action: string;
  monthlyCost: string;
};

export const SCALING_STEPS: ScalingStep[] = [
  { metric: 'tenants', threshold: 1, service: 'Stripe live + dominio + Supabase Pro + Vercel Pro', action: 'Antes del primer cliente de pago: configura Stripe live, copias de seguridad y tareas automáticas.', monthlyCost: 'Según los planes contratados' },
  { metric: 'tenants', threshold: 50, service: 'Capacidad y correo', action: 'Revisa el uso en Vercel y Supabase; amplía Resend si superas 3.000 correos/mes.', monthlyCost: 'Según consumo' },
  { metric: 'tenants', threshold: 200, service: 'Supabase compute + cola PostgreSQL', action: 'Revisa la latencia, los trabajos pendientes y el uso de la base de datos antes de ampliar compute.', monthlyCost: 'Según consumo' },
  { metric: 'tenants', threshold: 1000, service: 'Supabase + soporte humano', action: 'Revisa SLA, copias de seguridad y capacidad de soporte.', monthlyCost: 'Según el plan y el equipo' },
  { metric: 'reviewsPerHour', threshold: 500, service: 'Cola PostgreSQL', action: 'Revisa trabajos pendientes, latencia y frecuencia del worker; amplía capacidad si hay retrasos.', monthlyCost: 'Incluido en la base de datos; ampliación según uso' },
  { metric: 'aiCallsPerHour', threshold: 600, service: 'Proveedor de IA', action: 'Revisa errores de cuota y límites del proveedor; activa facturación si es necesario.', monthlyCost: 'Según consumo' },
  { metric: 'aiCallsPerHour', threshold: 6000, service: 'Cuota de IA o proveedor de respaldo', action: 'Pide subida de cuota o añade AI_FALLBACK_PROVIDER.', monthlyCost: 'Según consumo' },
  { metric: 'aiCostMonthUsd', threshold: 50, service: 'Presupuesto de IA', action: 'Configura un presupuesto con alerta al 80 % en el proveedor utilizado.', monthlyCost: 'Según proveedor' },
  { metric: 'dbMb', threshold: 350, service: 'Almacenamiento Supabase', action: 'Revisa el uso de almacenamiento y el espacio disponible del plan contratado.', monthlyCost: 'Según el plan' },
  { metric: 'dbMb', threshold: 6000, service: 'Disco extra Supabase', action: 'Añade disco o aplica la política de retención de logs.', monthlyCost: 'Según consumo' },
  { metric: 'dbConnections', threshold: 40, service: 'Pooler / compute superior', action: 'Usa el pooler (puerto 6543) o sube el compute.', monthlyCost: 'Según el plan' },
];

export type CapacitySnapshot = Record<ScalingMetric, number>;

type ScalingAdvice = ScalingStep & { current: number; reached: boolean; pct: number };

/** Para cada métrica devuelve el siguiente paso pendiente (o el último alcanzado). */
export function scalingAdvice(snap: CapacitySnapshot): ScalingAdvice[] {
  const metrics = [...new Set(SCALING_STEPS.map((s) => s.metric))];
  return metrics.map((m) => {
    const steps = SCALING_STEPS.filter((s) => s.metric === m).sort((a, b) => a.threshold - b.threshold);
    const current = snap[m] ?? 0;
    const next = steps.find((s) => current < s.threshold);
    const step = next ?? steps[steps.length - 1];
    return {
      ...step,
      current,
      reached: !next,
      pct: Math.min(100, Math.round((current / step.threshold) * 100)),
    };
  });
}
