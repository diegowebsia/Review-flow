/**
 * Capa de IA GENÉRICA (independiente del proveedor).
 *
 * Para cambiar de modelo o de proveedor SOLO hay que tocar variables de entorno,
 * nunca el código. Ejemplos:
 *
 *   # Gemini (por defecto). Subir de nivel = cambiar el modelo:
 *   AI_PROVIDER=gemini      AI_MODEL=gemini-2.5-flash   (barato)
 *   AI_PROVIDER=gemini      AI_MODEL=gemini-2.5-pro     (superior)
 *
 *   # Cualquier API compatible con OpenAI (OpenAI, OpenRouter, Groq, DeepSeek, Mistral, Together…):
 *   AI_PROVIDER=openai      AI_MODEL=gpt-4.1-mini   AI_API_KEY=sk-...
 *   AI_PROVIDER=openai      AI_BASE_URL=https://openrouter.ai/api/v1  AI_MODEL=anthropic/claude-sonnet-4  AI_API_KEY=...
 *
 *   # Anthropic directo:
 *   AI_PROVIDER=anthropic   AI_MODEL=claude-sonnet-4-5  AI_API_KEY=sk-ant-...
 *
 *   # Respaldo automático si el principal falla (cuota agotada, caída, timeout):
 *   AI_FALLBACK_PROVIDER=gemini  AI_FALLBACK_MODEL=gemini-2.5-flash  AI_FALLBACK_API_KEY=...
 *
 * Compatibilidad: si no defines nada de esto, se usa GEMINI_API_KEY + GEMINI_MODEL como antes.
 * Si TODO falla, `lib/ai.ts` usa sus plantillas locales: la web nunca se rompe.
 */
import { generateWithGemini, type GeminiChatOutcome } from '@/lib/gemini';
import { aiModelPricing } from '@/lib/plans';

type LlmProvider = 'gemini' | 'openai' | 'anthropic';
type LlmOutcome = GeminiChatOutcome & { provider?: LlmProvider };

type Target = { provider: LlmProvider; model: string; apiKey: string; baseUrl?: string };

const TIMEOUT_MS = Number(process.env.AI_TIMEOUT_MS) || 20_000;

function normProvider(v: string | undefined): LlmProvider {
  const p = (v || 'gemini').trim().toLowerCase();
  if (p === 'anthropic' || p === 'claude') return 'anthropic';
  if (['openai', 'openrouter', 'groq', 'deepseek', 'mistral', 'together', 'compatible'].includes(p)) return 'openai';
  return 'gemini';
}

/** Objetivos de IA en orden (principal → respaldo), solo los que tienen clave. */
/** Limpia comillas/espacios pegados por error en el .env. */
function cleanVar(v: string | undefined): string {
  return (v || '').trim().replace(/^["']|["']$/g, '').trim();
}

/** Si el modelo no corresponde al proveedor (p. ej. AI_PROVIDER=openai con AI_MODEL=gemini-2.5-flash), usa el modelo por defecto. */
function modelFor(p: LlmProvider, model: string, baseUrl?: string): string {
  const m = model.toLowerCase();
  if (!m) return defaultModel(p);
  if (p === 'gemini' && !m.startsWith('gemini')) return defaultModel(p);
  if (p === 'anthropic' && !m.startsWith('claude')) return defaultModel(p);
  // En APIs compatibles con OpenAI (OpenRouter, Groq…) cualquier nombre es válido salvo un modelo Gemini/Claude sin prefijo en OpenAI oficial.
  if (p === 'openai' && !baseUrl && (m.startsWith('gemini') || m.startsWith('claude'))) return defaultModel(p);
  return model;
}

function llmTargets(): Target[] {
  const raw = process.env;
  const env = new Proxy({} as Record<string, string>, { get: (_t, k: string) => cleanVar(raw[k]) });
  const out: Target[] = [];
  const primaryProvider = normProvider(env.AI_PROVIDER);
  const primaryKey = (env.AI_API_KEY || (primaryProvider === 'gemini' ? env.GEMINI_API_KEY : '') || '').trim();
  const primaryModel = (env.AI_MODEL || (primaryProvider === 'gemini' ? env.GEMINI_MODEL : '') || defaultModel(primaryProvider)).trim();
  if (primaryKey) out.push({ provider: primaryProvider, model: modelFor(primaryProvider, primaryModel, env.AI_BASE_URL), apiKey: primaryKey, baseUrl: env.AI_BASE_URL || undefined });

  if (env.AI_FALLBACK_PROVIDER || env.AI_FALLBACK_MODEL) {
    const fp = normProvider(env.AI_FALLBACK_PROVIDER || primaryProvider);
    const fk = (env.AI_FALLBACK_API_KEY || (fp === primaryProvider ? primaryKey : '') || (fp === 'gemini' ? env.GEMINI_API_KEY : '') || '').trim();
    if (fk) out.push({ provider: fp, model: modelFor(fp, env.AI_FALLBACK_MODEL, env.AI_FALLBACK_BASE_URL), apiKey: fk, baseUrl: env.AI_FALLBACK_BASE_URL || undefined });
  }
  // Compatibilidad: si el principal no es Gemini pero hay GEMINI_API_KEY, úsalo de último respaldo.
  if (primaryProvider !== 'gemini' && env.GEMINI_API_KEY && !out.some((t) => t.provider === 'gemini')) {
    out.push({ provider: 'gemini', model: (env.GEMINI_MODEL || 'gemini-2.5-flash').trim(), apiKey: env.GEMINI_API_KEY.trim() });
  }
  return out;
}

function defaultModel(p: LlmProvider): string {
  if (p === 'openai') return 'gpt-4.1-mini';
  if (p === 'anthropic') return 'claude-haiku-4-5';
  return 'gemini-2.5-flash';
}

export function isLlmConfigured(): boolean {
  return llmTargets().length > 0;
}

export function llmStatus() {
  return llmTargets().map((t) => ({ provider: t.provider, model: t.model, baseUrl: t.baseUrl ?? null }));
}

type Params = {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  maxOutputTokens?: number;
  model?: string;
  maxAttempts?: number;
};

function fail(model: string, start: number, attempts: number, code: string, provider: LlmProvider): LlmOutcome {
  return { ok: false, model, tokens: { prompt: 0, completion: 0, total: 0 }, latencyMs: Date.now() - start, costUsd: 0, attempts, code, provider };
}

function cost(model: string, p: number, c: number) {
  const price = aiModelPricing(model);
  return (p / 1_000_000) * price.input + (c / 1_000_000) * price.output;
}

type LlmApiBody = {
  choices?: Array<{ message?: { content?: string } }>;
  content?: Array<{ text?: string }>;
  usage?: { prompt_tokens?: number; completion_tokens?: number; input_tokens?: number; output_tokens?: number };
};

async function fetchJson(url: string, init: RequestInit): Promise<{ status: number; body: LlmApiBody }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { ...init, signal: ctrl.signal });
    const body = (await res.json().catch(() => ({}))) as LlmApiBody;
    return { status: res.status, body };
  } finally {
    clearTimeout(timer);
  }
}

async function callOpenAiCompatible(t: Target, p: Params, attempts: number): Promise<LlmOutcome> {
  const start = Date.now();
  const base = (t.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
  for (let a = 1; a <= attempts; a += 1) {
    try {
      const { status, body } = await fetchJson(`${base}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t.apiKey}` },
        body: JSON.stringify({
          model: t.model,
          // Los modelos de razonamiento de OpenAI (gpt-5*, o1/o3/o4…) rechazan `max_tokens` y `temperature`.
          ...(/^(openai\/)?(gpt-5|o\d)/i.test(t.model)
            ? { max_completion_tokens: Math.max(p.maxOutputTokens ?? 250, 1000) }
            : { temperature: p.temperature ?? 0.7, max_tokens: p.maxOutputTokens ?? 250 }),
          messages: [
            { role: 'system', content: p.systemPrompt },
            { role: 'user', content: p.userPrompt },
          ],
        }),
      });
      if (status === 401 || status === 403) return fail(t.model, start, a, 'invalid_api_key', 'openai');
      if (status >= 400) throw new Error(`http_${status}`);
      const text = String(body?.choices?.[0]?.message?.content ?? '').trim();
      const pt = Number(body?.usage?.prompt_tokens ?? Math.ceil((p.systemPrompt.length + p.userPrompt.length) / 4));
      const ct = Number(body?.usage?.completion_tokens ?? Math.ceil(text.length / 4));
      if (!text) throw new Error('empty');
      return { ok: true, text, model: t.model, tokens: { prompt: pt, completion: ct, total: pt + ct }, latencyMs: Date.now() - start, costUsd: cost(t.model, pt, ct), attempts: a, provider: 'openai' };
    } catch {
      if (a >= attempts) return fail(t.model, start, a, 'llm_api_error', 'openai');
      await new Promise((r) => setTimeout(r, 200 * a));
    }
  }
  return fail(t.model, start, attempts, 'llm_api_error', 'openai');
}

async function callAnthropic(t: Target, p: Params, attempts: number): Promise<LlmOutcome> {
  const start = Date.now();
  const base = (t.baseUrl || 'https://api.anthropic.com/v1').replace(/\/$/, '');
  for (let a = 1; a <= attempts; a += 1) {
    try {
      const { status, body } = await fetchJson(`${base}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': t.apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({
          model: t.model,
          max_tokens: p.maxOutputTokens ?? 250,
          temperature: p.temperature ?? 0.7,
          system: p.systemPrompt,
          messages: [{ role: 'user', content: p.userPrompt }],
        }),
      });
      if (status === 401 || status === 403) return fail(t.model, start, a, 'invalid_api_key', 'anthropic');
      if (status >= 400) throw new Error(`http_${status}`);
      const text = String((body?.content ?? []).map((c: { text?: string }) => c.text ?? '').join('')).trim();
      const pt = Number(body?.usage?.input_tokens ?? 0);
      const ct = Number(body?.usage?.output_tokens ?? 0);
      if (!text) throw new Error('empty');
      return { ok: true, text, model: t.model, tokens: { prompt: pt, completion: ct, total: pt + ct }, latencyMs: Date.now() - start, costUsd: cost(t.model, pt, ct), attempts: a, provider: 'anthropic' };
    } catch {
      if (a >= attempts) return fail(t.model, start, a, 'llm_api_error', 'anthropic');
      await new Promise((r) => setTimeout(r, 200 * a));
    }
  }
  return fail(t.model, start, attempts, 'llm_api_error', 'anthropic');
}

async function callGemini(t: Target, p: Params, attempts: number): Promise<LlmOutcome> {
  // El SDK de Gemini lee GEMINI_API_KEY; si la clave viene de AI_API_KEY la exponemos para esta llamada.
  if (!cleanVar(process.env.GEMINI_API_KEY)) process.env.GEMINI_API_KEY = t.apiKey;
  const pm = p.model && p.model.toLowerCase().startsWith('gemini') ? p.model : t.model;
  const r = await generateWithGemini({ ...p, model: pm, maxAttempts: attempts });
  return { ...r, provider: 'gemini' };
}

/**
 * Genera texto con el primer proveedor disponible y, si falla, salta al siguiente.
 * Devuelve SIEMPRE la misma forma (compatible con el antiguo `generateWithGemini`).
 */
export async function generateWithLlm(p: Params): Promise<LlmOutcome> {
  const targets = llmTargets();
  const attempts = Math.max(1, Math.min(4, p.maxAttempts ?? 2));
  let last: LlmOutcome = fail(p.model || 'none', Date.now(), 0, 'llm_not_configured', 'gemini');
  for (const t of targets) {
    const outcome =
      t.provider === 'openai'
        ? await callOpenAiCompatible(t, p, attempts)
        : t.provider === 'anthropic'
          ? await callAnthropic(t, p, attempts)
          : await callGemini(t, p, attempts);
    if (outcome.ok && outcome.text) return outcome;
    last = outcome;
  }
  return last;
}
