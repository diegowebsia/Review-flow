import type { SupabaseClient } from '@supabase/supabase-js';

/** Pasos persistentes del checklist de activación (tenants.settings.onboarding_steps). */
export const ONBOARDING_STEPS = [
  'connect_google',
  'import_reviews',
  'define_tone',
  'send_first_request',
  'publish_first_reply',
] as const;

type OnboardingStep = (typeof ONBOARDING_STEPS)[number];

/**
 * Marca un paso del onboarding como completado en el servidor.
 * Best-effort: nunca lanza ni bloquea la acción real del cliente.
 */
export async function markOnboardingStep(
  admin: SupabaseClient,
  tenantId: string,
  step: OnboardingStep,
): Promise<void> {
  try {
    const { data } = await admin.from('tenants').select('settings').eq('id', tenantId).single();
    const settings = ((data?.settings as Record<string, unknown> | null) ?? {}) as Record<string, unknown>;
    const steps = (settings.onboarding_steps as Record<string, boolean> | undefined) ?? {};
    if (steps[step]) return;
    await admin
      .from('tenants')
      .update({ settings: { ...settings, onboarding_steps: { ...steps, [step]: true } } })
      .eq('id', tenantId);
  } catch {
    /* best effort */
  }
}
