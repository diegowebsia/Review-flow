/**
 * Prueba gratuita: SOLO 1 vez por cuenta (v1.0).
 *
 * Una cuenta pierde la prueba gratis en cuanto se cumple cualquiera de estas condiciones:
 *   1. Ya existe una fila en `free_trial_claims` para su usuario o su email normalizado.
 *   2. Alguna de sus empresas tuvo antes un periodo de prueba (`trial_ends_at`) o una suscripción.
 *   3. Su cliente de Stripe ya tuvo alguna suscripción (aunque esté cancelada).
 *
 * El email se normaliza (minúsculas, sin «+alias» y sin puntos en Gmail) para que
 * «ana+2@gmail.com» o «a.na@gmail.com» no consigan una segunda prueba.
 * Las empresas adicionales del multipanel se cobran siempre desde el primer día.
 */
import type Stripe from 'stripe';
import type { createAdminClient } from '@/lib/supabase/admin';

type AdminClient = NonNullable<ReturnType<typeof createAdminClient>>;

function normalizeTrialEmail(email: string | null | undefined): string {
  const raw = (email ?? '').trim().toLowerCase();
  const at = raw.lastIndexOf('@');
  if (at <= 0) return raw;
  let local = raw.slice(0, at);
  let domain = raw.slice(at + 1);
  local = local.split('+')[0] ?? local;
  if (domain === 'googlemail.com') domain = 'gmail.com';
  if (domain === 'gmail.com') local = local.replace(/\./g, '');
  return `${local}@${domain}`;
}

export async function hasUsedFreeTrial(
  admin: AdminClient | null,
  stripe: Stripe | null,
  input: { userId: string; email?: string | null; customerId?: string | null },
): Promise<boolean> {
  const normalized = normalizeTrialEmail(input.email);

  if (admin) {
    try {
      const filters = [`user_id.eq.${input.userId}`];
      if (normalized) filters.push(`email.eq.${normalized}`);
      const { data } = await admin
        .from('free_trial_claims')
        .select('user_id')
        .or(filters.join(','))
        .limit(1);
      if (data && data.length > 0) return true;
    } catch {
      /* tabla aún no creada: seguimos con el resto de comprobaciones */
    }

    const { data: owned } = await admin
      .from('tenants')
      .select('id, trial_ends_at, stripe_subscription_id, subscription_status')
      .eq('owner_id', input.userId);
    const rows = (owned ?? []) as Array<{
      trial_ends_at: string | null;
      stripe_subscription_id: string | null;
      subscription_status: string | null;
    }>;
    if (
      rows.some(
        (t) =>
          Boolean(t.trial_ends_at) ||
          Boolean(t.stripe_subscription_id) ||
          (t.subscription_status && t.subscription_status !== 'none'),
      )
    ) {
      return true;
    }
  }

  if (stripe && input.customerId) {
    try {
      const subs = await stripe.subscriptions.list({ customer: input.customerId, status: 'all', limit: 1 });
      if (subs.data.length > 0) return true;
    } catch {
      /* cliente de otra cuenta de Stripe */
    }
  }
  return false;
}

/** Marca la prueba gratis como gastada (idempotente). */
export async function recordFreeTrial(
  admin: AdminClient | null,
  input: { userId: string | null; email: string | null | undefined; tenantId?: string | null },
): Promise<void> {
  if (!admin || !input.userId) return;
  const email = normalizeTrialEmail(input.email);
  try {
    await admin.from('free_trial_claims').upsert(
      { user_id: input.userId, email: email || null, tenant_id: input.tenantId ?? null },
      { onConflict: 'user_id', ignoreDuplicates: true },
    );
  } catch {
    /* no bloquea el alta */
  }
}
