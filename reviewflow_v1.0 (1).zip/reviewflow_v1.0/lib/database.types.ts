import type { SupabaseClient } from '@supabase/supabase-js';

type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type TenantSettingsJson = {
  tone?: 'profesional' | 'cercano' | 'formal';
  brand_instructions?: string;
  brand_rules?: string[];
  forbidden_words?: string[];
  brand_signature?: string;
  vertical_template?: string;
  locale?: 'es' | 'en' | 'ca' | 'pt' | 'fr' | 'de' | 'it';
  customer_locale?: 'es' | 'en' | 'ca' | 'pt' | 'fr' | 'de' | 'it';
  slack_webhook_url?: string;
  teams_webhook_url?: string;
  outbound_webhook_url?: string;
  outbound_webhook_secret?: string;
  place_id?: string;
  whatsapp_to?: string;
  trustpilot_url?: string;
  funnel_enabled?: boolean;
  weekly_digest?: boolean;
  scheduled_downgrade_plan?: string | null;
  scheduled_downgrade_at?: string | null;
  paused_until?: string | null;
  recovery_discount_applied_at?: string | null;
  payment_failed_at?: string | null;
  grace_period_ends_at?: string | null;
  reminder_log?: Array<{
    tenant_id: string;
    reminder_type: string;
    period_key: string;
    sent_at: string;
    email_kind: string;
  }>;
  api_key_security?: {
    prefix?: string | null;
    current_hash?: string | null;
    previous_hash?: string | null;
    previous_expires_at?: string | null;
    rotated_at?: string | null;
    last_used_at?: string | null;
    revoked_at?: string | null;
  };
  [key: string]: unknown;
};

export interface Database {
  public: {
    // Generado a partir de supabase/schema.sql (v1.0). Si cambias el esquema, regenera este bloque.
    Tables: {
      addons: {
        Row: {
          id: string;
          tenant_id: string;
          type: string;
          pack: string | null;
          events: number;
          reviews: number;
          ai: number;
          whatsapp: number;
          quantity: number;
          unit_amount_cents: number | null;
          cycle: string;
          stripe_payment_id: string | null;
          stripe_invoice_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          type?: string;
          pack?: string | null;
          events?: number;
          reviews?: number;
          ai?: number;
          whatsapp?: number;
          quantity?: number;
          unit_amount_cents?: number | null;
          cycle: string;
          stripe_payment_id?: string | null;
          stripe_invoice_id?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['addons']['Row']>;
      };
      admin_audit_events: {
        Row: {
          id: number;
          created_at: string;
          actor_email: string;
          action: string;
          tenant_id: string | null;
          reason: string;
          ticket: string;
        };
        Insert: {
          id?: number;
          created_at?: string;
          actor_email: string;
          action: string;
          tenant_id?: string | null;
          reason: string;
          ticket: string;
        };
        Update: Partial<Database['public']['Tables']['admin_audit_events']['Row']>;
      };
      ai_interactions: {
        Row: {
          id: number;
          tenant_id: string;
          cycle: string;
          model: string;
          purpose: string;
          prompt_tokens: number;
          completion_tokens: number;
          total_tokens: number | null;
          cost_usd: number;
          latency_ms: number;
          provider: string;
          ok: boolean;
          error_code: string | null;
          review_id: string | null;
          job_id: string | null;
          result_text: string | null;
          result_status: string;
          created_at: string;
        };
        Insert: {
          id?: number;
          tenant_id: string;
          cycle?: string;
          model?: string;
          purpose?: string;
          prompt_tokens?: number;
          completion_tokens?: number;
          total_tokens?: number | null;
          cost_usd?: number;
          latency_ms?: number;
          provider?: string;
          ok?: boolean;
          error_code?: string | null;
          review_id?: string | null;
          job_id?: string | null;
          result_text?: string | null;
          result_status?: string;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['ai_interactions']['Row']>;
      };
      api_rate_limits: {
        Row: {
          key_hash: string;
          count: number;
          reset_at: string;
        };
        Insert: {
          key_hash: string;
          count?: number;
          reset_at: string;
        };
        Update: Partial<Database['public']['Tables']['api_rate_limits']['Row']>;
      };
      feedback_responses: {
        Row: {
          id: string;
          tenant_id: string;
          stars: number;
          kind: string;
          channel: string | null;
          campaign: string | null;
          customer_name: string | null;
          contact: string | null;
          message: string | null;
          order_id: string | null;
          status: string;
          resolved_at: string | null;
          ip_hash: string | null;
          user_agent: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          stars: number;
          kind: string;
          channel?: string | null;
          campaign?: string | null;
          customer_name?: string | null;
          contact?: string | null;
          message?: string | null;
          order_id?: string | null;
          status?: string;
          resolved_at?: string | null;
          ip_hash?: string | null;
          user_agent?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['feedback_responses']['Row']>;
      };
      free_trial_claims: {
        Row: {
          user_id: string;
          email: string | null;
          tenant_id: string | null;
          claimed_at: string;
        };
        Insert: {
          user_id: string;
          email?: string | null;
          tenant_id?: string | null;
          claimed_at?: string;
        };
        Update: Partial<Database['public']['Tables']['free_trial_claims']['Row']>;
      };
      integrations: {
        Row: {
          id: string;
          tenant_id: string;
          provider: string;
          status: string;
          credentials: unknown;
          external_label: string | null;
          last_sync_at: string | null;
          last_error: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          provider: string;
          status?: string;
          credentials?: unknown;
          external_label?: string | null;
          last_sync_at?: string | null;
          last_error?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['integrations']['Row']>;
      };
      job_queue: {
        Row: {
          id: string;
          type: string;
          payload: Record<string, unknown>;
          status: string;
          attempts: number;
          created_at: string;
          processed_at: string | null;
          locked_at: string | null;
        };
        Insert: {
          id?: string;
          type: string;
          payload?: Record<string, unknown>;
          status?: string;
          attempts?: number;
          created_at?: string;
          processed_at?: string | null;
          locked_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['job_queue']['Row']>;
      };
      memberships: {
        Row: {
          id: string;
          tenant_id: string;
          user_id: string;
          role: string;
          invited_by: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          user_id: string;
          role?: string;
          invited_by?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['memberships']['Row']>;
      };
      processed_events: {
        Row: {
          id: number;
          provider: string;
          tenant_scope: string;
          event_id: string;
          created_at: string;
        };
        Insert: {
          id?: number;
          provider: string;
          tenant_scope?: string;
          event_id: string;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['processed_events']['Row']>;
      };
      quota_events: {
        Row: {
          id: number;
          tenant_id: string;
          cycle: string;
          kind: string;
          amount: number;
          source: string;
          ref: string | null;
          created_at: string;
        };
        Insert: {
          id?: number;
          tenant_id: string;
          cycle?: string;
          kind: string;
          amount?: number;
          source?: string;
          ref?: string | null;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['quota_events']['Row']>;
      };
      reviews: {
        Row: {
          id: string;
          tenant_id: string;
          source: string;
          external_id: string | null;
          author_name: string;
          rating: number;
          text: string;
          reply_text: string | null;
          replied_at: string | null;
          is_verified: boolean;
          flagged_private: boolean;
          private_note: string | null;
          created_at: string;
          detected_locale: string;
          spam_score: number;
          scheduled_publish_at: string | null;
          approval_status: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          source?: string;
          external_id?: string | null;
          author_name?: string;
          rating: number;
          text?: string;
          reply_text?: string | null;
          replied_at?: string | null;
          is_verified?: boolean;
          flagged_private?: boolean;
          private_note?: string | null;
          created_at?: string;
          detected_locale?: string;
          spam_score?: number;
          scheduled_publish_at?: string | null;
          approval_status?: string;
        };
        Update: Partial<Database['public']['Tables']['reviews']['Row']>;
      };
      support_messages: {
        Row: {
          id: string;
          tenant_id: string;
          author_id: string | null;
          author_email: string | null;
          from_admin: boolean;
          body: string;
          read_by_admin: boolean;
          read_by_client: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          author_id?: string | null;
          author_email?: string | null;
          from_admin?: boolean;
          body: string;
          read_by_admin?: boolean;
          read_by_client?: boolean;
          created_at?: string;
        };
        Update: Partial<Database['public']['Tables']['support_messages']['Row']>;
      };
      system_logs: {
        Row: {
          id: string;
          created_at: string;
          level: string;
          source: string;
          message: string;
          meta: Record<string, unknown> | null;
        };
        Insert: {
          id?: string;
          created_at?: string;
          level?: string;
          source?: string;
          message: string;
          meta?: Record<string, unknown> | null;
        };
        Update: Partial<Database['public']['Tables']['system_logs']['Row']>;
      };
      system_settings: {
        Row: {
          key: string;
          value: Json;
          updated_at: string;
          updated_by: string | null;
        };
        Insert: {
          key: string;
          value?: Json;
          updated_at?: string;
          updated_by?: string | null;
        };
        Update: Partial<Database['public']['Tables']['system_settings']['Row']>;
      };
      tenant_roles: {
        Row: {
          id: string;
          tenant_id: string;
          user_id: string;
          role: string;
          invited_by: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          user_id: string;
          role?: string;
          invited_by?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['tenant_roles']['Row']>;
      };
      tenants: {
        Row: {
          id: string;
          name: string;
          slug: string;
          owner_id: string | null;
          owner_email: string;
          plan: string;
          subscription_status: string;
          stripe_customer_id: string | null;
          stripe_subscription_id: string | null;
          trial_ends_at: string | null;
          grace_period_ends_at: string | null;
          api_key: string;
          settings: TenantSettingsJson;
          suspended: boolean;
          extra_requests: number;
          extra_reviews: number;
          extra_ai: number;
          extra_syncs: number;
          extra_stored: number;
          ai_tokens_in: number;
          ai_tokens_out: number;
          ai_requests: number;
          ai_cost_usd: number;
          extra_quota_cycle: string | null;
          extra_quota: number;
          extra_whatsapp: number;
          whatsapp_unlimited: boolean;
          reviews_unlimited: boolean;
          extra_locations: number;
          created_at: string;
          updated_at: string;
          max_members: number;
          api_key_hash: string | null;
          api_key_prefix: string | null;
          api_key_last_used_at: string | null;
          previous_api_key_hash: string | null;
          previous_api_key_expires_at: string | null;
          api_key_revoked_at: string | null;
          locale: string;
          customer_locale: string;
          billing_interval: string;
          tax_id: string | null;
          legal_name: string | null;
        };
        Insert: {
          id?: string;
          name: string;
          slug: string;
          owner_id?: string | null;
          owner_email: string;
          plan?: string;
          subscription_status?: string;
          stripe_customer_id?: string | null;
          stripe_subscription_id?: string | null;
          trial_ends_at?: string | null;
          grace_period_ends_at?: string | null;
          api_key?: string;
          settings?: TenantSettingsJson;
          suspended?: boolean;
          extra_requests?: number;
          extra_reviews?: number;
          extra_ai?: number;
          extra_syncs?: number;
          extra_stored?: number;
          ai_tokens_in?: number;
          ai_tokens_out?: number;
          ai_requests?: number;
          ai_cost_usd?: number;
          extra_quota_cycle?: string | null;
          extra_quota?: number;
          extra_whatsapp?: number;
          whatsapp_unlimited?: boolean;
          reviews_unlimited?: boolean;
          extra_locations?: number;
          created_at?: string;
          updated_at?: string;
          max_members?: number;
          api_key_hash?: string | null;
          api_key_prefix?: string | null;
          api_key_last_used_at?: string | null;
          previous_api_key_hash?: string | null;
          previous_api_key_expires_at?: string | null;
          api_key_revoked_at?: string | null;
          locale?: string;
          customer_locale?: string;
          billing_interval?: string;
          tax_id?: string | null;
          legal_name?: string | null;
        };
        Update: Partial<Database['public']['Tables']['tenants']['Row']>;
      };
      usage_counters: {
        Row: {
          tenant_id: string;
          cycle: string;
          ai_responses: number;
          whatsapp_sent: number;
          reviews_ingested: number;
          google_calls: number;
          ai_tokens_in: number;
          ai_tokens_out: number;
          updated_at: string;
        };
        Insert: {
          tenant_id: string;
          cycle: string;
          ai_responses?: number;
          whatsapp_sent?: number;
          reviews_ingested?: number;
          google_calls?: number;
          ai_tokens_in?: number;
          ai_tokens_out?: number;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['usage_counters']['Row']>;
      };
      user_profiles: {
        Row: {
          user_id: string;
          full_name: string | null;
          phone: string | null;
          locale: string;
          email_prefs: Json;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          full_name?: string | null;
          phone?: string | null;
          locale?: string;
          email_prefs?: Json;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['user_profiles']['Row']>;
      };
      webhook_events: {
        Row: {
          id: number;
          provider: string;
          event_id: string;
          event_type: string;
          status: string;
          attempts: number;
          last_error: string | null;
          created_at: string;
          updated_at: string;
          completed_at: string | null;
        };
        Insert: {
          id?: number;
          provider: string;
          event_id: string;
          event_type: string;
          status?: string;
          attempts?: number;
          last_error?: string | null;
          created_at?: string;
          updated_at?: string;
          completed_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['webhook_events']['Row']>;
      };
      whatsapp_contacts: {
        Row: {
          tenant_id: string;
          phone: string;
          last_inbound_at: string | null;
          last_outbound_at: string | null;
          updated_at: string;
        };
        Insert: {
          tenant_id: string;
          phone: string;
          last_inbound_at?: string | null;
          last_outbound_at?: string | null;
          updated_at?: string;
        };
        Update: Partial<Database['public']['Tables']['whatsapp_contacts']['Row']>;
      };
      whatsapp_optins: {
        Row: {
          id: string;
          tenant_id: string;
          phone: string;
          customer_name: string | null;
          order_id: string | null;
          source: string;
          proof_text: string | null;
          created_at: string;
          revoked_at: string | null;
        };
        Insert: {
          id?: string;
          tenant_id: string;
          phone: string;
          customer_name?: string | null;
          order_id?: string | null;
          source?: string;
          proof_text?: string | null;
          created_at?: string;
          revoked_at?: string | null;
        };
        Update: Partial<Database['public']['Tables']['whatsapp_optins']['Row']>;
      };
    };
    Views: {
      v_ai_usage: {
        Row: {
          tenant_id: string | null;
          name: string | null;
          plan: string | null;
          cycle: string | null;
          ai_replies: number | null;
          tokens_in: number | null;
          tokens_out: number | null;
          tokens_total: number | null;
          tokens_limit: number | null;
          pct_used: number | null;
          calls_cycle: number | null;
          cost_usd_cycle: number | null;
          fallbacks_cycle: number | null;
          tokens_total_historico: number | null;
          cost_usd_historico: number | null;
        };
      };
      v_quota_overview: {
        Row: {
          tenant_id: string | null;
          name: string | null;
          plan: string | null;
          subscription_status: string | null;
          trial_ends_at: string | null;
          cycle: string | null;
          reviews_ingested: number | null;
          ai_responses: number | null;
          whatsapp_sent: number | null;
          google_calls: number | null;
          used_events: number | null;
          quota_events: number | null;
          extra_reviews: number | null;
          extra_ai: number | null;
          extra_syncs: number | null;
          extra_stored: number | null;
          reviews_stored_cap: number | null;
          audit_rows_cap: number | null;
          integrations_cap: number | null;
          addon_packs: number | null;
          addon_events: number | null;
        };
      };
    };
  };
}

/** Cliente Supabase tipado sin uso de `any` explícito */
export type AdminDatabaseClient = SupabaseClient;
export type TypedSupabaseClient = SupabaseClient;

/* ================================================================== */
/* ESQUEMAS ZOD DE LÍMITES DE ENTRADA (WEBHOOKS, PAGOS Y AUTENTICACIÓN) */
/* ================================================================== */
