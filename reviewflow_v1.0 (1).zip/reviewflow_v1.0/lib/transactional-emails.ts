/**
 * ============================================================
 * ReviewFlow AI v1.0 — Emails Transaccionales Multilingües (7 Idiomas)
 * ============================================================
 * Traduce y formatea los correos transaccionales del ciclo de vida del cliente
 * a los 7 idiomas soportados (es, en, ca, pt, fr, de, it), usando Intl.* para
 * precios, fechas y números.
 */

import { formatDateIntl, formatMoneyIntl, formatNumberIntl, resolveLocale, type SupportedCurrency, type SupportedLocale } from '@/lib/i18n';
import { escapeHtml } from '@/lib/security';
import { SITE, version } from '@/lib/site';

export type TransactionalEmailKind =
  | 'welcome'
  | 'payment_confirmed'
  | 'trial_expiring'
  | 'payment_failed'
  | 'abandoned_trial_day3'
  | 'abandoned_trial_day6';

type TransactionalEmailPayload = {
  kind: TransactionalEmailKind;
  locale?: SupportedLocale | string | null;
  currency?: SupportedCurrency;
  tenantName?: string;
  planName?: string;
  amountCents?: number;
  trialEndDate?: Date | string | number;
  graceEndDate?: Date | string | number;
  graceDays?: number;
  attemptCount?: number;
  reviewsCount?: number;
  hoursSaved?: string | number;
  actionUrl?: string;
  invoiceUrl?: string | null;
};

type RenderedEmail = {
  subject: string;
  html: string;
  text: string;
  locale: SupportedLocale;
};

type EmailCopy = {
  welcomeSubject: (brand: string) => string;
  welcomeTitle: (name: string) => string;
  welcomeBody: (brand: string) => string;
  welcomeCta: string;

  paymentConfirmedSubject: (brand: string, plan: string) => string;
  paymentConfirmedTitle: (name: string) => string;
  paymentConfirmedBody: (plan: string, formattedPrice: string) => string;
  paymentConfirmedCta: string;

  trialExpiringSubject: (name: string, dateStr: string) => string;
  trialExpiringTitle: (name: string, dateStr: string) => string;
  trialExpiringValue: (reviewsStr: string, hoursStr: string) => string;
  trialExpiringCharge: (plan: string, priceStr: string) => string;
  trialExpiringCta: string;

  paymentFailedSubject: (name: string, graceDays: number) => string;
  paymentFailedTitle: (name: string) => string;
  paymentFailedBody: (graceDays: number) => string;
  paymentFailedCta: string;

  abandonedDay3Subject: (brand: string, name: string) => string;
  abandonedDay3Title: (name: string) => string;
  abandonedDay3Body: string;
  abandonedDay3Cta: string;

  abandonedDay6Subject: (brand: string, name: string) => string;
  abandonedDay6Title: (name: string) => string;
  abandonedDay6Body: string;
  abandonedDay6Cta: string;
};

const EMAIL_TEMPLATES: Record<SupportedLocale, EmailCopy> = {
  es: {
    welcomeSubject: (b) => `Bienvenido a ${b} — Tu bandeja de reseñas con IA está lista`,
    welcomeTitle: (n) => `Hola, ${n}`,
    welcomeBody: (b) =>
      `Tu cuenta en ${b} ya está creada. Conecta Google Business, Trustpilot o tu tienda online para importar tus primeras reseñas y responder en segundos con la memoria de tu marca.`,
    welcomeCta: 'Abrir mi panel de control',

    paymentConfirmedSubject: (b, p) => `${b} · Pago confirmado y plan ${p} activo`,
    paymentConfirmedTitle: (n) => `Suscripción confirmada para ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Hemos procesado correctamente tu suscripción al plan ${p} (${price}/mes). Tus cuotas mensuales de IA, sincronización y peticiones por email están 100 % activas.`,
    paymentConfirmedCta: 'Ver mi suscripción y facturas',

    trialExpiringSubject: (n, d) => `Tu prueba en ${n} termina el ${d} · Resumen de valor`,
    trialExpiringTitle: (n, d) => `Tu prueba de 7 días para ${n} finaliza el ${d}`,
    trialExpiringValue: (r, h) =>
      `Resumen de valor en tu prueba: hemos gestionado ${r} reseñas y ahorrado ~${h} h de trabajo manual a tu equipo.`,
    trialExpiringCharge: (p, price) =>
      `Si deseas continuar con el plan ${p} (${price}/mes), no tienes que hacer nada. También puedes pasar a facturación anual (2 meses gratis) o cancelar en 1 clic.`,
    trialExpiringCta: 'Revisar mi suscripción en el panel',

    paymentFailedSubject: (n, g) => `Aviso importante: cobro pendiente en ${n} (${g} días de gracia activos)`,
    paymentFailedTitle: (n) => `No hemos podido procesar la renovación de ${n}`,
    paymentFailedBody: (g) =>
      `Hemos activado un periodo de gracia de ${g} días para que tu negocio no pierda acceso al panel ni a las alertas de reseñas mientras actualizas tu tarjeta.`,
    paymentFailedCta: 'Actualizar método de pago',

    abandonedDay3Subject: (b, n) => `${n}: conecta tu primera fuente de reseñas en 2 minutos (${b})`,
    abandonedDay3Title: (n) => `Saca partido a tu cuenta de ${n}`,
    abandonedDay3Body:
      'Vemos que creaste tu cuenta hace 3 días pero aún no has activado tus conexiones automáticas. Conecta tu Google Place ID o carga las 12 reseñas de demostración para probar la IA hoy mismo.',
    abandonedDay3Cta: 'Completar activación en 2 minutos',

    abandonedDay6Subject: (b, n) => `Últimas 24h de tu prueba en ${n} — ¿Necesitas más tiempo o ayuda?`,
    abandonedDay6Title: (n) => `Estamos en el día 6 de tu prueba en ${n}`,
    abandonedDay6Body:
      'Queremos asegurarnos de que hayas podido probar las respuestas con IA y el embudo QR antes de finalizar la prueba. Entra a tu panel para activar tu plan o pausar 1 mes sin perder tu configuración.',
    abandonedDay6Cta: 'Acceder a mi cuenta ahora',
  },

  en: {
    welcomeSubject: (b) => `Welcome to ${b} — Your AI review inbox is ready`,
    welcomeTitle: (n) => `Hello, ${n}`,
    welcomeBody: (b) =>
      `Your ${b} account is ready. Connect Google Business, Trustpilot, or your online store to import your reviews and reply in seconds with your brand voice.`,
    welcomeCta: 'Open my dashboard',

    paymentConfirmedSubject: (b, p) => `${b} · Payment confirmed & ${p} plan active`,
    paymentConfirmedTitle: (n) => `Subscription confirmed for ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Your subscription to the ${p} plan (${price}/mo) is confirmed. Your monthly AI, sync, and email outreach quotas are now fully active.`,
    paymentConfirmedCta: 'View subscription & invoices',

    trialExpiringSubject: (n, d) => `Your trial for ${n} ends on ${d} · Value summary`,
    trialExpiringTitle: (n, d) => `Your 7-day trial for ${n} ends on ${d}`,
    trialExpiringValue: (r, h) =>
      `Trial value summary: we have processed ${r} reviews and saved your team ~${h} hours of manual work.`,
    trialExpiringCharge: (p, price) =>
      `To continue on the ${p} plan (${price}/mo), no action is required. You can also switch to annual billing (2 months free) or cancel in 1 click.`,
    trialExpiringCta: 'Review my subscription',

    paymentFailedSubject: (n, g) => `Action needed: payment failed for ${n} (${g}-day grace period active)`,
    paymentFailedTitle: (n) => `We could not process the renewal for ${n}`,
    paymentFailedBody: (g) =>
      `We have activated a ${g}-day grace period so your team keeps full access to your dashboard and review alerts while you update your payment method.`,
    paymentFailedCta: 'Update payment method',

    abandonedDay3Subject: (b, n) => `${n}: connect your first review source in 2 minutes (${b})`,
    abandonedDay3Title: (n) => `Get the most out of ${n}`,
    abandonedDay3Body:
      'You created your account 3 days ago but have not connected your review sources yet. Paste your Google Place ID or load the 12 interactive sample reviews to test AI replies right away.',
    abandonedDay3Cta: 'Complete setup in 2 minutes',

    abandonedDay6Subject: (b, n) => `Final 24h of your ${n} trial — Need help or extra time?`,
    abandonedDay6Title: (n) => `Day 6 of your trial for ${n}`,
    abandonedDay6Body:
      'Make sure you test our multi-language AI drafts and QR review funnel before your trial wraps up. Sign in to activate your plan or pause for 1 month without losing your setup.',
    abandonedDay6Cta: 'Open my account now',
  },

  ca: {
    welcomeSubject: (b) => `Benvingut a ${b} — La teva safata de ressenyes amb IA està llesta`,
    welcomeTitle: (n) => `Hola, ${n}`,
    welcomeBody: (b) =>
      `El teu compte a ${b} ja està creat. Connecta Google Business, Trustpilot o la teva botiga online per importar les teves ressenyes i respondre en segons.`,
    welcomeCta: 'Obrir el meu panell',

    paymentConfirmedSubject: (b, p) => `${b} · Pagament confirmat i pla ${p} actiu`,
    paymentConfirmedTitle: (n) => `Subscripció confirmada per a ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Hem processat correctament la teva subscripció al pla ${p} (${price}/mes). Les teves quotes mensuals d’IA i sincronització estan 100 % actives.`,
    paymentConfirmedCta: 'Veure subscripció i factures',

    trialExpiringSubject: (n, d) => `La teva prova a ${n} acaba el ${d} · Resum de valor`,
    trialExpiringTitle: (n, d) => `La teva prova de 7 dies per a ${n} finalitza el ${d}`,
    trialExpiringValue: (r, h) =>
      `Resum de valor a la teva prova: hem gestionat ${r} ressenyes i estalviat ~${h} h de feina manual.`,
    trialExpiringCharge: (p, price) =>
      `Si vols continuar amb el pla ${p} (${price}/mes), no has de fer res. També pots passar a pla anual (2 mesos gratis) o cancel·lar en 1 clic.`,
    trialExpiringCta: 'Revisar la meva subscripció',

    paymentFailedSubject: (n, g) => `Avís important: cobrament pendent a ${n} (${g} dies de gràcia actius)`,
    paymentFailedTitle: (n) => `No hem pogut processar la renovació de ${n}`,
    paymentFailedBody: (g) =>
      `Hem activat un període de gràcia de ${g} dies perquè el teu negoci no perdi accés mentre actualitzes la targeta.`,
    paymentFailedCta: 'Actualitzar mètode de pagament',

    abandonedDay3Subject: (b, n) => `${n}: connecta la teva primera font de ressenyes en 2 minuts (${b})`,
    abandonedDay3Title: (n) => `Treu partit al teu compte de ${n}`,
    abandonedDay3Body:
      'Vam veure que vas crear el compte fa 3 dies però encara no has connectat les teves fonts. Connecta Google Places o carrega les 12 ressenyes d’exemple per provar la IA avui mateix.',
    abandonedDay3Cta: 'Completar activació en 2 minuts',

    abandonedDay6Subject: (b, n) => `Últimes 24h de la teva prova a ${n}`,
    abandonedDay6Title: (n) => `Som al dia 6 de la teva prova a ${n}`,
    abandonedDay6Body:
      'Entra al panell per activar el teu pla o pausar 1 mes sense perdre la teva configuració.',
    abandonedDay6Cta: 'Accedir al meu compte',
  },

  pt: {
    welcomeSubject: (b) => `Bem-vindo ao ${b} — A sua caixa de avaliações com IA está pronta`,
    welcomeTitle: (n) => `Olá, ${n}`,
    welcomeBody: (b) =>
      `A sua conta no ${b} já está criada. Ligue o Google Business, Trustpilot ou a sua loja online para importar avaliações e responder em segundos.`,
    welcomeCta: 'Abrir o meu painel',

    paymentConfirmedSubject: (b, p) => `${b} · Pagamento confirmado e plano ${p} ativo`,
    paymentConfirmedTitle: (n) => `Subscrição confirmada para ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Processámos com sucesso a sua subscrição do plano ${p} (${price}/mês). As suas quotas mensais de IA e sincronização estão 100% ativas.`,
    paymentConfirmedCta: 'Ver subscrição e faturas',

    trialExpiringSubject: (n, d) => `O seu teste em ${n} termina a ${d} · Resumo de valor`,
    trialExpiringTitle: (n, d) => `O seu teste de 7 dias para ${n} termina a ${d}`,
    trialExpiringValue: (r, h) =>
      `Resumo de valor no seu teste: gerimos ${r} avaliações e poupámos ~${h} h de trabalho manual.`,
    trialExpiringCharge: (p, price) =>
      `Para continuar com o plano ${p} (${price}/mês), não precisa de fazer nada. Também pode mudar para o plano anual (2 meses grátis) ou cancelar em 1 clique.`,
    trialExpiringCta: 'Rever a minha subscrição',

    paymentFailedSubject: (n, g) => `Aviso importante: pagamento pendente em ${n} (${g} dias de graça ativos)`,
    paymentFailedTitle: (n) => `Não foi possível processar a renovação de ${n}`,
    paymentFailedBody: (g) =>
      `Ativámos um período de graça de ${g} dias para que não perca o acesso enquanto atualiza o seu cartão.`,
    paymentFailedCta: 'Atualizar método de pagamento',

    abandonedDay3Subject: (b, n) => `${n}: ligue a sua primeira fonte de avaliações em 2 minutos (${b})`,
    abandonedDay3Title: (n) => `Tire partido da sua conta ${n}`,
    abandonedDay3Body:
      'Criou a sua conta há 3 dias, mas ainda não ligou as suas fontes de avaliações. Ligue o Google Place ID ou carregue as 12 avaliações de exemplo para testar a IA agora.',
    abandonedDay3Cta: 'Concluir ativação em 2 minutos',

    abandonedDay6Subject: (b, n) => `Últimas 24h do seu teste em ${n}`,
    abandonedDay6Title: (n) => `Dia 6 do seu teste em ${n}`,
    abandonedDay6Body:
      'Aceda ao seu painel para ativar o seu plano ou pausar por 1 mês sem perder a sua configuração.',
    abandonedDay6Cta: 'Aceder à minha conta',
  },

  fr: {
    welcomeSubject: (b) => `Bienvenue sur ${b} — Votre boîte de réception d'avis IA est prête`,
    welcomeTitle: (n) => `Bonjour, ${n}`,
    welcomeBody: (b) =>
      `Votre compte ${b} est prêt. Connectez Google Business, Trustpilot ou votre boutique en ligne pour importer vos avis et répondre en quelques secondes.`,
    welcomeCta: 'Ouvrir mon tableau de bord',

    paymentConfirmedSubject: (b, p) => `${b} · Paiement confirmé et offre ${p} active`,
    paymentConfirmedTitle: (n) => `Abonnement confirmé pour ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Votre abonnement à l'offre ${p} (${price}/mois) est confirmé. Vos quotas mensuels d'IA et de synchronisation sont actifs.`,
    paymentConfirmedCta: 'Voir mon abonnement et mes factures',

    trialExpiringSubject: (n, d) => `Votre essai pour ${n} se termine le ${d} · Bilan de valeur`,
    trialExpiringTitle: (n, d) => `Votre essai de 7 jours pour ${n} se termine le ${d}`,
    trialExpiringValue: (r, h) =>
      `Bilan de votre essai : nous avons traité ${r} avis et économisé ~${h} h de travail manuel à votre équipe.`,
    trialExpiringCharge: (p, price) =>
      `Pour continuer avec l'offre ${p} (${price}/mois), aucune action n'est requise. Vous pouvez aussi passer au forfait annuel (2 mois offerts) ou annuler en 1 clic.`,
    trialExpiringCta: 'Gérer mon abonnement',

    paymentFailedSubject: (n, g) => `Action requise : échec de paiement pour ${n} (${g} jours de grâce actifs)`,
    paymentFailedTitle: (n) => `Nous n'avons pas pu traiter le renouvellement de ${n}`,
    paymentFailedBody: (g) =>
      `Nous avons activé une période de grâce de ${g} jours afin que vous conserviez l'accès complet pendant la mise à jour de votre carte.`,
    paymentFailedCta: 'Mettre à jour mon moyen de paiement',

    abandonedDay3Subject: (b, n) => `${n} : connectez votre première source d'avis en 2 minutes (${b})`,
    abandonedDay3Title: (n) => `Tirez pleinement parti de ${n}`,
    abandonedDay3Body:
      "Vous avez créé votre compte il y a 3 jours mais n'avez pas encore connecté vos sources d'avis. Ajoutez votre Google Place ID ou chargez les 12 avis de démonstration.",
    abandonedDay3Cta: 'Terminer la configuration en 2 minutes',

    abandonedDay6Subject: (b, n) => `Dernières 24h de votre essai ${n}`,
    abandonedDay6Title: (n) => `Jour 6 de votre essai pour ${n}`,
    abandonedDay6Body:
      'Connectez-vous à votre tableau de bord pour activer votre offre ou mettre votre abonnement en pause pendant 1 mois.',
    abandonedDay6Cta: 'Accéder à mon compte',
  },

  de: {
    welcomeSubject: (b) => `Willkommen bei ${b} — Ihr KI-Bewertungspostfach ist bereit`,
    welcomeTitle: (n) => `Hallo, ${n}`,
    welcomeBody: (b) =>
      `Ihr ${b}-Konto ist bereit. Verbinden Sie Google Business, Trustpilot oder Ihren Onlineshop, um Bewertungen zu importieren und in Sekunden zu antworten.`,
    welcomeCta: 'Dashboard öffnen',

    paymentConfirmedSubject: (b, p) => `${b} · Zahlung bestätigt & Tarif ${p} aktiv`,
    paymentConfirmedTitle: (n) => `Abonnement bestätigt für ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Ihr Abonnement für den Tarif ${p} (${price}/Monat) wurde bestätigt. Ihre monatlichen KI- und Synchronisierungskontingente sind vollständig aktiv.`,
    paymentConfirmedCta: 'Abonnement & Rechnungen ansehen',

    trialExpiringSubject: (n, d) => `Ihre Testphase für ${n} endet am ${d} · Mehrwert-Übersicht`,
    trialExpiringTitle: (n, d) => `Ihre 7-tägige Testphase für ${n} endet am ${d}`,
    trialExpiringValue: (r, h) =>
      `Mehrwert-Bilanz Ihrer Testphase: Wir haben ${r} Bewertungen verarbeitet und Ihrem Team ~${h} Std. manuelle Arbeit erspart.`,
    trialExpiringCharge: (p, price) =>
      `Um mit dem Tarif ${p} (${price}/Monat) fortzufahren, müssen Sie nichts tun. Sie können auch auf jährliche Abrechnung (2 Monate gratis) wechseln oder mit 1 Klick kündigen.`,
    trialExpiringCta: 'Abonnement im Dashboard prüfen',

    paymentFailedSubject: (n, g) => `Wichtiger Hinweis: Zahlung fehlgeschlagen für ${n} (${g} Tage Kulanzfrist aktiv)`,
    paymentFailedTitle: (n) => `Wir konnten die Verlängerung für ${n} nicht abbuchen`,
    paymentFailedBody: (g) =>
      `Wir haben eine ${g}-tägige Kulanzfrist aktiviert, damit Ihr Unternehmen vollen Zugriff behält, während Sie Ihre Zahlungsmethode aktualisieren.`,
    paymentFailedCta: 'Zahlungsmethode aktualisieren',

    abandonedDay3Subject: (b, n) => `${n}: Verbinden Sie Ihre erste Bewertungsquelle in 2 Minuten (${b})`,
    abandonedDay3Title: (n) => `Nutzen Sie Ihr Konto bei ${n} optimal`,
    abandonedDay3Body:
      'Sie haben Ihr Konto vor 3 Tagen erstellt, aber noch keine Bewertungsquelle verbunden. Hinterlegen Sie Ihre Google Place ID oder laden Sie die 12 Beispielbewertungen.',
    abandonedDay3Cta: 'Einrichtung in 2 Minuten abschließen',

    abandonedDay6Subject: (b, n) => `Letzte 24 Stunden Ihrer Testphase bei ${n}`,
    abandonedDay6Title: (n) => `Tag 6 Ihrer Testphase für ${n}`,
    abandonedDay6Body:
      'Öffnen Sie Ihr Dashboard, um Ihren Tarif zu aktivieren oder Ihr Abonnement für 1 Monat zu pausieren.',
    abandonedDay6Cta: 'Jetzt Konto öffnen',
  },

  it: {
    welcomeSubject: (b) => `Benvenuto su ${b} — La tua casella recensioni con IA è pronta`,
    welcomeTitle: (n) => `Ciao, ${n}`,
    welcomeBody: (b) =>
      `Il tuo account su ${b} è pronto. Connetti Google Business, Trustpilot o il tuo e-commerce per importare le recensioni e rispondere in pochi secondi.`,
    welcomeCta: 'Apri il mio pannello',

    paymentConfirmedSubject: (b, p) => `${b} · Pagamento confermato e piano ${p} attivo`,
    paymentConfirmedTitle: (n) => `Abbonamento confermato per ${n}`,
    paymentConfirmedBody: (p, price) =>
      `Abbiamo confermato il tuo abbonamento al piano ${p} (${price}/mese). Le tue quote mensili di IA e sincronizzazione sono attive al 100%.`,
    paymentConfirmedCta: 'Vedi abbonamento e fatture',

    trialExpiringSubject: (n, d) => `La tua prova per ${n} scade il ${d} · Riepilogo del valore`,
    trialExpiringTitle: (n, d) => `I tuoi 7 giorni di prova per ${n} terminano il ${d}`,
    trialExpiringValue: (r, h) =>
      `Riepilogo del valore nella prova: abbiamo gestito ${r} recensioni e risparmiato ~${h} ore di lavoro manuale.`,
    trialExpiringCharge: (p, price) =>
      `Per continuare con il piano ${p} (${price}/mese), non devi fare nulla. Puoi anche passare al piano annuale (2 mesi gratis) o disdire in 1 clic.`,
    trialExpiringCta: 'Rivedi il mio abbonamento',

    paymentFailedSubject: (n, g) => `Avviso importante: pagamento in sospeso per ${n} (${g} giorni di grazia attivi)`,
    paymentFailedTitle: (n) => `Non siamo riusciti a elaborare il rinnovo per ${n}`,
    paymentFailedBody: (g) =>
      `Abbiamo attivato un periodo di grazia di ${g} giorni affinché la tua azienda non perda l’accesso mentre aggiorni la carta.`,
    paymentFailedCta: 'Aggiorna metodo di pagamento',

    abandonedDay3Subject: (b, n) => `${n}: connetti la tua prima fonte di recensioni in 2 minuti (${b})`,
    abandonedDay3Title: (n) => `Ottieni il massimo dal tuo account ${n}`,
    abandonedDay3Body:
      'Hai creato il tuo account 3 giorni fa ma non hai ancora collegato le tue fonti di recensioni. Inserisci il tuo Google Place ID o carica le 12 recensioni di esempio.',
    abandonedDay3Cta: 'Completa l’attivazione in 2 minuti',

    abandonedDay6Subject: (b, n) => `Ultime 24 ore della tua prova per ${n}`,
    abandonedDay6Title: (n) => `Giorno 6 della tua prova per ${n}`,
    abandonedDay6Body:
      'Accedi al tuo pannello per attivare il piano o mettere in pausa per 1 mese senza perdere la configurazione.',
    abandonedDay6Cta: 'Accedi al mio account',
  },
};

export function renderTransactionalEmail(input: TransactionalEmailPayload): RenderedEmail {
  const locale = resolveLocale(input.locale);
  const currency = input.currency ?? 'EUR';
  const copy = EMAIL_TEMPLATES[locale] ?? EMAIL_TEMPLATES.es;

  const brand = SITE.brand;
  const safeTenant = escapeHtml(input.tenantName?.trim() || brand);
  const safePlan = escapeHtml(input.planName?.trim() || 'Pro');
  const priceStr = formatMoneyIntl(input.amountCents ?? 2900, locale, currency);
  const dateStr = input.trialEndDate
    ? formatDateIntl(input.trialEndDate, locale, { day: '2-digit', month: 'long', year: 'numeric' })
    : formatDateIntl(new Date(Date.now() + 3 * 86_400_000), locale);
  const reviewsStr = formatNumberIntl(input.reviewsCount ?? 0, locale);
  const hoursStr = String(input.hoursSaved ?? '1.5');
  const graceDays = input.graceDays ?? 3;
  const actionUrl = input.actionUrl || `${SITE.url.replace(/\/$/, '')}/dashboard`;

  let subject = '';
  let heading = '';
  let paragraphs: string[] = [];
  let ctaLabel = '';
  let highlightBox = '';

  switch (input.kind) {
    case 'welcome':
      subject = copy.welcomeSubject(brand);
      heading = copy.welcomeTitle(safeTenant);
      paragraphs = [copy.welcomeBody(brand)];
      ctaLabel = copy.welcomeCta;
      break;

    case 'payment_confirmed':
      subject = copy.paymentConfirmedSubject(brand, safePlan);
      heading = copy.paymentConfirmedTitle(safeTenant);
      paragraphs = [copy.paymentConfirmedBody(safePlan, priceStr)];
      ctaLabel = copy.paymentConfirmedCta;
      break;

    case 'trial_expiring':
      subject = copy.trialExpiringSubject(safeTenant, dateStr);
      heading = copy.trialExpiringTitle(safeTenant, dateStr);
      highlightBox = `<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;padding:14px;margin:14px 0;color:#166534;font-size:14px"><strong>${escapeHtml(copy.trialExpiringValue(reviewsStr, hoursStr))}</strong></div>`;
      paragraphs = [copy.trialExpiringCharge(safePlan, priceStr)];
      ctaLabel = copy.trialExpiringCta;
      break;

    case 'payment_failed':
      subject = copy.paymentFailedSubject(safeTenant, graceDays);
      heading = copy.paymentFailedTitle(safeTenant);
      paragraphs = [copy.paymentFailedBody(graceDays)];
      ctaLabel = copy.paymentFailedCta;
      break;

    case 'abandoned_trial_day3':
      subject = copy.abandonedDay3Subject(brand, safeTenant);
      heading = copy.abandonedDay3Title(safeTenant);
      paragraphs = [copy.abandonedDay3Body];
      ctaLabel = copy.abandonedDay3Cta;
      break;

    case 'abandoned_trial_day6':
      subject = copy.abandonedDay6Subject(brand, safeTenant);
      heading = copy.abandonedDay6Title(safeTenant);
      paragraphs = [copy.abandonedDay6Body];
      ctaLabel = copy.abandonedDay6Cta;
      break;
  }

  const html = `
    <div style="font-family:Inter,system-ui,-apple-system,sans-serif;max-width:560px;margin:0 auto;padding:28px;color:#0f172a;background:#ffffff;border:1px solid #e2e8f0;border-radius:16px">
      <p style="margin:0 0 8px;font-size:12px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:#2563eb">${escapeHtml(brand)}</p>
      <h2 style="margin:0 0 14px;font-size:20px;line-height:1.3;color:#0f172a">${heading}</h2>
      ${highlightBox}
      ${paragraphs.map((p) => `<p style="margin:0 0 14px;font-size:15px;line-height:1.6;color:#334155">${escapeHtml(p)}</p>`).join('')}
      <p style="margin:22px 0 10px">
        <a href="${escapeHtml(actionUrl)}" style="display:inline-block;background:#2563eb;color:#ffffff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:600;font-size:14px">${escapeHtml(ctaLabel)}</a>
      </p>
      <hr style="border:0;border-top:1px solid #e2e8f0;margin:24px 0 12px" />
      <p style="margin:0;font-size:12px;color:#64748b">${escapeHtml(brand)} v${escapeHtml(version)} · EU GDPR Compliant</p>
    </div>
  `.trim();

  const text = [heading, ...paragraphs, `${ctaLabel}: ${actionUrl}`].join('\n\n');

  return { subject, html, text, locale };
}

/* ========================================================================== */
/* PRIORIDAD DE RECORDATORIOS Y DEDUPLICACIÓN POR PERIODO (ARREGLO #1 y #2)   */
/* ========================================================================== */

/**
 * Estados de suscripción con fallo de cobro.
 * Las empresas en cualquiera de estos estados NUNCA deben recibir el recordatorio
 * de "prueba sin convertir" (`abandoned_trial_day3` / `abandoned_trial_day6`).
 */
export const PAYMENT_FAILED_STATUSES = ['past_due', 'unpaid', 'incomplete'] as const;

/**
 * Estados permitidos en la consulta de recordatorios de "prueba sin convertir".
 */
export const ABANDONED_TRIAL_ALLOWED_STATUSES = ['trialing', 'none'] as const;

export type EmailSendLogEntry = {
  tenantId: string;
  kind: TransactionalEmailKind;
  sentAt: string;
  period: string;
};

export type ReminderTenantRecord = {
  id: string;
  name: string;
  owner_email?: string | null;
  plan?: string | null;
  subscription_status?: string | null;
  created_at?: string | null;
  trial_ends_at?: string | null;
  locale?: string | null;
  settings?: {
    locale?: string;
    abandoned_day3_sent_at?: string;
    abandoned_day6_sent_at?: string;
    trial_expiring_sent_at?: string;
    payment_failed_sent_at?: string;
    email_send_log?: EmailSendLogEntry[];
    sent_reminders?: Record<string, { tenantId: string; sentAt: string; period: string }>;
    [key: string]: unknown;
  } | null;
};

export function isPaymentFailedStatus(status?: string | null): boolean {
  if (!status) return false;
  return (PAYMENT_FAILED_STATUSES as readonly string[]).includes(status.trim().toLowerCase());
}

export function getReminderPeriodKey(now: Date | number | string = Date.now()): string {
  const d = now instanceof Date ? now : new Date(now);
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

/**
 * Comprueba si ya se envió el mismo tipo de correo a la empresa en el mismo periodo
 * (o durante el ciclo de vida de la prueba para recordatorios únicos de trial).
 */
export function hasReminderBeenSentInPeriod(
  settings: ReminderTenantRecord['settings'],
  kind: TransactionalEmailKind,
  period: string,
): boolean {
  if (!settings) return false;

  if (kind === 'abandoned_trial_day3' && settings.abandoned_day3_sent_at) return true;
  if (kind === 'abandoned_trial_day6' && settings.abandoned_day6_sent_at) return true;

  const byKind = settings.sent_reminders?.[kind];
  if (byKind && byKind.period === period) return true;

  if (Array.isArray(settings.email_send_log)) {
    const found = settings.email_send_log.some(
      (entry) => entry && entry.kind === kind && entry.period === period,
    );
    if (found) return true;
  }

  return false;
}

/**
 * Registra el envío de un recordatorio (empresa, tipo, fecha, periodo) en `settings`
 * para garantizar idempotencia y evitar duplicados en el mismo periodo.
 */
export function recordReminderSend(
  settings: ReminderTenantRecord['settings'],
  entry: EmailSendLogEntry,
): NonNullable<ReminderTenantRecord['settings']> {
  const base = { ...(settings ?? {}) };
  const prevLog = Array.isArray(base.email_send_log) ? base.email_send_log : [];
  const alreadyLogged = prevLog.some(
    (item) => item.tenantId === entry.tenantId && item.kind === entry.kind && item.period === entry.period,
  );
  const nextLog = alreadyLogged ? prevLog : [...prevLog, entry];

  const prevMap =
    base.sent_reminders && typeof base.sent_reminders === 'object' ? base.sent_reminders : {};

  const nextSettings: NonNullable<ReminderTenantRecord['settings']> = {
    ...base,
    email_send_log: nextLog,
    sent_reminders: {
      ...prevMap,
      [entry.kind]: {
        tenantId: entry.tenantId,
        sentAt: entry.sentAt,
        period: entry.period,
      },
    },
  };

  if (entry.kind === 'abandoned_trial_day3') {
    nextSettings.abandoned_day3_sent_at = entry.sentAt;
  } else if (entry.kind === 'abandoned_trial_day6') {
    nextSettings.abandoned_day6_sent_at = entry.sentAt;
  } else if (entry.kind === 'trial_expiring') {
    nextSettings.trial_expiring_sent_at = entry.sentAt;
  } else if (entry.kind === 'payment_failed') {
    nextSettings.payment_failed_sent_at = entry.sentAt;
  }

  return nextSettings;
}

/**
 * Determina el ÚNICO tipo de recordatorio que debe recibir una empresa en la ejecución actual,
 * aplicando la prioridad estricta:
 *   1. `payment_failed` (pago fallido: `past_due`, `unpaid`, `incomplete`)
 *   2. `trial_expiring` (prueba a punto de caducar en <= 48h)
 *   3. `abandoned_trial_day6` / `abandoned_trial_day3` (prueba sin convertir; NUNCA si hay pago fallido)
 *
 * Si el correo correspondiente a su prioridad ya se envió en el mismo periodo, devuelve `null`
 * (nunca degrada a un recordatorio de menor prioridad como "prueba sin convertir").
 */
export function resolveSingleReminderForTenant(
  tenant: ReminderTenantRecord,
  nowMs: number = Date.now(),
  period: string = getReminderPeriodKey(nowMs),
): TransactionalEmailKind | null {
  if (!tenant.owner_email) return null;
  const status = (tenant.subscription_status ?? '').trim().toLowerCase();
  const settings = tenant.settings ?? {};

  // 1. Prioridad máxima: Pago fallido (past_due / unpaid / incomplete).
  // Jamás recibe recordatorios de prueba sin convertir ni de prueba a punto de caducar.
  if (isPaymentFailedStatus(status)) {
    if (hasReminderBeenSentInPeriod(settings, 'payment_failed', period)) {
      return null;
    }
    return 'payment_failed';
  }

  // Solo los estados de prueba sin convertir ('trialing' | 'none') pueden continuar.
  if (!(ABANDONED_TRIAL_ALLOWED_STATUSES as readonly string[]).includes(status)) {
    return null;
  }

  // 2. Segunda prioridad: Prueba a punto de caducar (<= 48h para trial_ends_at).
  if (status === 'trialing' && tenant.trial_ends_at) {
    const trialEndsMs = new Date(tenant.trial_ends_at).getTime();
    const msRemaining = trialEndsMs - nowMs;
    if (Number.isFinite(msRemaining) && msRemaining > 0 && msRemaining <= 48 * 3_600_000) {
      if (hasReminderBeenSentInPeriod(settings, 'trial_expiring', period)) {
        return null;
      }
      return 'trial_expiring';
    }
  }

  // 3. Tercera prioridad: Prueba sin convertir (día 6 o día 3).
  if (!tenant.created_at) return null;
  const ageDays = (nowMs - new Date(tenant.created_at).getTime()) / 86_400_000;

  if (ageDays >= 6 && ageDays <= 9) {
    if (hasReminderBeenSentInPeriod(settings, 'abandoned_trial_day6', period)) {
      return null;
    }
    return 'abandoned_trial_day6';
  }

  if (ageDays >= 3 && ageDays < 5.5) {
    if (hasReminderBeenSentInPeriod(settings, 'abandoned_trial_day3', period)) {
      return null;
    }
    return 'abandoned_trial_day3';
  }

  return null;
}
