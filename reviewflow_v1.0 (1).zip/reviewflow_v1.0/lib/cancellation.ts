/**
 * Reglas de baja de plan.
 *  - "period_end": la baja se programa para el final del periodo ya pagado.
 *    Mientras no llegue esa fecha, el cliente puede deshacerla con «Reactivar».
 *  - "now": la baja es inmediata y no se puede reactivar desde aquí.
 */
export type CancelMode = 'period_end' | 'now';

export interface CancellationState {
  cancel_mode?: CancelMode | null;
  cancel_at?: string | null;
  canceled_at?: string | null;
}

/** Fecha de fin del periodo pagado (Stripe si existe; si no, día 1 del mes siguiente). */
export function periodEndDate(stripePeriodEndSec: number | null | undefined, now: Date = new Date()): Date {
  if (typeof stripePeriodEndSec === 'number' && stripePeriodEndSec * 1000 > now.getTime()) {
    return new Date(stripePeriodEndSec * 1000);
  }
  return new Date(now.getFullYear(), now.getMonth() + 1, 1);
}

/** Solo se puede reactivar una baja programada a final de periodo cuya fecha aún no ha llegado. */
export function canReactivate(state: CancellationState | null | undefined, now: Date = new Date()): boolean {
  if (!state || state.cancel_mode !== 'period_end' || !state.cancel_at) return false;
  const at = new Date(state.cancel_at).getTime();
  return Number.isFinite(at) && at > now.getTime();
}
