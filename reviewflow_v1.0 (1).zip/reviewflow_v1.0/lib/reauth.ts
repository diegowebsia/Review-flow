import { createClient as createSupabaseClient } from '@supabase/supabase-js';
import { env } from '@/lib/env';

/**
 * Comprueba la contraseña actual del usuario con un cliente aislado (sin guardar sesión).
 * Se usa antes de acciones irreversibles: una sesión robada no basta para ejecutarlas.
 */
export async function verifyCurrentPassword(email: string | null | undefined, password: string): Promise<boolean> {
  if (!email || !password) return false;
  const verifier = createSupabaseClient(env.supabaseUrl, env.supabaseAnonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { error } = await verifier.auth.signInWithPassword({ email, password });
  if (error) return false;
  await verifier.auth.signOut().catch(() => undefined);
  return true;
}

/** En producción el registro exige confirmar el email salvo que SIGNUP_EMAIL_CONFIRMATION=false. */
export function signupRequiresEmailConfirmation(): boolean {
  const flag = process.env.SIGNUP_EMAIL_CONFIRMATION;
  if (flag === 'true') return true;
  if (flag === 'false') return false;
  return process.env.NODE_ENV === 'production';
}
