import { GoogleGenAI } from '@google/genai';
import { aiModelPricing, DEFAULT_AI_MODEL } from '@/lib/plans';

export const GEMINI_MODEL = (process.env.GEMINI_MODEL || DEFAULT_AI_MODEL).trim();

export type GeminiChatOutcome = {
  ok: boolean;
  text?: string;
  model: string;
  tokens: { prompt: number; completion: number; total: number };
  latencyMs: number;
  costUsd: number;
  attempts: number;
  code?: string;
};

type GeminiStatus = {
  configured: boolean;
  model: string;
  timeoutMs: number;
  maxAttempts: number;
  rpmPerTenant: number;
  maxConcurrency: number;
  pricing: { input: number; output: number };
};

export function geminiStatus(): GeminiStatus {
  return {
    configured: isGeminiConfigured(),
    model: GEMINI_MODEL,
    timeoutMs: 15_000,
    maxAttempts: 2,
    rpmPerTenant: 30,
    maxConcurrency: 10,
    pricing: aiModelPricing(GEMINI_MODEL),
  };
}

export function geminiRuntime() {
  return geminiStatus();
}

let clientInstance: GoogleGenAI | null = null;

/**
 * Obtiene el cliente oficial de Google Gemini SDK de forma perezosa (lazy).
 * Solo se inicializa si GEMINI_API_KEY está configurada en el servidor.
 */
function getGemini(): GoogleGenAI | null {
  const apiKey = (process.env.GEMINI_API_KEY || '').trim().replace(/^["']|["']$/g, '');
  if (!apiKey || apiKey.trim().length === 0) {
    return null;
  }
  if (!clientInstance) {
    clientInstance = new GoogleGenAI({
      apiKey: apiKey.trim(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return clientInstance;
}

function isGeminiConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
}

/**
 * Llama al modelo Gemini configurado para redactar o analizar opiniones.
 * Incluye medición de latencia, tokens aproximados y cálculo de coste.
 */
export async function generateWithGemini(params: {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  maxOutputTokens?: number;
  model?: string;
  maxAttempts?: number;
}): Promise<GeminiChatOutcome> {
  const ai = getGemini();
  const modelName = params.model || GEMINI_MODEL;
  const maxAttempts = Math.max(1, Math.min(4, params.maxAttempts ?? geminiStatus().maxAttempts));
  const start = Date.now();

  if (!ai) {
    return {
      ok: false,
      model: modelName,
      tokens: { prompt: 0, completion: 0, total: 0 },
      latencyMs: 0,
      costUsd: 0,
      attempts: 0,
      code: 'gemini_not_configured',
    };
  }

  let lastErrorCode = 'gemini_api_error';
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
          {
            role: 'user',
            parts: [{ text: `${params.systemPrompt}\n\n${params.userPrompt}` }],
          },
        ],
        config: {
          temperature: params.temperature ?? 0.7,
          maxOutputTokens: params.maxOutputTokens ?? 250,
        },
      });

      const text = response.text?.trim() ?? '';
      const latencyMs = Date.now() - start;

      // Tokens aproximados o extraídos de metadata
      const usageMeta = response.usageMetadata;
      const promptTokens =
        usageMeta?.promptTokenCount ?? Math.ceil((params.systemPrompt.length + params.userPrompt.length) / 4);
      const completionTokens = usageMeta?.candidatesTokenCount ?? Math.ceil(text.length / 4);
      const totalTokens = promptTokens + completionTokens;

      // Coste real según el modelo Gemini
      const pricing = aiModelPricing(modelName);
      const costUsd = (promptTokens / 1_000_000) * pricing.input + (completionTokens / 1_000_000) * pricing.output;

      return {
        ok: true,
        text,
        model: modelName,
        tokens: { prompt: promptTokens, completion: completionTokens, total: totalTokens },
        latencyMs,
        costUsd,
        attempts: attempt,
      };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      lastErrorCode = message.includes('API key') ? 'invalid_api_key' : 'gemini_api_error';
      if (lastErrorCode === 'invalid_api_key' || attempt >= maxAttempts) {
        return {
          ok: false,
          model: modelName,
          tokens: { prompt: 0, completion: 0, total: 0 },
          latencyMs: Date.now() - start,
          costUsd: 0,
          attempts: attempt,
          code: lastErrorCode,
        };
      }
      // Backoff exponencial corto antes del siguiente reintento
      await new Promise((resolve) => setTimeout(resolve, 120 * attempt));
    }
  }

  return {
    ok: false,
    model: modelName,
    tokens: { prompt: 0, completion: 0, total: 0 },
    latencyMs: Date.now() - start,
    costUsd: 0,
    attempts: maxAttempts,
    code: lastErrorCode,
  };
}
