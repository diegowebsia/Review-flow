/**
 * ============================================================
 * ReviewFlow AI v1.0 — Observabilidad, Sentry & Correlation IDs
 * ============================================================
 * - Release tagging oficial: `reviewflow-ai@1.0`
 * - Captura de excepciones en frontend y backend compatible con Sentry Envelope API
 * - Trazabilidad distribuida con `X-Correlation-Id` en pagos, webhooks e IA
 */

import { redactSecretsInText, sanitizeLogMeta, systemLog } from '@/lib/logger';

export const APP_VERSION = '1.0';
export const SENTRY_RELEASE = process.env.NEXT_PUBLIC_SENTRY_RELEASE || `reviewflow-ai@${APP_VERSION}`;

type ObservabilityContext = {
  correlationId?: string;
  source?: string;
  tenantId?: string;
  userId?: string;
  userEmail?: string | null;
  plan?: string;
  tags?: Record<string, string>;
  extra?: Record<string, unknown>;
};

/**
 * Extrae el Correlation ID de las cabeceras entrantes (`x-correlation-id` o `x-request-id`)
 * o genera uno criptográficamente único (`rf_corr_...`).
 */
export function getOrCreateCorrelationId(req?: Request | { headers?: Headers | Record<string, string | undefined> } | null): string {
  try {
    if (req && 'headers' in req && req.headers) {
      if (typeof (req.headers as Headers).get === 'function') {
        const h = req.headers as Headers;
        const existing = h.get('x-correlation-id') || h.get('x-request-id');
        if (existing && existing.trim().length >= 6) {
          return existing.trim().slice(0, 64);
        }
      } else {
        const rec = req.headers as Record<string, string | undefined>;
        const existing = rec['x-correlation-id'] || rec['x-request-id'];
        if (existing && existing.trim().length >= 6) {
          return existing.trim().slice(0, 64);
        }
      }
    }
  } catch {
    /* ignore */
  }
  const randomPart =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().replace(/-/g, '').slice(0, 16)
      : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
  return `rf_corr_${randomPart}`;
}

/**
 * Cabeceras estándar de observabilidad para adjuntar a respuestas HTTP críticas.
 */
export function correlationHeaders(correlationId: string, extra?: Record<string, string>): Record<string, string> {
  return {
    'X-Correlation-Id': correlationId,
    'X-Release': SENTRY_RELEASE,
    ...(extra ?? {}),
  };
}

/**
 * Parsea un DSN de Sentry (`https://<key>@<host>/<projectId>`) para enviar eventos por HTTP Envelope.
 */
function parseSentryDsn(dsn: string | undefined | null): { endpoint: string; publicKey: string; projectId: string } | null {
  if (!dsn || !dsn.trim()) return null;
  try {
    const url = new URL(dsn.trim());
    const publicKey = url.username;
    const projectId = url.pathname.replace(/^\/+/, '');
    if (!publicKey || !projectId) return null;
    const endpoint = `${url.protocol}//${url.host}/api/${projectId}/store/?sentry_version=7&sentry_key=${publicKey}`;
    return { endpoint, publicKey, projectId };
  } catch {
    return null;
  }
}

/**
 * Captura una excepción en frontend o backend con etiqueta de versión (`release: reviewflow-ai@1.0`)
 * y `correlationId`. Si `SENTRY_DSN` / `NEXT_PUBLIC_SENTRY_DSN` está configurado, la envía a Sentry;
 * además registra la traza estructurada en `system_logs`.
 */
export async function captureException(error: unknown, context: ObservabilityContext = {}): Promise<string> {
  const correlationId = context.correlationId || getOrCreateCorrelationId();
  const rawMessage = error instanceof Error ? error.message : String(error ?? 'Unknown error');
  const message = redactSecretsInText(rawMessage);
  const rawStack = error instanceof Error ? error.stack : undefined;
  const stack = rawStack ? redactSecretsInText(rawStack) : undefined;
  const source = context.source || 'observability.exception';
  const safeExtra = sanitizeLogMeta(context.extra ?? {});

  await systemLog('error', source, message, {
    correlationId,
    release: SENTRY_RELEASE,
    tenantId: context.tenantId ?? null,
    userId: context.userId ?? null,
    plan: context.plan ?? null,
    tags: context.tags ?? {},
    stack: stack?.slice(0, 1500) ?? null,
    ...safeExtra,
  });

  const rawDsn = process.env.SENTRY_DSN || process.env.NEXT_PUBLIC_SENTRY_DSN;
  const parsedDsn = parseSentryDsn(rawDsn);
  if (parsedDsn && typeof fetch === 'function') {
    try {
      await fetch(parsedDsn.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_id: correlationId.replace(/[^a-f0-9]/gi, '').padEnd(32, '0').slice(0, 32),
          timestamp: new Date().toISOString(),
          platform: 'javascript',
          level: 'error',
          release: SENTRY_RELEASE,
          environment: process.env.NODE_ENV || 'production',
          message,
          tags: {
            correlation_id: correlationId,
            source,
            ...(context.tenantId ? { tenant_id: context.tenantId } : {}),
            ...(context.plan ? { plan: context.plan } : {}),
            ...(context.tags ?? {}),
          },
          extra: {
            stack,
            ...safeExtra,
          },
        }),
      });
    } catch {
      /* Nunca romper el flujo si Sentry externo no responde */
    }
  }

  return correlationId;
}

/**
 * Log estructurado para llamadas críticas (pagos, webhooks, IA) con Correlation ID obligatorio.
 */
export async function logStructured(
  level: 'info' | 'warn' | 'error',
  source: string,
  message: string,
  context: ObservabilityContext & Record<string, unknown> = {},
): Promise<string> {
  const correlationId = context.correlationId || getOrCreateCorrelationId();
  await systemLog(level, source, message, {
    ...context,
    correlationId,
    release: SENTRY_RELEASE,
  });
  return correlationId;
}

type OperationalDomain = 'review_sync' | 'stripe_webhook' | 'job_queue';

type FailureEntry = {
  consecutiveFailures: number;
  lastError: string | null;
  lastFailedAt: string | null;
  alerted: boolean;
};

const operationalFailures = new Map<OperationalDomain, FailureEntry>();
const DEFAULT_ALERT_THRESHOLD = 3;

/**
 * Registra el resultado de una operación crítica (`review_sync`, `stripe_webhook`, `job_queue`)
 * y dispara una alerta estructurada (`operational.alert`) + captura en Sentry cuando se acumulan
 * fallos consecutivos (>= threshold). Se reinicia automáticamente al primer éxito.
 */
export async function recordServiceOutcome(
  domain: OperationalDomain,
  ok: boolean,
  detail?: string,
  context: ObservabilityContext & { threshold?: number } = {},
): Promise<{ consecutiveFailures: number; alertTriggered: boolean }> {
  const threshold = Math.max(2, context.threshold ?? DEFAULT_ALERT_THRESHOLD);
  if (ok) {
    operationalFailures.set(domain, {
      consecutiveFailures: 0,
      lastError: null,
      lastFailedAt: null,
      alerted: false,
    });
    return { consecutiveFailures: 0, alertTriggered: false };
  }

  const prev = operationalFailures.get(domain) ?? {
    consecutiveFailures: 0,
    lastError: null,
    lastFailedAt: null,
    alerted: false,
  };
  const nextCount = prev.consecutiveFailures + 1;
  const nowIso = new Date().toISOString();
  const safeDetail = redactSecretsInText(detail ?? 'Fallo operativo');
  const shouldTriggerAlert = nextCount >= threshold && !prev.alerted;

  operationalFailures.set(domain, {
    consecutiveFailures: nextCount,
    lastError: safeDetail,
    lastFailedAt: nowIso,
    alerted: prev.alerted || shouldTriggerAlert,
  });

  if (shouldTriggerAlert) {
    const correlationId = context.correlationId || getOrCreateCorrelationId();
    await captureException(
      new Error(`Alerta operativa (${domain}): ${nextCount} fallos consecutivos — ${safeDetail}`),
      {
        ...context,
        correlationId,
        source: `operational.alert.${domain}`,
        tags: {
          domain,
          consecutive_failures: String(nextCount),
          ...(context.tags ?? {}),
        },
      },
    );
  }

  return { consecutiveFailures: nextCount, alertTriggered: shouldTriggerAlert };
}

export function getServiceFailureState(domain: OperationalDomain): FailureEntry {
  return (
    operationalFailures.get(domain) ?? {
      consecutiveFailures: 0,
      lastError: null,
      lastFailedAt: null,
      alerted: false,
    }
  );
}

export function resetServiceFailures(): void {
  operationalFailures.clear();
}

