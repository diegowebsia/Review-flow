import { requestIp } from '@/lib/security';

type AntiBotResult = {
  allowed: boolean;
  reason?: string;
};

/**
 * Protección anti-bot multicapa para `/api/auth/signup` y `/valorar/[slug]` (`/api/feedback`):
 *  1. Honeypot invisible (`website` / `company_url` debe venir vacío).
 *  2. Verificación criptográfica contra Cloudflare Turnstile (`TURNSTILE_SECRET_KEY`)
 *     cuando está configurado en el entorno.
 */
export async function verifyAntiBot(
  req: Request,
  payload: {
    captchaToken?: string | null;
    honeypot?: string | null;
  },
): Promise<AntiBotResult> {
  // 1. Honeypot relleno por bots automatizados
  if (payload.honeypot && payload.honeypot.trim().length > 0) {
    return { allowed: false, reason: 'honeypot_triggered' };
  }

  const turnstileSecret = process.env.TURNSTILE_SECRET_KEY?.trim();

  // Si no hay clave de Turnstile configurada en el entorno, el honeypot + rate-limit por slug/IP actúan
  if (!turnstileSecret) {
    return { allowed: true };
  }

  const token = payload.captchaToken?.trim();
  if (!token) {
    return { allowed: false, reason: 'missing_captcha_token' };
  }

  const ip = requestIp(req);

  try {
    const form = new URLSearchParams();
    form.set('secret', turnstileSecret);
    form.set('response', token);
    if (ip !== 'unknown') form.set('remoteip', ip);

    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      body: form,
      signal: AbortSignal.timeout(5_000),
    });
    const data = (await res.json()) as { success?: boolean };
    return data.success ? { allowed: true } : { allowed: false, reason: 'turnstile_failed' };
  } catch {
    // Fail-open controlado si el proveedor externo de captcha sufre caída de red
    return { allowed: true };
  }
}
