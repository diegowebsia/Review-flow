import { NextResponse } from 'next/server';
import { correlationHeaders, getOrCreateCorrelationId } from '@/lib/observability';

type ApiErrorCode =
  | 'bad_request'
  | 'validation_error'
  | 'unauthenticated'
  | 'forbidden'
  | 'not_found'
  | 'conflict'
  | 'payload_too_large'
  | 'rate_limited'
  | 'quota_exhausted'
  | 'no_subscription'
  | 'past_due'
  | 'trial_expired'
  | 'suspended'
  | 'canceled'
  | 'feature_locked'
  | 'storage_limit'
  | 'ai_budget_exceeded'
  | 'provider_error'
  | 'service_unavailable'
  | 'internal_error'
  | (string & {});

type ApiErrorEnvelope = {
  error: string;
  code: ApiErrorCode;
  correlationId: string;
  [key: string]: unknown;
};

type ApiErrorOptions = {
  error?: string;
  code?: ApiErrorCode;
  status?: number;
  correlationId?: string;
  details?: string[];
  headers?: Record<string, string>;
  extra?: Record<string, unknown>;
};

/**
 * Extrae un mensaje seguro desde cualquier valor `unknown` capturado en `catch`.
 */
export function errorMessage(err: unknown, fallback = 'Error interno del servidor.'): string {
  if (err instanceof Error && err.message.trim().length > 0) {
    return err.message;
  }
  if (typeof err === 'string' && err.trim().length > 0) {
    return err;
  }
  if (err && typeof err === 'object' && 'message' in err) {
    const msg = (err as { message?: unknown }).message;
    if (typeof msg === 'string' && msg.trim().length > 0) {
      return msg;
    }
  }
  return fallback;
}

export function describeUnknownError(
  err: unknown,
  fallback = 'Error interno del servidor.',
): { message: string; code: ApiErrorCode } {
  const message = errorMessage(err, fallback);
  const code =
    err && typeof err === 'object' && 'code' in err && typeof (err as { code?: unknown }).code === 'string'
      ? ((err as { code: string }).code as ApiErrorCode)
      : 'internal_error';
  return { message, code };
}

/**
 * Deduce un código de error semántico por defecto según el código HTTP.
 */
function defaultCodeForStatus(status: number): ApiErrorCode {
  switch (status) {
    case 400:
      return 'bad_request';
    case 401:
      return 'unauthenticated';
    case 402:
      return 'no_subscription';
    case 403:
      return 'forbidden';
    case 404:
      return 'not_found';
    case 409:
      return 'conflict';
    case 413:
      return 'payload_too_large';
    case 429:
      return 'rate_limited';
    case 502:
      return 'provider_error';
    case 503:
      return 'service_unavailable';
    case 507:
      return 'storage_limit';
    default:
      return 'internal_error';
  }
}

/**
 * Construye el cuerpo estándar `{ error, code, correlationId }` sin crear Response
 * (útil para pruebas unitarias y helpers internos).
 */
function buildApiErrorBody(
  firstArg: Request | string | null | undefined,
  options: ApiErrorOptions = {},
): { body: ApiErrorEnvelope; status: number; headers: Record<string, string>; correlationId: string } {
  const status = options.status ?? 400;
  const isFirstArgErrorMessage = typeof firstArg === 'string' && !options.error;

  const resolvedError = isFirstArgErrorMessage
    ? firstArg
    : options.error ?? 'Error en la petición.';

  const correlationId =
    options.correlationId && options.correlationId.trim().length > 0
      ? options.correlationId.trim()
      : !isFirstArgErrorMessage && typeof firstArg === 'string' && firstArg.trim().length > 0
        ? firstArg.trim()
        : getOrCreateCorrelationId(firstArg instanceof Request ? firstArg : null);

  const code: ApiErrorCode = options.code ?? defaultCodeForStatus(status);

  const body: ApiErrorEnvelope = {
    ...(options.extra ?? {}),
    ...(options.details ? { details: options.details } : {}),
    error: resolvedError,
    code,
    correlationId,
  };

  const headers: Record<string, string> = {
    ...correlationHeaders(correlationId),
    ...(options.headers ?? {}),
  };

  return { body, status, headers, correlationId };
}

/**
 * Helper unificado de respuesta de error para todas las rutas de `app/api/**`.
 * Devuelve siempre JSON con `{ error, code, correlationId }` y cabeceras de correlación.
 */
export function apiError(
  firstArg: Request | string | null | undefined,
  options: ApiErrorOptions = {},
): NextResponse<ApiErrorEnvelope> {
  const { body, status, headers } = buildApiErrorBody(firstArg, options);
  return NextResponse.json(body, { status, headers });
}
