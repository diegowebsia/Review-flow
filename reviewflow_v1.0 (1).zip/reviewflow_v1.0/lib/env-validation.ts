export function productionEnvErrors(env: NodeJS.ProcessEnv = process.env): string[] {
  const required = [
    'NEXT_PUBLIC_APP_URL',
    'NEXT_PUBLIC_SUPABASE_URL',
    'NEXT_PUBLIC_SUPABASE_ANON_KEY',
    'SUPABASE_SERVICE_ROLE_KEY',
    'STRIPE_SECRET_KEY',
    'APP_SIGNING_SECRET',
    'INTEGRATION_ENCRYPTION_KEY',
    'PRIVACY_HASH_PEPPER',
    'HEALTHCHECK_SECRET',
  ];
  const errors = required.filter((name) => !env[name]?.trim()).map((name) => `Falta ${name}`);

  // Validación estricta de longitud y aislamiento criptográfico (sin reutilizar SUPABASE_SERVICE_ROLE_KEY)
  if (env.APP_SIGNING_SECRET && env.APP_SIGNING_SECRET.trim().length < 32) {
    errors.push('APP_SIGNING_SECRET debe tener al menos 32 caracteres');
  }
  if (env.PRIVACY_HASH_PEPPER && env.PRIVACY_HASH_PEPPER.trim().length < 32) {
    errors.push('PRIVACY_HASH_PEPPER debe tener al menos 32 caracteres');
  }
  if (
    env.SUPABASE_SERVICE_ROLE_KEY &&
    (env.APP_SIGNING_SECRET === env.SUPABASE_SERVICE_ROLE_KEY ||
      env.PRIVACY_HASH_PEPPER === env.SUPABASE_SERVICE_ROLE_KEY)
  ) {
    errors.push('APP_SIGNING_SECRET y PRIVACY_HASH_PEPPER no pueden reutilizar SUPABASE_SERVICE_ROLE_KEY');
  }

  const appUrl = env.NEXT_PUBLIC_APP_URL ?? '';
  if (appUrl && (!appUrl.startsWith('https://') || appUrl.includes('localhost'))) {
    errors.push('NEXT_PUBLIC_APP_URL debe ser HTTPS y no localhost');
  }
  return errors;
}

export function formatProductionConfigError(errors: string[]): string {
  return [
    '[ReviewFlow AI] CONFIGURACIÓN INCOMPLETA: la aplicación no puede arrancar en producción.',
    ...errors.map((error) => `  - ${error}`),
    'Solución: configura estas variables en el alojamiento y vuelve a desplegar.',
    'Comprueba el resultado con: npm run verify -- --url https://tu-dominio.com',
    'Guía de publicación: GUIA_2_PUBLICAR_Y_PAGAR.md',
  ].join('\n');
}

/**
 * Lista de claves de entorno operativas que se comprueban al arrancar la aplicación.
 * La comprobación informa únicamente de los NOMBRES de las variables que faltan,
 * sin exponer ni registrar jamás ningún valor o secreto.
 */
const STARTUP_MONITORED_ENV_KEYS = [
  'NEXT_PUBLIC_SUPABASE_URL',
  'NEXT_PUBLIC_SUPABASE_ANON_KEY',
  'SUPABASE_SERVICE_ROLE_KEY',
  'GEMINI_API_KEY',
  'STRIPE_SECRET_KEY',
  'STRIPE_WEBHOOK_SECRET',
  'RESEND_API_KEY',
  'SENTRY_DSN',
  'CRON_SECRET',
  'HEALTH_KEY',
] as const;

type StartupEnvCheckResult = {
  missing: string[];
  configuredCount: number;
  totalChecked: number;
  warningMessage: string | null;
};

/**
 * Comprueba en el arranque qué variables de entorno clave faltan por configurar.
 * Devuelve únicamente los nombres de las variables ausentes y un mensaje de aviso
 * seguro (nunca incluye valores de ninguna variable de entorno).
 */
export function checkMissingEnvOnStartup(
  envObj: NodeJS.ProcessEnv = process.env,
  onWarn?: (message: string) => void,
): StartupEnvCheckResult {
  const missing: string[] = [];

  for (const key of STARTUP_MONITORED_ENV_KEYS) {
    if (key === 'RESEND_API_KEY') {
      const hasMailKey = Boolean(envObj.RESEND_API_KEY?.trim() || envObj.SMTP_PASS?.trim());
      if (!hasMailKey) missing.push('RESEND_API_KEY (o SMTP_PASS)');
      continue;
    }
    if (key === 'SENTRY_DSN') {
      const hasSentry = Boolean(envObj.SENTRY_DSN?.trim() || envObj.NEXT_PUBLIC_SENTRY_DSN?.trim());
      if (!hasSentry) missing.push('SENTRY_DSN');
      continue;
    }
    if (key === 'HEALTH_KEY') {
      const hasHealthKey = Boolean(envObj.HEALTH_KEY?.trim() || envObj.HEALTHCHECK_SECRET?.trim());
      if (!hasHealthKey) missing.push('HEALTH_KEY');
      continue;
    }

    if (!envObj[key]?.trim()) {
      missing.push(key);
    }
  }

  const totalChecked = STARTUP_MONITORED_ENV_KEYS.length;
  const configuredCount = totalChecked - missing.length;

  let warningMessage: string | null = null;
  if (missing.length > 0) {
    warningMessage = `[ReviewFlow AI] Configuración parcial: faltan ${missing.length} variables (${missing.join(', ')}). Las funciones asociadas permanecerán desactivadas. Ejecuta npm run setup y consulta .env.example.`;
    if (onWarn) {
      onWarn(warningMessage);
    }
  }

  return {
    missing,
    configuredCount,
    totalChecked,
    warningMessage,
  };
}

/**
 * Valida en producción que el dominio público y los datos legales (LSSI-CE art. 10)
 * sean reales. No existe ningún dominio de marca como fallback silencioso: si faltan,
 * el arranque se detiene en lugar de publicar avisos legales con placeholders.
 */
export async function assertProductionSiteConfig(env: NodeJS.ProcessEnv = process.env): Promise<void> {
  if (env.NODE_ENV !== 'production') return;
  if (env.NEXT_PHASE === 'phase-production-build') return;
  const { placeholderSiteFields } = await import('@/lib/site');
  const pending = placeholderSiteFields();
  if (pending.length === 0) return;
  const message =
    `[Configuración Crítica] Dominio o datos legales sin configurar en producción (${pending.join(', ')}). ` +
    'Rellena estas variables antes de desplegar (ver GUIA_2_PUBLICAR_Y_PAGAR.md).';
  if (env.ALLOW_PLACEHOLDER_SITE_CONFIG === 'true') {
    console.warn(`${message} Continuando por ALLOW_PLACEHOLDER_SITE_CONFIG=true.`);
    return;
  }
  throw new Error(message);
}
