import { createHash, randomBytes, timingSafeEqual } from 'crypto';
import type { TypedSupabaseClient } from '@/lib/database.types';

type AdminLike = TypedSupabaseClient;

const API_KEY_PREFIX = 'rf_live_';

export function hashApiKey(rawKey: string): string {
  return createHash('sha256').update(rawKey.trim()).digest('hex');
}

export function generateTenantApiKey(): {
  rawKey: string;
  prefix: string;
  hash: string;
} {
  const token = randomBytes(24).toString('hex');
  const rawKey = `${API_KEY_PREFIX}${token}`;
  const prefix = `${API_KEY_PREFIX}${token.slice(0, 8)}…${token.slice(-4)}`;
  const hash = hashApiKey(rawKey);
  return { rawKey, prefix, hash };
}

function constantTimeHexMatch(aHex: string, bHex: string): boolean {
  if (!aHex || !bHex || aHex.length !== bHex.length) return false;
  try {
    return timingSafeEqual(Buffer.from(aHex, 'utf8'), Buffer.from(bHex, 'utf8'));
  } catch {
    return false;
  }
}

export function isRotatedPreviousKeyValid(
  rawKey: string,
  record: {
    previous_api_key_hash?: string | null;
    previous_api_key_expires_at?: string | null;
  },
  nowMs: number = Date.now(),
): boolean {
  if (!rawKey || !record.previous_api_key_hash || !record.previous_api_key_expires_at) {
    return false;
  }
  const expiresMs = new Date(record.previous_api_key_expires_at).getTime();
  if (Number.isNaN(expiresMs) || expiresMs <= nowMs) {
    return false;
  }
  const candidateHash = hashApiKey(rawKey);
  return constantTimeHexMatch(candidateHash, record.previous_api_key_hash);
}

type ApiKeySecuritySettings = {
  prefix?: string | null;
  current_hash?: string | null;
  previous_hash?: string | null;
  previous_expires_at?: string | null;
  rotated_at?: string | null;
  last_used_at?: string | null;
  revoked_at?: string | null;
};

type ResolvedTenantByApiKey = {
  id: string;
  name: string;
  slug?: string;
  plan: string;
  subscription_status: string;
  suspended: boolean;
  settings: (Record<string, unknown> & { api_key_security?: ApiKeySecuritySettings }) | null;
  api_key_revoked_at?: string | null;
  previous_api_key_expires_at?: string | null;
  api_key?: string | null;
};

/**
 * Autentica una `api_key` de ingesta pública:
 *  1. Calcula `SHA-256(api_key)` y busca por `api_key_hash` o dentro de `settings.api_key_security`.
 *  2. Soporta rotación con solape de 24 h (`previous_hash` vigente hasta `previous_expires_at`).
 *  3. Mantiene compatibilidad hacia atrás con claves legacy en `tenants.api_key` y actualiza
 *     `api_key_last_used_at` en cada uso exitoso.
 */
export async function verifyAndResolveTenantByApiKey(
  admin: AdminLike,
  rawKey: string | null | undefined,
): Promise<ResolvedTenantByApiKey | null> {
  const cleanKey = (rawKey ?? '').trim();
  if (cleanKey.length < 10) return null;

  const candidateHash = hashApiKey(cleanKey);
  const nowIso = new Date().toISOString();

  // 1) Intento por columna hash dedicada (si existe en el esquema)
  try {
    const { data: rawByHash } = await admin
      .from('tenants')
      .select('id, name, slug, plan, subscription_status, suspended, settings, api_key_revoked_at')
      .eq('api_key_hash', candidateHash)
      .maybeSingle();
    const byHash = rawByHash as ResolvedTenantByApiKey | null;

    if (byHash && !byHash.api_key_revoked_at) {
      await touchApiKeyLastUsed(admin, byHash.id, byHash.settings, nowIso);
      return byHash;
    }
  } catch {
    /* columna opcional aún no migrada */
  }

  // 2) Intento por columna api_key directa o clave en solape de rotación 24h
  const { data: rawDirect } = await admin
    .from('tenants')
    .select('id, name, slug, plan, subscription_status, suspended, settings')
    .eq('api_key', cleanKey)
    .maybeSingle();
  const direct = rawDirect as ResolvedTenantByApiKey | null;

  if (direct) {
    const sec = direct.settings?.api_key_security ?? {};
    if (sec.revoked_at) return null;
    await touchApiKeyLastUsed(admin, direct.id, direct.settings, nowIso, candidateHash);
    return direct;
  }

  // 3) Comprobación de clave previa en periodo de solape de 24 h (rotación sin caída)
  try {
    const { data: rawByPrevHash } = await admin
      .from('tenants')
      .select('id, name, slug, plan, subscription_status, suspended, settings, previous_api_key_expires_at, api_key_revoked_at')
      .eq('previous_api_key_hash', candidateHash)
      .maybeSingle();
    const byPrevHash = rawByPrevHash as ResolvedTenantByApiKey | null;

    if (
      byPrevHash &&
      !byPrevHash.api_key_revoked_at &&
      byPrevHash.previous_api_key_expires_at &&
      new Date(byPrevHash.previous_api_key_expires_at).getTime() > Date.now()
    ) {
      await touchApiKeyLastUsed(admin, byPrevHash.id, byPrevHash.settings, nowIso);
      return byPrevHash;
    }
  } catch {
    /* columna opcional */
  }

  return null;
}

async function touchApiKeyLastUsed(
  admin: AdminLike,
  tenantId: string,
  currentSettings: (Record<string, unknown> & { api_key_security?: ApiKeySecuritySettings }) | null | undefined,
  nowIso: string,
  upgradeHash?: string,
): Promise<void> {
  try {
    const nextSettings = {
      ...(currentSettings ?? {}),
      api_key_security: {
        ...(currentSettings?.api_key_security ?? {}),
        last_used_at: nowIso,
        ...(upgradeHash ? { current_hash: upgradeHash } : {}),
      },
    };
    await admin
      .from('tenants')
      .update({
        settings: nextSettings,
      })
      .eq('id', tenantId);
  } catch {
    /* best effort */
  }
}

/**
 * Rota la API key del tenant manteniendo la clave anterior válida durante `overlapHours` (por defecto 24 h)
 * para no interrumpir webhooks de Shopify/WooCommerce mientras el cliente actualiza su tienda.
 */
export async function rotateTenantApiKey(
  admin: AdminLike,
  tenantId: string,
  overlapHours = 24,
): Promise<{
  rawKey: string;
  prefix: string;
  overlapExpiresAt: string;
}> {
  const { data: rawTenant } = await admin
    .from('tenants')
    .select('api_key, settings')
    .eq('id', tenantId)
    .single();
  const tenant = rawTenant as Pick<ResolvedTenantByApiKey, 'api_key' | 'settings'> | null;

  const currentRaw = tenant?.api_key ?? undefined;
  const currentSettings = tenant?.settings ?? {};
  const prevSecurity = currentSettings.api_key_security ?? {};
  const previousHash =
    prevSecurity.current_hash || (currentRaw ? hashApiKey(currentRaw) : null);

  const generated = generateTenantApiKey();
  const overlapExpiresAt = new Date(Date.now() + overlapHours * 3600_000).toISOString();

  const nextSettings = {
    ...currentSettings,
    api_key_security: {
      prefix: generated.prefix,
      current_hash: generated.hash,
      previous_hash: previousHash,
      previous_expires_at: previousHash ? overlapExpiresAt : null,
      rotated_at: new Date().toISOString(),
      last_used_at: prevSecurity.last_used_at ?? null,
      revoked_at: null,
    },
  };

  // Intentamos guardar también en las columnas dedicadas si la migración SQL está aplicada
  const { error: colErr } = await admin
    .from('tenants')
    .update({
      api_key: generated.rawKey,
      api_key_hash: generated.hash,
      api_key_prefix: generated.prefix,
      previous_api_key_hash: previousHash,
      previous_api_key_expires_at: previousHash ? overlapExpiresAt : null,
      api_key_revoked_at: null,
      settings: nextSettings,
    })
    .eq('id', tenantId);

  if (colErr) {
    await admin
      .from('tenants')
      .update({
        api_key: generated.rawKey,
        settings: nextSettings,
      })
      .eq('id', tenantId);
  }

  return {
    rawKey: generated.rawKey,
    prefix: generated.prefix,
    overlapExpiresAt,
  };
}

/**
 * Revoca inmediatamente la API key activa y cualquier clave en periodo de solape.
 */
export async function revokeTenantApiKey(admin: AdminLike, tenantId: string): Promise<void> {
  const { data: rawTenant } = await admin
    .from('tenants')
    .select('settings')
    .eq('id', tenantId)
    .single();
  const tenant = rawTenant as Pick<ResolvedTenantByApiKey, 'settings'> | null;

  const currentSettings = tenant?.settings ?? {};
  const revokedAt = new Date().toISOString();
  const revokedPlaceholder = `revoked_${randomBytes(16).toString('hex')}`;

  const nextSettings = {
    ...currentSettings,
    api_key_security: {
      ...(currentSettings.api_key_security ?? {}),
      current_hash: null,
      previous_hash: null,
      previous_expires_at: null,
      revoked_at: revokedAt,
    },
  };

  const { error: colErr } = await admin
    .from('tenants')
    .update({
      api_key: revokedPlaceholder,
      api_key_hash: null,
      previous_api_key_hash: null,
      previous_api_key_expires_at: null,
      api_key_revoked_at: revokedAt,
      settings: nextSettings,
    })
    .eq('id', tenantId);

  if (colErr) {
    await admin
      .from('tenants')
      .update({
        api_key: revokedPlaceholder,
        settings: nextSettings,
      })
      .eq('id', tenantId);
  }
}
