import { configuredPublicUrl } from './public-url';
/**
 * ReviewFlow AI — Datos del sitio y de la empresa (v1.0).
 *
 * FUENTE ÚNICA DE VERDAD para los datos fiscales y de contacto.
 * Se consumen dinámicamente desde el footer y las páginas legales
 * (/aviso-legal, /privacidad, /terminos, /cookies).
 *
 * Configuración (prioridad):
 *  1. Variables de entorno NEXT_PUBLIC_* (recomendado en producción).
 *  2. Valores por defecto de abajo (placeholders a sustituir).
 *
 * ⚠️ ACCIÓN MANUAL: define estas variables en tu `.env` / hosting con tus
 * datos fiscales reales (ver GUIA_2_PUBLICAR_Y_PAGAR.md):
 *   NEXT_PUBLIC_COMPANY_NAME, NEXT_PUBLIC_CIF, NEXT_PUBLIC_ADDRESS,
 *   NEXT_PUBLIC_LEGAL_EMAIL, NEXT_PUBLIC_SUPPORT_EMAIL, NEXT_PUBLIC_DOMAIN
 */

/**
 * IMPORTANTE: Next.js solo sustituye las variables NEXT_PUBLIC_* en el
 * navegador cuando se escriben de forma literal (process.env.NOMBRE).
 * Con acceso dinámico (process.env[clave]) el servidor veía el valor real
 * y el navegador el placeholder, lo que rompía la hidratación de React.
 */
const pick = (value: string | undefined, fallback: string): string =>
  value && value.trim().length > 0 ? value.trim() : fallback;

/** Versión oficial de la aplicación. */
export const version = '1.0';

/** Nombre comercial de la plataforma. */
export const brand = 'ReviewFlow AI';

/** Titular: nombre y apellidos si eres autónomo, o razón social si es sociedad. */
export const companyName = pick(process.env.NEXT_PUBLIC_COMPANY_NAME, '[NOMBRE Y APELLIDOS DEL TITULAR]');

/** NIF (autónomo) o CIF (sociedad). */
export const cif = pick(process.env.NEXT_PUBLIC_CIF, '[NIF]');

/** Domicilio fiscal (LSSI-CE art. 10). */
export const address = pick(process.env.NEXT_PUBLIC_ADDRESS, '[CALLE, Nº, CP, CIUDAD, ESPAÑA]');

/** Email legal / privacidad / RGPD. */
export const legalEmail = pick(process.env.NEXT_PUBLIC_LEGAL_EMAIL, 'legal@[tudominio.com]');

/** Email de soporte. */
export const supportEmail = pick(process.env.NEXT_PUBLIC_SUPPORT_EMAIL, 'soporte@[tudominio.com]');

/** Dominio público (sin protocolo). */
export const domain = pick(process.env.NEXT_PUBLIC_DOMAIN, '[tudominio.com]');

/**
 * URL base pública con protocolo HTTPS.
 * `invalid.example` es un dominio técnico reservado: permite compilar sin
 * publicar silenciosamente una marca ajena y sigue detectándose como pendiente.
 */
const placeholderUrl = 'https://invalid.example';
const url = configuredPublicUrl() || placeholderUrl;

/**
 * Objeto agregado (compatibilidad con el código existente).
 * Las páginas legales y el footer deben preferir las exportaciones
 * individuales (`companyName`, `cif`, `address`, `supportEmail`, `domain`).
 */
export const SITE = {
  brand,
  tagline: 'Todas tus reseñas. Una sola bandeja. Respuestas con IA.',
  url,
  // ---- Datos fiscales (LSSI-CE art. 10) — centralizados arriba ----
  company: companyName,
  companyName,
  cif,
  address,
  email: legalEmail,
  supportEmail,
  domain,
  // Precios: única fuente en lib/plans.ts (no duplicar aquí).
};

/**
 * Indica si alguno de los datos fiscales o de dominio sigue con un valor placeholder
 * pendiente de sustituir antes de facturar en producción.
 */
export function hasPlaceholderSiteConfig(): boolean {
  return (
    companyName.includes('[') ||
    cif.includes('[') ||
    address.includes('[') ||
    legalEmail.includes('[') ||
    supportEmail.includes('[') ||
    domain.includes('[') ||
    url.includes('[') ||
    url === placeholderUrl ||
    cif === 'B-12345678' ||
    legalEmail.endsWith('@tudominio.com') ||
    supportEmail.endsWith('@tudominio.com')
  );
}

/**
 * Devuelve la lista de datos legales / de dominio que siguen sin configurar.
 * Se usa para bloquear el arranque en producción (ver lib/env-validation.ts).
 */
export function placeholderSiteFields(): string[] {
  const pending: string[] = [];
  if (companyName.includes('[')) pending.push('NEXT_PUBLIC_COMPANY_NAME');
  if (cif.includes('[') || cif === 'B-12345678') pending.push('NEXT_PUBLIC_CIF');
  if (address.includes('[')) pending.push('NEXT_PUBLIC_ADDRESS');
  if (legalEmail.includes('[') || legalEmail.endsWith('@tudominio.com')) pending.push('NEXT_PUBLIC_LEGAL_EMAIL');
  if (supportEmail.includes('[') || supportEmail.endsWith('@tudominio.com')) pending.push('NEXT_PUBLIC_SUPPORT_EMAIL');
  if (domain.includes('[')) pending.push('NEXT_PUBLIC_DOMAIN');
  if (url.includes('[') || url === placeholderUrl) pending.push('NEXT_PUBLIC_APP_URL');
  return pending;
}
