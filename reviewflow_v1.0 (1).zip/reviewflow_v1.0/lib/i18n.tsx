'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';

/**
 * ============================================================
 * Internacionalización (i18n) — Arquitectura de 3 Capas de Idioma
 * ============================================================
 * Fase 1: es, en, ca, pt · Fase 2: fr, de, it.
 *
 * Tres capas separadas para venta B2B internacional:
 *   1. `uiLocale`: Idioma de la interfaz elegido por el usuario del panel (cookie `NEXT_LOCALE` + `tenants.locale`).
 *   2. `customerLocale`: Idioma de las comunicaciones al cliente final (email de solicitud de reseña) por sede/tienda.
 *   3. `detectedReviewLocale`: Idioma detectado automáticamente del texto de cada reseña (`reviews.detected_locale`)
 *      para que la IA responda siempre en el idioma exacto del autor de la reseña.
 */

export type SupportedLocale = 'es' | 'en' | 'ca' | 'pt' | 'fr' | 'de' | 'it';
export type SupportedCurrency = 'EUR' | 'GBP' | 'USD';

export const SUPPORTED_LOCALES: ReadonlyArray<{
  code: SupportedLocale;
  /** Nombre del idioma en su propio idioma (nunca banderas: una bandera no es un idioma). */
  nativeName: string;
  phase: 1 | 2;
  ogLocale: string;
  aiLanguageName: string;
}> = [
  { code: 'es', nativeName: 'Español', phase: 1, ogLocale: 'es_ES', aiLanguageName: 'español' },
  { code: 'en', nativeName: 'English', phase: 1, ogLocale: 'en_GB', aiLanguageName: 'English' },
  { code: 'ca', nativeName: 'Català', phase: 1, ogLocale: 'ca_ES', aiLanguageName: 'català' },
  { code: 'pt', nativeName: 'Português', phase: 1, ogLocale: 'pt_PT', aiLanguageName: 'português' },
  { code: 'fr', nativeName: 'Français', phase: 2, ogLocale: 'fr_FR', aiLanguageName: 'français' },
  { code: 'de', nativeName: 'Deutsch', phase: 2, ogLocale: 'de_DE', aiLanguageName: 'Deutsch' },
  { code: 'it', nativeName: 'Italiano', phase: 2, ogLocale: 'it_IT', aiLanguageName: 'italiano' },
];

const CURRENCY_RATES_FROM_EUR: Record<SupportedCurrency, number> = {
  EUR: 1,
  GBP: 0.85,
  USD: 1.09,
};

export function resolveLocale(raw: string | null | undefined): SupportedLocale {
  if (!raw) return 'es';
  const short = raw.toLowerCase().trim().slice(0, 2);
  const found = SUPPORTED_LOCALES.find((l) => l.code === short);
  return found ? found.code : 'es';
}

export function aiLanguageNameFor(locale: SupportedLocale): string {
  return SUPPORTED_LOCALES.find((l) => l.code === locale)?.aiLanguageName ?? 'español';
}

/**
 * CAPA 3: Detecta automáticamente el idioma de una reseña escrita por un cliente
 * para guardarlo en `reviews.detected_locale` y responderle en su propio idioma.
 */
export function detectReviewLocale(text: string | null | undefined, fallback: SupportedLocale = 'es'): SupportedLocale {
  const sample = (text ?? '').toLowerCase().trim();
  if (sample.length < 4) return fallback;

  const scores: Record<SupportedLocale, number> = {
    es: 0,
    en: 0,
    ca: 0,
    pt: 0,
    fr: 0,
    de: 0,
    it: 0,
  };

  const countMatches = (words: string[], weight = 2) => {
    let total = 0;
    for (const w of words) {
      const escaped = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const re = new RegExp(`(?:^|[^\\p{L}])${escaped}(?:$|[^\\p{L}])`, 'iu');
      if (re.test(sample)) total += weight;
    }
    return total;
  };

  scores.en += countMatches(
    ['the', 'and', 'very', 'good', 'great', 'service', 'food', 'staff', 'would', 'recommend', 'wait', 'order', 'place', 'friendly', 'amazing', 'awesome', 'disappointed', 'terrible', 'delivery', 'customer', 'experience', 'definitely', 'best', 'town'],
    2,
  );
  scores.ca += countMatches(
    ['molt', 'això', 'però', 'també', 'servei', 'menjar', 'atenció', 'bona', 'gràcies', 'lloc', 'tornarem', 'recomanable', 'equip', 'nostra'],
    3,
  );
  scores.pt += countMatches(
    ['muito', 'bom', 'ótimo', 'atendimento', 'comida', 'obrigado', 'obrigada', 'recomendo', 'entrega', 'excelente', 'voltar', 'pelo', 'equipa'],
    3,
  );
  scores.fr += countMatches(
    ['très', 'bien', 'super', 'accueil', 'repas', 'service', 'merci', 'beaucoup', 'toute', 'équipe', 'recommande', 'parfait', 'chaleureux', 'attente'],
    3,
  );
  scores.de += countMatches(
    ['vielen', 'dank', 'für', 'den', 'tollen', 'und', 'das', 'leckere', 'sehr', 'gut', 'essen', 'freundlich', 'schnell', 'immer', 'wieder', 'danke', 'empfehlen', 'preis', 'leistung', 'lecker'],
    3,
  );
  scores.it += countMatches(
    ['molto', 'buono', 'ottimo', 'servizio', 'personale', 'cibo', 'consiglio', 'grazie', 'mille', 'tutti', 'esperienza', 'sempre', 'posto'],
    3,
  );
  scores.es += countMatches(
    ['muy', 'bueno', 'buena', 'atención', 'comida', 'gracias', 'excelente', 'recomiendo', 'trato', 'servicio', 'pedido', 'siempre', 'todo', 'equipo', 'muchas'],
    2,
  );

  let best: SupportedLocale = fallback;
  let bestScore = 0;
  for (const [loc, sc] of Object.entries(scores) as Array<[SupportedLocale, number]>) {
    if (sc > bestScore) {
      bestScore = sc;
      best = loc;
    }
  }
  return bestScore > 0 ? best : fallback;
}

/**
 * Formateo de precios, números y fechas con `Intl.*` y soporte multimoneda (EUR, GBP, USD).
 */
export function formatMoneyIntl(
  centsInEur: number,
  locale: SupportedLocale = 'es',
  currency: SupportedCurrency = 'EUR',
): string {
  const rate = CURRENCY_RATES_FROM_EUR[currency] ?? 1;
  const amount = Math.round((centsInEur / 100) * rate);
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatCurrencyAmount(
  amountInEur: number,
  currency: SupportedCurrency = 'EUR',
  locale: SupportedLocale = 'es',
): string {
  return formatMoneyIntl(Math.round(amountInEur * 100), locale, currency);
}

export function formatNumberIntl(value: number, locale: SupportedLocale = 'es'): string {
  return new Intl.NumberFormat(locale).format(value);
}


export function formatDateIntl(
  dateInput: string | number | Date,
  locale: SupportedLocale = 'es',
  options: Intl.DateTimeFormatOptions = { day: '2-digit', month: 'short', year: 'numeric' },
): string {
  const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat(locale, options).format(date);
}


/* ------------------------------------------------------------------ */
/* Capa 1 (interfaz): la traducción de páginas la hace automáticamente  */
/* el traductor web de `components/LanguageSelector.tsx`. Aquí solo se  */
/* mantiene la divisa y el formateo de precios/números/fechas.          */
/* ------------------------------------------------------------------ */

type I18nContextValue = {
  locale: SupportedLocale;
  currency: SupportedCurrency;
  setCurrency: (next: SupportedCurrency) => void;
  formatPrice: (centsInEur: number) => string;
  formatNumber: (value: number) => string;
  formatDate: (dateInput: string | number | Date, options?: Intl.DateTimeFormatOptions) => string;
};

const I18nContext = createContext<I18nContextValue>({
  locale: 'es',
  currency: 'EUR',
  setCurrency: () => undefined,
  formatPrice: (c) => formatMoneyIntl(c, 'es', 'EUR'),
  formatNumber: (v) => formatNumberIntl(v, 'es'),
  formatDate: (d, o) => formatDateIntl(d, 'es', o),
});

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const locale: SupportedLocale = 'es';
  const [currency, setCurrencyState] = useState<SupportedCurrency>('EUR');

  useEffect(() => {
    try {
      const saved = (localStorage.getItem('rf_currency') ?? 'EUR').toUpperCase();
      if (saved === 'EUR' || saved === 'GBP' || saved === 'USD') setCurrencyState(saved);
    } catch {
      /* ignore */
    }
  }, []);

  const setCurrency = (next: SupportedCurrency) => {
    setCurrencyState(next);
    try {
      localStorage.setItem('rf_currency', next);
    } catch {
      /* ignore */
    }
  };

  return (
    <I18nContext.Provider
      value={{
        locale,
        currency,
        setCurrency,
        formatPrice: (centsInEur) => formatMoneyIntl(centsInEur, locale, currency),
        formatNumber: (value) => formatNumberIntl(value, locale),
        formatDate: (dateInput, options) => formatDateIntl(dateInput, locale, options),
      }}
    >
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  return useContext(I18nContext);
}
