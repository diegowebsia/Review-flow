import { z } from 'zod';
import { encryptCredentials } from '@/lib/credentials';
import {
  normalizeGoogleReview,
  normalizePlaceReview,
  syncGoogleBusinessForTenant,
  syncGooglePlacesForTenant,
} from '@/lib/google';
import { normalizeTrustpilotReview, syncTrustpilotForTenant } from '@/lib/trustpilot';
import type { AdminLike } from '@/lib/usage';

type ProviderId = 'google' | 'trustpilot';

type NormalizedReview = {
  externalId: string;
  author: string;
  rating: number;
  text: string;
  createdAt: string;
  verified: boolean;
};

type ProviderContext = {
  admin: AdminLike;
  tenantId: string;
};

type ProviderConnectResult = {
  ok: boolean;
  provider: ProviderId;
  connectedAt: string;
  redirectUrl?: string;
  error?: string;
};

type ProviderSyncResult = {
  ok: boolean;
  status: number;
  provider: ProviderId;
  imported?: number;
  error?: string;
  code?: string;
  quota?: unknown;
};

interface ReviewProviderAdapter<TCredentials = Record<string, unknown>> {
  readonly id: ProviderId;
  connect(ctx: ProviderContext, credentials: TCredentials): Promise<ProviderConnectResult>;
  sync(ctx: ProviderContext, credentials: TCredentials): Promise<ProviderSyncResult>;
  normalizeReview(raw: unknown, index?: number, contextId?: string): NormalizedReview;
}

/* ================================================================== */
/* Esquemas Zod de credenciales por proveedor                          */
/* ================================================================== */

const GoogleCredentialsSchema = z.object({
  access_token: z.string().optional(),
  refresh_token: z.string().optional(),
  placeId: z.string().optional(),
});
type GoogleCredentials = z.infer<typeof GoogleCredentialsSchema>;

const TrustpilotCredentialsSchema = z.object({
  apiKey: z.string().min(1, 'La API Key de Trustpilot es obligatoria.'),
  businessUnitId: z.string().min(1, 'El Business Unit ID de Trustpilot es obligatorio.'),
});
type TrustpilotCredentials = z.infer<typeof TrustpilotCredentialsSchema>;

/* ================================================================== */
/* Implementaciones concretas de ReviewProviderAdapter                 */
/* ================================================================== */

const googleProviderAdapter: ReviewProviderAdapter<GoogleCredentials> = {
  id: 'google',
  async connect(ctx, credentials) {
    const parsed = GoogleCredentialsSchema.safeParse(credentials);
    if (!parsed.success) {
      return {
        ok: false,
        provider: 'google',
        connectedAt: new Date().toISOString(),
        error: parsed.error.issues[0]?.message ?? 'Credenciales de Google inválidas.',
      };
    }
    const now = new Date().toISOString();
    const { data } = parsed;
    if (data.placeId && !data.access_token && !data.refresh_token) {
      const { data: tenantRow } = await ctx.admin
        .from('tenants')
        .select('settings')
        .eq('id', ctx.tenantId)
        .single();
      const prevSettings =
        (tenantRow as { settings?: Record<string, unknown> | null } | null)?.settings ?? {};
      await ctx.admin
        .from('tenants')
        .update({ settings: { ...prevSettings, place_id: data.placeId.trim() } })
        .eq('id', ctx.tenantId);
      return { ok: true, provider: 'google', connectedAt: now };
    }
    const { error: upsertError } = await ctx.admin.from('integrations').upsert(
      {
        tenant_id: ctx.tenantId,
        provider: 'google',
        credentials: encryptCredentials({
          access_token: data.access_token ?? '',
          refresh_token: data.refresh_token ?? '',
        }),
        status: 'connected',
        last_error: null,
      },
      { onConflict: 'tenant_id,provider' },
    );
    if (upsertError) throw new Error('integration_save_failed');
    return { ok: true, provider: 'google', connectedAt: now };
  },
  async sync(ctx, credentials) {
    const usePlaces = Boolean(credentials.placeId && !credentials.access_token && !credentials.refresh_token);
    const res = usePlaces
      ? await syncGooglePlacesForTenant(ctx, credentials.placeId ?? '')
      : await syncGoogleBusinessForTenant(ctx, {
          access_token: credentials.access_token,
          refresh_token: credentials.refresh_token,
        });
    if (!res.ok) {
      return {
        ok: false,
        status: res.status,
        provider: 'google',
        error: res.error,
        code: res.code,
        quota: res.body.quota,
      };
    }
    return {
      ok: true,
      status: 200,
      provider: 'google',
      imported: res.result.imported,
      quota: res.quota,
    };
  },
  normalizeReview(raw, index = 0, contextId = 'locations/default') {
    if (contextId.startsWith('places:') || (raw && typeof raw === 'object' && 'authorAttribution' in raw)) {
      return normalizePlaceReview(raw, index, contextId.replace(/^places:/, '') || 'default');
    }
    return normalizeGoogleReview(raw, contextId);
  },
};

const trustpilotProviderAdapter: ReviewProviderAdapter<TrustpilotCredentials> = {
  id: 'trustpilot',
  async connect(ctx, credentials) {
    const parsed = TrustpilotCredentialsSchema.safeParse(credentials);
    if (!parsed.success) {
      return {
        ok: false,
        provider: 'trustpilot',
        connectedAt: new Date().toISOString(),
        error: parsed.error.issues[0]?.message ?? 'Credenciales de Trustpilot inválidas.',
      };
    }
    const now = new Date().toISOString();
    const { error: upsertError } = await ctx.admin.from('integrations').upsert(
      {
        tenant_id: ctx.tenantId,
        provider: 'trustpilot',
        credentials: encryptCredentials({
          apiKey: parsed.data.apiKey.trim(),
          businessUnitId: parsed.data.businessUnitId.trim(),
        }),
        status: 'connected',
        last_error: null,
      },
      { onConflict: 'tenant_id,provider' },
    );
    if (upsertError) throw new Error('integration_save_failed');
    return { ok: true, provider: 'trustpilot', connectedAt: now };
  },
  async sync(ctx, credentials) {
    const res = await syncTrustpilotForTenant(ctx, {
      apiKey: credentials.apiKey,
      businessUnitId: credentials.businessUnitId,
    });
    if (!res.ok) {
      return {
        ok: false,
        status: res.status,
        provider: 'trustpilot',
        error: res.error,
        code: res.code,
        quota: res.body.quota,
      };
    }
    return {
      ok: true,
      status: 200,
      provider: 'trustpilot',
      imported: res.result.imported,
      quota: res.quota,
    };
  },
  normalizeReview(raw, index = 0) {
    return normalizeTrustpilotReview(raw, index);
  },
};

export const PROVIDERS_REGISTRY: Record<ProviderId, ReviewProviderAdapter<never>> = {
  google: googleProviderAdapter as ReviewProviderAdapter<never>,
  trustpilot: trustpilotProviderAdapter as ReviewProviderAdapter<never>,
};


export function getProviderAdapter(provider: ProviderId): ReviewProviderAdapter<Record<string, unknown>> {
  return PROVIDERS_REGISTRY[provider] as unknown as ReviewProviderAdapter<Record<string, unknown>>;
}

export function listProviders(): ReviewProviderAdapter<Record<string, unknown>>[] {
  return (Object.keys(PROVIDERS_REGISTRY) as ProviderId[]).map((id) => getProviderAdapter(id));
}

export async function connectProvider(
  ctx: ProviderContext,
  provider: ProviderId,
  credentials: Record<string, unknown>,
): Promise<ProviderConnectResult> {
  return getProviderAdapter(provider).connect(ctx, credentials);
}

export function normalizeProviderReview(
  provider: ProviderId,
  raw: unknown,
  index = 0,
  contextId?: string,
): NormalizedReview {
  return getProviderAdapter(provider).normalizeReview(raw, index, contextId);
}

