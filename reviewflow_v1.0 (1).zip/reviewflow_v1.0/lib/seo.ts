import type { Metadata } from 'next';
import { SITE } from './site';

/** Leaf metadata must not inherit the home page's social title/description. */
export function pageMetadata(title: string, description: string, path?: string, index = true): Metadata {
  const socialTitle = title.includes(SITE.brand) ? title : `${title} · ${SITE.brand}`;
  return {
    title: { absolute: socialTitle },
    description,
    ...(path ? { alternates: { canonical: path } } : {}),
    robots: { index, follow: index },
    openGraph: {
      title: socialTitle, description, type: 'website', locale: 'es_ES', siteName: SITE.brand,
      ...(path ? { url: path } : {}),
      images: [{ url: '/opengraph-image', width: 1200, height: 630, alt: SITE.brand }],
    },
    twitter: { card: 'summary_large_image', title: socialTitle, description, images: ['/opengraph-image'] },
  };
}
