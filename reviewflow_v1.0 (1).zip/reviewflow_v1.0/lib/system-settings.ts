import { createAdminClient } from '@/lib/supabase/admin';
import { env } from '@/lib/env';
import { systemLog } from '@/lib/logger';

const FREE_TRIAL_SETTING_KEY = 'enable_free_trial';
const FREE_TRIAL_LOG_SOURCE = 'system.settings.free_trial';

/** Cache en memoria de corta duración para lecturas ultrarrápidas en SSR. */
let cachedFreeTrial: { value: boolean; expiresAt: number } | null = null;
const CACHE_TTL_MS = 5_000;

/**
 * Obtiene si los 7 días de prueba gratuita están habilitados globalmente.
 * Orden de prioridad:
 *   1. Tabla `public.system_settings` en Supabase (`key = 'enable_free_trial'`).
 *   2. Último registro en `public.system_logs` (`source = 'system.settings.free_trial'`),
 *      como respaldo inmediato si aún no se migró la tabla `system_settings`.
 *   3. Variable de entorno `NEXT_PUBLIC_ENABLE_FREE_TRIAL` (por defecto `true`).
 */
export async function getFreeTrialEnabled(skipCache = false): Promise<boolean> {
  if (!skipCache && cachedFreeTrial && cachedFreeTrial.expiresAt > Date.now()) {
    return cachedFreeTrial.value;
  }

  const defaultFromEnv = env.enableFreeTrial;
  const admin = createAdminClient();
  if (!admin) {
    return defaultFromEnv;
  }

  try {
    const { data, error } = await admin
      .from('system_settings')
      .select('value')
      .eq('key', FREE_TRIAL_SETTING_KEY)
      .maybeSingle();

    if (!error && data && data.value !== null && data.value !== undefined) {
      const val = data.value as boolean | { enabled?: boolean };
      const resolved =
        typeof val === 'boolean'
          ? val
          : typeof val?.enabled === 'boolean'
            ? val.enabled
            : defaultFromEnv;
      cachedFreeTrial = { value: resolved, expiresAt: Date.now() + CACHE_TTL_MS };
      return resolved;
    }
  } catch {
    /* Si la tabla system_settings aún no existe, consultamos system_logs */
  }

  try {
    const { data: logRow } = await admin
      .from('system_logs')
      .select('message')
      .eq('source', FREE_TRIAL_LOG_SOURCE)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (logRow?.message === 'enabled' || logRow?.message === 'disabled') {
      const resolved = logRow.message === 'enabled';
      cachedFreeTrial = { value: resolved, expiresAt: Date.now() + CACHE_TTL_MS };
      return resolved;
    }
  } catch {
    /* Fallback silencioso a variable de entorno */
  }

  cachedFreeTrial = { value: defaultFromEnv, expiresAt: Date.now() + CACHE_TTL_MS };
  return defaultFromEnv;
}

/**
 * Actualiza en tiempo real el estado global de la prueba gratuita de 7 días.
 * Persiste tanto en `system_settings` como en `system_logs` para máxima compatibilidad.
 */
export async function setFreeTrialEnabled(
  enabled: boolean,
  updatedBy: string,
): Promise<{ ok: boolean; enabled: boolean; error?: string }> {
  cachedFreeTrial = { value: enabled, expiresAt: Date.now() + CACHE_TTL_MS };

  const admin = createAdminClient();
  if (!admin) {
    return {
      ok: false,
      enabled,
      error: 'Supabase (service_role) no está configurado en el servidor.',
    };
  }

  try {
    await admin.from('system_settings').upsert(
      {
        key: FREE_TRIAL_SETTING_KEY,
        value: { enabled },
        updated_at: new Date().toISOString(),
        updated_by: updatedBy,
      },
      { onConflict: 'key' },
    );
  } catch {
    /* Si la tabla system_settings no se ha creado aún, el registro en system_logs actúa como persistencia */
  }

  await systemLog(
    'info',
    FREE_TRIAL_LOG_SOURCE,
    enabled ? 'enabled' : 'disabled',
    { enabled, by: updatedBy },
  );

  return { ok: true, enabled };
}
