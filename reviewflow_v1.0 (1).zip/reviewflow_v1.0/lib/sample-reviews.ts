import type { ReviewItem } from '@/components/dashboard/types';

export type VerticalTemplateId = 'restaurante' | 'clinica_dental' | 'ecommerce' | 'hotel' | 'taller' | 'belleza' | 'gimnasio' | 'inmobiliaria' | 'servicios_profesionales' | 'generico';

export type VerticalTemplate = {
  id: VerticalTemplateId;
  name: string;
  sector: string;
  tone: 'profesional' | 'cercano' | 'formal';
  brandInstructions: string;
  brandRules: string[];
  forbiddenWords: string[];
  brandSignature: string;
};

export const VERTICAL_TEMPLATES: ReadonlyArray<VerticalTemplate> = [
  {
    id: 'restaurante',
    name: 'Restaurante / Hostelería',
    sector: 'Gastronomía y restauración',
    tone: 'cercano',
    brandInstructions:
      'Somos un restaurante de cocina elaborada con producto fresco de temporada y trato cercano.',
    brandRules: [
      'Agradecer la mención a la cocina y al servicio de sala',
      'Invitar a reservar mesa desde nuestra web para disfrutar del menú de temporada',
    ],
    forbiddenWords: ['culpa vuestra', 'imposible', 'mentira'],
    brandSignature: 'El equipo de Dirección y Sala',
  },
  {
    id: 'clinica_dental',
    name: 'Clínica Dental / Salud',
    sector: 'Salud y bienestar',
    tone: 'formal',
    brandInstructions:
      'Clínica sanitaria centrada en la excelencia médica, puntualidad, empatía con el paciente y estricta confidencialidad.',
    brandRules: [
      'Nunca confirmar datos clínicos públicos por confidencialidad médica (RGPD)',
      'Recordar que disponemos de primera revisión diagnóstica sin compromiso',
    ],
    forbiddenWords: ['barato', 'oferta agresiva', 'garantía 100%'],
    brandSignature: 'Dirección Médica y Atención al Paciente',
  },
  {
    id: 'ecommerce',
    name: 'Tienda Online / E-commerce',
    sector: 'Comercio electrónico D2C',
    tone: 'profesional',
    brandInstructions:
      'Marca de comercio electrónico con envíos rápidos en 24/48h, cambios sencillos y soporte ágil.',
    brandRules: [
      'En incidencias de envío, pedir el número de pedido para rastrearlo en el acto',
      'Mencionar que los cambios y devoluciones son gratuitos durante 30 días',
    ],
    forbiddenWords: ['no nos hacemos cargo', 'reclama al transportista'],
    brandSignature: 'Equipo de Customer Experience',
  },
  {
    id: 'hotel',
    name: 'Hotel / Alojamiento Turístico',
    sector: 'Turismo y hospitalidad',
    tone: 'formal',
    brandInstructions:
      'Alojamiento orientado al descanso, limpieza impecable y atención multilingüe 24h en recepción.',
    brandRules: [
      'Responder en el idioma del huésped (español, inglés, francés, alemán, italiano)',
      'Recordar que reservando en nuestra web oficial obtienen late check-out gratuito',
    ],
    forbiddenWords: ['exageración', 'ruido normal'],
    brandSignature: 'Guest Relations & Dirección del Hotel',
  },
  {
    id: 'taller',
    name: 'Taller / Servicios Profesionales',
    sector: 'Automoción y servicios técnicos',
    tone: 'profesional',
    brandInstructions:
      'Servicio técnico con presupuesto cerrado previo, recambios originales y garantía por escrito.',
    brandRules: [
      'Destacar que todas las reparaciones cuentan con garantía oficial',
      'Ofrecer revisión preventiva gratuita en su próxima visita',
    ],
    forbiddenWords: ['avería tuya', 'sin garantía'],
    brandSignature: 'Jefe de Taller y Postventa',
  },
  {
    id: 'belleza',
    name: 'Peluquería / Estética',
    sector: 'Belleza y cuidado personal',
    tone: 'cercano',
    brandInstructions: 'Somos un salón de belleza que cuida cada detalle y la experiencia del cliente.',
    brandRules: ['Agradecer la confianza en nuestro equipo', 'Invitar a reservar la próxima cita'],
    forbiddenWords: ['culpa vuestra', 'imposible', 'mentira'],
    brandSignature: 'El equipo del salón',
  },
  {
    id: 'gimnasio',
    name: 'Gimnasio / Deporte',
    sector: 'Deporte y fitness',
    tone: 'cercano',
    brandInstructions: 'Somos un centro deportivo que acompaña a cada socio en sus objetivos.',
    brandRules: ['Reconocer el esfuerzo del socio', 'Invitar a probar otras clases o servicios'],
    forbiddenWords: ['culpa vuestra', 'imposible', 'mentira'],
    brandSignature: 'El equipo del centro',
  },
  {
    id: 'inmobiliaria',
    name: 'Inmobiliaria',
    sector: 'Inmobiliario',
    tone: 'profesional',
    brandInstructions: 'Somos una agencia inmobiliaria centrada en la transparencia y el asesoramiento cercano.',
    brandRules: ['Agradecer la confianza en la operación', 'Ofrecer ayuda para futuras gestiones'],
    forbiddenWords: ['culpa vuestra', 'imposible', 'mentira'],
    brandSignature: 'El equipo de la agencia',
  },
  {
    id: 'servicios_profesionales',
    name: 'Servicios profesionales (asesoría, abogados, reformas...)',
    sector: 'Servicios profesionales',
    tone: 'profesional',
    brandInstructions: 'Somos un despacho de servicios profesionales que prioriza la calidad y el trato personal.',
    brandRules: ['Agradecer la confianza depositada', 'No revelar nunca datos del caso o del cliente'],
    forbiddenWords: ['culpa vuestra', 'imposible', 'mentira'],
    brandSignature: 'El equipo profesional',
  },
  {
    id: 'generico',
    name: 'Otro sector (genérico)',
    sector: 'Cualquier negocio',
    tone: 'profesional',
    brandInstructions: 'Somos un negocio local que valora a cada cliente y mejora cada día gracias a sus opiniones.',
    brandRules: ['Agradecer siempre la opinión', 'Ante una queja, disculparse y ofrecer un canal privado de contacto'],
    forbiddenWords: ['culpa vuestra', 'imposible', 'mentira'],
    brandSignature: 'El equipo',
  },
];

/**
 * 12 reseñas de demostración claramente etiquetadas («Vista de ejemplo») para que el cliente
 * que acaba de registrarse pueda probar respuestas con IA, triaje de quejas, detección de idioma
 * y analítica en su primer minuto. Desaparecen automáticamente al importar la primera reseña real.
 */
export const SAMPLE_REVIEWS: ReviewItem[] = [
  {
    id: 'sample-01',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Laura Méndez (Ejemplo)',
    rating: 5,
    text: 'Trato espectacular desde que entramos por la puerta. Todo impecable, rapidísimos y una relación calidad-precio de diez. Volveremos seguro la semana que viene.',
    reply: null,
    replied: false,
    verified: true,
    created_at: new Date(Date.now() - 2 * 3600_000).toISOString(),
  },
  {
    id: 'sample-02',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Carlos Gómez (Ejemplo)',
    rating: 2,
    text: 'Tuvimos que esperar casi 35 minutos más de la hora acordada y nadie nos avisó del retraso. El producto final estaba bien, pero la espera fue desesperante.',
    reply: null,
    replied: false,
    verified: true,
    flagged_private: true,
    created_at: new Date(Date.now() - 5 * 3600_000).toISOString(),
  },
  {
    id: 'sample-03',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'James Thompson (Sample EN)',
    rating: 5,
    text: 'Amazing experience and very friendly staff! The service was fast and the quality exceeded our expectations. We would definitely recommend this place.',
    reply: null,
    replied: false,
    verified: true,
    created_at: new Date(Date.now() - 12 * 3600_000).toISOString(),
  },
  {
    id: 'sample-04',
    tenant: 'Vista de Ejemplo',
    source: 'trustpilot',
    author: 'Marta Ruiz (Ejemplo)',
    rating: 1,
    text: 'Mi pedido #4821 llegó con la caja golpeada y un artículo equivocado. He intentado llamar por teléfono dos veces y comunicaba. Necesito solución urgente.',
    reply: null,
    replied: false,
    verified: true,
    flagged_private: true,
    created_at: new Date(Date.now() - 18 * 3600_000).toISOString(),
  },
  {
    id: 'sample-05',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Jordi Puig (Exemple CA)',
    rating: 5,
    text: 'Molt bon servei i una atenció excel·lent per part de tot l’equip. Sens dubte tornarem molt aviat, totalment recomanable!',
    reply: null,
    replied: false,
    verified: true,
    created_at: new Date(Date.now() - 26 * 3600_000).toISOString(),
  },
  {
    id: 'sample-06',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Claire Dubois (Exemple FR)',
    rating: 4,
    text: 'Très bon accueil et service rapide. Le rapport qualité-prix est super, je recommande vivement cette adresse.',
    reply: null,
    replied: false,
    verified: true,
    created_at: new Date(Date.now() - 36 * 3600_000).toISOString(),
  },
  {
    id: 'sample-07',
    tenant: 'Vista de Ejemplo',
    source: 'trustpilot',
    author: 'Pedro Navarro (Ejemplo)',
    rating: 5,
    text: 'Envío en menos de 24 horas y el empaquetado cuidadísimo. Tuve una duda con la talla y por chat me la resolvieron al instante.',
    reply:
      'Hola Pedro, muchas gracias por tu valoración de 5 estrellas. Nos alegra saber que recibiste tu pedido en menos de 24 horas y que nuestro soporte por chat te resultó útil. ¡Te esperamos pronto!',
    replied: true,
    verified: true,
    created_at: new Date(Date.now() - 44 * 3600_000).toISOString(),
  },
  {
    id: 'sample-08',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Markus Weber (Beispiel DE)',
    rating: 5,
    text: 'Sehr gut und freundlich! Preis-Leistung ist top, wir kommen immer wieder gerne vorbei. Vielen Dank!',
    reply: null,
    replied: false,
    verified: true,
    created_at: new Date(Date.now() - 52 * 3600_000).toISOString(),
  },
  {
    id: 'sample-09',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Elena Morales (Ejemplo)',
    rating: 3,
    text: 'El sitio es bonito y el personal amable, pero hacía algo de frío en el local y los precios han subido un poco respecto al año pasado.',
    reply: null,
    replied: false,
    verified: true,
    flagged_private: true,
    created_at: new Date(Date.now() - 68 * 3600_000).toISOString(),
  },
  {
    id: 'sample-10',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'User998877_Promo (Ejemplo Spam)',
    rating: 1,
    text: 'No vayáis aquí, mejor comprad en http://competidor-barato-spam.xyz donde regalan cupones gratis!!!',
    reply: null,
    replied: false,
    verified: false,
    flagged_private: true,
    created_at: new Date(Date.now() - 75 * 3600_000).toISOString(),
  },
  {
    id: 'sample-11',
    tenant: 'Vista de Ejemplo',
    source: 'google',
    author: 'Sofía Castro (Ejemplo)',
    rating: 5,
    text: 'Profesionales de pies a cabeza. Me explicaron cada paso con mucha claridad y el resultado ha sido inmejorable.',
    reply:
      'Hola Sofía, muchísimas gracias por tus 5 estrellas y por destacar la claridad de nuestro equipo. ¡Aquí nos tienes para lo que necesites!',
    replied: true,
    verified: true,
    created_at: new Date(Date.now() - 85 * 3600_000).toISOString(),
  },
  {
    id: 'sample-12',
    tenant: 'Vista de Ejemplo',
    source: 'trustpilot',
    author: 'João Silva (Exemplo PT)',
    rating: 5,
    text: 'Muito bom atendimento e entrega super rápida. Recomendo a todos, excelente experiência de compra!',
    reply: null,
    replied: false,
    verified: true,
    created_at: new Date(Date.now() - 96 * 3600_000).toISOString(),
  },
];
