import { createHash, createHmac, randomBytes, timingSafeEqual } from 'crypto';

export function safeInternalRedirect(value: string | null | undefined, fallback = '/dashboard'): string {
  if (!value || !value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return fallback;
  try {
    const url = new URL(value, 'https://reviewflow.invalid');
    if (url.origin !== 'https://reviewflow.invalid') return fallback;
    return `${url.pathname}${url.search}${url.hash}`;
  } catch {
    return fallback;
  }
}

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const IPV4_OR_IPV6_RE = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$|^[0-9a-fA-F:]{2,45}$/;

function sanitizeIpCandidate(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const clean = raw.trim().replace(/^\[|\]$/g, '');
  if (!clean || clean.length > 45) return null;
  return IPV4_OR_IPV6_RE.test(clean) ? clean : null;
}

/**
 * Extrae la IP real del cliente validando cabeceras de proxy de confianza
 * (Vercel `x-vercel-forwarded-for`, Cloudflare `cf-connecting-ip`, `x-real-ip`).
 * Si solo existe `x-forwarded-for`, toma el último salto añadido por el reverse-proxy
 * (o el primero si `TRUST_PROXY_HOPS=1`) y valida formato IPv4/IPv6 para impedir
 * suplantación trivial de cabecera `X-Forwarded-For` en rate-limiting.
 */
export function requestIp(req: Request): string {
  const vercelIp = sanitizeIpCandidate(req.headers.get('x-vercel-forwarded-for')?.split(',')[0]);
  if (vercelIp) return vercelIp;

  const cfIp = sanitizeIpCandidate(req.headers.get('cf-connecting-ip'));
  if (cfIp) return cfIp;

  const realIp = sanitizeIpCandidate(req.headers.get('x-real-ip'));
  if (realIp) return realIp;

  const xff = req.headers.get('x-forwarded-for');
  if (xff) {
    const hops = xff
      .split(',')
      .map((part) => sanitizeIpCandidate(part))
      .filter((ip): ip is string => Boolean(ip));
    if (hops.length > 0) {
      // El último hop en XFF es el inyectado por el proxy perimetral más cercano al servidor
      return hops[hops.length - 1]!;
    }
  }
  return 'unknown';
}

/**
 * Obtiene el pepper de privacidad RGPD.
 * NUNCA usa `SUPABASE_SERVICE_ROLE_KEY` como fallback: en producción exige `PRIVACY_HASH_PEPPER`.
 */
function privacyPepper(): string {
  const configured = process.env.PRIVACY_HASH_PEPPER?.trim();
  if (configured) return configured;
  if (process.env.NODE_ENV === 'production' && process.env.NEXT_PHASE !== 'phase-production-build') {
    throw new Error('Falta PRIVACY_HASH_PEPPER obligatorio en producción.');
  }
  return 'dev-only-privacy-pepper-never-use-in-prod-32chars';
}

export function hashPersonalValue(value: string): string {
  const pepper = privacyPepper();
  return createHmac('sha256', pepper).update(value).digest('hex');
}

/**
 * Obtiene el secreto de firma de tokens opacos y estado OAuth.
 * NUNCA usa `SUPABASE_SERVICE_ROLE_KEY` ni `INTEGRATION_ENCRYPTION_KEY` como fallback:
 * cada clave tiene un propósito criptográfico aislado.
 */
function signingSecret(): string {
  const configured = (process.env.APP_SIGNING_SECRET || process.env.OAUTH_STATE_SECRET)?.trim();
  if (configured) return configured;
  if (process.env.NODE_ENV === 'production' && process.env.NEXT_PHASE !== 'phase-production-build') {
    throw new Error('Falta APP_SIGNING_SECRET obligatorio en producción.');
  }
  return 'dev-only-app-signing-secret-never-use-in-prod-32chars';
}

export function signOpaqueId(value: string): string {
  const secret = signingSecret();
  if (!secret) return '';
  return createHmac('sha256', secret).update(value).digest('base64url');
}

export function verifyOpaqueId(value: string, signature: string): boolean {
  const expected = signOpaqueId(value);
  if (!expected || !signature) return false;
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && timingSafeEqual(a, b);
}

type OAuthState = { tenantId: string; userId: string; nonce: string; exp: number };

export function createOAuthState(tenantId: string, userId: string): string {
  const secret = signingSecret();
  if (!secret) throw new Error('Falta APP_SIGNING_SECRET.');
  const payload: OAuthState = {
    tenantId,
    userId,
    nonce: randomBytes(18).toString('base64url'),
    exp: Date.now() + 10 * 60_000,
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return `${encoded}.${createHmac('sha256', secret).update(encoded).digest('base64url')}`;
}

export function verifyOAuthState(state: string): OAuthState | null {
  const secret = signingSecret();
  const [encoded, signature] = state.split('.');
  if (!secret || !encoded || !signature) return null;
  const expected = createHmac('sha256', secret).update(encoded).digest('base64url');
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as OAuthState;
    if (!payload.tenantId || !payload.userId || !payload.nonce || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function createPkce(): { verifier: string; challenge: string } {
  const verifier = randomBytes(32).toString('base64url');
  const challenge = createHash('sha256').update(verifier).digest('base64url');
  return { verifier, challenge };
}

/**
 * Comparación en tiempo constante de dos cadenas mediante `crypto.timingSafeEqual`.
 * Comprueba antes que ambas cadenas tengan la misma longitud.
 */
export function timingSafeStringEqual(a: string | null | undefined, b: string | null | undefined): boolean {
  if (!a || !b) return false;
  const trimmedA = a.trim();
  const trimmedB = b.trim();
  if (!trimmedA || !trimmedB) return false;
  if (trimmedA.length !== trimmedB.length) return false;
  const bufA = Buffer.from(trimmedA, 'utf8');
  const bufB = Buffer.from(trimmedB, 'utf8');
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

/**
 * Verifica el secreto de rutas `/api/cron/*` en cabeceras (`x-cron-secret`,
 * `authorization: Bearer <CRON_SECRET>`) o query `?secret=` usando `timingSafeEqual`.
 */
export function verifyCronSecret(req: Request, expectedSecret = process.env.CRON_SECRET): boolean {
  const secret = expectedSecret?.trim() ?? '';
  if (!secret) return false;

  const headerCron = req.headers.get('x-cron-secret');
  if (headerCron && timingSafeStringEqual(headerCron, secret)) {
    return true;
  }

  const authHeader = req.headers.get('authorization') ?? '';
  if (authHeader.toLowerCase().startsWith('bearer ')) {
    const token = authHeader.slice(7).trim();
    if (timingSafeStringEqual(token, secret)) {
      return true;
    }
  }

  // `?secret=` queda en logs de acceso y del proxy: solo se acepta fuera de producción.
  if (process.env.NODE_ENV === 'production' && process.env.ALLOW_CRON_QUERY_SECRET !== 'true') return false;
  try {
    const url = new URL(req.url);
    const querySecret = url.searchParams.get('secret');
    if (querySecret && timingSafeStringEqual(querySecret, secret)) {
      return true;
    }
  } catch {
    /* ignore malformed url */
  }

  return false;
}

/**
 * Verifica la clave de la página de estado (`/api/health`) usando la misma función
 * auxiliar en tiempo constante (`timingSafeStringEqual` con `crypto.timingSafeEqual`)
 * que usa la tarea cron.
 *
 * - Si la clave (`HEALTH_KEY` o `HEALTHCHECK_SECRET`) no está configurada en el entorno,
 *   la versión detallada queda desactivada (nunca abierta).
 */
export function verifyHealthKey(
  req: Request,
  expectedKey = process.env.HEALTH_KEY ?? process.env.HEALTHCHECK_SECRET,
): { authorized: boolean; provided: boolean; configured: boolean } {
  const secret = (expectedKey ?? '').trim();
  const configured = secret.length > 0;

  let hasKeyParam = false;
  let keyParamVal = '';
  let mode: string | null = null;
  let detailedParam: string | null = null;
  try {
    const url = new URL(req.url);
    mode = url.searchParams.get('mode');
    detailedParam = url.searchParams.get('detailed');
    hasKeyParam = url.searchParams.has('key');
    keyParamVal = url.searchParams.get('key')?.trim() ?? '';
  } catch {
    /* ignore malformed url */
  }

  const hasAuthHeader = req.headers.has('authorization');
  const hasHealthHeader = req.headers.has('x-health-key') || req.headers.has('x-healthcheck-secret');

  const provided =
    hasKeyParam ||
    hasAuthHeader ||
    hasHealthHeader ||
    mode === 'ready' ||
    mode === 'detailed' ||
    detailedParam === '1' ||
    detailedParam === 'true';

  let supplied = '';
  const authHeader = req.headers.get('authorization')?.trim() ?? '';
  if (authHeader) {
    supplied = authHeader.toLowerCase().startsWith('bearer ')
      ? authHeader.slice(7).trim()
      : authHeader;
  } else if (req.headers.has('x-health-key')) {
    supplied = req.headers.get('x-health-key')?.trim() ?? '';
  } else if (req.headers.has('x-healthcheck-secret')) {
    supplied = req.headers.get('x-healthcheck-secret')?.trim() ?? '';
  } else if (hasKeyParam) {
    supplied = keyParamVal;
  }

  if (!configured) {
    return { authorized: false, provided, configured: false };
  }

  if (!supplied) {
    return { authorized: false, provided, configured: true };
  }

  const authorized = timingSafeStringEqual(supplied, secret);
  return { authorized, provided: true, configured: true };
}

