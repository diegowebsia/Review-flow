import { resolvePublicUrl, resolvePublicUrlFromEnv } from './public-url';

/**
 * Acceso centralizado y tolerante a variables de entorno.
 * Limpia comillas accidentales, espacios o valores placeholder para que
 * copiar y pegar en `.env` nunca rompa la detección de Supabase o Stripe.
 */

function clean(raw?: string): string {
  if (!raw) return '';
  const trimmed = raw.trim().replace(/^["']|["']$/g, '').trim();
  if (
    !trimmed ||
    trimmed.includes('placeholder') ||
    trimmed.includes('tu-proyecto.supabase.co') ||
    trimmed === 'tu_clave' ||
    trimmed === 'sk_test_...' ||
    trimmed === 'pk_test_...' ||
    trimmed.endsWith('...')
  ) {
    return '';
  }
  return trimmed;
}

function list(raw?: string): string[] {
  return clean(raw)
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

/** Compatibilidad: delega en lib/public-url.ts (única fuente de verdad). */
export function resolveAppUrlFromEnv(envObj: NodeJS.ProcessEnv = process.env): string {
  return resolvePublicUrlFromEnv(envObj);
}

export const env = {
  /* ---------- App ---------- */
  appUrl: resolveAppUrlFromEnv(process.env),
  port: Number(process.env.PORT ?? '3000'),

  /* ---------- Super-admin ---------- */
  superadminEmails: list(process.env.SUPERADMIN_EMAILS),

  /* ---------- PostgreSQL directo (pool) ---------- */
  databaseUrl: clean(process.env.DATABASE_URL),

  /* ---------- Supabase ---------- */
  supabaseUrl: clean(process.env.NEXT_PUBLIC_SUPABASE_URL).replace(/\/+$/, ''),
  supabaseAnonKey: clean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
  supabaseServiceRoleKey: clean(process.env.SUPABASE_SERVICE_ROLE_KEY),

  /* ---------- Stripe ---------- */
  stripeSecretKey: clean(process.env.STRIPE_SECRET_KEY),
  stripePublishableKey: clean(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY),
  stripeWebhookSecret: clean(process.env.STRIPE_WEBHOOK_SECRET),
  enableFreeTrial:
    clean(process.env.NEXT_PUBLIC_ENABLE_FREE_TRIAL).toLowerCase() !== 'false' &&
    clean(process.env.NEXT_PUBLIC_ENABLE_FREE_TRIAL) !== '0' &&
    clean(process.env.ENABLE_FREE_TRIAL).toLowerCase() !== 'false' &&
    clean(process.env.ENABLE_FREE_TRIAL) !== '0',
  stripePriceLocalStarter: clean(process.env.STRIPE_PRICE_LOCAL_STARTER),
  stripePriceEcommerceStarter: clean(process.env.STRIPE_PRICE_ECOMMERCE_STARTER),
  stripePriceLocalPro: clean(process.env.STRIPE_PRICE_LOCAL_PRO),
  stripePriceEcommercePro: clean(process.env.STRIPE_PRICE_ECOMMERCE_PRO),
  // Alias directos del catálogo actual (Local Pro / E-Commerce Pro):
  stripePricePro: clean(process.env.STRIPE_PRICE_LOCAL_PRO),
  stripePriceBusiness: clean(process.env.STRIPE_PRICE_ECOMMERCE_PRO),
  stripePriceAddonRequests: clean(process.env.STRIPE_PRICE_ADDON_REQUESTS),
  stripePriceAddonReviews: clean(process.env.STRIPE_PRICE_ADDON_REVIEWS),
  stripePriceAddonAi: clean(process.env.STRIPE_PRICE_ADDON_AI),
  stripePriceAddonSyncs: clean(process.env.STRIPE_PRICE_ADDON_SYNCS),

  /* ---------- SMTP / Resend ---------- */
  resendApiKey: clean(process.env.RESEND_API_KEY),
  smtpHost: clean(process.env.SMTP_HOST),
  smtpPort: Number(process.env.SMTP_PORT ?? '587'),
  smtpUser: clean(process.env.SMTP_USER),
  smtpPass: clean(process.env.SMTP_PASS),
  smtpFrom: clean(process.env.SMTP_FROM) || 'ReviewFlow AI <no-reply@example.com>',

  /* ---------- Google Gemini ---------- */
  geminiApiKey: clean(process.env.GEMINI_API_KEY),
  geminiModel: clean(process.env.GEMINI_MODEL) || 'gemini-2.5-flash',

  /* ---------- Google ---------- */
  googleClientId: clean(process.env.GOOGLE_CLIENT_ID),
  googleClientSecret: clean(process.env.GOOGLE_CLIENT_SECRET),
  googlePlacesApiKey: clean(process.env.GOOGLE_PLACES_API_KEY),

};

export const isSupabaseConfigured = Boolean(env.supabaseUrl && env.supabaseAnonKey);
export const isSupabaseAdminConfigured = Boolean(
  env.supabaseUrl && env.supabaseServiceRoleKey,
);
export const isStripeConfigured = Boolean(env.stripeSecretKey);
export const isStripeWebhookConfigured = Boolean(env.stripeWebhookSecret);
export const isSmtpConfigured = Boolean(
  env.resendApiKey || (env.smtpHost && env.smtpUser && env.smtpPass),
);
export const isGeminiConfigured = Boolean(env.geminiApiKey || process.env.AI_API_KEY);
export const isGoogleConfigured = Boolean(env.googleClientId && env.googleClientSecret);
export const isSuperAdminConfigured = env.superadminEmails.length > 0;

/** Compatibilidad: delega en lib/public-url.ts (única fuente de verdad). */
export function resolveBaseUrl(req?: Request, envObj: NodeJS.ProcessEnv = process.env): string {
  return resolvePublicUrl(req, envObj);
}

export function isSuperAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return env.superadminEmails.includes(email.trim().toLowerCase());
}
