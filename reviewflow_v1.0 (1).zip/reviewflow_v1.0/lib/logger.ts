import { createAdminClient } from '@/lib/supabase/admin';

type SystemLogLevel = 'info' | 'warn' | 'error';

const SENSITIVE_KEY_RE =
  /password|passwd|secret|token|api[_-]?key|authorization|cookie|private[_-]?key|service[_-]?role|credit[_-]?card|cvv|iban|pepper/i;
const EMAIL_KEY_RE = /^(email|user_email|owner_email|customer_email|user|by)$/i;
const PHONE_KEY_RE = /^(phone|customer_phone|whatsapp_to|to|contact)$/i;
const INLINE_SECRET_RE = /\b(sk_(?:live|test)_[A-Za-z0-9]+|whsec_[A-Za-z0-9]+|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}|rf_live_[A-Za-z0-9_-]{12,})\b/g;

export function maskEmailForLog(value: string): string {
  const trimmed = value.trim();
  const atIdx = trimmed.indexOf('@');
  if (atIdx <= 0) return '[REDACTED_EMAIL]';
  const local = trimmed.slice(0, atIdx);
  const domain = trimmed.slice(atIdx + 1);
  return `${local.slice(0, 1)}***@${domain}`;
}

export function maskPhoneForLog(value: string): string {
  const digits = value.replace(/\D/g, '');
  if (digits.length < 5) return '[REDACTED_PHONE]';
  return `***${digits.slice(-2)}`;
}

export function redactSecretsInText(text: string): string {
  return text.replace(INLINE_SECRET_RE, '[REDACTED_SECRET]');
}

/**
 * Purga recursivamente secretos, tokens, claves API y enmascara datos personales (PII)
 * antes de persistir en `system_logs` o enviar a Sentry.
 */
export function sanitizeLogMeta(meta?: Record<string, unknown> | null): Record<string, unknown> {
  if (!meta || typeof meta !== 'object') return {};
  const result: Record<string, unknown> = {};
  for (const [key, rawValue] of Object.entries(meta)) {
    if (SENSITIVE_KEY_RE.test(key)) {
      result[key] = '[REDACTED]';
      continue;
    }
    if (typeof rawValue === 'string') {
      if (EMAIL_KEY_RE.test(key) && rawValue.includes('@')) {
        result[key] = maskEmailForLog(rawValue);
      } else if (PHONE_KEY_RE.test(key)) {
        result[key] = maskPhoneForLog(rawValue);
      } else {
        result[key] = redactSecretsInText(rawValue);
      }
      continue;
    }
    if (Array.isArray(rawValue)) {
      result[key] = rawValue.map((item) =>
        typeof item === 'string'
          ? redactSecretsInText(item)
          : item && typeof item === 'object'
            ? sanitizeLogMeta(item as Record<string, unknown>)
            : item,
      );
      continue;
    }
    if (rawValue && typeof rawValue === 'object') {
      result[key] = sanitizeLogMeta(rawValue as Record<string, unknown>);
      continue;
    }
    result[key] = rawValue;
  }
  return result;
}

/**
 * Logger del sistema: escribe en consola + tabla `system_logs` (si existe).
 * Nunca lanza excepciones (el log no puede romper el flujo principal).
 */
export async function systemLog(
  level: SystemLogLevel,
  source: string,
  message: string,
  meta?: Record<string, unknown>,
): Promise<void> {
  const safeMessage = redactSecretsInText(message);
  const safeMeta = sanitizeLogMeta(meta);
  const enrichedMeta: Record<string, unknown> = {
    release: 'reviewflow-ai@1.0',
    timestamp: new Date().toISOString(),
    ...safeMeta,
  };
  const corr = typeof enrichedMeta.correlationId === 'string' ? `[corr:${enrichedMeta.correlationId}]` : '';
  const line = `[${level.toUpperCase()}][${source}]${corr} ${safeMessage}`;
  if (level === 'error') console.error(line, enrichedMeta);
  else if (level === 'warn') console.warn(line, enrichedMeta);
  else console.log(line, enrichedMeta);

  try {
    const admin = createAdminClient();
    if (!admin) return;
    await admin.from('system_logs').insert({ level, source, message: safeMessage, meta: enrichedMeta });
  } catch {
    /* tabla inexistente o sin conexión: solo consola */
  }
}

