'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { browserOrigin } from '@/lib/public-url';

/** Paso 1: pedir el enlace de recuperación por email. */
export function RequestResetForm() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const { error } = await createClient().auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${browserOrigin()}/auth/callback?next=${encodeURIComponent('/nueva-contrasena')}`,
    });
    setLoading(false);
    // Por privacidad, mostramos el mismo mensaje exista o no la cuenta.
    if (error && error.status === 429) setError('Demasiados intentos. Espera unos minutos.');
    else setSent(true);
  }

  if (sent)
    return (
      <p role="status" className="text-sm text-ink-200">
        Si existe una cuenta con <strong>{email}</strong>, te hemos enviado un enlace para crear una contraseña nueva.
        Revisa también la carpeta de spam.
      </p>
    );

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <label className="label" htmlFor="email">Email de tu cuenta</label>
        <input id="email" type="email" required autoComplete="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      {error && <p role="alert" className="text-sm text-rose-400">{error}</p>}
      <button type="submit" className="btn-primary w-full" disabled={loading}>
        {loading ? 'Enviando…' : 'Enviarme el enlace'}
      </button>
      <p className="text-center text-xs text-ink-400"><Link href="/login" className="hover:underline">Volver a entrar</Link></p>
    </form>
  );
}

/** Paso 2: tras pulsar el enlace del email, el usuario ya tiene sesión y elige contraseña. */
export function SetNewPasswordForm() {
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSession, setHasSession] = useState<boolean | null>(null);

  useEffect(() => {
    createClient().auth.getUser().then(({ data }) => setHasSession(!!data.user));
  }, []);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) return setError('La contraseña debe tener al menos 8 caracteres.');
    if (password !== confirm) return setError('Las contraseñas no coinciden.');
    setLoading(true);
    setError(null);
    const { error } = await createClient().auth.updateUser({ password });
    setLoading(false);
    if (error) return setError('No se pudo cambiar la contraseña. Pide un enlace nuevo.');
    router.replace('/dashboard');
  }

  if (hasSession === false)
    return (
      <p role="alert" className="text-sm text-ink-200">
        El enlace ha caducado o ya se usó. <Link href="/recuperar" className="underline">Pide uno nuevo</Link>.
      </p>
    );

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <label className="label" htmlFor="new-password">Contraseña nueva</label>
        <input id="new-password" type="password" required minLength={8} autoComplete="new-password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} />
      </div>
      <div>
        <label className="label" htmlFor="confirm-password">Repítela</label>
        <input id="confirm-password" type="password" required minLength={8} autoComplete="new-password" className="input" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      </div>
      {error && <p role="alert" className="text-sm text-rose-400">{error}</p>}
      <button type="submit" className="btn-primary w-full" disabled={loading || hasSession === null}>
        {loading ? 'Guardando…' : 'Guardar contraseña'}
      </button>
    </form>
  );
}
