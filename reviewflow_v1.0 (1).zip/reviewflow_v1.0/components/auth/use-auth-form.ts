'use client';
import { browserOrigin } from '@/lib/public-url';

import { useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { useToast } from '@/components/Toast';
import { PLANS, TRIAL_DAYS, resolvePlan } from '@/lib/plans';

export function useAuthForm(mode: 'signin' | 'signup') {
  const params = useSearchParams();
  const toast = useToast();
  const redirect = useMemo(() => {
    const value = params.get('redirect');
    if (!value || !value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return '/dashboard';
    try {
      const url = new URL(value, browserOrigin());
      return url.origin === browserOrigin() ? `${url.pathname}${url.search}${url.hash}` : '/dashboard';
    } catch {
      return '/dashboard';
    }
  }, [params]);
  const urlError = params.get('error');
  const reason = params.get('reason');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [magicLoading, setMagicLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Anti-bot en el formulario público de registro (captcha Turnstile + honeypot)
  const [captchaToken, setCaptchaToken] = useState<string | null>(null);
  const [honeypot, setHoneypot] = useState('');

  async function handleOAuthSignIn(provider: 'google' | 'apple') {
    setError(null);
    setLoading(true);
    try {
      const supabase = createClient();
      const plan = params.get('plan');
      const validPlan = plan ? resolvePlan(plan) : null;
      const nextUrl = validPlan ? `/bienvenido?plan=${validPlan}` : redirect;
      const { error: oauthErr } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: `${browserOrigin()}/auth/callback?next=${encodeURIComponent(nextUrl)}`,
        },
      });
      if (oauthErr) throw oauthErr;
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : `No se pudo iniciar con ${provider}.`);
      setLoading(false);
    }
  }

  async function handleMagicLink() {
    if (!email.trim() || !email.includes('@')) {
      toast({
        kind: 'warning',
        title: 'Introduce tu email primero',
        body: 'Escribe tu correo arriba para enviarte el enlace mágico de acceso sin contraseña.',
      });
      return;
    }
    setError(null);
    setMagicLoading(true);
    try {
      const supabase = createClient();
      const plan = params.get('plan');
      const validPlan = plan ? resolvePlan(plan) : null;
      const nextUrl = validPlan ? `/bienvenido?plan=${validPlan}` : redirect;
      const { error: otpErr } = await supabase.auth.signInWithOtp({
        email: email.trim(),
        options: {
          emailRedirectTo: `${browserOrigin()}/auth/callback?next=${encodeURIComponent(nextUrl)}`,
        },
      });
      if (otpErr) throw otpErr;
      toast({
        kind: 'success',
        title: 'Magic Link enviado a tu correo',
        body: `Revisa la bandeja de ${email.trim()} y haz clic en el enlace para entrar en 1 clic sin contraseña.`,
      });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'No se pudo enviar el Magic Link.');
    } finally {
      setMagicLoading(false);
    }
  }

  const planParam = params.get('plan');
  const preselectedPlan = planParam ? PLANS[resolvePlan(planParam)] : null;

  const infoBanner = useMemo(() => {
    if (urlError === 'forbidden')
      return 'No tienes permiso para acceder a esa sección. Si crees que es un error, escribe a soporte.';
    if (reason === 'configure-supabase')
      return process.env.NODE_ENV === 'development'
        ? 'Falta configurar la base de datos: añade NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY y SUPABASE_SERVICE_ROLE_KEY en tu .env y reinicia (ver GUIA_1_PROBAR_EN_LOCALHOST.md).'
        : 'El servicio no está disponible en este momento. Inténtalo de nuevo en unos minutos.';
    if (reason === 'trial-ended')
      return `Tu prueba de ${TRIAL_DAYS} días terminó y el pago no se completó. Vuelve a activar tu plan para entrar al panel.`;
    if (reason === 'past-due')
      return 'Hay un pago pendiente. Actualiza tu método de pago para recuperar el acceso.';
    return null;
  }, [urlError, reason]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const supabase = createClient();
      const plan = params.get('plan');
      const validPlan = plan ? resolvePlan(plan) : null;

      if (mode === 'signup') {
        const res = await fetch('/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email,
            password,
            captchaToken: captchaToken ?? undefined,
            website: honeypot || undefined,
          }),
        });
        const signupData = (await res.json().catch(() => ({}))) as {
          error?: string;
          fallbackClientSignup?: boolean;
          confirmationRequired?: boolean;
        };
        if (!res.ok) {
          throw new Error(signupData?.error ?? 'No se pudo crear la cuenta.');
        }

        if (signupData?.confirmationRequired) {
          toast({ kind: 'success', title: 'Revisa tu correo', body: `Te hemos enviado un enlace a ${email}. Ábrelo para activar tu cuenta y continuar.` });
          setError(`Cuenta creada. Abre el enlace que te hemos enviado a ${email} para activarla.`);
          return;
        }

        if (signupData?.fallbackClientSignup) {
          const nextUrl = validPlan ? `/bienvenido?plan=${validPlan}` : '/bienvenido';
          const { data, error: signUpErr } = await supabase.auth.signUp({
            email,
            password,
            options: {
              emailRedirectTo: `${browserOrigin()}/auth/callback?next=${encodeURIComponent(nextUrl)}`,
            },
          });
          if (signUpErr) throw signUpErr;
          if (!data?.session) {
            setError(
              'Falta SUPABASE_SERVICE_ROLE_KEY en tu archivo .env para activar la cuenta al instante sin confirmar email (o desactiva "Confirm email" en Supabase -> Authentication -> Providers -> Email). Si ya recibiste el correo, haz clic en el enlace para continuar.',
            );
            return;
          }
        } else {
          const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
          if (signInErr) throw signInErr;
        }

        toast({
          kind: 'success',
          title: '¡Cuenta creada!',
          body: 'Redirigiendo a la activación de tu plan con Stripe…',
        });
        const target = validPlan ? `/bienvenido?plan=${validPlan}` : '/bienvenido';
        window.location.assign(target);
        return;
      } else {
        const { error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
        if (signInErr) throw signInErr;

        toast({ kind: 'success', title: 'Sesión iniciada', body: 'Accediendo a tu cuenta…' });
        const target = validPlan ? `/bienvenido?plan=${validPlan}` : redirect;
        window.location.assign(target);
        return;
      }
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : 'Error de autenticación.';
      const friendly =
        msg.includes('placeholder') || msg.includes('Failed to fetch')
          ? 'No se pudo conectar con Supabase. Si acabas de guardar las claves en el .env, asegúrate de reiniciar el servidor en tu terminal (pulsa Ctrl + C y escribe npm run dev) para que cargue los cambios.'
          : msg === 'Invalid login credentials'
            ? 'Email o contraseña incorrectos. Verifica tus datos o crea una cuenta nueva.'
            : msg.includes('Password should be at least')
              ? 'La contraseña debe tener al menos 8 caracteres.'
              : msg.includes('already registered')
                ? 'Ese email ya tiene cuenta. Pulsa abajo en «Entrar» con tu contraseña.'
                : msg;
      setError(friendly);
      toast({
        kind: 'error',
        title: mode === 'signup' ? 'No se pudo crear la cuenta' : 'No se pudo entrar',
        body: friendly,
      });
    } finally {
      setLoading(false);
    }
  }

  return {
    email,
    setEmail,
    password,
    setPassword,
    showPass,
    setShowPass,
    captchaToken,
    setCaptchaToken,
    honeypot,
    setHoneypot,
    loading,
    magicLoading,
    error,
    planParam,
    preselectedPlan,
    infoBanner,
    handleOAuthSignIn,
    handleMagicLink,
    onSubmit,
  };
}
