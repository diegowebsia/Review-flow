'use client';

/*
 * Cabecera pública (v1.0).
 * Patrón SaaS: marca + 2 destinos principales + "Más" (secundarios agrupados)
 * + acceso + una única acción primaria. En móvil, un menú accesible
 * (botón con aria-expanded, cierre con Escape, foco gestionado).
 */
import { useCallback, useEffect, useId, useRef, useState } from 'react';
import Link from 'next/link';
import { ArrowRight, ChevronDown, Menu, Star, X } from 'lucide-react';
import { SITE } from '@/lib/site';
import { LanguageSelector } from '@/components/LanguageSelector';
import { ThemeToggle } from '@/components/ThemeToggle';

type NavItem = { label: string; href: string };

export function SiteHeader({ freeTrialEnabled = true }: { freeTrialEnabled?: boolean }) {
  
  const [scrolled, setScrolled] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const moreId = useId();
  const mobileId = useId();
  const moreBtnRef = useRef<HTMLButtonElement>(null);
  const moreMenuRef = useRef<HTMLDivElement>(null);
  const mobileBtnRef = useRef<HTMLButtonElement>(null);
  const mobilePanelRef = useRef<HTMLDivElement>(null);

  const primary: NavItem[] = [
    { label: "Cómo funciona", href: '/#como-funciona' },
    { label: 'Precios', href: '/#planes' },
  ];
  const secondary: NavItem[] = [
    { label: "Funciones", href: '/#funciones' },
    { label: "Comparador", href: '/#comparativa' },
    { label: "Preguntas frecuentes", href: '/#faq' },
    { label: 'Sobre nosotros', href: '/sobre-nosotros' },
    { label: 'Contacto', href: '/contacto' },
  ];
  const ctaLabel = freeTrialEnabled ? "Probar 7 días" : "Empezar ahora";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Cierre del desplegable "Más": clic fuera y Escape.
  useEffect(() => {
    if (!moreOpen) return;
    const onDown = (e: MouseEvent) => {
      const target = e.target as Node;
      if (!moreMenuRef.current?.contains(target) && !moreBtnRef.current?.contains(target)) setMoreOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMoreOpen(false);
        moreBtnRef.current?.focus();
      }
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [moreOpen]);

  const closeMobile = useCallback((restoreFocus = true) => {
    setMobileOpen(false);
    if (restoreFocus) mobileBtnRef.current?.focus();
  }, []);

  // Menú móvil: foco al primer enlace, trampa de foco, Escape, bloqueo de scroll.
  useEffect(() => {
    if (!mobileOpen) return;
    const panel = mobilePanelRef.current;
    const focusables = () =>
      Array.from(panel?.querySelectorAll<HTMLElement>('a[href], button:not([disabled])') ?? []);
    focusables()[0]?.focus();
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        closeMobile();
        return;
      }
      if (e.key === 'Tab') {
        const items = [mobileBtnRef.current, ...focusables()].filter(Boolean) as HTMLElement[];
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    const onResize = () => {
      if (window.innerWidth >= 768) closeMobile(false);
    };
    document.addEventListener('keydown', onKey);
    window.addEventListener('resize', onResize);
    return () => {
      document.body.style.overflow = prevOverflow;
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('resize', onResize);
    };
  }, [mobileOpen, closeMobile]);

  const linkCls =
    'rounded-lg px-3.5 py-2 font-medium text-slate-300 transition-colors duration-200 hover:bg-white/[0.08] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400';

  return (
    <header
      className={`nav-blur sticky top-0 z-50 w-full border-b transition-all duration-300 ${
        scrolled || mobileOpen
          ? 'border-white/15 bg-slate-900/90 shadow-[0_14px_36px_-14px_rgba(2,6,23,0.92)] backdrop-blur-lg'
          : 'border-white/10 bg-slate-900/75 backdrop-blur-md'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Link href="/" className="group flex min-w-0 items-center gap-2.5 font-bold tracking-tightish text-white">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] text-white shadow-[0_8px_24px_-10px_rgba(37,99,235,0.95)] transition-transform duration-300 group-hover:scale-105">
            <Star size={17} fill="currentColor" />
          </span>
          <span className="truncate">{SITE.brand}</span>
        </Link>

        <nav className="hidden items-center gap-1 text-sm md:flex" aria-label="Navegación principal">
          {primary.map((i) => (
            <a key={i.href} href={i.href} className={linkCls}>
              {i.label}
            </a>
          ))}
          <div className="relative">
            <button
              ref={moreBtnRef}
              type="button"
              aria-haspopup="true"
              aria-expanded={moreOpen}
              aria-controls={moreId}
              onClick={() => setMoreOpen((v) => !v)}
              className={`${linkCls} inline-flex items-center gap-1 ${moreOpen ? 'bg-white/[0.08] text-white' : ''}`}
            >
              Más
              <ChevronDown size={15} className={`transition-transform ${moreOpen ? 'rotate-180' : ''}`} aria-hidden />
            </button>
            {moreOpen && (
              <div
                ref={moreMenuRef}
                id={moreId}
                className="absolute left-0 top-full mt-2 w-56 rounded-xl border border-white/10 bg-slate-900 p-1.5 shadow-lift"
              >
                <ul className="flex flex-col">
                  {secondary.map((i) => (
                    <li key={i.href}>
                      <a
                        href={i.href}
                        onClick={() => setMoreOpen(false)}
                        className="block rounded-lg px-3 py-2 text-sm text-slate-200 transition-colors hover:bg-white/[0.08] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400"
                      >
                        {i.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <div className="hidden items-center gap-2 md:flex">
            <LanguageSelector showCurrency />
            <ThemeToggle />
            <Link href="/login" className="btn-quiet">
              {"Entrar"}
            </Link>
          </div>
          <Link href="/registro" className="btn-primary btn-sm group">
            {ctaLabel}
            <ArrowRight size={15} className="hidden transition-transform duration-300 group-hover:translate-x-0.5 sm:block" />
          </Link>
          <button
            ref={mobileBtnRef}
            type="button"
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/10 text-slate-200 transition-colors hover:bg-white/[0.08] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 md:hidden"
            aria-expanded={mobileOpen}
            aria-controls={mobileId}
            aria-label={mobileOpen ? 'Cerrar menú' : 'Abrir menú'}
            onClick={() => (mobileOpen ? closeMobile() : setMobileOpen(true))}
          >
            {mobileOpen ? <X size={20} aria-hidden /> : <Menu size={20} aria-hidden />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div
          ref={mobilePanelRef}
          id={mobileId}
          role="dialog"
          aria-modal="true"
          aria-label="Menú"
          className="max-h-[calc(100dvh-4rem)] overflow-y-auto border-t border-white/[0.08] px-4 pb-6 pt-3 md:hidden"
        >
          <nav aria-label="Navegación móvil">
            <ul className="flex flex-col">
              {[...primary, ...secondary].map((i, idx) => (
                <li key={i.href} className={idx === primary.length ? 'mt-2 border-t border-white/[0.08] pt-2' : ''}>
                  <a
                    href={i.href}
                    onClick={() => closeMobile(false)}
                    className={`block rounded-lg px-3 py-3 text-base transition-colors hover:bg-white/[0.08] hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-400 ${
                      idx < primary.length ? 'font-semibold text-white' : 'text-slate-300'
                    }`}
                  >
                    {i.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div className="mt-4 grid gap-2">
            <Link href="/login" onClick={() => closeMobile(false)} className="btn-secondary w-full justify-center">
              {"Entrar"}
            </Link>
            <Link href="/registro" onClick={() => closeMobile(false)} className="btn-primary w-full justify-center">
              {ctaLabel}
            </Link>
          </div>
          <div className="mt-4 flex items-center justify-between gap-2 border-t border-white/[0.08] pt-4">
            <LanguageSelector showCurrency />
            <ThemeToggle />
          </div>
        </div>
      )}
    </header>
  );
}
