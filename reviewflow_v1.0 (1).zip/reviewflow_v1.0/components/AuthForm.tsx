'use client';

import Link from 'next/link';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, Eye, EyeOff, Loader2, MailCheck, ShieldCheck, Sparkles, Star } from 'lucide-react';
import { Spinner } from '@/components/Skeleton';
import { Aurora, EASE } from '@/components/Motion';
import { LanguageSelector } from '@/components/LanguageSelector';
import { ThemeToggle } from '@/components/ThemeToggle';
import { TRIAL_DAYS } from '@/lib/plans';
import { SITE } from '@/lib/site';
import { useAuthForm } from '@/components/auth/use-auth-form';
import { HoneypotField, Turnstile, turnstileEnabled } from '@/components/Turnstile';

/**
 * Autenticación unificada (estética premium dark).
 * mode signin → /login · mode signup → /registro (también /login?mode=signup legacy).
 * Acepta `?plan=pro|business` para preseleccionar el plan tras el alta.
 */
export function AuthForm({
  mode,
  freeTrialEnabled = true,
}: {
  mode: 'signin' | 'signup';
  freeTrialEnabled?: boolean;
}) {
  const {
    email,
    setEmail,
    password,
    setPassword,
    showPass,
    setShowPass,
    captchaToken,
    setCaptchaToken,
    honeypot,
    setHoneypot,
    loading,
    magicLoading,
    error,
    planParam,
    preselectedPlan,
    infoBanner,
    handleOAuthSignIn,
    handleMagicLink,
    onSubmit,
  } = useAuthForm(mode);

  return (
    <div className="relative flex min-h-screen flex-col bg-ink-950 text-ink-100">
      <header className="nav-blur sticky top-0 z-50 w-full border-b border-white/10 bg-slate-900/80 backdrop-blur-lg transition-all duration-300">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link href="/" className="group flex items-center gap-2.5 font-bold tracking-tightish text-white">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] shadow-[0_8px_24px_-10px_rgba(37,99,235,0.95)] transition-transform duration-300 group-hover:scale-105">
              <Star size={17} fill="currentColor" />
            </span>
            <span>{SITE.brand}</span>
          </Link>
          <div className="flex items-center gap-2">
            <LanguageSelector />
            <ThemeToggle />
            <Link href="/" className="btn-quiet btn-sm">
              <ArrowLeft size={14} /> Volver a la web
            </Link>
            <Link href={mode === 'signup' ? '/login' : '/registro'} className="btn-secondary btn-sm">
              {mode === 'signup' ? 'Ya tengo cuenta' : 'Crear cuenta'}
            </Link>
          </div>
        </div>
      </header>

      <div className="relative grid flex-1 lg:grid-cols-2">
        <div className="relative hidden flex-col justify-between overflow-hidden border-r border-white/[0.06] p-10 lg:flex">
          <Aurora />
          <div />

          <div className="relative">
            <p className="kicker">Cómo funciona</p>
            <h2 className="mt-3 max-w-md text-balance text-3xl font-extrabold leading-tight tracking-tighter text-white">
              Tu reputación, atendida en minutos y no en semanas
            </h2>
            <div className="mt-7 max-w-md space-y-3">
              {[
                ['1', 'Conecta Google, Places, Trustpilot o tu tienda'],
                ['2', 'La IA redacta cada respuesta con tu tono'],
                ['3', 'Revisas, publicas y recibes alertas al móvil'],
              ].map(([n, t], i) => (
                <motion.div
                  key={n}
                  initial={{ opacity: 0, x: -18 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.12 + i * 0.09, ease: EASE }}
                  className="card card-hover flex items-center gap-3.5 p-3.5"
                >
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] text-sm font-extrabold text-white">
                    {n}
                  </span>
                  <p className="text-sm font-semibold text-white">{t}</p>
                </motion.div>
              ))}
            </div>

            <div className="mt-7 grid max-w-md grid-cols-3 gap-3 text-center">
              {[
                ['4 planes', 'Starter · Pro'],
                freeTrialEnabled ? [`${TRIAL_DAYS} días`, 'de prueba'] : ['Sin permanencia', 'cancela en 1 clic'],
                ['1 plan', '= 1 negocio'],
              ].map(([n, l]) => (
                <div key={l} className="panel py-3">
                  <p className="text-lg font-extrabold tracking-tightish text-white">{n}</p>
                  <p className="mt-0.5 text-2xs text-ink-400">{l}</p>
                </div>
              ))}
            </div>
          </div>

          <p className="relative text-xs text-ink-500">
            © {new Date().getFullYear()} {SITE.company} ·{' '}
            <Link href="/privacidad" className="underline-offset-2 hover:text-ink-200 hover:underline">
              Privacidad
            </Link>{' '}
            ·{' '}
            <Link href="/terminos" className="underline-offset-2 hover:text-ink-200 hover:underline">
              Términos
            </Link>
          </p>
        </div>

        <div className="relative flex items-center justify-center px-4 py-12">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_0%,rgba(37,99,235,0.14),transparent_70%)] lg:hidden"
            aria-hidden
          />
          <motion.div
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="relative w-full max-w-md"
          >
            <div className="card glow-border p-6 sm:p-8">
              <p className="flex items-center gap-2 font-bold text-white lg:hidden">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[linear-gradient(135deg,#2563eb,#8b5cf6)]">
                  <Star size={14} fill="currentColor" />
                </span>
                {SITE.brand}
              </p>

              <h1 className="mt-1 text-2xl font-extrabold tracking-tighter text-white lg:mt-0">
                {mode === 'signup' ? 'Crea tu cuenta' : 'Bienvenido de nuevo'}
              </h1>
              <p className="mt-1.5 text-sm text-ink-300">
                {mode === 'signup'
                  ? freeTrialEnabled
                    ? `1 Plan = 1 Negocio: tienes ${TRIAL_DAYS} días de prueba gratis con Stripe.`
                    : '1 Plan = 1 Negocio: elige tu plan tras registrarte y empieza hoy mismo.'
                  : 'Accede a tu panel de reseñas.'}
              </p>

              {preselectedPlan && mode === 'signup' && (
                <div className="mt-4 flex items-center gap-3 rounded-xl border border-brand-400/25 bg-brand-500/10 p-3">
                  <Sparkles size={16} className="shrink-0 text-brand-300" />
                  <p className="text-xs text-brand-100">
                    Plan seleccionado: <strong className="font-bold">{preselectedPlan.name}</strong> ·{' '}
                    {freeTrialEnabled
                      ? `${preselectedPlan.price}/mes tras la prueba`
                      : `${preselectedPlan.price}/mes`}{' '}
                    · {preselectedPlan.limits.requestsPerMonth.toLocaleString('es-ES')} peticiones de opiniones/mes
                  </p>
                </div>
              )}

              <AnimatePresence>
                {infoBanner && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 rounded-xl border border-amber-400/25 bg-amber-400/10 p-3 text-sm text-amber-100"
                  >
                    {infoBanner}
                  </motion.div>
                )}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    role="alert"
                    className="mt-4 rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-sm text-rose-100"
                  >
                    {error}
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="mt-5 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => handleOAuthSignIn('google')}
                  className="btn-secondary btn-sm w-full justify-center py-2.5 text-xs font-semibold"
                >
                  Continuar con Google
                </button>
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => handleOAuthSignIn('apple')}
                  className="btn-secondary btn-sm w-full justify-center py-2.5 text-xs font-semibold"
                >
                  Continuar con Apple
                </button>
              </div>

              <div className="my-4 flex items-center gap-3 text-2xs uppercase tracking-wider text-ink-500">
                <span className="h-px flex-1 bg-white/10" />
                <span>o con tu correo corporativo</span>
                <span className="h-px flex-1 bg-white/10" />
              </div>

              <form onSubmit={onSubmit} className="space-y-4">
                <div>
                  <label className="label" htmlFor="email">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="tu@empresa.com"
                    className="input"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="label" htmlFor="password">
                      Contraseña
                    </label>
                    {mode === 'signin' && (
                      <Link href="/recuperar" className="text-xs text-ink-400 underline-offset-2 hover:text-white hover:underline">
                        ¿Has olvidado tu contraseña?
                      </Link>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      id="password"
                      type={showPass ? 'text' : 'password'}
                      required
                      minLength={8}
                      autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mínimo 8 caracteres"
                      className="input pr-11"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass((v) => !v)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-ink-400 transition hover:bg-white/10 hover:text-white"
                      aria-label={showPass ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                    >
                      {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {mode === 'signup' && (
                  <>
                    <HoneypotField value={honeypot} onChange={setHoneypot} />
                    <Turnstile action="signup" onToken={setCaptchaToken} />
                  </>
                )}

                <button
                  type="submit"
                  disabled={loading || (mode === 'signup' && turnstileEnabled && !captchaToken)}
                  className="btn-primary w-full py-3"
                >
                  {loading ? (
                    <Spinner label={mode === 'signup' ? 'Creando cuenta…' : 'Entrando…'} />
                  ) : mode === 'signup' ? (
                    <>
                      {freeTrialEnabled ? `Empezar prueba de ${TRIAL_DAYS} días` : 'Crear mi cuenta'}{' '}
                      <ArrowLeft size={15} className="rotate-180" />
                    </>
                  ) : (
                    'Entrar'
                  )}
                </button>

                <button
                  type="button"
                  disabled={magicLoading}
                  onClick={handleMagicLink}
                  className="btn-quiet btn-sm w-full justify-center text-xs text-brand-200 hover:text-white"
                >
                  <MailCheck size={14} />{' '}
                  {magicLoading ? 'Enviando enlace mágico…' : 'Entrar sin contraseña (enviar Magic Link al email)'}
                </button>
              </form>

              {mode === 'signup' && (
                <p className="mt-3 flex items-start gap-1.5 text-xs text-ink-500">
                  <ShieldCheck size={13} className="mt-0.5 shrink-0" />
                  Al registrarte aceptas los{' '}
                  <Link href="/terminos" className="underline-offset-2 hover:text-ink-200 hover:underline">
                    Términos
                  </Link>{' '}
                  y la{' '}
                  <Link href="/privacidad" className="underline-offset-2 hover:text-ink-200 hover:underline">
                    Privacidad
                  </Link>
                  .
                </p>
              )}

              <div className="divider my-5" />

              <p className="text-center text-sm text-ink-400">
                {mode === 'signup' ? (
                  <>
                    ¿Ya tienes cuenta?{' '}
                    <Link
                      href={planParam ? `/login?plan=${encodeURIComponent(planParam)}` : '/login'}
                      className="font-semibold text-brand-200 transition hover:text-white"
                    >
                      Entrar
                    </Link>
                  </>
                ) : (
                  <>
                    ¿Sin cuenta?{' '}
                    <Link
                      href={planParam ? `/registro?plan=${encodeURIComponent(planParam)}` : '/registro'}
                      className="font-semibold text-brand-200 transition hover:text-white"
                    >
                      Crear una cuenta
                    </Link>
                  </>
                )}
              </p>
            </div>

            <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-ink-500">
              {loading ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />}
              ¿Problemas para entrar? Escríbenos desde{' '}
              <Link href="/contacto" className="underline-offset-2 hover:text-ink-200 hover:underline">
                contacto
              </Link>{' '}
              y te ayudamos.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
