'use client';

import { Bot, Zap, CheckCircle2, Link2, MapPin, Plug, RefreshCw, Store } from 'lucide-react';
import { Accordion } from '@/components/Accordion';
import { Spinner } from '@/components/Skeleton';
import { StoreConnect } from '@/components/dashboard/StoreConnect';
import { AutoPublishToggle } from '@/components/dashboard/AutoPublishToggle';
import { TenantBrandToneSection } from '@/components/dashboard/TenantBrandToneSection';
import type { TenantInfo } from '@/components/dashboard/types';
import type { useTenantCard } from '@/components/dashboard/use-tenant-card';
import { planHasFeature, planOf } from '@/lib/plans';

export function TenantChannelsAccordion({
  tenant: t,
  syncing,
  onSync,
  cardState,
}: {
  tenant: TenantInfo;
  syncing: string | null;
  onSync: (p: 'google' | 'trustpilot' | 'places', id: string, placeId?: string) => void;
  cardState: ReturnType<typeof useTenantCard>;
}) {
  const plan = planOf(t.plan);
  const integ = (p: string) => t.integrations.find((i) => i.provider === p);
  const busy = (key: string) => syncing === key;

  const {
    saving, companyName, setCompanyName, companySlug, setCompanySlug, tone, setTone,
    brandInstructions, setBrandInstructions, brandRulesText, setBrandRulesText,
    forbiddenWordsText, setForbiddenWordsText, brandSignature, setBrandSignature,
    customerLocale, setCustomerLocale, slackWebhookUrl, setSlackWebhookUrl,
    teamsWebhookUrl, setTeamsWebhookUrl, outboundWebhookUrl, setOutboundWebhookUrl,
    placeId, setPlaceId,
    tpKey, setTpKey, tpUnit, setTpUnit,
    saveSettings, applyVerticalTemplate, connectTrustpilot,
  } = cardState;

  return (
    <Accordion
      exclusive={false}
      defaultOpen={[0]}
      items={[
        {
          id: `${t.id}-store`,
          title: 'Tienda online (Shopify · WooCommerce · TPV)',
          icon: <Store size={15} />,
          meta: planHasFeature(t.plan, 'storeIntegration')
            ? integ('shopify') || integ('woocommerce') || integ('store')
              ? 'Conectada · email al entregar activo'
              : 'Plan Completo · email automático al entregar'
            : 'Requiere el plan Completo E-commerce',
          content: <StoreConnect tenant={t} />,
        },
        {
          id: `${t.id}-google`,
          title: 'Google Business Profile',
          icon: <Plug size={15} />,
          meta: integ('google')
            ? `Conectado${integ('google')?.last_sync_at ? ` · sincronizado ${new Date(integ('google')!.last_sync_at!).toLocaleString('es-ES')}` : ''}`
            : 'OAuth en 1 clic · importar y publicar respuestas',
          content: (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                {!integ('google') ? (
                  <a href={`/api/integrations/google/connect?tenantId=${t.id}`} className="btn-light btn-sm">
                    <Link2 size={13} /> Conectar con Google
                  </a>
                ) : (
                  <>
                    <span className="badge-ok">
                      <CheckCircle2 size={11} /> conectado
                    </span>
                    <button
                      onClick={() => onSync('google', t.id)}
                      disabled={busy(`google-${t.id}`)}
                      className="btn-secondary btn-sm"
                    >
                      {busy(`google-${t.id}`) ? (
                        <Spinner label="Sincronizando…" size={13} />
                      ) : (
                        <>
                          <RefreshCw size={13} /> Sincronizar reseñas
                        </>
                      )}
                    </button>
                  </>
                )}
              </div>
              <p className="text-xs leading-relaxed text-ink-400">
                La sincronización importa tus reseñas reales y permite publicar las respuestas
                directamente en Google ({plan.limits.syncsPerMonth}/mes).
              </p>
            </div>
          ),
        },
        {
          id: `${t.id}-places`,
          title: 'Google Places API (por Place ID)',
          icon: <MapPin size={15} />,
          meta: placeId ? `Place ID configurado · ${placeId.slice(0, 18)}…` : 'Sin Place ID guardado',
          content: (
            <div className="space-y-3">
              <div>
                <label className="label" htmlFor={`${t.id}-place`}>
                  Place ID de tu negocio
                </label>
                <input
                  id={`${t.id}-place`}
                  className="input"
                  placeholder="ChIJN1t_tDeuEmsRUsoyG83frY4"
                  value={placeId}
                  onChange={(e) => setPlaceId(e.target.value)}
                />
                <p className="hint">
                  Se guarda con «Guardar ajustes» o al sincronizar. Requiere <code>GOOGLE_PLACES_API_KEY</code> en el servidor.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => onSync('places', t.id, placeId.trim())}
                  disabled={busy(`places-${t.id}`) || !placeId.trim()}
                  className="btn-secondary btn-sm"
                >
                  {busy(`places-${t.id}`) ? (
                    <Spinner label="Sincronizando…" size={13} />
                  ) : (
                    <>
                      <RefreshCw size={13} /> Sincronizar con Places
                    </>
                  )}
                </button>
                <button onClick={saveSettings} disabled={saving} className="btn-primary btn-sm">
                  {saving ? <Spinner label="Guardando…" size={13} /> : 'Guardar ajustes'}
                </button>
                {placeId && (
                  <a
                    href={`https://search.google.com/local/writereview?placeid=${encodeURIComponent(placeId)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="btn-quiet btn-sm"
                  >
                    Enlace «déjanos una reseña» ↗
                  </a>
                )}
              </div>
            </div>
          ),
        },
        {
          id: `${t.id}-trustpilot`,
          title: 'Trustpilot Business',
          icon: <Store size={15} />,
          meta: integ('trustpilot') ? 'Conectado con tu API key' : 'Plan Business de Trustpilot',
          content: integ('trustpilot') ? (
            <div className="flex flex-wrap items-center gap-2">
              <span className="badge-ok">
                <CheckCircle2 size={11} /> conectado
              </span>
              <button
                onClick={() => onSync('trustpilot', t.id)}
                disabled={busy(`trustpilot-${t.id}`)}
                className="btn-secondary btn-sm"
              >
                {busy(`trustpilot-${t.id}`) ? (
                  <Spinner label="Sincronizando…" size={13} />
                ) : (
                  <>
                    <RefreshCw size={13} /> Sincronizar reseñas
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
              <div>
                <label className="label" htmlFor={`${t.id}-tp-key`}>
                  API key
                </label>
                <input
                  id={`${t.id}-tp-key`}
                  className="input"
                  placeholder="API key de Trustpilot Business"
                  value={tpKey}
                  onChange={(e) => setTpKey(e.target.value)}
                />
              </div>
              <div>
                <label className="label" htmlFor={`${t.id}-tp-unit`}>
                  Business Unit ID
                </label>
                <input
                  id={`${t.id}-tp-unit`}
                  className="input"
                  placeholder="507f1f77bcf86cd799439011"
                  value={tpUnit}
                  onChange={(e) => setTpUnit(e.target.value)}
                />
              </div>
              <div className="flex items-end">
                <button onClick={connectTrustpilot} disabled={saving} className="btn-primary btn-sm h-[42px]">
                  {saving ? <Spinner label="…" size={13} /> : 'Conectar'}
                </button>
              </div>
            </div>
          ),
        },
        {
          id: `${t.id}-tone`,
          title: 'Nombre comercial, enlace público y tono de marca (IA)',
          icon: <Bot size={15} />,
          meta: `${companyName} · /valorar/${companySlug || t.slug} · Tono: ${tone}`,
          content: (
            <TenantBrandToneSection
              tenantId={t.id} tenantSlug={t.slug} companyName={companyName} setCompanyName={setCompanyName}
              companySlug={companySlug} setCompanySlug={setCompanySlug} tone={tone} setTone={setTone}
              brandInstructions={brandInstructions} setBrandInstructions={setBrandInstructions}
              brandRulesText={brandRulesText} setBrandRulesText={setBrandRulesText}
              forbiddenWordsText={forbiddenWordsText} setForbiddenWordsText={setForbiddenWordsText}
              brandSignature={brandSignature} setBrandSignature={setBrandSignature}
              customerLocale={customerLocale} setCustomerLocale={setCustomerLocale}
              slackWebhookUrl={slackWebhookUrl} setSlackWebhookUrl={setSlackWebhookUrl}
              teamsWebhookUrl={teamsWebhookUrl} setTeamsWebhookUrl={setTeamsWebhookUrl}
              outboundWebhookUrl={outboundWebhookUrl} setOutboundWebhookUrl={setOutboundWebhookUrl}
              saving={saving} onApplyTemplate={applyVerticalTemplate} onSaveSettings={saveSettings}
            />
          ),
        },
        {
          id: `${t.id}-autopublish`,
          title: 'Piloto automático: la IA responde y publica sola',
          icon: <Zap size={15} />,
          meta: t.settings.auto_publish ? 'Activado' : 'Desactivado (revisión humana)',
          content: <AutoPublishToggle tenantId={t.id} settings={t.settings} />,
        },
      ]}
    />
  );
}
