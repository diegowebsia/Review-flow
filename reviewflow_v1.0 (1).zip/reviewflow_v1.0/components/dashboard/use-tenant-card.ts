'use client';

import { useState } from 'react';
import { useToast } from '@/components/Toast';
import { describeApiError, type TenantInfo } from '@/components/dashboard/types';
import type { VerticalTemplate } from '@/lib/sample-reviews';

interface GdprDeletionCertificate {
  certificateId: string;
  cryptographicSignature: string;
  deletedAt?: string;
}


export function useTenantCard(t: TenantInfo) {
  const toast = useToast();
  const [open, setOpen] = useState(true);
  const [saving, setSaving] = useState(false);
  const [companyName, setCompanyName] = useState(t.name);
  const [companySlug, setCompanySlug] = useState(t.slug ?? '');
  const [tone, setTone] = useState(t.settings.tone ?? 'profesional');
  const [brandInstructions, setBrandInstructions] = useState(t.settings.brand_instructions ?? '');
  const [brandRulesText, setBrandRulesText] = useState((t.settings.brand_rules ?? []).join('\n'));
  const [forbiddenWordsText, setForbiddenWordsText] = useState(
    (t.settings.forbidden_words ?? []).join(', '),
  );
  const [brandSignature, setBrandSignature] = useState<string>(t.settings.brand_signature ?? '');
  const [customerLocale, setCustomerLocale] = useState<string>(t.settings.customer_locale ?? 'es');
  const [slackWebhookUrl, setSlackWebhookUrl] = useState<string>(t.settings.slack_webhook_url ?? '');
  const [teamsWebhookUrl, setTeamsWebhookUrl] = useState<string>(t.settings.teams_webhook_url ?? '');
  const [outboundWebhookUrl, setOutboundWebhookUrl] = useState<string>(
    t.settings.outbound_webhook_url ?? '',
  );
  const [activeApiKey, setActiveApiKey] = useState<string>(t.api_key ?? '');
  const [rotatingKey, setRotatingKey] = useState(false);
  const [gdprConfirm, setGdprConfirm] = useState('');
  const [gdprPassword, setGdprPassword] = useState('');
  const [deletingTenant, setDeletingTenant] = useState(false);
  const [gdprCert, setGdprCert] = useState<GdprDeletionCertificate | null>(null);
  const [placeId, setPlaceId] = useState(t.settings.place_id ?? '');
  const [tpKey, setTpKey] = useState('');
  const [tpUnit, setTpUnit] = useState('');
  const [copied, setCopied] = useState(false);

  async function saveSettings() {
    setSaving(true);
    try {
      const res = await fetch('/api/tenants/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: t.id,
          name: companyName.trim() || undefined,
          slug: companySlug.trim() || undefined,
          tone,
          brand_instructions: brandInstructions.trim() || undefined,
          brand_rules: brandRulesText.split('\n').map((r) => r.trim()).filter(Boolean).slice(0, 5),
          forbidden_words: forbiddenWordsText.split(',').map((w: string) => w.trim()).filter(Boolean).slice(0, 20),
          brand_signature: brandSignature.trim() || undefined,
          customer_locale: customerLocale || 'es',
          slack_webhook_url: slackWebhookUrl.trim() || undefined,
          teams_webhook_url: teamsWebhookUrl.trim() || undefined,
          outbound_webhook_url: outboundWebhookUrl.trim() || undefined,
          place_id: placeId,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const described = describeApiError(res.status, data);
        toast({ kind: described.kind, title: described.title, body: described.body });
        return;
      }
      toast({ kind: 'success', title: 'Ajustes guardados', body: 'Datos de empresa, tono y conexiones actualizados.' });
      if (companyName.trim() !== t.name || (companySlug.trim() && companySlug.trim() !== t.slug)) {
        setTimeout(() => window.location.reload(), 700);
      }
    } catch (e: unknown) {
      toast({ kind: 'error', title: 'No se pudo guardar', body: e instanceof Error ? e.message : undefined });
    } finally {
      setSaving(false);
    }
  }

  function applyVerticalTemplate(tpl: VerticalTemplate) {
    setTone(tpl.tone);
    setBrandInstructions(tpl.brandInstructions);
    setBrandRulesText(tpl.brandRules.join('\n'));
    setForbiddenWordsText(tpl.forbiddenWords.join(', '));
    setBrandSignature(tpl.brandSignature);
    toast({ kind: 'info', title: `Plantilla «${tpl.name}» cargada`, body: 'Pulsa «Guardar identidad y tono» para aplicarla a tus próximas respuestas.' });
  }

  async function rotateKey() {
    setRotatingKey(true);
    try {
      const res = await fetch('/api/tenants/api-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenantId: t.id, overlapHours: 24 }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo rotar la clave', body: data.error });
        return;
      }
      if (data.apiKey) setActiveApiKey(data.apiKey);
      toast({ kind: 'success', title: 'API key rotada (solape 24 h activo)', body: 'La clave anterior seguirá aceptando webhooks durante 24 horas para evitar caídas.' });
    } finally {
      setRotatingKey(false);
    }
  }

  async function revokeKey() {
    setRotatingKey(true);
    try {
      const res = await fetch(`/api/tenants/api-key?tenantId=${encodeURIComponent(t.id)}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo revocar', body: data.error });
        return;
      }
      setActiveApiKey('');
      toast({ kind: 'warning', title: 'API key revocada de inmediato', body: 'Cualquier ingesta externa con la clave anterior ha quedado bloqueada.' });
    } finally {
      setRotatingKey(false);
    }
  }

  async function handleGdprDelete() {
    if (gdprConfirm.trim() !== 'ELIMINAR') {
      toast({
        kind: 'warning',
        title: 'Confirmación requerida',
        body: 'Escribe exactamente ELIMINAR en mayúsculas para confirmar la purga RGPD.',
      });
      return;
    }
    if (!gdprPassword) {
      toast({ kind: 'warning', title: 'Contraseña requerida', body: 'Escribe tu contraseña actual para confirmar el borrado.' });
      return;
    }
    setDeletingTenant(true);
    try {
      const res = await fetch('/api/tenants/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: t.id,
          confirmationText: 'ELIMINAR',
          password: gdprPassword,
          reason: 'Autoservicio RGPD Art. 17 desde panel',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo completar el borrado', body: data.error });
        return;
      }
      setGdprPassword('');
      setGdprCert(data.certificate as GdprDeletionCertificate);
      toast({
        kind: 'success',
        title: 'Cuenta purgada (Certificado RGPD emitido)',
        body: `ID de certificado: ${data.certificate?.certificateId}`,
      });
    } finally {
      setDeletingTenant(false);
    }
  }

  async function connectTrustpilot() {
    if (!tpKey || !tpUnit) {
      toast({ kind: 'warning', title: 'Faltan datos', body: 'Pega tu API key y tu Business Unit ID.' });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/integrations/trustpilot/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenantId: t.id, apiKey: tpKey, businessUnitId: tpUnit }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const described = describeApiError(res.status, data);
        toast({ kind: described.kind, title: described.title, body: described.body });
        return;
      }
      toast({ kind: 'success', title: 'Trustpilot conectado', body: data.message });
      setTpKey('');
      setTpUnit('');
      setTimeout(() => window.location.reload(), 900);
    } catch (e: unknown) {
      toast({ kind: 'error', title: 'No se pudo conectar', body: e instanceof Error ? e.message : undefined });
    } finally {
      setSaving(false);
    }
  }

  async function copyApiKey() {
    if (!t.api_key) return;
    try {
      await navigator.clipboard.writeText(t.api_key);
      setCopied(true);
      toast({ kind: 'success', title: 'API key copiada', body: 'Úsala en los webhooks de tu tienda.' });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ kind: 'error', title: 'Tu navegador bloqueó el portapapeles' });
    }
  }

  return {
    open, setOpen, saving, companyName, setCompanyName, companySlug, setCompanySlug,
    tone, setTone, brandInstructions, setBrandInstructions, brandRulesText, setBrandRulesText,
    forbiddenWordsText, setForbiddenWordsText, brandSignature, setBrandSignature,
    customerLocale, setCustomerLocale, slackWebhookUrl, setSlackWebhookUrl,
    teamsWebhookUrl, setTeamsWebhookUrl, outboundWebhookUrl, setOutboundWebhookUrl,
    activeApiKey, rotatingKey, gdprConfirm, setGdprConfirm, gdprPassword, setGdprPassword, deletingTenant, gdprCert,
    placeId, setPlaceId,
    tpKey, setTpKey, tpUnit, setTpUnit, copied,
    saveSettings, applyVerticalTemplate, rotateKey, revokeKey, handleGdprDelete,
    connectTrustpilot, copyApiKey,
  };
}
