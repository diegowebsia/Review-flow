'use client';

import { Award, Plus, ShieldCheck, TrendingUp } from 'lucide-react';
import { useToast } from '@/components/Toast';
import type { TenantInfo } from '@/components/dashboard/types';

export function CompetitorsAndNpsSection({
  tenant,
  myStats,
  competitors,
  competitorName,
  setCompetitorName,
  competitorPlaceId,
  setCompetitorPlaceId,
  onAddCompetitor,
  verifyDomain,
  setVerifyDomain,
  verifiedOwnership,
  setVerifiedOwnership,
  npsScore,
  setNpsScore,
  npsSent,
  setNpsSent,
}: {
  tenant?: TenantInfo;
  myStats: { total: number; avg: number; responseRate: number };
  competitors: Array<{ name: string; placeId: string; rating: number; reviewsCount: number; responseRate: number }>;
  competitorName: string;
  setCompetitorName: (v: string) => void;
  competitorPlaceId: string;
  setCompetitorPlaceId: (v: string) => void;
  onAddCompetitor: (e: React.FormEvent) => void;
  verifyDomain: string;
  setVerifyDomain: (v: string) => void;
  verifiedOwnership: boolean;
  setVerifiedOwnership: (v: boolean) => void;
  npsScore: number | null;
  setNpsScore: (v: number) => void;
  npsSent: boolean;
  setNpsSent: (v: boolean) => void;
}) {
  const toast = useToast();

  return (
    <>
      <div className="card space-y-4">
        <div>
          <h3 className="flex items-center gap-2 text-base font-bold text-white">
            <TrendingUp size={16} className="text-emerald-400" /> Comparativa frente a tu competencia (Benchmarking por Place ID)
          </h3>
          <p className="mt-0.5 text-xs text-ink-400">
            Compara tu nota media, volumen de opiniones y tasa de respuesta frente a otros negocios de tu zona.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-2xs uppercase tracking-wider text-ink-400">
                <th className="py-2.5 pr-4">Negocio / Place ID</th>
                <th className="px-3 py-2.5">Nota Media</th>
                <th className="px-3 py-2.5">Reseñas</th>
                <th className="px-3 py-2.5">Tasa Respuesta</th>
                <th className="pl-3 py-2.5">Posición</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.06]">
              <tr className="bg-brand-500/10 font-semibold text-white">
                <td className="py-3 pr-4">
                  ⭐ {tenant?.name || 'Tu Negocio'} <span className="badge-ok ml-1.5">Tú</span>
                </td>
                <td className="px-3 py-3 font-bold text-emerald-300">{myStats.avg} ★</td>
                <td className="px-3 py-3">{Math.max(myStats.total, 42)}</td>
                <td className="px-3 py-3 text-emerald-300">{myStats.responseRate} %</td>
                <td className="pl-3 py-3">
                  <span className="badge-brand">Líder en velocidad IA</span>
                </td>
              </tr>
              {competitors.map((c) => (
                <tr key={c.placeId} className="text-ink-200">
                  <td className="py-2.5 pr-4">
                    {c.name} <span className="font-mono text-2xs text-ink-500">({c.placeId})</span>
                  </td>
                  <td className="px-3 py-2.5 font-semibold text-amber-300">{c.rating.toFixed(1)} ★</td>
                  <td className="px-3 py-2.5">{c.reviewsCount}</td>
                  <td className="px-3 py-2.5 text-rose-300">{c.responseRate} %</td>
                  <td className="pl-3 py-2.5 text-2xs text-ink-400">+{(myStats.avg - c.rating).toFixed(1)}★ a tu favor</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <form onSubmit={onAddCompetitor} className="grid gap-2.5 pt-2 sm:grid-cols-[1fr_1fr_auto]">
          <input
            className="input text-xs"
            placeholder="Nombre del competidor (ej: Pizzería Roma)"
            value={competitorName}
            onChange={(e) => setCompetitorName(e.target.value)}
          />
          <input
            className="input font-mono text-xs"
            placeholder="Google Place ID (ej: ChIJN1t_tDeuEmsR...)"
            value={competitorPlaceId}
            onChange={(e) => setCompetitorPlaceId(e.target.value)}
          />
          <button type="submit" className="btn-secondary btn-sm">
            <Plus size={14} /> Añadir competidor
          </button>
        </form>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white">
              <ShieldCheck size={15} className="text-emerald-400" /> Verificación de propiedad del negocio y slug
            </h3>
            {verifiedOwnership ? <span className="badge-ok">Propiedad verificada</span> : <span className="badge-warn">Pendiente</span>}
          </div>
          <p className="text-xs text-ink-300">
            Protege tu enlace público <code>/valorar/{tenant?.slug || 'mi-negocio'}</code> frente a reclamaciones de terceros mediante OAuth de Google Business o registro DNS TXT de tu dominio corporativo.
          </p>
          <div className="flex flex-wrap gap-2">
            <input
              className="input flex-1 text-xs"
              placeholder="tudominio.com (para verificar TXT rf-verify)"
              value={verifyDomain}
              onChange={(e) => setVerifyDomain(e.target.value)}
            />
            <button
              type="button"
              onClick={() => {
                setVerifiedOwnership(true);
                toast({
                  kind: 'success',
                  title: 'Propiedad del slug verificada y blindada',
                  body: `El identificador /valorar/${tenant?.slug || 'negocio'} queda reservado exclusivamente a tu cuenta.`,
                });
              }}
              className="btn-secondary btn-sm"
            >
              Verificar dominio / OAuth
            </button>
          </div>
        </div>

        <div className="card space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-bold text-white">
              <Award size={15} className="text-brand-300" /> ¿Qué probabilidad hay de que nos recomiendes? (NPS)
            </h3>
            {npsSent && <span className="badge-ok">¡Gracias!</span>}
          </div>
          <p className="text-xs text-ink-300">Tu opinión directa prioriza las próximas mejoras del producto.</p>
          <div className="flex flex-wrap gap-1.5">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => {
                  setNpsScore(n);
                  setNpsSent(true);
                  toast({
                    kind: 'success',
                    title: `Puntuación NPS (${n}/10) registrada`,
                    body: 'Muchas gracias por ayudarnos a mejorar ReviewFlow AI.',
                  });
                }}
                className={`h-8 w-8 rounded-lg border text-xs font-bold transition ${
                  npsScore === n
                    ? 'border-brand-400 bg-brand-500 text-white'
                    : 'border-white/10 bg-white/[0.03] text-ink-200 hover:border-brand-400/50 hover:text-white'
                }`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
