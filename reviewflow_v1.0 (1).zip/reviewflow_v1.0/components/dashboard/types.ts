import type { UsageMetric } from '@/lib/plans';

/** Tipos compartidos por el panel privado (/dashboard). */

export type ReviewSource =
  | 'google'
  | 'trustpilot'
  | 'facebook'
  | 'manual'
  | 'places'
  | 'amazon'
  | 'booking'
  | 'glassdoor'
  | 'yelp'
  | 'idealista';

export type ReviewItem = {
  id: string;
  tenant: string;
  tenant_id?: string;
  author: string;
  rating: number;
  text: string;
  source: ReviewSource;
  created_at: string;
  replied: boolean;
  verified: boolean;
  flagged_private?: boolean;
  private_note?: string | null;
  reply?: string | null;
};

export type SupportSessionInfo = {
  actor_email?: string;
  ticket?: string;
  reason?: string;
  expires_at?: string;
  read_only_billing?: boolean;
};

export type ApiKeySecuritySettings = {
  prefix?: string;
  current_hash?: string | null;
  previous_hash?: string | null;
  previous_expires_at?: string | null;
  rotated_at?: string | null;
  last_used_at?: string | null;
  revoked_at?: string | null;
};

export type TenantSettings = {
  tone?: string;
  brand_instructions?: string;
  brand_rules?: string[];
  forbidden_words?: string[];
  brand_signature?: string;
  customer_locale?: string;
  locale?: string;
  place_id?: string;
  place_rating?: number | null;
  trustpilot_url?: string;
  funnel_enabled?: boolean;
  auto_publish?: boolean;
  auto_publish_min_rating?: number;
  slack_webhook_url?: string;
  teams_webhook_url?: string;
  outbound_webhook_url?: string;
  active_support_session?: SupportSessionInfo;
  onboarding_steps?: Record<string, boolean>;
  grace_period_ends_at?: string | null;
  scheduled_downgrade_plan?: string | null;
  scheduled_downgrade_at?: string | null;
  api_key_security?: ApiKeySecuritySettings;
  tax_id?: string;
  legal_name?: string;
  extra_locations?: number;
  abandoned_trial_emails_sent?: Record<string, string>;
};

export type TenantInfo = {
  id: string;
  name: string;
  slug: string;
  plan: string;
  subscription_status: string;
  suspended: boolean;
  trial_ends_at: string | null;
  grace_period_ends_at?: string | null;
  access: boolean;
  settings: TenantSettings;
  api_key: string | null;
  integrations: Array<{ provider: string; status: string; last_sync_at: string | null }>;
  /** Rol de la persona conectada en esta empresa: owner | admin | agent | viewer. */
  my_role?: 'owner' | 'admin' | 'agent' | 'viewer';
};

export type MetricQuotaView = {
  used: number;
  quota: number;
  remaining: number;
  allowed: boolean;
  pct: number;
};

/** Tope de una tabla protegida (opiniones, auditoría, conexiones). */
export type TableCapView = MetricQuotaView & {
  label: string;
  cap: number;
};

export type AiUsageView = {
  tokensUsed: number;
  tokensLimit: number;
  tokensRemaining: number;
  pct: number;
  costUsd: number;
  requests: number;
  model: string;
};

export type StorageView = {
  reviews: TableCapView;
  audit: TableCapView;
  integrations: TableCapView;
  /** Contabilidad de tokens (`ai_interactions`). */
  ai: TableCapView;
  limitMb: number;
  usedMb: number;
  remainingMb: number;
  pct: number;
  logRetentionDays: number;
  purged?: { reviews: number; audit: number; ai: number; logs: number };
};

export type UsageResponse = {
  ok: boolean;
  plan: string;
  planLabel: string;
  tier: string;
  cycle: string;
  /** Cuotas mensuales por métrica (peticiones, opiniones, IA, sincronizaciones). */
  metrics: Record<UsageMetric, MetricQuotaView>;
  /** Consumo real de tokens de IA del ciclo (medido por llamada) + coste estimado. */
  aiUsage: AiUsageView;
  limits: {
    requestsPerMonth: number;
    reviewsPerMonth: number;
    aiRepliesPerMonth: number;
    aiTokensPerMonth: number;
    syncsPerMonth: number;
    locations: number;
  };
  used: number;
  limit: number;
  remaining: number;
  allowed: boolean;
  blockedBy: UsageMetric | 'storage' | null;
  /** Topes de base de datos por empresa. */
  storage: StorageView;
  storageLimitMb: number;
  storageUsedMb: number;
  /** Ampliaciones del ciclo en curso. */
  extras: { requests: number; reviews: number; ai: number; syncs: number; stored: number };
  packs: number;
  catalog: Array<{
    id: string;
    name: string;
    description: string;
    priceCents: number;
    price: string;
    metric: UsageMetric;
    amount: number;
    badge: string | null;
  }>;
  counters: {
    reviews_ingested: number;
    ai_replies: number;
    whatsapp_sent: number;
    google_calls: number;
    ai_tokens_in: number;
    ai_tokens_out: number;
  };
  features: Record<string, boolean | string>;
  renewalAt: string;
  renewalLabel: string;
  hasAccess: boolean;
};

type ApiError = {
  error?: string;
  code?: string;
  quota?: {
    used?: number;
    limit?: number;
    remaining?: number;
    renewalLabel?: string;
    planLabel?: string;
    storage?: { reviews?: { used: number; cap: number } };
  };
  upgrade?: { addonUrl?: string; billingUrl?: string; suggestedPack?: string | null };
};

/** Traduce una respuesta de API fallida a un mensaje accionable para el toast. */
export function describeApiError(status: number, data: ApiError | null): {
  kind: 'error' | 'warning' | 'info';
  title: string;
  body?: string;
  action?: { label: string; onClick: () => void };
} {
  const message = data?.error ?? `Error ${status}`;
  if (status === 429) {
    return {
      kind: 'warning',
      title: 'Cuota del ciclo agotada',
      body: message,
      action: {
        label: 'Ampliar cuota',
        onClick: () => {
          window.location.href = '/dashboard?tab=facturacion';
        },
      },
    };
  }
  if (status === 507) {
    return {
      kind: 'warning',
      title: 'Límite de almacenamiento del plan',
      body: message,
      action: {
        label: 'Ver límites',
        onClick: () => {
          window.location.href = '/dashboard?tab=facturacion';
        },
      },
    };
  }
  if (status === 402) {
    return {
      kind: 'warning',
      title: 'Suscripción sin acceso',
      body: message,
      action: { label: 'Activar plan', onClick: () => (window.location.href = '/bienvenido') },
    };
  }
  if (status === 403) {
    return { kind: 'warning', title: 'No incluido en tu plan', body: message };
  }
  if (status === 401) {
    return {
      kind: 'error',
      title: 'Sesión caducada',
      body: message,
      action: { label: 'Entrar de nuevo', onClick: () => (window.location.href = '/login') },
    };
  }
  return { kind: 'error', title: 'Algo ha fallado', body: message };
}
