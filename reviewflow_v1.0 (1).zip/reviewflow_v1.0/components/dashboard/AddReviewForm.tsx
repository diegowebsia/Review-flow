'use client';

import { motion } from 'framer-motion';
import { EASE } from '@/components/Motion';
import { Spinner } from '@/components/Skeleton';
import type { NewReviewSource } from './use-dashboard-state';

export function AddReviewForm({
  tenantName,
  newAuthor,
  setNewAuthor,
  newRating,
  setNewRating,
  newSource,
  setNewSource,
  newText,
  setNewText,
  creatingReview,
  onCreateReview,
  onCancel,
}: {
  tenantName: string;
  newAuthor: string;
  setNewAuthor: (v: string) => void;
  newRating: number;
  setNewRating: (v: number) => void;
  newSource: NewReviewSource;
  setNewSource: (v: NewReviewSource) => void;
  newText: string;
  setNewText: (v: string) => void;
  creatingReview: boolean;
  onCreateReview: (e: React.FormEvent) => Promise<void>;
  onCancel: () => void;
}) {
  return (
    <motion.form
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.25, ease: EASE }}
      onSubmit={onCreateReview}
      className="card space-y-3 overflow-hidden border-brand-400/25"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white">
          Registrar reseña real en {tenantName}
        </h3>
        <span className="text-2xs text-ink-300">
          Se guarda en Supabase y activa el flujo de IA / alertas
        </span>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor="new-review-author">
            Autor / Cliente
          </label>
          <input
            id="new-review-author"
            className="input"
            placeholder="Ej: María López"
            value={newAuthor}
            onChange={(e) => setNewAuthor(e.target.value)}
            required
          />
        </div>
        <div>
          <label className="label" htmlFor="new-review-rating">
            Puntuación
          </label>
          <select
            id="new-review-rating"
            className="select"
            value={newRating}
            onChange={(e) => setNewRating(Number(e.target.value))}
          >
            <option value={5}>★★★★★ (5 estrellas)</option>
            <option value={4}>★★★★☆ (4 estrellas)</option>
            <option value={3}>★★★☆☆ (3 estrellas — alerta privada)</option>
            <option value={2}>★★☆☆☆ (2 estrellas — alerta privada)</option>
            <option value={1}>★☆☆☆☆ (1 estrella — alerta privada)</option>
          </select>
        </div>
        <div>
          <label className="label" htmlFor="new-review-source">
            Plataforma de origen
          </label>
          <select
            id="new-review-source"
            className="select"
            value={newSource}
            onChange={(e) => setNewSource(e.target.value as NewReviewSource)}
          >
            <option value="google">Google Business / Maps</option>
            <option value="trustpilot">Trustpilot</option>
            <option value="facebook">Facebook</option>
            <option value="manual">Directa / Local</option>
          </select>
        </div>
      </div>
      <div>
        <label className="label" htmlFor="new-review-text">
          Texto de la reseña
        </label>
        <textarea
          id="new-review-text"
          className="textarea min-h-[80px]"
          placeholder="Escribe aquí el comentario del cliente para procesarlo y responderlo con IA…"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          required
        />
      </div>
      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={onCancel}
          className="btn-quiet btn-sm"
        >
          Cancelar
        </button>
        <button type="submit" disabled={creatingReview} className="btn-primary btn-sm">
          {creatingReview ? <Spinner label="Guardando…" size={13} /> : 'Guardar reseña'}
        </button>
      </div>
    </motion.form>
  );
}
