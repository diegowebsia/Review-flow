'use client';

import { useCallback, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { LogOut, Mail, Trash2, UserPlus, Users } from 'lucide-react';
import { useToast } from '@/components/Toast';
import type { TenantInfo } from '@/components/dashboard/types';

type Role = 'owner' | 'admin' | 'agent' | 'viewer';
type Member = {
  userId: string;
  email: string;
  role: Role;
  joinedAt: string;
  pending: boolean;
  isMe: boolean;
};

const ROLE_LABEL: Record<Role, string> = {
  owner: 'Dueño',
  admin: 'Administrar',
  agent: 'Responder reseñas',
  viewer: 'Solo mirar',
};

const ROLE_HINT: Record<Exclude<Role, 'owner'>, string> = {
  admin: 'Todo el panel, conexiones y el equipo.',
  agent: 'Responde reseñas y usa la IA.',
  viewer: 'Ve el panel, sin cambiar nada.',
};

const ASSIGNABLE: Array<Exclude<Role, 'owner'>> = ['admin', 'agent', 'viewer'];

export function TeamPanel({ tenant }: { tenant?: TenantInfo }) {
  const toast = useToast();
  const [members, setMembers] = useState<Member[]>([]);
  const [myRole, setMyRole] = useState<Role>('viewer');
  const [maxMembers, setMaxMembers] = useState(10);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Exclude<Role, 'owner'>>('agent');
  const [busy, setBusy] = useState<string | null>(null);

  const canManage = myRole === 'owner' || myRole === 'admin';

  const load = useCallback(async () => {
    if (!tenant) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/team?tenantId=${encodeURIComponent(tenant.id)}`, { cache: 'no-store' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? 'No se pudo cargar el equipo.');
      setMembers(data.members ?? []);
      setMyRole(data.myRole ?? 'viewer');
      setMaxMembers(data.maxMembers ?? 10);
    } catch (err) {
      toast({ kind: 'error', title: 'Equipo', body: err instanceof Error ? err.message : 'Error' });
    } finally {
      setLoading(false);
    }
  }, [tenant, toast]);

  useEffect(() => {
    void load();
  }, [load]);

  async function call(method: 'POST' | 'PATCH' | 'DELETE', body: Record<string, unknown>) {
    const res = await fetch('/api/team', {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tenantId: tenant?.id, ...body }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error ?? 'Algo ha fallado.');
    return data as { message?: string; left?: boolean };
  }

  async function invite(e: React.FormEvent) {
    e.preventDefault();
    setBusy('invite');
    try {
      const data = await call('POST', { email, role });
      toast({ kind: 'success', title: 'Invitación', body: data.message ?? 'Invitación enviada.' });
      setEmail('');
      await load();
    } catch (err) {
      toast({ kind: 'error', title: 'No se pudo invitar', body: err instanceof Error ? err.message : 'Error' });
    } finally {
      setBusy(null);
    }
  }

  async function changeRole(m: Member, next: Exclude<Role, 'owner'>) {
    setBusy(m.userId);
    try {
      await call('PATCH', { userId: m.userId, role: next });
      toast({ kind: 'success', title: 'Permiso cambiado', body: `${m.email}: ${ROLE_LABEL[next]}` });
      await load();
    } catch (err) {
      toast({ kind: 'error', title: 'No se pudo cambiar', body: err instanceof Error ? err.message : 'Error' });
    } finally {
      setBusy(null);
    }
  }

  async function remove(m: Member) {
    const question = m.isMe
      ? `¿Seguro que quieres salir del equipo de ${tenant?.name}? Dejarás de ver su panel.`
      : `¿Quitar a ${m.email} del equipo?`;
    if (!window.confirm(question)) return;
    setBusy(m.userId);
    try {
      const data = await call('DELETE', { userId: m.userId });
      if (data.left) {
        window.location.assign('/dashboard');
        return;
      }
      toast({ kind: 'success', title: 'Equipo', body: `${m.email} ya no está en el equipo.` });
      await load();
    } catch (err) {
      toast({ kind: 'error', title: 'No se pudo completar', body: err instanceof Error ? err.message : 'Error' });
    } finally {
      setBusy(null);
    }
  }

  if (!tenant) {
    return (
      <div className="card p-10 text-center" role="status">
        <p className="font-bold text-white">Crea tu empresa para invitar a tu equipo</p>
      </div>
    );
  }

  const full = members.length >= maxMembers;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      <div>
        <h2 className="flex items-center gap-2 text-base font-bold tracking-tightish text-white">
          <Users size={16} className="text-brand-300" /> Equipo de {tenant.name}
        </h2>
        <p className="mt-1 text-sm text-ink-300">
          {members.length} de {maxMembers} personas. Tu permiso: <strong className="text-white">{ROLE_LABEL[myRole]}</strong>.
        </p>
      </div>

      {canManage && (
        <form onSubmit={invite} className="card space-y-4 p-5">
          <p className="flex items-center gap-2 text-sm font-bold text-white">
            <UserPlus size={15} className="text-brand-300" /> Invitar a una persona
          </p>
          <div>
            <label className="label" htmlFor="team-email">Email</label>
            <input
              id="team-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input mt-1.5"
              placeholder="persona@empresa.com"
              disabled={full}
            />
          </div>
          <fieldset>
            <legend className="label">¿Qué puede hacer?</legend>
            <div className="mt-2 grid gap-2 sm:grid-cols-3">
              {ASSIGNABLE.map((r) => (
                <label
                  key={r}
                  className={
                    role === r
                      ? 'cursor-pointer rounded-xl border border-brand-400/50 bg-brand-500/10 p-3'
                      : 'cursor-pointer rounded-xl border border-white/10 bg-white/[0.02] p-3 hover:border-white/20'
                  }
                >
                  <input
                    type="radio"
                    name="team-role"
                    value={r}
                    checked={role === r}
                    onChange={() => setRole(r)}
                    className="sr-only"
                  />
                  <span className="block text-sm font-semibold text-white">{ROLE_LABEL[r]}</span>
                  <span className="mt-0.5 block text-xs text-ink-400">{ROLE_HINT[r]}</span>
                </label>
              ))}
            </div>
          </fieldset>
          {full ? (
            <p className="text-sm text-amber-300">
              El equipo está completo ({maxMembers} personas). Quita a alguien para invitar a otra persona.
            </p>
          ) : (
            <p className="hint">
              Si no tiene cuenta, le llegará un email para crear su contraseña. Si ya la tiene, recibirá un aviso.
            </p>
          )}
          <button type="submit" className="btn-primary" disabled={busy === 'invite' || full}>
            <Mail size={15} /> {busy === 'invite' ? 'Enviando…' : 'Enviar invitación'}
          </button>
        </form>
      )}

      <div className="card divide-y divide-white/[0.06] p-0">
        {loading && <p className="p-5 text-sm text-ink-400">Cargando equipo…</p>}
        {!loading &&
          members.map((m) => (
            <div key={m.userId} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-white">
                  {m.email} {m.isMe && <span className="text-xs font-normal text-ink-400">(tú)</span>}
                </p>
                <p className="text-xs text-ink-400">
                  {m.pending ? 'Invitación pendiente' : `En el equipo desde ${new Date(m.joinedAt).toLocaleDateString('es-ES')}`}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {m.role === 'owner' || !canManage || m.isMe ? (
                  <span className="badge-ok">{ROLE_LABEL[m.role]}</span>
                ) : (
                  <select
                    aria-label={`Permiso de ${m.email}`}
                    className="input py-1.5 text-sm"
                    value={m.role}
                    disabled={busy === m.userId}
                    onChange={(e) => changeRole(m, e.target.value as Exclude<Role, 'owner'>)}
                  >
                    {ASSIGNABLE.map((r) => (
                      <option key={r} value={r}>{ROLE_LABEL[r]}</option>
                    ))}
                  </select>
                )}
                {m.isMe && m.role !== 'owner' && (
                  <button type="button" className="btn-secondary btn-sm" disabled={busy === m.userId} onClick={() => remove(m)}>
                    <LogOut size={14} /> Salir del equipo
                  </button>
                )}
                {!m.isMe && canManage && m.role !== 'owner' && (
                  <button
                    type="button"
                    className="btn-secondary btn-sm"
                    aria-label={`Quitar a ${m.email}`}
                    disabled={busy === m.userId}
                    onClick={() => remove(m)}
                  >
                    <Trash2 size={14} /> Quitar
                  </button>
                )}
              </div>
            </div>
          ))}
      </div>
    </motion.div>
  );
}
