'use client';

import type { Dispatch, SetStateAction } from 'react';
import type { useToast } from '@/components/Toast';
import type { SubscriptionOverviewInfo } from '@/components/dashboard/BillingTaxAndRetentionSection';

/** Acciones de baja (final de periodo / inmediata) y «Reactivar». */
export function useCancellationActions({
  tenantId,
  reason,
  toast,
  setSubInfo,
  setProcessingAction,
}: {
  tenantId?: string;
  reason: string;
  toast: ReturnType<typeof useToast>;
  setSubInfo: Dispatch<SetStateAction<SubscriptionOverviewInfo | null>>;
  setProcessingAction: (v: string | null) => void;
}) {
  async function handleCancel(mode: 'period_end' | 'now') {
    if (!tenantId) return;
    if (
      mode === 'now' &&
      !window.confirm('¿Seguro? La baja inmediata corta el acceso ahora y no se puede deshacer desde aquí.')
    ) {
      return;
    }
    setProcessingAction(`cancel_${mode}`);
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'cancel', tenantId, mode, cancelReason: reason }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo dar de baja', body: data.error });
        return;
      }
      setSubInfo((prev) => ({
        ...(prev ?? {}),
        cancellation: { mode, cancelAt: data.cancelAt ?? null, canReactivate: mode === 'period_end' },
      }));
      toast({ kind: 'info', title: mode === 'now' ? 'Baja realizada' : 'Baja programada', body: data.message });
      if (mode === 'now') setTimeout(() => window.location.reload(), 900);
    } finally {
      setProcessingAction(null);
    }
  }

  async function handleReactivate() {
    if (!tenantId) return;
    setProcessingAction('reactivate');
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reactivate', tenantId }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo reactivar', body: data.error });
        return;
      }
      setSubInfo((prev) => ({
        ...(prev ?? {}),
        cancellation: { mode: null, cancelAt: null, canReactivate: false },
      }));
      toast({ kind: 'success', title: 'Suscripción reactivada', body: data.message });
    } finally {
      setProcessingAction(null);
    }
  }

  /** Oferta de permanencia: descuento real en Stripe (una vez por empresa). */
  async function handleAcceptDiscount() {
    if (!tenantId) return;
    setProcessingAction('retention_discount');
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'apply_retention_discount', tenantId, cancelReason: reason }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo aplicar el descuento', body: data.error });
        return false;
      }
      setSubInfo((prev) => ({
        ...(prev ?? {}),
        cancellation: { mode: null, cancelAt: null, canReactivate: false },
        retentionOffers: prev?.retentionOffers
          ? {
              ...prev.retentionOffers,
              discount: { ...prev.retentionOffers.discount, alreadyUsed: true, available: false },
            }
          : prev?.retentionOffers,
      }));
      toast({ kind: 'success', title: 'Descuento aplicado', body: data.message });
      return true;
    } finally {
      setProcessingAction(null);
    }
  }

  return { handleCancel, handleReactivate, handleAcceptDiscount };
}
