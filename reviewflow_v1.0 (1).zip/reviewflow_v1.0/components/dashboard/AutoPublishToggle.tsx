'use client';

import { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { useToast } from '@/components/Toast';
import { Spinner } from '@/components/Skeleton';
import type { TenantSettings } from '@/components/dashboard/types';

/**
 * Interruptor del piloto automático: la IA responde y publica sola las
 * reseñas nuevas, y avisa al dueño por email. Activarlo pide confirmación
 * porque quita la revisión humana.
 */
export function AutoPublishToggle({ tenantId, settings }: { tenantId: string; settings: TenantSettings }) {
  const toast = useToast();
  const [enabled, setEnabled] = useState(settings.auto_publish === true);
  const [minRating, setMinRating] = useState<number>(settings.auto_publish_min_rating ?? 4);
  const [confirming, setConfirming] = useState(false);
  const [saving, setSaving] = useState(false);

  async function save(next: { auto_publish?: boolean; auto_publish_min_rating?: number }) {
    setSaving(true);
    try {
      const res = await fetch('/api/tenants/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenantId, ...next }),
      });
      const j = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(j.error ?? 'No se pudo guardar.');
      if (next.auto_publish !== undefined) setEnabled(next.auto_publish);
      if (next.auto_publish_min_rating !== undefined) setMinRating(next.auto_publish_min_rating);
      toast({
        kind: 'success',
        title: next.auto_publish === true ? 'Piloto automático activado' : next.auto_publish === false ? 'Piloto automático desactivado' : 'Ajuste guardado',
      });
      return true;
    } catch (e) {
      toast({ kind: 'error', title: 'No se pudo guardar', body: e instanceof Error ? e.message : undefined });
      return false;
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-3">
      <p className="hint">
        Normalmente la IA prepara la respuesta y una persona la revisa y pulsa «Publicar». Con el piloto automático,
        cada reseña nueva se responde y se publica sola, y te llega un email con lo que se ha publicado.
      </p>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          role="switch"
          aria-checked={enabled}
          aria-label="Piloto automático de respuestas"
          disabled={saving}
          onClick={() => (enabled ? void save({ auto_publish: false }) : setConfirming(true))}
          className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition ${enabled ? 'bg-brand-500' : 'bg-white/15'}`}
        >
          <span className={`inline-block h-5 w-5 rounded-full bg-white shadow transition ${enabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
        </button>
        <span className="text-sm font-medium">{enabled ? 'Activado: se publica solo' : 'Desactivado: revisas tú antes de publicar'}</span>
        {saving && <Spinner label="…" size={13} />}
      </div>

      <div className="max-w-xs">
        <label className="label" htmlFor={`${tenantId}-auto-min`}>
          Responder solas las reseñas de
        </label>
        <select
          id={`${tenantId}-auto-min`}
          className="select"
          value={minRating}
          disabled={saving}
          onChange={(e) => void save({ auto_publish_min_rating: Number(e.target.value) })}
        >
          <option value={5}>Solo 5★</option>
          <option value={4}>4★ y 5★ (recomendado)</option>
          <option value={3}>3★ o más</option>
          <option value={1}>Todas, también las negativas</option>
        </select>
        <p className="hint mt-1">Las reseñas por debajo de esta nota siguen esperando tu revisión.</p>
      </div>

      {confirming && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" role="dialog" aria-modal="true">
          <div className="card max-w-md space-y-3 p-5">
            <div className="flex items-center gap-2 text-amber-300">
              <AlertTriangle size={18} />
              <h3 className="font-semibold">Cuidado: quitas el filtro humano</h3>
            </div>
            <p className="text-sm">
              Funcionará igual de bien, pero nadie revisará las respuestas antes de que se publiquen. La IA leerá cada
              reseña nueva, escribirá la respuesta y la publicará directamente. Te avisaremos por email de cada una y
              podrás editarla o desactivar esto cuando quieras.
            </p>
            <div className="flex justify-end gap-2">
              <button type="button" className="btn-ghost btn-sm" onClick={() => setConfirming(false)}>
                Cancelar
              </button>
              <button
                type="button"
                className="btn-primary btn-sm"
                disabled={saving}
                onClick={async () => {
                  if (await save({ auto_publish: true })) setConfirming(false);
                }}
              >
                Sí, activar el piloto automático
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
