'use client';

import { useState } from 'react';
import type { PlanId } from '@/lib/plans';
import type { RetentionOffersView } from '@/lib/retention-offers';
import type { SubscriptionOverviewInfo } from './BillingTaxAndRetentionSection';

function durationLabel(months: number) {
  return months === 1 ? 'el próximo mes' : `los próximos ${months} meses`;
}

/** Tarjeta «Darse de baja» con ofertas de retención antes de confirmar. */
export function BillingCancellationCard({
  processingAction, cancellation, onCancel, onReactivate, retentionOffers, onAcceptDiscount, onDowngradeOffer, onPauseMonth,
}: {
  processingAction: string | null;
  cancellation?: SubscriptionOverviewInfo['cancellation'];
  onCancel: (mode: 'period_end' | 'now') => void;
  onReactivate: () => void;
  retentionOffers?: RetentionOffersView;
  onAcceptDiscount: () => Promise<boolean | undefined>;
  onDowngradeOffer: (plan: PlanId) => Promise<void> | void;
  onPauseMonth: () => void;
}) {
  const [offersFor, setOffersFor] = useState<'period_end' | 'now' | null>(null);
  const hasOffers = Boolean(
    retentionOffers &&
      (retentionOffers.discount.available || retentionOffers.pause.available || retentionOffers.downgrade.available),
  );
  function requestCancel(mode: 'period_end' | 'now') {
    if (hasOffers) setOffersFor(mode);
    else onCancel(mode);
  }
  return (
      <div className="card space-y-3">
        <h3 className="text-sm font-bold text-white">Darse de baja</h3>
        {cancellation?.canReactivate && cancellation.cancelAt ? (
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <p className="text-ink-300">
              Tu baja está programada para el{' '}
              <strong className="text-white">{new Date(cancellation.cancelAt).toLocaleDateString('es-ES')}</strong>.
              Hasta entonces mantienes todo activo.
            </p>
            <button
              type="button"
              disabled={processingAction === 'reactivate'}
              onClick={onReactivate}
              className="btn-primary btn-sm"
            >
              {processingAction === 'reactivate' ? 'Reactivando…' : 'Reactivar'}
            </button>
          </div>
        ) : cancellation?.mode === 'now' ? (
          <p className="text-xs text-ink-300">Tu suscripción está dada de baja.</p>
        ) : offersFor && retentionOffers ? (
          <div className="space-y-3 text-xs">
            <p className="text-ink-300">
              Antes de irte, ¿te sirve alguna de estas opciones? Si no, puedes continuar con la baja.
            </p>
            <div className="grid gap-2.5 md:grid-cols-3">
              {retentionOffers.discount.available && (
                <div className="flex flex-col justify-between gap-2 rounded-xl border border-brand-400/30 bg-brand-500/[0.07] p-3">
                  <div>
                    <p className="font-semibold text-white">{retentionOffers.discount.percent} % de descuento</p>
                    <p className="mt-1 text-2xs text-ink-400">
                      Durante {durationLabel(retentionOffers.discount.months)}. Se aplica directamente en tu factura. Solo se puede usar una vez.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={processingAction === 'retention_discount'}
                    onClick={async () => {
                      const ok = await onAcceptDiscount();
                      if (ok) setOffersFor(null);
                    }}
                    className="btn-primary btn-sm"
                  >
                    {processingAction === 'retention_discount' ? 'Aplicando…' : 'Quiero el descuento'}
                  </button>
                </div>
              )}
              {retentionOffers.pause.available && (
                <div className="flex flex-col justify-between gap-2 rounded-xl border border-amber-400/25 bg-amber-500/[0.06] p-3">
                  <div>
                    <p className="font-semibold text-white">
                      Pausar {retentionOffers.pause.months === 1 ? '1 mes' : `${retentionOffers.pause.months} meses`}
                    </p>
                    <p className="mt-1 text-2xs text-ink-400">Sin cobros mientras dure la pausa. Conservas todos tus datos.</p>
                  </div>
                  <button
                    type="button"
                    disabled={processingAction === 'pause'}
                    onClick={() => {
                      onPauseMonth();
                      setOffersFor(null);
                    }}
                    className="btn-secondary btn-sm"
                  >
                    {processingAction === 'pause' ? 'Pausando…' : 'Pausar'}
                  </button>
                </div>
              )}
              {retentionOffers.downgrade.available && retentionOffers.downgrade.targetPlan && (
                <div className="flex flex-col justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <div>
                    <p className="font-semibold text-white">
                      Pasar a {retentionOffers.downgrade.targetName} ({retentionOffers.downgrade.targetPrice}/mes)
                    </p>
                    <p className="mt-1 text-2xs text-ink-400">Pagas menos. El cambio se aplica al final del ciclo actual.</p>
                  </div>
                  <button
                    type="button"
                    disabled={processingAction === retentionOffers.downgrade.targetPlan}
                    onClick={async () => {
                      await onDowngradeOffer(retentionOffers.downgrade.targetPlan as PlanId);
                      setOffersFor(null);
                    }}
                    className="btn-secondary btn-sm"
                  >
                    Cambiar a plan más barato
                  </button>
                </div>
              )}
            </div>
            <div className="flex flex-wrap gap-2 pt-1">
              <button type="button" onClick={() => setOffersFor(null)} className="btn-quiet btn-sm">
                Volver
              </button>
              <button
                type="button"
                disabled={processingAction?.startsWith('cancel')}
                onClick={() => {
                  const mode = offersFor;
                  setOffersFor(null);
                  onCancel(mode);
                }}
                className="btn-secondary btn-sm text-red-300"
              >
                {processingAction?.startsWith('cancel') ? 'Procesando…' : 'No, gracias. Continuar con la baja'}
              </button>
            </div>
          </div>
        ) : (
          <>
            <p className="text-xs text-ink-400">
              Elige cuándo quieres que termine tu suscripción. Si la programas para el final del periodo
              pagado, podrás deshacerla con «Reactivar» hasta esa fecha.
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                disabled={processingAction?.startsWith('cancel')}
                onClick={() => requestCancel('period_end')}
                className="btn-secondary btn-sm"
              >
                {processingAction === 'cancel_period_end' ? 'Programando…' : 'Baja al final del periodo pagado'}
              </button>
              <button
                type="button"
                disabled={processingAction?.startsWith('cancel')}
                onClick={() => requestCancel('now')}
                className="btn-secondary btn-sm text-red-300"
              >
                {processingAction === 'cancel_now' ? 'Dando de baja…' : 'Baja inmediata'}
              </button>
            </div>
          </>
        )}
      </div>
  );
}
