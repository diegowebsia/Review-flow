'use client';

import {
  PLAN_CATALOG,
  annualMonthlyEquivalentCents,
  annualPriceCentsOf,
  formatEur,
  planOf,
  resolvePlan,
  type PlanId,
} from '@/lib/plans';

export function BillingPlanSwitcherCard({
  currentPlanSlug,
  billingInterval,
  setBillingInterval,
  processingAction,
  onPlanChange,
}: {
  currentPlanSlug: string;
  billingInterval: 'month' | 'year';
  setBillingInterval: (interval: 'month' | 'year') => void;
  processingAction: string | null;
  onPlanChange: (targetPlan: PlanId, isUpgrade: boolean) => void;
}) {
  const plan = planOf(currentPlanSlug);

  return (
    <div className="card space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-bold tracking-tightish text-white">
            Cambiar de plan en 1 clic (sin salir del panel)
          </h3>
          <p className="mt-1 text-sm text-ink-300">
            Los upgrades aplican al instante con prorrateo exacto (<code>always_invoice</code>). Los downgrades se programan a fin de ciclo para que no pierdas nada ya pagado.
          </p>
        </div>

        <div className="inline-flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1">
          <button
            type="button"
            onClick={() => setBillingInterval('month')}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              billingInterval === 'month' ? 'bg-brand-600 text-white' : 'text-ink-300 hover:text-white'
            }`}
          >
            Mensual
          </button>
          <button
            type="button"
            onClick={() => setBillingInterval('year')}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              billingInterval === 'year' ? 'bg-brand-600 text-white' : 'text-ink-300 hover:text-white'
            }`}
          >
            Anual (2 meses gratis)
            <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-2xs font-bold text-emerald-300">
              -17 %
            </span>
          </button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {PLAN_CATALOG.map((p) => {
          const current = resolvePlan(currentPlanSlug) === p.id;
          const isUpgrade = p.priceCents >= plan.priceCents;
          const displayedMonthlyCents =
            billingInterval === 'year' ? annualMonthlyEquivalentCents(p) : p.priceCents;
          const annualTotal = annualPriceCentsOf(p);

          return (
            <div
              key={p.id}
              className={`rounded-2xl border p-4 transition ${
                current ? 'border-brand-400/50 bg-brand-500/10' : 'border-white/[0.07] bg-white/[0.02]'
              }`}
            >
              <p className="flex items-center gap-2 text-sm font-bold text-white">
                {p.name}
                <span className="badge-brand">{p.tier}</span>
                {current && <span className="badge-ok ml-auto">tu plan actual</span>}
              </p>
              <p className="mt-1.5 text-2xl font-extrabold tracking-tighter text-white">
                {formatEur(displayedMonthlyCents)}
                <span className="text-xs font-medium text-ink-400">/mes</span>
                {billingInterval === 'year' && (
                  <span className="ml-2 text-xs font-normal text-emerald-300">
                    ({formatEur(annualTotal)}/año · ahorras {formatEur(p.priceCents * 2)})
                  </span>
                )}
              </p>
              <p className="mt-1 text-xs text-ink-400">
                {p.limits.requestsPerMonth.toLocaleString('es-ES')} peticiones ·{' '}
                {p.limits.aiRepliesPerMonth.toLocaleString('es-ES')} IA ·{' '}
                {p.limits.reviewsStored.toLocaleString('es-ES')} opiniones guardadas
              </p>

              {!current && (
                <div className="mt-3 space-y-1.5">
                  <button
                    type="button"
                    disabled={processingAction === p.id}
                    onClick={() => onPlanChange(p.id, isUpgrade)}
                    className={`btn-sm w-full justify-center ${
                      isUpgrade ? 'btn-primary' : 'btn-secondary'
                    }`}
                  >
                    {processingAction === p.id
                      ? 'Procesando…'
                      : isUpgrade
                        ? `Subir a ${p.name} en 1 clic (prorrateado)`
                        : `Programar cambio a ${p.name} (fin de ciclo)`}
                  </button>
                  {!isUpgrade && (
                    <p className="text-2xs text-amber-300/90">
                      Al bajar de plan a fin de ciclo el tope pasa a {p.limits.reviewsStored.toLocaleString('es-ES')} reseñas y {p.limits.integrations} conexiones.
                    </p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
