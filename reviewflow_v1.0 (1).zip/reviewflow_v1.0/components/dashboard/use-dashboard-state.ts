'use client';

import { useEffect, useMemo, useState } from 'react';
import { errorMessage } from '@/lib/api-error';
import { SAMPLE_REVIEWS } from '@/lib/sample-reviews';
import { useToast } from '@/components/Toast';
import { useGoogleReturn } from '@/components/dashboard/use-google-return';
import { describeApiError, type ReviewItem, type TenantInfo } from '@/components/dashboard/types';

export type DashboardTabId = 'bandeja' | 'analitica' | 'empresa' | 'embudo' | 'equipo' | 'facturacion';

export type NewReviewSource = 'google' | 'trustpilot' | 'facebook' | 'manual';

export function useDashboardState({
  tenants, initialReviews, initialTab = 'bandeja', addonResult, pageSize = 10,
}: {
  tenants: TenantInfo[]; initialReviews: ReviewItem[]; initialTab?: DashboardTabId;
  addonResult?: 'success' | 'canceled' | null; pageSize?: number;
}) {
  const toast = useToast();
  const [tab, setTab] = useState<DashboardTabId>(initialTab);
  const [reviews, setReviews] = useState<ReviewItem[]>(initialReviews);
  const [filter, setFilter] = useState('');
  const [onlyPending, setOnlyPending] = useState(false);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [publishedIds, setPublishedIds] = useState<Set<string>>(new Set());
  const [showWizard, setShowWizard] = useState(false);
  const [syncing, setSyncing] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [reviewPage, setReviewPage] = useState(1);

  const [showAddReview, setShowAddReview] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newRating, setNewRating] = useState<number>(5);
  const [newSource, setNewSource] = useState<NewReviewSource>('google');
  const [newText, setNewText] = useState('');
  const [creatingReview, setCreatingReview] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  useEffect(() => {
    setReviews(initialReviews);
  }, [initialReviews]);

  useEffect(() => {
    if (addonResult === 'success') {
      toast({
        kind: 'success',
        title: 'Ampliación de cuota activada',
        body: 'Stripe confirmó el pago y los créditos ya están sumados a tu ciclo actual.',
      });
    }
    if (addonResult === 'canceled') {
      toast({ kind: 'info', title: 'Pago cancelado', body: 'No se ha realizado ningún cargo.' });
    }
  }, [addonResult, toast]);

  useGoogleReturn(tenants[0]?.id, toast, sync);

  const filtered = useMemo(
    () =>
      reviews.filter((r) => {
        const replied = r.replied || publishedIds.has(r.id);
        if (onlyPending && replied) return false;
        if (!filter) return true;
        const q = filter.toLowerCase();
        return (
          r.author.toLowerCase().includes(q) ||
          r.text.toLowerCase().includes(q) ||
          r.tenant.toLowerCase().includes(q)
        );
      }),
    [reviews, filter, onlyPending, publishedIds],
  );

  const reviewTotalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paginatedReviews = useMemo(() => {
    const safePage = Math.min(reviewPage, reviewTotalPages);
    const start = (safePage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, reviewPage, reviewTotalPages, pageSize]);

  const flagged = useMemo(
    () =>
      reviews.filter(
        (r) => r.flagged_private || (r.rating <= 3 && !r.replied && !publishedIds.has(r.id)),
      ),
    [reviews, publishedIds],
  );

  const stats = useMemo(() => {
    const total = reviews.length;
    const pending = reviews.filter((r) => !r.replied && !publishedIds.has(r.id)).length;
    const avg = total ? Number((reviews.reduce((a, r) => a + r.rating, 0) / total).toFixed(1)) : 0;
    const negative = reviews.filter((r) => r.rating <= 3).length;
    return { total, pending, avg, negative };
  }, [reviews, publishedIds]);

  function toneFor(review: ReviewItem): 'profesional' | 'cercano' | 'formal' {
    const t = tenants.find((x) => x.id === review.tenant_id)?.settings?.tone;
    if (t === 'cercano' || t === 'formal' || t === 'profesional') return t;
    try {
      const local = localStorage.getItem('rf-tone');
      if (local === 'cercano' || local === 'formal' || local === 'profesional') return local;
    } catch {
      /* noop */
    }
    return 'profesional';
  }

  function loadSampleReviews() {
    const primary = tenants[0];
    const namedSamples = SAMPLE_REVIEWS.map((s) => ({
      ...s,
      tenant: primary?.name || 'Vista de Ejemplo',
      tenant_id: primary?.id,
    }));
    setReviews(namedSamples);
    setReviewPage(1);
    toast({
      kind: 'info',
      title: '12 reseñas de ejemplo cargadas',
      body: 'Prueba borradores IA en varios idiomas y el detector de reseñas falsas.',
    });
  }

  async function handleCreateReview(e: React.FormEvent) {
    e.preventDefault();
    const primary = tenants[0];
    if (!primary) return;
    if (newAuthor.trim().length < 2 || newText.trim().length < 3) {
      toast({
        kind: 'warning',
        title: 'Completa los campos',
        body: 'Indica el nombre del cliente y el comentario recibido.',
      });
      return;
    }
    setCreatingReview(true);
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: primary.id,
          author_name: newAuthor.trim(),
          rating: newRating,
          source: newSource,
          text: newText.trim(),
          verified: true,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        code?: string;
        review?: ReviewItem;
      };
      if (!res.ok) {
        const described = describeApiError(res.status, data);
        toast({
          kind: described.kind,
          title: described.title,
          body: described.body,
          action: described.action,
        });
        return;
      }
      if (data.review) {
        setReviews((prev) => [data.review!, ...prev]);
      }
      setNewAuthor('');
      setNewText('');
      setNewRating(5);
      setShowAddReview(false);
      setReviewPage(1);
      toast({
        kind: 'success',
        title: 'Reseña registrada en tu bandeja',
        body:
          newRating <= 3
            ? 'Guardada en Supabase y añadida a la cola de gestión privada.'
            : 'Guardada en Supabase. Ya puedes generar y publicar su respuesta con IA.',
      });
      window.dispatchEvent(new Event('rf:quota-refresh'));
    } catch (err: unknown) {
      toast({
        kind: 'error',
        title: 'Error al registrar reseña',
        body: errorMessage(err, 'No se pudo guardar la reseña.'),
      });
    } finally {
      setCreatingReview(false);
    }
  }

  async function sync(
    provider: 'google' | 'trustpilot' | 'places',
    tenantId: string,
    placeIdOverride?: string,
  ) {
    setSyncing(`${provider}-${tenantId}`);
    const endpoint =
      provider === 'trustpilot'
        ? '/api/integrations/trustpilot/sync'
        : '/api/integrations/google/sync';
    const payload =
      provider === 'trustpilot'
        ? { tenantId }
        : {
            tenantId,
            provider: provider === 'places' ? 'places' : 'business',
            ...(placeIdOverride ? { placeId: placeIdOverride } : {}),
          };

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        quotaCut?: boolean;
        message?: string;
        imported?: number;
      };

      if (!res.ok) {
        const message = data.error ?? `Error ${res.status}`;
        toast({
          kind: res.status === 429 || res.status === 402 ? 'warning' : 'error',
          title:
            res.status === 429
              ? 'Cuota agotada: sincronización bloqueada'
              : res.status === 402
                ? 'Suscripción sin acceso'
                : res.status === 403
                  ? 'No incluido en tu plan'
                  : 'Sincronización fallida',
          body: message,
          action:
            res.status === 429
              ? { label: 'Ampliar cuota', onClick: () => setTab('facturacion') }
              : res.status === 402
                ? {
                    label: 'Activar plan',
                    onClick: () => {
                      window.location.href = '/bienvenido';
                    },
                  }
                : undefined,
          duration: 8000,
        });
        return;
      }

      toast({
        kind: 'success',
        title: data.quotaCut
          ? 'Sincronización parcial (cuota al límite)'
          : 'Sincronización completa',
        body: data.message ?? `${data.imported ?? 0} reseñas importadas.`,
      });
      window.dispatchEvent(new Event('rf:quota-refresh'));
      setTimeout(() => window.location.reload(), 900);
    } catch (e: unknown) {
      toast({
        kind: 'error',
        title: 'Sincronización fallida',
        body: errorMessage(e, 'Fallo de red en la sincronización.'),
      });
    } finally {
      setSyncing(null);
    }
  }

  function handleFilterChange(val: string) {
    setFilter(val);
    setReviewPage(1);
  }

  function handleOnlyPendingChange(val: boolean) {
    setOnlyPending(val);
    setReviewPage(1);
  }

  return {
    tab, setTab, reviews, setReviews, filter, setFilter: handleFilterChange,
    onlyPending, setOnlyPending: handleOnlyPendingChange, filtered, paginatedReviews,
    reviewPage, setReviewPage, reviewTotalPages, flagged, stats, drafts, setDrafts,
    publishedIds, setPublishedIds, showWizard, setShowWizard, syncing, hydrated,
    helpOpen, setHelpOpen, showAddReview, setShowAddReview, newAuthor, setNewAuthor,
    newRating, setNewRating, newSource, setNewSource, newText, setNewText,
    creatingReview, toneFor, loadSampleReviews, handleCreateReview, sync,
  };
}
