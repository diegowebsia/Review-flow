'use client';

import Link from 'next/link';
import { AnimatePresence, motion } from 'framer-motion';
import { Building2, ChevronLeft, ChevronRight, Gauge, Inbox, MessageSquarePlus, Search, ShieldAlert, Sparkles, Star } from 'lucide-react';
import { CountUp, EASE } from '@/components/Motion';
import { StatSkeleton } from '@/components/Skeleton';
import { TriageCard } from '@/components/dashboard/TriageCard';
import { ReviewCard } from '@/components/dashboard/ReviewCard';
import { AddReviewForm } from '@/components/dashboard/AddReviewForm';
import type { ReviewItem, TenantInfo } from '@/components/dashboard/types';
import type { DashboardTabId, NewReviewSource } from './use-dashboard-state';

export function DashboardReviewsSection({
  hydrated, hasAccess, primaryTenant, reviews, filteredCount, paginatedReviews,
  reviewPage, reviewTotalPages, onPageChange, flagged, stats, filter, onFilterChange,
  onlyPending, onOnlyPendingChange, drafts, onDraftChange, publishedIds, onPublished,
  toneFor, showAddReview, setShowAddReview, newAuthor, setNewAuthor, newRating,
  setNewRating, newSource, setNewSource, newText, setNewText, creatingReview,
  onCreateReview, onLoadSamples, onSelectTab,
}: {
  hydrated: boolean; hasAccess: boolean; primaryTenant?: TenantInfo;
  reviews: ReviewItem[]; filteredCount: number; paginatedReviews: ReviewItem[];
  reviewPage: number; reviewTotalPages: number; onPageChange: (next: number) => void;
  flagged: ReviewItem[]; stats: { total: number; pending: number; avg: number; negative: number };
  filter: string; onFilterChange: (v: string) => void;
  onlyPending: boolean; onOnlyPendingChange: (v: boolean) => void;
  drafts: Record<string, string>; onDraftChange: (id: string, value: string) => void;
  publishedIds: Set<string>; onPublished: (id: string) => void;
  toneFor: (r: ReviewItem) => 'profesional' | 'cercano' | 'formal';
  showAddReview: boolean; setShowAddReview: React.Dispatch<React.SetStateAction<boolean>>;
  newAuthor: string; setNewAuthor: (v: string) => void;
  newRating: number; setNewRating: (v: number) => void;
  newSource: NewReviewSource; setNewSource: (v: NewReviewSource) => void;
  newText: string; setNewText: (v: string) => void;
  creatingReview: boolean; onCreateReview: (e: React.FormEvent) => Promise<void>;
  onLoadSamples: () => void; onSelectTab: (tab: DashboardTabId) => void;
}) {
  return (
    <motion.div
      key="bandeja"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.3, ease: EASE }}
      className="space-y-5"
    >
      {/* Resumen compacto de la bandeja */}
      <section aria-label="Resumen de la bandeja">
        {!hydrated ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <StatSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="panel-surface grid grid-cols-2 divide-white/[0.06] sm:grid-cols-4 sm:divide-x">
            {[
              {
                label: 'En bandeja',
                value: stats.total,
                icon: <Inbox size={13} />,
                tone: 'text-brand-300',
              },
              {
                label: 'Pendientes',
                value: stats.pending,
                icon: <Gauge size={13} />,
                tone: 'text-amber-300',
              },
              {
                label: 'Nota media',
                value: stats.avg,
                icon: <Star size={13} />,
                tone: 'text-emerald-300',
                decimals: true,
              },
              {
                label: 'Quejas ≤3★',
                value: stats.negative,
                icon: <ShieldAlert size={13} />,
                tone: 'text-rose-300',
              },
            ].map((s) => (
              <div key={s.label} className="panel-metric">
                <p className="flex items-center gap-1.5 text-2xs font-semibold tracking-wider text-ink-300">
                  <span className={s.tone}>{s.icon}</span>
                  {s.label}
                </p>
                <p className="font-display text-2xl font-bold tracking-tighter text-white tabular-nums">
                  {s.decimals ? (
                    <>
                      {s.value ? s.value.toFixed(1).replace('.', ',') : '—'}
                      {s.value ? <span className="ml-1 text-sm text-ink-400">★</span> : null}
                    </>
                  ) : (
                    <CountUp value={s.value} />
                  )}
                </p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Cola de gestión privada */}
      {hasAccess && flagged.length > 0 && (
        <section className="space-y-3" aria-label="Cola de gestión privada">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <h2 className="flex items-center gap-2 text-base font-bold tracking-tightish text-white">
                <ShieldAlert size={16} className="text-amber-300" /> Gestión privada
                <span className="badge-warn">{flagged.length}</span>
              </h2>
              <p className="mt-1 text-sm text-ink-300">
                Quejas para resolver en privado antes de responder en público. La IA inspecciona la
                reclamación y redacta el mensaje conciliador.
              </p>
            </div>
          </div>
          {flagged.map((r) => (
            <TriageCard key={r.id} review={r} tone={toneFor(r)} businessName={r.tenant} />
          ))}
        </section>
      )}

      {/* Filtros y botón para registrar reseña */}
      {hasAccess && (
        <div className="panel-surface space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative min-w-[220px] flex-1 sm:max-w-sm">
              <Search
                size={15}
                className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400"
              />
              <input
                className="input pl-10"
                placeholder="Buscar por autor, texto o empresa…"
                value={filter}
                onChange={(e) => onFilterChange(e.target.value)}
                aria-label="Buscar reseñas"
              />
            </div>
            <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-white/[0.08] bg-white/[0.03] px-3 py-2.5 text-sm text-ink-200 transition hover:border-white/20">
              <input
                type="checkbox"
                className="checkbox"
                checked={onlyPending}
                onChange={(e) => onOnlyPendingChange(e.target.checked)}
              />
              Solo pendientes
            </label>
            <button
              type="button"
              onClick={() => setShowAddReview((v) => !v)}
              className="btn-secondary btn-sm"
            >
              <MessageSquarePlus size={14} /> Registrar reseña
            </button>
            <span className="ml-auto text-xs text-ink-400 tabular-nums">
              {filteredCount} de {reviews.length}
            </span>
          </div>

          <AnimatePresence initial={false}>
            {showAddReview && primaryTenant && (
              <AddReviewForm
                tenantName={primaryTenant.name}
                newAuthor={newAuthor}
                setNewAuthor={setNewAuthor}
                newRating={newRating}
                setNewRating={setNewRating}
                newSource={newSource}
                setNewSource={setNewSource}
                newText={newText}
                setNewText={setNewText}
                creatingReview={creatingReview}
                onCreateReview={onCreateReview}
                onCancel={() => setShowAddReview(false)}
              />
            )}
          </AnimatePresence>
        </div>
      )}

      {/* Reseñas */}
      {hasAccess && (
        <div className="space-y-3">
          <AnimatePresence initial={false}>
            {paginatedReviews.map((r) => (
              <ReviewCard
                key={r.id}
                review={r}
                draft={drafts[r.id]}
                published={publishedIds.has(r.id)}
                tone={toneFor(r)}
                onDraftChange={onDraftChange}
                onPublished={onPublished}
              />
            ))}
          </AnimatePresence>

          {filteredCount === 0 && (
            <div className="card p-10 text-center" role="status">
              <Inbox size={26} className="mx-auto text-ink-400" />
              <p className="mt-3 font-bold text-white">Sin reseñas por aquí</p>
              <p className="mx-auto mt-1 max-w-md text-sm text-ink-300">
                {reviews.length === 0
                  ? 'Conecta Google Business, Google Places o Trustpilot en «Empresa y conexiones», comparte tu QR del «Embudo», o pulsa «Registrar reseña» para añadir una opinión ahora mismo.'
                  : 'Ninguna coincide con el filtro aplicado.'}
              </p>
              {reviews.length === 0 && (
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddReview(true)}
                    className="btn-primary btn-sm"
                  >
                    <MessageSquarePlus size={15} /> Registrar primera reseña
                  </button>
                  <button type="button" onClick={onLoadSamples} className="btn-secondary btn-sm">
                    <Sparkles size={15} /> Cargar 12 reseñas de ejemplo
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectTab('empresa')}
                    className="btn-secondary btn-sm"
                  >
                    <Building2 size={15} /> Ir a conexiones
                  </button>
                </div>
              )}
            </div>
          )}

          {reviewTotalPages > 1 && (
            <div className="flex items-center justify-between rounded-2xl border border-white/[0.06] bg-white/[0.02] px-4 py-3 text-xs text-ink-300">
              <span>
                Página <strong className="text-white tabular-nums">{reviewPage}</strong> de{' '}
                <strong className="text-white tabular-nums">{reviewTotalPages}</strong>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={reviewPage <= 1}
                  onClick={() => onPageChange(Math.max(1, reviewPage - 1))}
                  className="btn-secondary btn-sm"
                  aria-label="Página anterior de reseñas"
                >
                  <ChevronLeft size={14} /> Anterior
                </button>
                <button
                  type="button"
                  disabled={reviewPage >= reviewTotalPages}
                  onClick={() => onPageChange(Math.min(reviewTotalPages, reviewPage + 1))}
                  className="btn-secondary btn-sm"
                  aria-label="Página siguiente de reseñas"
                >
                  Siguiente <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      <p className="text-xs text-ink-400">
        Transparencia (Dir. UE 2019/2161): cada reseña muestra su fuente y verificación.{' '}
        <Link href="/terminos" className="underline-offset-2 hover:text-ink-200 hover:underline">
          Términos
        </Link>{' '}
        ·{' '}
        <Link href="/contacto" className="underline-offset-2 hover:text-ink-200 hover:underline">
          Soporte
        </Link>
      </p>
    </motion.div>
  );
}
