'use client';

import { useState } from 'react';
import Link from 'next/link';
import { AnimatePresence, motion } from 'framer-motion';
import { PLANS, hasAccess as planHasAccess, type PlanId } from '@/lib/plans';
import { Building2, CreditCard, Plus, Rocket } from 'lucide-react';
import { EASE } from '@/components/Motion';
import { TenantCard } from '@/components/dashboard/TenantCard';
import type { TenantInfo } from '@/components/dashboard/types';

export function DashboardCompaniesSection({
  tenants,
  hasAccess,
  canAddCompany,
  showWizard,
  setShowWizard,
  newBusinessResult = null,
  syncing,
  onSync,
}: {
  newBusinessResult?: 'canceled' | null;
  tenants: TenantInfo[];
  hasAccess: boolean;
  canAddCompany: boolean;
  showWizard: boolean;
  setShowWizard: React.Dispatch<React.SetStateAction<boolean>>;
  syncing: string | null;
  onSync: (
    provider: 'google' | 'trustpilot' | 'places',
    tenantId: string,
    placeIdOverride?: string,
  ) => Promise<void>;
}) {
  return (
    <motion.div
      key="empresa"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.3, ease: EASE }}
      className="space-y-4"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="flex items-center gap-2 text-base font-bold tracking-tightish text-white">
            <Building2 size={16} className="text-brand-300" /> Mis empresas
          </h2>
          <p className="mt-1 text-sm text-ink-300">
            Conexiones reales, ajustes de la IA y alertas.
          </p>
        </div>
        {canAddCompany ? (
          <button
            type="button"
            onClick={() => setShowWizard((v) => !v)}
            className="btn-secondary btn-sm"
          >
            <Plus size={14} /> Añadir otra empresa
          </button>
        ) : (
          hasAccess && (
            <span className="text-xs text-ink-300">
              Cada plan incluye 1 empresa ·{' '}
              <Link href="/bienvenido" className="text-brand-200 underline underline-offset-2">
                cambiar de plan
              </Link>
            </span>
          )
        )}
      </div>

      <AnimatePresence initial={false}>
        {showWizard && canAddCompany && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.32, ease: EASE }}
            className="overflow-hidden"
          >
            <div className="pt-1">
              <AddBusinessForm />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {tenants.length === 0 && (
        <div className="card p-10 text-center" role="status">
          <Rocket size={26} className="mx-auto text-brand-300" />
          <p className="mt-3 font-bold text-white">Todavía no tienes empresa creada</p>
          <p className="mx-auto mt-1 max-w-md text-sm text-ink-300">
            Se crea automáticamente al activar tu suscripción. Si ya pagaste y no aparece, recarga
            la página en unos segundos (el webhook de Stripe tarda poco).
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            <Link href="/bienvenido" className="btn-primary">
              <CreditCard size={15} /> Activar suscripción
            </Link>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="btn-secondary"
            >
              Recargar
            </button>
          </div>
        </div>
      )}

      {newBusinessResult === 'canceled' && (
        <p className="card p-3 text-sm text-ink-300" role="status">
          Has cancelado el pago: no se ha creado la nueva empresa ni se te ha cobrado nada.
        </p>
      )}

      {tenants.length > 1 && (
        <div className="card p-4">
          <p className="text-sm font-bold text-white">Mis empresas ({tenants.length})</p>
          <p className="mt-0.5 text-xs text-ink-300">
            Cada empresa tiene su propio plan. Pulsa «Abrir» para gestionarla.
          </p>
          <ul className="mt-3 divide-y divide-white/[0.06]">
            {tenants.map((t, i) => {
              const ok = planHasAccess(t.subscription_status, t.suspended);
              return (
                <li key={t.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-white">{t.name}</p>
                    <p className="text-xs text-ink-400">
                      {PLANS[t.plan as PlanId]?.name ?? t.plan} ·{' '}
                      <span className={ok ? 'text-emerald-300' : 'text-amber-300'}>
                        {t.subscription_status === 'trialing' ? 'En prueba' : ok ? 'Activa' : 'Sin plan'}
                      </span>
                    </p>
                  </div>
                  {i === 0 ? (
                    <span className="text-xs text-brand-200">Abierta ahora</span>
                  ) : (
                    <Link href={`/dashboard?tab=empresa&empresa=${t.id}`} className="btn-secondary btn-sm">
                      Abrir
                    </Link>
                  )}
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {tenants[0] && <TenantCard key={tenants[0].id} tenant={tenants[0]} syncing={syncing} onSync={onSync} />}
    </motion.div>
  );
}


const SELLABLE: PlanId[] = ['local_starter', 'ecommerce_starter', 'local_pro', 'ecommerce_pro'];

/** Multipanel: contrata un plan nuevo para otra empresa con la misma cuenta. */
function AddBusinessForm() {
  const [name, setName] = useState('');
  const [plan, setPlan] = useState<PlanId>('local_starter');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError('Escribe el nombre de la empresa (mínimo 2 letras).');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ plan, newBusiness: true, businessName: name.trim() }),
      });
      const data = (await res.json().catch(() => ({}))) as { url?: string; error?: string };
      if (res.ok && data.url) {
        window.location.assign(data.url);
        return;
      }
      setError(data.error ?? 'No se pudo abrir el pago. Inténtalo de nuevo.');
    } catch {
      setError('Sin conexión. Inténtalo de nuevo.');
    }
    setBusy(false);
  }

  return (
    <form onSubmit={submit} className="card space-y-3 p-4">
      <div>
        <p className="text-sm font-bold text-white">Nueva empresa</p>
        <p className="mt-0.5 text-xs text-ink-300">
          Ideal si tienes varios locales (por ejemplo, varios bares). Todo queda en esta misma cuenta;
          la nueva empresa tiene su propio plan y se cobra desde el primer día (la prueba gratis es solo una vez por cuenta).
        </p>
      </div>
      <label className="block text-xs text-ink-300">
        Nombre de la empresa
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={80}
          placeholder="Ej.: Bar La Plaza"
          className="input mt-1 w-full"
        />
      </label>
      <label className="block text-xs text-ink-300">
        Plan para esta empresa
        <select value={plan} onChange={(e) => setPlan(e.target.value as PlanId)} className="input mt-1 w-full">
          {SELLABLE.map((id) => (
            <option key={id} value={id}>
              {PLANS[id].name} · {(PLANS[id].priceCents / 100).toFixed(0)} €/mes + IVA
            </option>
          ))}
        </select>
      </label>
      {error && <p className="text-xs text-red-300" role="alert">{error}</p>}
      <button type="submit" disabled={busy} className="btn-primary btn-sm">
        <CreditCard size={14} /> {busy ? 'Abriendo pago…' : 'Ir al pago'}
      </button>
    </form>
  );
}
