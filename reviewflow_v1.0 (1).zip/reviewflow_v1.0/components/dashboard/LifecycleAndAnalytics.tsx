'use client';

import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CreditCard,
  Percent,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import { useToast } from '@/components/Toast';
import type { ReviewItem, TenantInfo } from '@/components/dashboard/types';
import { GRACE_PERIOD_DAYS } from '@/lib/plans';

export { OnboardingChecklist } from '@/components/dashboard/OnboardingChecklist';
export { AnalyticsAndCompetitorsPanel } from '@/components/dashboard/AnalyticsAndCompetitorsPanel';

/**
 * Calcula la marca temporal actual en cliente fuera del cuerpo puro de renderizado
 * para cumplir con las reglas de pureza de React 19 (`react-hooks/purity`).
 */
function useClientNowMs(initialNowMs?: number): number | null {
  const [nowMs, setNowMs] = useState<number | null>(initialNowMs ?? null);
  useEffect(() => {
    setNowMs(Date.now());
  }, []);
  return nowMs;
}

/**
 * 1. Banner de seguridad cuando existe una sesión de soporte técnico (Impersonación con TTL de 15m).
 */
export function SupportImpersonationBanner({
  tenant,
  nowMs: propNowMs,
}: {
  tenant?: TenantInfo;
  nowMs?: number;
}) {
  const nowMs = useClientNowMs(propNowMs);
  const session = tenant?.settings?.active_support_session;

  if (!session?.expires_at || nowMs === null) return null;
  const expiresMs = new Date(session.expires_at).getTime();
  if (!Number.isFinite(expiresMs) || expiresMs < nowMs) return null;

  const remainingMin = Math.max(1, Math.ceil((expiresMs - nowMs) / 60_000));

  return (
    <div
      role="status"
      className="card border-amber-400/40 bg-amber-500/10 p-4 text-xs text-amber-100"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 font-bold text-amber-200">
          <ShieldAlert size={16} className="shrink-0 text-amber-300" />
          <span>
            Sesión auditada de soporte activa · Ticket #{session.ticket || 'SOPORTE'} ({session.actor_email})
          </span>
        </div>
        <span className="badge-warn">
          Expira en {remainingMin} min · Pagos y borrado bloqueados
        </span>
      </div>
      <p className="mt-1 text-amber-200/90">
        Motivo registrado en <code>admin_audit_events</code>: «{session.reason}». Por seguridad RGPD, ninguna operación de facturación o supresión está permitida durante esta sesión.
      </p>
    </div>
  );
}

/**
 * 3. Banner de Prueba de 7 días (avisos a 3d, 1d, 0d + resumen de valor) y Periodo de Gracia Dunning (3 días).
 */
export function TrialAndGraceBanner({
  tenant,
  reviewsCount,
  onOpenBilling,
  nowMs: propNowMs,
}: {
  tenant?: TenantInfo;
  reviewsCount: number;
  onOpenBilling: () => void;
  nowMs?: number;
}) {
  const nowMs = useClientNowMs(propNowMs);
  if (!tenant) return null;

  const managedReviews = Math.max(1, reviewsCount);
  const hoursSaved = Math.max(0.5, Math.round(((managedReviews * 7) / 60) * 10) / 10);

  if (tenant.subscription_status === 'past_due') {
    const graceEndRaw = tenant.grace_period_ends_at || tenant.settings?.grace_period_ends_at;
    const daysLeft =
      graceEndRaw && nowMs !== null
        ? Math.max(1, Math.ceil((new Date(graceEndRaw).getTime() - nowMs) / 86_400_000))
        : GRACE_PERIOD_DAYS;

    return (
      <div className="card border-amber-400/40 bg-amber-500/10 p-4 text-xs text-amber-100">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <AlertTriangle size={18} className="mt-0.5 shrink-0 text-amber-300" />
            <div>
              <p className="font-bold text-white">
                Fallo puntual en el cobro de tu tarjeta · Tienes {daysLeft} día(s) de periodo de gracia activo
              </p>
              <p className="mt-0.5 text-amber-200/90">
                No hemos cortado tu acceso: tus integraciones y respuestas IA siguen activas mientras Stripe realiza reintentos inteligentes (Smart Retries). Actualiza tu método de pago para evitar interrupciones.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="/api/stripe/portal" className="btn-primary btn-sm">
              <CreditCard size={13} /> Actualizar tarjeta ahora
            </a>
            <button type="button" onClick={onOpenBilling} className="btn-secondary btn-sm">
              Ver facturación
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (tenant.subscription_status === 'trialing' && tenant.trial_ends_at) {
    const msLeft = nowMs !== null ? new Date(tenant.trial_ends_at).getTime() - nowMs : 7 * 86_400_000;
    const daysLeft = Math.max(0, Math.ceil(msLeft / 86_400_000));
    const urgent = daysLeft <= 3;

    return (
      <div
        className={`card p-4 text-xs ${
          urgent
            ? 'border-amber-400/35 bg-amber-500/10 text-amber-100'
            : 'border-brand-400/25 bg-brand-500/10 text-brand-100'
        }`}
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Sparkles size={16} className="shrink-0 text-brand-300" />
            <div>
              <p className="font-bold text-white">
                {daysLeft === 0
                  ? '⏰ Tu prueba gratuita termina hoy'
                  : daysLeft === 1
                    ? '⏰ Queda 1 día de tu prueba gratuita'
                    : `Prueba gratuita activa (${daysLeft} días restantes)`}{' '}
                · Resumen de valor en {tenant.name}:
              </p>
              <p className="mt-0.5 text-ink-200">
                En tu prueba hemos gestionado <strong>{managedReviews} reseñas</strong> y ahorrado{' '}
                <strong>~{hoursSaved} h</strong> de trabajo a tu equipo.
              </p>
            </div>
          </div>
          <button type="button" onClick={onOpenBilling} className="btn-secondary btn-sm">
            Pasar a plan anual (2 meses gratis) →
          </button>
        </div>
      </div>
    );
  }

  return null;
}

/**
 * 4. Paywall Contextual con datos retenidos visibles y Descuento de Recuperación Automático (-20% primer mes).
 */
export function ContextualPaywallCard({
  tenant,
  reviews,
  onOpenBilling,
}: {
  tenant?: TenantInfo;
  reviews: ReviewItem[];
  onOpenBilling: () => void;
}) {
  const toast = useToast();
  const [applyingDiscount, setApplyingDiscount] = useState(false);

  const totalReviews = Math.max(reviews.length, 12);
  const repliedCount = reviews.filter((r) => r.replied).length;
  const hoursSaved = Math.max(1.5, Math.round(((totalReviews * 7) / 60) * 10) / 10);

  async function applyRecoveryOffer() {
    if (!tenant) return;
    setApplyingDiscount(true);
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'apply_recovery_discount',
          tenantId: tenant.id,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo aplicar el descuento', body: data.error });
        return;
      }
      toast({
        kind: 'success',
        title: '¡Descuento del 20 % activado!',
        body: data.message,
      });
      setTimeout(() => window.location.reload(), 800);
    } finally {
      setApplyingDiscount(false);
    }
  }

  return (
    <div className="card border-rose-400/35 bg-rose-950/20 p-6">
      <div className="grid gap-6 lg:grid-cols-[1.25fr_1fr]">
        <div>
          <span className="badge-warn">
            <ShieldAlert size={13} /> Suscripción en pausa · Tus datos siguen 100 % seguros y visibles
          </span>
          <h2 className="mt-3 text-xl font-extrabold text-white">
            Todo el trabajo hecho en {tenant?.name || 'tu empresa'} te está esperando
          </h2>
          <p className="mt-1.5 text-sm text-ink-300">
            Mantenemos intacto tu histórico de reseñas, tus reglas de tono de marca y tu código QR. Solo están pausadas las nuevas sincronizaciones y envíos hasta que reactives tu plan.
          </p>

          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <p className="text-2xs uppercase text-ink-400">Reseñas custodiadas</p>
              <p className="mt-1 text-xl font-extrabold text-white">{totalReviews}</p>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <p className="text-2xs uppercase text-ink-400">Respuestas IA listas</p>
              <p className="mt-1 text-xl font-extrabold text-emerald-300">{repliedCount}</p>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <p className="text-2xs uppercase text-ink-400">Tiempo ahorrado</p>
              <p className="mt-1 text-xl font-extrabold text-brand-300">~{hoursSaved} h</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col justify-between rounded-2xl border border-emerald-400/30 bg-emerald-500/10 p-5">
          <div>
            <span className="badge-ok">
              <Percent size={12} /> Oferta automática de recuperación (-20 % primer mes)
            </span>
            <p className="mt-2 text-base font-bold text-white">
              Reactiva hoy con un 20 % de descuento inmediato
            </p>
            <p className="mt-1 text-xs text-ink-200">
              Usa el cupón automático <code>RECOVERY20</code> sin perder ni una sola reseña ni configuración de IA.
            </p>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {tenant && (
              <button
                type="button"
                disabled={applyingDiscount}
                onClick={applyRecoveryOffer}
                className="btn-primary btn-sm w-full justify-center"
              >
                <Sparkles size={14} />{' '}
                {applyingDiscount ? 'Activando descuento…' : 'Reactivar ahora con -20 % el primer mes'}
              </button>
            )}
            <a href="/api/stripe/portal" className="btn-secondary btn-sm flex-1 justify-center">
              <CreditCard size={14} /> Actualizar tarjeta
            </a>
            <button type="button" onClick={onOpenBilling} className="btn-quiet btn-sm">
              Ver planes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
