'use client';

import { formatEur, type PlanId } from '@/lib/plans';
import type { RetentionOffersView } from '@/lib/retention-offers';
import { BillingCancellationCard } from './BillingCancellationCard';

export interface BillingInvoiceItem {
  id: string;
  number: string;
  date: string;
  amountCents: number;
  status: string;
  pdfUrl?: string | null;
}

export interface SubscriptionOverviewInfo {
  ok?: boolean;
  taxInfo?: {
    taxId?: string;
    legalName?: string;
  };
  extraLocations?: number;
  invoices?: BillingInvoiceItem[];
  cancellation?: {
    mode: 'period_end' | 'now' | null;
    cancelAt: string | null;
    canReactivate: boolean;
  };
  pausedUntil?: string | null;
  retentionOffers?: RetentionOffersView;
}

export function BillingTaxAndRetentionSection({
  legalName,
  setLegalName,
  taxId,
  setTaxId,
  extraLocations,
  pauseReason,
  setPauseReason,
  processingAction,
  invoices,
  onSaveTax,
  onAddLocation: _onAddLocation,
  onPauseMonth,
  cancellation,
  onCancel,
  onReactivate,
  retentionOffers,
  onAcceptDiscount,
  onDowngradeOffer,
}: {
  legalName: string;
  setLegalName: (v: string) => void;
  taxId: string;
  setTaxId: (v: string) => void;
  extraLocations: number;
  pauseReason: string;
  setPauseReason: (v: string) => void;
  processingAction: string | null;
  invoices?: BillingInvoiceItem[];
  onSaveTax: (e: React.FormEvent) => void;
  onAddLocation: (nextCount: number) => void;
  onPauseMonth: () => void;
  cancellation?: SubscriptionOverviewInfo['cancellation'];
  onCancel: (mode: 'period_end' | 'now') => void;
  onReactivate: () => void;
  retentionOffers?: RetentionOffersView;
  onAcceptDiscount: () => Promise<boolean | undefined>;
  onDowngradeOffer: (plan: PlanId) => Promise<void> | void;
}) {
  const pauseMonths = retentionOffers?.pause.months ?? 1;
  const pauseEnabled = retentionOffers ? retentionOffers.pause.enabled : true;

  return (
    <>
      <div className="grid gap-4 lg:grid-cols-2">
        <form onSubmit={onSaveTax} className="card space-y-3">
          <h3 className="text-sm font-bold text-white">
            Datos fiscales para facturas (NIF / CIF / Razón Social)
          </h3>
          <p className="text-xs text-ink-400">
            Se aplican automáticamente a tus facturas de Stripe Tax (España / UE).
          </p>
          <div className="grid gap-2.5 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="billing-legal-name">
                Razón social o nombre autónomo
              </label>
              <input
                id="billing-legal-name"
                className="input text-xs"
                placeholder="Ej: Hostelería Bella Roma S.L."
                value={legalName}
                onChange={(e) => setLegalName(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="label" htmlFor="billing-tax-id">
                NIF / CIF / IVA intracomunitario
              </label>
              <input
                id="billing-tax-id"
                className="input font-mono text-xs uppercase"
                placeholder="Ej: B12345678 / ESB12345678"
                value={taxId}
                onChange={(e) => setTaxId(e.target.value)}
                required
              />
            </div>
          </div>
          <div className="flex items-center justify-between pt-1">
            <span className="text-2xs text-ink-400">IVA calculado según país fiscal</span>
            <button type="submit" disabled={processingAction === 'tax'} className="btn-secondary btn-sm">
              {processingAction === 'tax' ? 'Guardando…' : 'Guardar datos fiscales'}
            </button>
          </div>
        </form>

        <div className="card space-y-3">
          <h3 className="text-sm font-bold text-white">
            Sedes adicionales y pausa de suscripción
          </h3>
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.02] p-3 text-xs">
            <div>
              <p className="font-semibold text-white">
                Sedes activas: {1 + extraLocations} ({extraLocations} extra)
              </p>
              <p className="text-2xs text-ink-400">
                ¿Necesitas más locales o tiendas en la misma cuenta? Escríbenos y te lo activamos (+15 €/sede).
              </p>
            </div>
            <a href="/contacto" className="btn-secondary btn-sm">
              Solicitar sede extra
            </a>
          </div>

          {pauseEnabled && (
          <div className="rounded-xl border border-amber-400/25 bg-amber-500/[0.06] p-3 text-xs">
            <p className="font-semibold text-amber-200">
              ¿Necesitas un descanso? Pausa tu suscripción {pauseMonths === 1 ? '1 mes' : `${pauseMonths} meses`} sin perder tus datos
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <select
                className="select flex-1 text-xs"
                value={pauseReason}
                onChange={(e) => setPauseReason(e.target.value)}
                aria-label="Motivo de pausa o cancelación"
              >
                <option value="Necesito pausar 1 mes por temporada baja">Temporada baja / cierre vacacional</option>
                <option value="Estoy ajustando presupuesto este mes">Ajuste puntual de presupuesto</option>
                <option value="Falta integrar una plataforma concreta">Necesito ayuda con las conexiones</option>
              </select>
              <button
                type="button"
                disabled={processingAction === 'pause'}
                onClick={onPauseMonth}
                className="btn-secondary btn-sm"
              >
                {processingAction === 'pause' ? 'Pausando…' : `Pausar ${pauseMonths === 1 ? '1 mes' : `${pauseMonths} meses`} (0 €)`}
              </button>
            </div>
          </div>
          )}
        </div>
      </div>

      <BillingCancellationCard
        processingAction={processingAction}
        cancellation={cancellation}
        onCancel={onCancel}
        onReactivate={onReactivate}
        retentionOffers={retentionOffers}
        onAcceptDiscount={onAcceptDiscount}
        onDowngradeOffer={onDowngradeOffer}
        onPauseMonth={onPauseMonth}
      />

      {invoices && invoices.length > 0 && (
        <div className="card space-y-3">
          <h3 className="text-sm font-bold text-white">Tus facturas y recibos descargables</h3>
          <div className="divide-y divide-white/[0.06] text-xs">
            {invoices.map((inv: BillingInvoiceItem) => (
              <div key={inv.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                <div>
                  <span className="font-mono font-semibold text-white">#{inv.number}</span>
                  <span className="ml-2 text-ink-400">{new Date(inv.date).toLocaleDateString('es-ES')}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold text-white">{formatEur(inv.amountCents)}</span>
                  <span className="badge-ok">{inv.status}</span>
                  {inv.pdfUrl && (
                    <a href={inv.pdfUrl} target="_blank" rel="noreferrer" className="text-brand-300 underline">
                      Descargar PDF
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
