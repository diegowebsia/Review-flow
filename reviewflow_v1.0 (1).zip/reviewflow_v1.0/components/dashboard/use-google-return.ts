'use client';

import { useEffect } from 'react';
import type { useToast } from '@/components/Toast';

type ToastFn = ReturnType<typeof useToast>;
type SyncFn = (provider: 'google' | 'trustpilot' | 'places', tenantId: string) => Promise<void> | void;

/** Vuelta del OAuth de Google (?google=…): aviso claro y primera importación automática. */
export function useGoogleReturn(tenantId: string | undefined, toast: ToastFn, sync: SyncFn) {
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const url = new URL(window.location.href);
    const status = url.searchParams.get('google');
    if (!status) return;
    url.searchParams.delete('google');
    window.history.replaceState(null, '', url.toString());
    const messages: Record<string, [string, string]> = {
      not_configured: ['Google no está configurado', 'Falta configurar el acceso a Google en el servidor.'],
      no_subscription: ['Suscripción sin acceso', 'Activa o reactiva tu plan para conectar Google.'],
      trial_expired: ['Prueba terminada', 'Reactiva tu suscripción para conectar Google.'],
      suspended: ['Empresa suspendida', 'Contacta con soporte para reactivarla.'],
      feature_not_included: ['No incluido en tu plan', 'Tu plan no incluye la conexión con Google Business.'],
      forbidden: ['Sin permiso', 'Tu usuario no puede conectar Google en esta empresa.'],
      invalid_state: ['Enlace caducado', 'Vuelve a pulsar «Conectar Google».'],
      error: ['No se pudo conectar Google', 'Inténtalo de nuevo en unos minutos.'],
      nodb: ['Servicio no disponible', 'Inténtalo de nuevo en unos minutos.'],
    };
    if (status === 'connected') {
      toast({ kind: 'success', title: 'Google conectado', body: 'Importando tus primeras reseñas…' });
      if (tenantId) void sync('google', tenantId);
      return;
    }
    const [title, body] = messages[status] ?? messages.error;
    toast({ kind: 'warning', title, body });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
