'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { BadgeCheck, Bot, CheckCircle2, Send, Sparkles, Undo2 } from 'lucide-react';
import { Spinner } from '@/components/Skeleton';
import { Stars } from '@/components/dashboard/Stars';
import { EASE } from '@/components/Motion';
import type { ReviewItem } from '@/components/dashboard/types';
import { useReviewCard } from '@/components/dashboard/review-card/use-review-card';
import { cn } from '@/lib/utils';

/**
 * Reseña de la bandeja: borrador IA → edición → publicación.
 * Cada borrador consume 1 evento de IA (controlado por el backend).
 */
export function ReviewCard({
  review: r,
  draft,
  published,
  tone,
  onDraftChange,
  onPublished,
}: {
  review: ReviewItem;
  draft?: string;
  published: boolean;
  tone: 'profesional' | 'cercano' | 'formal';
  onDraftChange: (id: string, value: string) => void;
  onPublished: (id: string) => void;
}) {
  const {
    toast,
    generating,
    publishing,
    showDraft,
    setShowDraft,
    providerUsed,
    showIntelligence,
    intelligence,
    loadingIntel,
    humanizeSchedule,
    setHumanizeSchedule,
    replied,
    generateReply,
    toggleIntelligence,
    publishReply,
  } = useReviewCard({ review: r, draft, published, tone, onDraftChange, onPublished });

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.3, ease: EASE }}
      className={cn('card card-hover', replied && 'border-emerald-400/20')}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-bold tracking-tightish text-white">
            {r.author} <span className="font-normal text-ink-500">· {r.tenant}</span>
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-ink-400">
            <Stars n={r.rating} />
            <span className="badge capitalize">{r.source}</span>
            {r.verified && (
              <span className="badge-ok">
                <BadgeCheck size={11} /> Verificada
              </span>
            )}
            <span>{new Date(r.created_at).toLocaleDateString('es-ES')}</span>
            {replied ? (
              <span className="badge-ok">
                <CheckCircle2 size={11} /> respondida
              </span>
            ) : (
              <span className="badge-warn">pendiente</span>
            )}
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button
            onClick={toggleIntelligence}
            className="btn-secondary btn-sm"
            title="Ver análisis de sentimiento y sugerencias rápidas"
          >
            <Sparkles size={13} className="text-brand-300" />
            <span className="hidden sm:inline">Inteligencia IA</span>
          </button>
          {r.reply && !draft && (
            <button
              onClick={() => {
                onDraftChange(r.id, r.reply as string);
                setShowDraft(true);
              }}
              className="btn-quiet btn-sm"
            >
              <Undo2 size={13} /> Ver respuesta
            </button>
          )}
          <button
            disabled={generating}
            onClick={() => generateReply()}
            className={cn('btn-sm', replied ? 'btn-secondary' : 'btn-primary')}
          >
            {generating ? <Spinner label="Generando…" size={13} /> : (<><Bot size={13} /> Responder con IA</>)}
          </button>
        </div>
      </div>

      <p translate="no" className="notranslate mt-3 text-sm leading-relaxed text-ink-200">{r.text}</p>

      {/* Panel de Inteligencia IA y Triaje de Sentimiento */}
      <AnimatePresence initial={false}>
        {showIntelligence && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: EASE }}
            className="overflow-hidden"
          >
            <div className="mt-3 rounded-xl border border-brand-500/20 bg-brand-950/30 p-3.5 text-xs">
              {loadingIntel ? (
                <div className="flex items-center gap-2 text-ink-300">
                  <Spinner label="Analizando reseña…" size={13} />
                  <span>Extrayendo sentimiento, causas raíz y variantes…</span>
                </div>
              ) : intelligence ? (
                <div className="space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-semibold text-brand-200">Diagnóstico IA:</span>
                      <span
                        className={cn(
                          'rounded-md px-2 py-0.5 text-2xs font-bold uppercase tracking-wider',
                          intelligence.sentiment === 'muy_positivo' || intelligence.sentiment === 'positivo'
                            ? 'border border-emerald-500/30 bg-emerald-500/15 text-emerald-300'
                            : intelligence.sentiment === 'neutral'
                              ? 'border border-amber-500/30 bg-amber-500/15 text-amber-300'
                              : 'border border-rose-500/30 bg-rose-500/15 text-rose-300',
                        )}
                      >
                        {intelligence.sentiment.replace('_', ' ')}
                      </span>
                      <span className="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 text-2xs text-ink-300">
                        Riesgo fuga: <strong className="text-white capitalize">{intelligence.churnRisk}</strong>
                      </span>
                      <span className="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 text-2xs text-ink-300">
                        Idioma: <strong className="text-white uppercase">{intelligence.language}</strong>
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {intelligence.topics?.map((topic: string) => (
                        <span key={topic} className="rounded-md bg-brand-500/10 px-1.5 py-0.5 text-2xs text-brand-300">
                          #{topic}
                        </span>
                      ))}
                    </div>
                  </div>

                  <p className="text-ink-200">
                    <strong className="text-white">Consejo operativo:</strong> {intelligence.recommendedAction}
                  </p>

                  {intelligence.spamAnalysis?.isSuspicious && (
                    <div className="rounded-lg border border-rose-400/35 bg-rose-500/10 p-2.5 text-xs text-rose-100">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-bold text-rose-200">
                          🚨 Posible reseña falsa / spam detectada ({intelligence.spamAnalysis.confidenceScore}/100) ·{' '}
                          {intelligence.spamAnalysis.googlePolicyLabel}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard?.writeText(intelligence.spamAnalysis?.reportDossier ?? '');
                            toast({
                              kind: 'success',
                              title: 'Dossier de disputa copiado',
                              body: 'Pégalo en el formulario de moderación de Google Business Profile.',
                            });
                          }}
                          className="rounded-md border border-rose-300/40 bg-rose-500/20 px-2 py-0.5 text-2xs font-semibold text-white hover:bg-rose-500/30"
                        >
                          Copiar informe para Google
                        </button>
                      </div>
                      <ul className="mt-1.5 list-disc pl-4 text-2xs text-rose-200/90">
                        {intelligence.spamAnalysis.reasons.map((reason: string) => (
                          <li key={reason}>{reason}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="pt-1">
                    <p className="mb-1.5 text-2xs font-semibold uppercase tracking-wider text-ink-400">
                      Sugerencias de respuesta directa (haz clic para cargar en el borrador):
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        onClick={() => generateReply(intelligence.suggestedReplyVariant?.standard)}
                        className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-2xs font-medium text-ink-200 transition hover:border-brand-400/40 hover:bg-brand-500/15 hover:text-white"
                      >
                        🎯 Estándar recomendada
                      </button>
                      <button
                        onClick={() => generateReply(intelligence.suggestedReplyVariant?.short)}
                        className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-2xs font-medium text-ink-200 transition hover:border-brand-400/40 hover:bg-brand-500/15 hover:text-white"
                      >
                        ⚡ Rápida y directa
                      </button>
                      <button
                        onClick={() => generateReply(intelligence.suggestedReplyVariant?.loyaltyRecovery)}
                        className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-2xs font-medium text-ink-200 transition hover:border-brand-400/40 hover:bg-brand-500/15 hover:text-white"
                      >
                        💎 Fidelización / Recuperación
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-ink-400">No se pudieron cargar los datos de inteligencia.</p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {generating && (
        <div className="mt-3 space-y-2 rounded-xl border border-white/[0.07] bg-white/[0.03] p-3.5" aria-busy="true">
          <p className="flex items-center gap-2 text-xs font-semibold text-brand-200">
            <Sparkles size={13} className="animate-pulse" /> La IA está redactando tu respuesta…
          </p>
          <span className="skeleton block h-3 w-full" />
          <span className="skeleton block h-3 w-11/12" />
          <span className="skeleton block h-3 w-2/3" />
        </div>
      )}

      <AnimatePresence initial={false}>
        {showDraft && draft !== undefined && !generating && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="notranslate overflow-hidden"
            translate="no"
          >
            <div className="mt-3 rounded-xl border border-brand-400/25 bg-brand-500/10 p-3.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-brand-200">
                  <Sparkles size={13} /> Borrador IA — revísalo antes de publicar
                </p>
                {providerUsed && (
                  <span className="rounded-full border border-brand-400/30 bg-brand-500/20 px-2 py-0.5 text-2xs font-semibold text-brand-300">
                    Motor: {providerUsed === 'gemini' ? 'Google Gemini 2.5 Flash' : 'Plantilla Local'}
                  </span>
                )}
              </div>
              <textarea
                className="textarea mt-2.5 min-h-[104px] bg-ink-950/60"
                value={draft}
                onChange={(e) => onDraftChange(r.id, e.target.value)}
                aria-label="Borrador de respuesta"
              />
              <div className="mt-2.5 flex flex-wrap items-center gap-2">
                <button disabled={publishing} onClick={publishReply} className="btn-primary btn-sm">
                  {publishing ? <Spinner label="Publicando…" size={13} /> : (<><Send size={13} /> Publicar respuesta</>)}
                </button>
                <button onClick={() => setShowDraft(false)} className="btn-quiet btn-sm">
                  Ocultar
                </button>
                <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-2xs text-ink-200">
                  <input
                    type="checkbox"
                    checked={humanizeSchedule}
                    onChange={(e) => setHumanizeSchedule(e.target.checked)}
                    className="h-3 w-3 rounded border-ink-600"
                  />
                  Cadencia humana (evitar publicar de madrugada)
                </label>
                <span className="ml-auto text-2xs text-ink-500">
                  {r.source === 'google'
                    ? 'Con Google conectado se publica directamente en la plataforma.'
                    : 'Se guarda en tu bandeja y puedes copiarla a la plataforma.'}
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.article>
  );
}
