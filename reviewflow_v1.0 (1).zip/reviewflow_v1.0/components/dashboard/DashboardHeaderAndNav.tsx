'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { CircleHelp, CreditCard, LogOut, Star, UserRound } from 'lucide-react';
import { LanguageSelector } from '@/components/LanguageSelector';
import { ThemeToggle } from '@/components/ThemeToggle';
import { EASE } from '@/components/Motion';
import type { DashboardTabId } from '@/components/dashboard/use-dashboard-state';
import type { TenantInfo } from '@/components/dashboard/types';
import { planOf } from '@/lib/plans';
import { version } from '@/lib/site';
import { cn } from '@/lib/utils';

type DashboardTab = { id: DashboardTabId; label: string; icon: React.ReactNode };

const CONNECTED_STATES = new Set(['connected', 'active', 'ok', 'synced']);

/** Nº de integraciones activas del negocio (sin inventar estados). */
function connectedCount(tenant?: TenantInfo) {
  return (tenant?.integrations ?? []).filter((i) =>
    CONNECTED_STATES.has(String(i.status).toLowerCase()),
  ).length;
}

/** Barra lateral de escritorio: navegación principal del panel. */
export function DashboardSidebar({
  tab,
  setTab,
  tabs,
}: {
  tab: DashboardTabId;
  setTab: (next: DashboardTabId) => void;
  tabs: DashboardTab[];
}) {
  return (
    <aside
      aria-label="Navegación principal del panel"
      className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-white/[0.07] bg-[rgba(12,17,28,0.72)] backdrop-blur-xl md:flex"
    >
      <Link
        href="/"
        className="group flex h-16 items-center gap-2.5 px-5 font-display font-bold tracking-tightish text-white"
      >
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] shadow-[0_8px_24px_-10px_rgba(37,99,235,0.95)] transition-transform duration-300 group-hover:scale-105">
          <Star size={17} fill="currentColor" />
        </span>
        ReviewFlow
      </Link>

      <nav className="flex-1 space-y-1 px-3 py-4">
        {tabs.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              aria-current={active ? 'page' : undefined}
              className={cn(
                'relative flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold outline-none transition-colors duration-200',
                'focus-visible:ring-2 focus-visible:ring-brand-400/70 focus-visible:ring-offset-2 focus-visible:ring-offset-ink-950',
                active
                  ? 'bg-white/[0.06] text-white'
                  : 'text-ink-300 hover:bg-white/[0.03] hover:text-ink-100',
              )}
            >
              {active && (
                <motion.span
                  layoutId="dash-rail"
                  transition={{ duration: 0.28, ease: EASE }}
                  className="absolute inset-y-1.5 left-0 w-0.5 rounded-full bg-[linear-gradient(180deg,#3b76f0,#8b5cf6)]"
                  aria-hidden="true"
                />
              )}
              <span className={active ? 'text-brand-300' : ''}>{t.icon}</span>
              {t.label}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-white/[0.07] px-5 py-4 text-2xs text-ink-400">
        v{version || '1.0'}
      </div>
    </aside>
  );
}

/** Cabecera compacta: negocio activo, conexiones, ayuda, idioma, tema, plan y cuenta. */
export function DashboardTopHeader({
  userEmail,
  primaryTenant,
  tenants = [],
  onOpenHelp,
  onOpenConnections,
}: {
  userEmail: string;
  primaryTenant?: TenantInfo;
  tenants?: TenantInfo[];
  onOpenHelp: () => void;
  onOpenConnections: () => void;
}) {
  
  const connected = connectedCount(primaryTenant);

  return (
    <header className="nav-blur sticky top-0 z-30 border-b border-white/[0.07] bg-[rgba(9,13,22,0.82)]">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
        <div className="min-w-0 flex-1">
          {tenants.length > 1 ? (
            <label className="block">
              <span className="sr-only">Cambiar de empresa</span>
              <select
                value={primaryTenant?.id}
                onChange={(e) => {
                  const params = new URLSearchParams(window.location.search);
                  params.set('empresa', e.target.value);
                  window.location.assign(`/dashboard?${params.toString()}`);
                }}
                className="max-w-full truncate rounded-md border border-white/10 bg-white/[0.04] px-2 py-1 font-display text-sm font-bold text-white"
              >
                {tenants.map((t) => (
                  <option key={t.id} value={t.id} className="bg-ink-900">
                    {t.name}
                  </option>
                ))}
              </select>
            </label>
          ) : (
            <p className="truncate font-display text-sm font-bold tracking-tightish text-white">
              {primaryTenant?.name ?? 'Sin negocio activo'}
            </p>
          )}
          <p className="truncate text-2xs text-ink-400">
            {primaryTenant ? planOf(primaryTenant.plan).tier : userEmail}
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenConnections}
          className="hidden items-center gap-1.5 rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1.5 text-2xs font-semibold text-ink-200 transition hover:border-white/20 hover:text-white sm:inline-flex"
        >
          <span
            className={cn(
              'h-1.5 w-1.5 rounded-full',
              connected > 0 ? 'bg-emerald-400' : 'bg-amber-400',
            )}
            aria-hidden="true"
          />
          {connected > 0 ? `${connected} conexiones activas` : 'Sin conexiones'}
        </button>

        <div className="flex items-center gap-1.5 text-sm">
          <LanguageSelector showCurrency />
          <ThemeToggle />
          <button
            type="button"
            onClick={onOpenHelp}
            className="btn-quiet btn-sm"
            aria-label={"Ayuda"}
          >
            <CircleHelp size={14} />
            <span className="sr-only sm:not-sr-only">{"Ayuda"}</span>
          </button>
          <a
            href="/api/stripe/portal"
            className="btn-secondary btn-sm"
            aria-label={"Suscripción"}
          >
            <CreditCard size={14} />
            <span className="hidden lg:inline">{"Suscripción"}</span>
          </a>
          <Link href="/cuenta" className="btn-quiet btn-sm" aria-label="Mi cuenta" title={userEmail}>
            <UserRound size={14} />
            <span className="hidden xl:inline">Mi cuenta</span>
          </Link>
          <form action="/api/auth/signout" method="post">
            <button type="submit" className="btn-quiet btn-sm" aria-label={"Salir"}>
              <LogOut size={14} />
              <span className="sr-only">{"Salir"}</span>
            </button>
          </form>
        </div>
      </div>
    </header>
  );
}

export function DashboardBottomNavAndFooter({
  tab,
  setTab,
  tabs,
}: {
  tab: DashboardTabId;
  setTab: (next: DashboardTabId) => void;
  tabs: DashboardTab[];
}) {
  

  return (
    <>
      <nav
        aria-label="Navegación móvil del panel"
        className="fixed inset-x-0 bottom-0 z-50 border-t border-white/10 bg-slate-900/95 backdrop-blur-lg md:hidden"
      >
        <div className="grid grid-cols-5">
          {tabs.map((t) => {
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'flex min-h-[52px] flex-col items-center justify-center gap-1 px-1 py-2 text-[11px] font-semibold transition-colors',
                  'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-brand-400/70',
                  active ? 'text-brand-300' : 'text-ink-300 hover:text-white',
                )}
              >
                {t.icon}
                <span className="max-w-full truncate">{t.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      <footer className="mt-10 border-t border-white/[0.06] px-4 py-6 text-xs text-ink-400 sm:px-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span>
            ReviewFlow AI <strong className="font-mono text-ink-200">v{version || '1.0'}</strong>{' '}
            · {"Datos alojados en la UE"}
          </span>
          <span className="flex items-center gap-3">
            <a
              href="/health"
              target="_blank"
              rel="noreferrer"
              className="transition hover:text-ink-200"
            >
              /health
            </a>
            <span>·</span>
            <Link href="/status" className="transition hover:text-ink-200">
              {"Estado del Servicio (SLA)"}
            </Link>
          </span>
        </div>
      </footer>
    </>
  );
}
