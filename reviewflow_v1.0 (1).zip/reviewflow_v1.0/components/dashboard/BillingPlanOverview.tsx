'use client';

import Link from 'next/link';
import {
  BadgeCheck,
  CalendarClock,
  CreditCard,
  Gauge,
  Receipt,
  ShieldCheck,
  Sparkles,
  TriangleAlert,
} from 'lucide-react';
import { AddonPicker } from '@/components/AddonPicker';
import { AiBudget, QuotaMeter, StorageCaps } from '@/components/Quota';
import { QuotaSkeleton } from '@/components/Skeleton';
import type { StorageView, TenantInfo, UsageResponse } from '@/components/dashboard/types';
import { formatEur, planOf, type PlanId } from '@/lib/plans';

const FEATURE_ROWS: Array<[string, string]> = [
  ['googleBusiness', 'Google Business Profile (OAuth)'],
  ['googlePlaces', 'Google Places API por Place ID'],
  ['trustpilot', 'Trustpilot Business API'],
  ['aiReplies', 'Borradores de respuesta con IA'],
  ['privateFilter', 'Canal privado de quejas'],
  ['publishToGoogle', 'Publicación directa en Google'],
  ['mapsLinks', 'Enlaces «déjanos una reseña»'],
  ['storeIntegration', 'Conexión con tienda (Shopify/Woo)'],
  ['publicApi', 'API pública de ingesta'],
  ['emailRequests', 'Peticiones de opiniones por email'],
];

export function BillingPlanOverview({
  tenant,
  usage,
  loading,
  onPlanChange,
}: {
  tenant: TenantInfo;
  usage: UsageResponse | null;
  loading: boolean;
  onPlanChange: (targetPlan: PlanId, isUpgrade: boolean) => void;
}) {
  const plan = planOf(tenant.plan);
  const trialActive = tenant.subscription_status === 'trialing';
  const blocked = !tenant.access;

  return (
    <>
      <div className="grid gap-4 lg:grid-cols-[1.15fr_1fr]">
        <div className="card relative overflow-hidden">
          <div className="pointer-events-none absolute -right-20 -top-20 h-52 w-52 rounded-full bg-brand-600/18 blur-3xl" aria-hidden />
          <div className="relative flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="kicker">Plan contratado</p>
              <h2 className="mt-2 flex items-center gap-2 text-2xl font-extrabold tracking-tighter text-white">
                {plan.name}
                <span className="badge-brand">{plan.tier}</span>
              </h2>
              <p className="mt-1.5 text-sm text-ink-300">
                {formatEur(plan.priceCents)} / mes ·{' '}
                {plan.limits.requestsPerMonth.toLocaleString('es-ES')} peticiones/mes · 1 empresa
              </p>
            </div>
            <StatusBadge status={tenant.subscription_status} suspended={tenant.suspended} />
          </div>

          <div className="relative mt-5 grid gap-2.5 sm:grid-cols-3">
            <InfoTile
              icon={<CalendarClock size={14} />}
              label={trialActive ? 'Prueba hasta' : 'Renovación'}
              value={
                trialActive && tenant.trial_ends_at
                  ? new Date(tenant.trial_ends_at).toLocaleDateString('es-ES')
                  : usage?.renewalLabel ?? '—'
              }
            />
            <InfoTile
              icon={<Gauge size={14} />}
              label="Peticiones del mes"
              value={usage ? `${usage.metrics.requests.used} / ${usage.metrics.requests.quota}` : '—'}
            />
            <InfoTile
              icon={<Receipt size={14} />}
              label="Almacenamiento"
              value={usage ? `${usage.storage.usedMb} / ${usage.storage.limitMb} MB` : '—'}
            />
          </div>

          <div className="relative mt-5 flex flex-wrap gap-2">
            <a href="/api/stripe/portal" className="btn-secondary btn-sm">
              <CreditCard size={14} /> Portal de facturación (Stripe)
            </a>
            <Link href="/bienvenido" className="btn-quiet btn-sm">
              Cambiar de plan
            </Link>
            <a href="/#planes" className="btn-quiet btn-sm">
              Ver comparativa
            </a>
          </div>

          {trialActive && tenant.trial_ends_at && (
            <p className="relative mt-4 flex items-start gap-2 rounded-xl border border-brand-400/25 bg-brand-500/10 p-3 text-xs text-brand-100">
              <Sparkles size={14} className="mt-0.5 shrink-0" />
              Estás en prueba gratuita hasta el{' '}
              <strong>{new Date(tenant.trial_ends_at).toLocaleDateString('es-ES')}</strong>. Ese día se
              cobra el primer mes con la tarjeta que diste de alta; si no se completa el pago, el
              acceso al panel se pausa automáticamente.
            </p>
          )}
          {blocked && (
            <p className="relative mt-4 flex items-start gap-2 rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-xs text-rose-100">
              <TriangleAlert size={14} className="mt-0.5 shrink-0" />
              Acceso bloqueado: tu suscripción no está activa ({tenant.subscription_status}). Actualiza
              el pago o contrata un plan para reactivar las integraciones.
            </p>
          )}
        </div>

        <div className="card">
          <p className="kicker">Qué incluye tu plan</p>
          <ul className="mt-3 space-y-2 text-sm">
            {FEATURE_ROWS.map(([key, label]) => {
              const on = Boolean(plan.features[key as keyof typeof plan.features]);
              return (
                <li key={key} className="flex items-center gap-2.5">
                  {on ? (
                    <BadgeCheck size={15} className="shrink-0 text-emerald-400" />
                  ) : (
                    <span className="flex h-[15px] w-[15px] shrink-0 items-center justify-center rounded-full border border-ink-600" />
                  )}
                  <span className={on ? 'text-ink-200' : 'text-ink-500 line-through decoration-ink-600/60'}>
                    {label}
                  </span>
                </li>
              );
            })}
          </ul>
          <div className="divider my-4" />
          <p className="text-xs text-ink-400">
            Cuota mensual: {plan.limits.requestsPerMonth.toLocaleString('es-ES')} peticiones de opiniones ·{' '}
            {plan.limits.reviewsPerMonth.toLocaleString('es-ES')} opiniones ·{' '}
            {plan.limits.aiRepliesPerMonth.toLocaleString('es-ES')} respuestas IA (
            {(plan.limits.aiTokensPerMonth / 1000).toLocaleString('es-ES')}k tokens) ·{' '}
            {plan.limits.syncsPerMonth.toLocaleString('es-ES')} sincronizaciones.
          </p>
          <p className="mt-2 flex items-center gap-1.5 text-xs text-ink-500">
            <ShieldCheck size={13} className="text-emerald-400" />
            Al agotar una cuota el servidor responde 429 y pausa esa función hasta el siguiente ciclo o
            hasta que amplíes con una recarga puntual.
          </p>
        </div>
      </div>

      <div className="card space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-bold tracking-tightish text-white">Consumo del ciclo actual</h3>
          {usage && (
            <span className="badge">
              ciclo {usage.cycle} · {usage.planLabel}
            </span>
          )}
        </div>

        {usage &&
          (['requests', 'reviews', 'ai', 'syncs'] as const).some((k) => {
            const m = usage.metrics[k];
            return m && m.quota > 0 && m.used / m.quota >= 0.8;
          }) && (
            <div className="rounded-xl border border-amber-400/35 bg-amber-500/10 p-3.5 text-xs text-amber-100">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-bold text-white">
                  ⚡ Has superado el 80 % de una de tus cuotas mensuales (quedan{' '}
                  {Math.max(0, usage.metrics.ai.quota - usage.metrics.ai.used)} respuestas IA ·{' '}
                  {Math.max(0, usage.metrics.requests.quota - usage.metrics.requests.used)} peticiones)
                </p>
                <button
                  type="button"
                  onClick={() => onPlanChange(plan.category === 'ecommerce' ? 'ecommerce_pro' : 'local_pro', true)}
                  className="btn-primary btn-sm"
                >
                  Ampliar en 1 clic (prorrateado) →
                </button>
              </div>
            </div>
          )}

        {loading && !usage ? (
          <div className="mt-4">
            <QuotaSkeleton />
          </div>
        ) : usage ? (
          <div className="mt-4 space-y-5">
            <QuotaMeter
              metrics={usage.metrics}
              cycle={usage.cycle}
              renewalLabel={usage.renewalLabel}
              blockedBy={usage.blockedBy}
            />
            {usage.aiUsage && <AiBudget ai={usage.aiUsage} />}
            <StorageCaps storage={usage.storage as StorageView} />
          </div>
        ) : (
          <p className="mt-3 text-sm text-ink-400">No se pudo cargar el consumo. Recarga la página.</p>
        )}
      </div>

      <AddonPicker
        variant="dashboard"
        tenantId={tenant.id}
        suggested={
          usage?.blockedBy === 'requests'
            ? 'extra_requests_1000'
            : usage?.blockedBy === 'reviews' || usage?.blockedBy === 'storage'
              ? 'extra_reviews_2000'
              : usage?.blockedBy === 'ai'
                ? 'extra_ai_500'
                : usage?.blockedBy === 'syncs'
                  ? 'extra_syncs_500'
                  : 'extra_requests_1000'
        }
        remaining={usage?.remaining ?? null}
        blocked={Boolean(usage && !usage.allowed)}
        onPurchased={() => window.dispatchEvent(new Event('rf:quota-refresh'))}
      />
    </>
  );
}

function InfoTile({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
      <p className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wider text-ink-400">
        <span className="text-brand-300">{icon}</span>
        {label}
      </p>
      <p className="mt-1 text-sm font-bold text-white">{value}</p>
    </div>
  );
}

function StatusBadge({ status, suspended }: { status: string; suspended: boolean }) {
  const map: Record<string, { label: string; className: string }> = {
    active: { label: 'Activa', className: 'badge-ok' },
    trialing: { label: 'En prueba', className: 'badge-brand' },
    past_due: { label: 'Pago pendiente', className: 'badge-warn' },
    canceled: { label: 'Cancelada', className: 'badge' },
    inactive: { label: 'Inactiva', className: 'badge' },
    paused: { label: 'Pausada', className: 'badge-warn' },
    none: { label: 'Sin plan', className: 'badge' },
  };
  const info = map[status] ?? { label: status, className: 'badge' };
  if (suspended) return <span className="badge-danger">Cuenta suspendida · contacta con soporte</span>;
  return <span className={info.className}>{info.label}</span>;
}
