'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { CreditCard, Zap } from 'lucide-react';
import { useToast } from '@/components/Toast';
import { EASE } from '@/components/Motion';
import { type TenantInfo, type UsageResponse } from '@/components/dashboard/types';
import {
  TRIAL_DAYS,
  type PlanId,
} from '@/lib/plans';
import { useCancellationActions } from '@/components/dashboard/useCancellationActions';
import { BillingPlanOverview } from '@/components/dashboard/BillingPlanOverview';
import { BillingPlanSwitcherCard } from '@/components/dashboard/BillingPlanSwitcherCard';
import {
  BillingTaxAndRetentionSection,
  type SubscriptionOverviewInfo,
} from '@/components/dashboard/BillingTaxAndRetentionSection';

/**
 * Pestaña «Facturación y cuota» del panel.
 * Modularizada en componentes pequeños y tipados sin `any`.
 */
export function BillingPanel({
  tenant,
  addonResult,
}: {
  tenant?: TenantInfo;
  addonResult?: 'success' | 'canceled' | null;
}) {
  const toast = useToast();
  const [usage, setUsage] = useState<UsageResponse | null>(null);
  const [loading, setLoading] = useState(Boolean(tenant));
  const [billingInterval, setBillingInterval] = useState<'month' | 'year'>('month');
  const [subInfo, setSubInfo] = useState<SubscriptionOverviewInfo | null>(null);
  const [taxId, setTaxId] = useState('');
  const [legalName, setLegalName] = useState('');
  const [extraLocations, setExtraLocations] = useState(0);
  const [pauseReason, setPauseReason] = useState('Necesito pausar 1 mes por temporada baja');
  const [processingAction, setProcessingAction] = useState<string | null>(null);

  const tenantId = tenant?.id;
  const tenantName = tenant?.name;

  useEffect(() => {
    if (!tenantId) return;
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        const [resUsage, resSub] = await Promise.all([
          fetch(`/api/tenants/usage?tenantId=${encodeURIComponent(tenantId)}`, { cache: 'no-store' }),
          fetch(`/api/stripe/subscription?tenantId=${encodeURIComponent(tenantId)}&interval=${billingInterval}`, {
            cache: 'no-store',
          }),
        ]);
        const data = await resUsage.json().catch(() => null);
        const subData = (await resSub.json().catch(() => null)) as SubscriptionOverviewInfo | null;
        if (!alive) return;
        if (resUsage.ok && data?.ok) setUsage(data as UsageResponse);
        if (resSub.ok && subData?.ok) {
          setSubInfo(subData);
          setTaxId(subData.taxInfo?.taxId ?? '');
          setLegalName(subData.taxInfo?.legalName ?? tenantName ?? '');
          setExtraLocations(Number(subData.extraLocations ?? 0));
        }
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : undefined;
        if (alive) toast({ kind: 'error', title: 'No se pudo leer tu facturación', body: msg });
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [tenantId, tenantName, billingInterval, toast]);

  async function handlePlanChange(targetPlan: PlanId, isUpgrade: boolean) {
    if (!tenant) return;
    setProcessingAction(targetPlan);
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(
          isUpgrade
            ? { action: 'upgrade', tenantId: tenant.id, targetPlan, interval: billingInterval }
            : { action: 'downgrade', tenantId: tenant.id, targetPlan },
        ),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (res.status === 409 && data.checkoutUrl) {
          window.location.assign(data.checkoutUrl);
          return;
        }
        toast({ kind: 'error', title: 'No se pudo actualizar el plan', body: data.error });
        return;
      }
      toast({
        kind: 'success',
        title: isUpgrade ? '¡Plan ampliado en 1 clic!' : 'Cambio programado a fin de ciclo',
        body: data.message,
      });
      window.dispatchEvent(new Event('rf:quota-refresh'));
      if (isUpgrade) setTimeout(() => window.location.reload(), 800);
    } finally {
      setProcessingAction(null);
    }
  }

  async function handleSaveTax(e: React.FormEvent) {
    e.preventDefault();
    if (!tenant) return;
    setProcessingAction('tax');
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'tax_info',
          tenantId: tenant.id,
          taxId,
          legalName,
          country: 'ES',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'Revisa los datos fiscales', body: data.error });
        return;
      }
      toast({ kind: 'success', title: 'Datos fiscales guardados', body: data.message });
    } finally {
      setProcessingAction(null);
    }
  }

  async function handlePauseMonth() {
    if (!tenant) return;
    setProcessingAction('pause');
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'pause',
          tenantId: tenant.id,
          months: subInfo?.retentionOffers?.pause.months ?? 1,
          cancelReason: pauseReason,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast({ kind: 'error', title: 'No se pudo pausar', body: data.error });
        return;
      }
      setSubInfo((prev) =>
        prev?.retentionOffers
          ? { ...prev, retentionOffers: { ...prev.retentionOffers, pause: { ...prev.retentionOffers.pause, available: false } } }
          : prev,
      );
      toast({ kind: 'info', title: 'Suscripción pausada sin coste', body: data.message });
    } finally {
      setProcessingAction(null);
    }
  }

  const { handleCancel, handleReactivate, handleAcceptDiscount } = useCancellationActions({
    tenantId: tenant?.id,
    reason: pauseReason,
    toast,
    setSubInfo,
    setProcessingAction,
  });

  async function handleAddLocation(nextCount: number) {
    if (!tenant) return;
    setProcessingAction('location');
    try {
      const res = await fetch('/api/stripe/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'add_location',
          tenantId: tenant.id,
          extraLocations: nextCount,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        setExtraLocations(nextCount);
        toast({ kind: 'success', title: 'Sedes actualizadas', body: data.message });
      }
    } finally {
      setProcessingAction(null);
    }
  }

  useEffect(() => {
    if (addonResult === 'success') {
      toast({
        kind: 'success',
        title: 'Ampliación activada',
        body: 'El webhook de Stripe ya sumó los créditos a tu cuota del ciclo actual.',
      });
      window.dispatchEvent(new Event('rf:quota-refresh'));
    }
    if (addonResult === 'canceled') {
      toast({ kind: 'info', title: 'Pago cancelado', body: 'No se ha realizado ningún cargo.' });
    }
  }, [addonResult, toast]);

  if (!tenant) {
    return (
      <div className="card p-8 text-center">
        <CreditCard size={26} className="mx-auto text-brand-300" />
        <h2 className="mt-3 text-lg font-bold text-white">Todavía no tienes empresa ni suscripción</h2>
        <p className="mx-auto mt-2 max-w-md text-sm text-ink-300">
          Activa tu prueba de {TRIAL_DAYS} días para contratar un plan y, desde aquí, ampliar la cuota
          cuando la necesites.
        </p>
        <Link href="/bienvenido" className="btn-primary mt-5">
          <Zap size={15} /> Elegir plan y empezar
        </Link>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: EASE }}
      className="space-y-5"
    >
      <BillingPlanOverview
        tenant={tenant}
        usage={usage}
        loading={loading}
        onPlanChange={handlePlanChange}
      />

      <BillingPlanSwitcherCard
        currentPlanSlug={tenant.plan}
        billingInterval={billingInterval}
        setBillingInterval={setBillingInterval}
        processingAction={processingAction}
        onPlanChange={handlePlanChange}
      />

      <BillingTaxAndRetentionSection
        legalName={legalName}
        setLegalName={setLegalName}
        taxId={taxId}
        setTaxId={setTaxId}
        extraLocations={extraLocations}
        pauseReason={pauseReason}
        setPauseReason={setPauseReason}
        processingAction={processingAction}
        invoices={subInfo?.invoices}
        onSaveTax={handleSaveTax}
        onAddLocation={handleAddLocation}
        onPauseMonth={handlePauseMonth}
        cancellation={subInfo?.cancellation}
        onCancel={handleCancel}
        onReactivate={handleReactivate}
        retentionOffers={subInfo?.retentionOffers}
        onAcceptDiscount={handleAcceptDiscount}
        onDowngradeOffer={(plan) => handlePlanChange(plan, false)}
      />
    </motion.div>
  );
}
