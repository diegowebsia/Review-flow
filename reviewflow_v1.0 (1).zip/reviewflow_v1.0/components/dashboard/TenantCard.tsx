'use client';

import Link from 'next/link';
import { AnimatePresence, motion } from 'framer-motion';
import {
  ChevronDown,
  KeyRound,
  Settings2,
  TriangleAlert,
  XCircle,
} from 'lucide-react';
import { UsagePanel } from '@/components/dashboard/UsagePanel';
import { TenantChannelsAccordion } from '@/components/dashboard/TenantChannelsAccordion';
import { useTenantCard } from '@/components/dashboard/use-tenant-card';
import { EASE } from '@/components/Motion';
import { type TenantInfo } from '@/components/dashboard/types';
import { planOf } from '@/lib/plans';
import { cn } from '@/lib/utils';

/**
 * Tarjeta de empresa: estado de suscripción, consumo del ciclo y todas las
 * conexiones reales (Google Business / Places, Trustpilot, Maps,
 * tono de la IA, tienda, Webhooks salientes, API Keys públicas con scopes y Centro de cumplimiento RGPD).
 */
export function TenantCard({
  tenant: t,
  syncing,
  onSync,
}: {
  tenant: TenantInfo;
  syncing: string | null;
  onSync: (p: 'google' | 'trustpilot' | 'places', id: string, placeId?: string) => void;
}) {
  const cardState = useTenantCard(t);
  const {
    open,
    setOpen,
    activeApiKey,
    rotatingKey,
    gdprConfirm,
    gdprPassword,
    setGdprPassword,
    setGdprConfirm,
    deletingTenant,
    gdprCert,
    copied,
    rotateKey,
    revokeKey,
    handleGdprDelete,
    copyApiKey,
  } = cardState;

  const plan = planOf(t.plan);

  function buyAddon(pack: string) {
    window.location.href = `/dashboard?tab=facturacion&pack=${pack}`;
  }

  return (
    <div className={cn('card', !t.access && 'border-rose-400/25')}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-3 text-left"
        aria-expanded={open}
      >
        <span className="min-w-0">
          <span className="flex flex-wrap items-center gap-2 font-bold tracking-tightish text-white">
            <span className="truncate">{t.name}</span>
            <span className="badge-brand">{plan.tier}</span>
            {!t.access && (
              <span className="badge-danger">
                <XCircle size={11} /> sin acceso
              </span>
            )}
            {t.subscription_status === 'trialing' && t.trial_ends_at && (
              <span className="badge-brand">
                prueba hasta {new Date(t.trial_ends_at).toLocaleDateString('es-ES')}
              </span>
            )}
          </span>
          <span className="mt-1 block truncate text-xs text-ink-400">
            {plan.label} · {t.subscription_status}
            {t.integrations.length > 0 && ` · ${t.integrations.length} conexión(es)`}
          </span>
        </span>
        <span className="flex shrink-0 items-center gap-2 text-sm text-ink-300">
          <Settings2 size={15} className="hidden sm:block" />
          <span className="hidden sm:inline">Conexiones y ajustes</span>
          <motion.span
            animate={{ rotate: open ? 180 : 0 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10"
          >
            <ChevronDown size={14} />
          </motion.span>
        </span>
      </button>

      <div className="mt-4">
        <UsagePanel tenantId={t.id} onBuyAddon={buyAddon} compact />
      </div>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.36, ease: EASE }}
            className="overflow-hidden"
          >
            <div className="mt-4 space-y-3 border-t border-white/[0.07] pt-4">
              <TenantChannelsAccordion
                tenant={t}
                syncing={syncing}
                onSync={onSync}
                cardState={cardState}
              />

              {/* API Keys públicas con scopes, rotación 24h y revocación */}
              {(activeApiKey || t.api_key) && (
                <div className="panel flex flex-wrap items-center gap-2">
                  <KeyRound size={14} className="text-brand-300" />
                  <span className="text-xs text-ink-300">
                    API Keys públicas con scopes (con hash SHA-256 y rotación 24 h):
                  </span>
                  <code className="rounded-lg bg-white/[0.07] px-2 py-1 font-mono text-2xs text-ink-100">
                    {(activeApiKey || t.api_key || '').slice(0, 10)}…
                    {(activeApiKey || t.api_key || '').slice(-4)}
                  </code>
                  <button onClick={copyApiKey} className="btn-secondary btn-sm">
                    {copied ? 'Copiada ✓' : 'Copiar'}
                  </button>
                  <button onClick={rotateKey} disabled={rotatingKey} className="btn-secondary btn-sm">
                    {rotatingKey ? '…' : 'Rotar (solape 24h)'}
                  </button>
                  <button
                    onClick={revokeKey}
                    disabled={rotatingKey}
                    className="btn-quiet btn-sm text-rose-300"
                  >
                    Revocar
                  </button>
                  <span className="ml-auto font-mono text-2xs text-ink-500">
                    POST /api/integrations/ingest · Webhooks salientes
                  </span>
                </div>
              )}

              {/* Centro de cumplimiento RGPD Art. 15 y Art. 17 */}
              <div className="panel space-y-2.5 border-white/10">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-bold text-white">
                      Centro de cumplimiento RGPD · Derechos Art. 15 y 17
                    </p>
                    <p className="text-2xs text-ink-400">
                      Exporta el 100 % de tus datos en CSV o solicita la supresión definitiva con
                      Certificado de Cumplimiento RGPD firmado.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <a
                      href={`/api/tenants/export?tenantId=${encodeURIComponent(t.id)}`}
                      className="btn-secondary btn-sm"
                    >
                      Exportar datos (Art. 15 RGPD)
                    </a>
                    <Link href="/dpa" className="btn-quiet btn-sm">
                      Ver DPA y Subencargados
                    </Link>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2 border-t border-white/[0.06] pt-2.5">
                  <input
                    className="input max-w-[210px] text-xs"
                    placeholder='Escribe "ELIMINAR" para borrar'
                    value={gdprConfirm}
                    onChange={(e) => setGdprConfirm(e.target.value)}
                    aria-label="Confirmar borrado RGPD"
                  />
                  <input
                    type="password"
                    autoComplete="current-password"
                    className="input max-w-[180px] text-xs"
                    placeholder="Tu contraseña actual"
                    value={gdprPassword}
                    onChange={(e) => setGdprPassword(e.target.value)}
                    aria-label="Contraseña actual para confirmar el borrado"
                  />
                  <button
                    type="button"
                    onClick={handleGdprDelete}
                    disabled={deletingTenant}
                    className="btn-quiet btn-sm border border-rose-500/30 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20"
                  >
                    {deletingTenant ? 'Purgando…' : 'Borrar cuenta y emitir certificado (Art. 17)'}
                  </button>
                  {gdprCert && (
                    <span className="font-mono text-2xs text-emerald-300">
                      Certificado: {gdprCert.certificateId} (Firma:{' '}
                      {String(gdprCert.cryptographicSignature).slice(0, 16)}…)
                    </span>
                  )}
                </div>
              </div>

              {!t.access && (
                <p className="flex items-start gap-2 rounded-xl border border-rose-400/30 bg-rose-500/10 p-3 text-xs text-rose-100">
                  <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                  Las integraciones están bloqueadas porque la suscripción no está activa. Reactívala
                  desde Facturación para volver a sincronizar, generar respuestas y enviar emails.
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
