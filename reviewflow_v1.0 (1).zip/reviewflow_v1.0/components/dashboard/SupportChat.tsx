'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { MessageCircle, Send, X } from 'lucide-react';

type Msg = { id: string; body: string; from_admin: boolean; author_email: string | null; created_at: string };

/** Chat flotante del cliente con el equipo de administración. Se refresca cada 10 s. */
export function SupportChat({ tenantId }: { tenantId?: string }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [unread, setUnread] = useState(0);
  const endRef = useRef<HTMLDivElement>(null);
  const seen = useRef(0);

  const load = useCallback(async () => {
    if (!tenantId) return;
    try {
      const res = await fetch(`/api/support?tenantId=${tenantId}`, { cache: 'no-store' });
      if (!res.ok) return;
      const json = (await res.json()) as { messages: Msg[] };
      setMessages(json.messages);
      const adminCount = json.messages.filter((m) => m.from_admin).length;
      if (open) seen.current = adminCount;
      setUnread(Math.max(0, adminCount - seen.current));
    } catch { /* sin red */ }
  }, [tenantId, open]);

  useEffect(() => {
    load();
    const id = setInterval(load, open ? 5_000 : 20_000);
    return () => clearInterval(id);
  }, [load, open]);

  useEffect(() => {
    if (open) endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  if (!tenantId) return null;

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    setError(null);
    try {
      const res = await fetch('/api/support', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenantId, body }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Error');
      setMessages((m) => [...m, json.message]);
      setText('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'No se pudo enviar.');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed bottom-20 right-4 z-50 md:bottom-6">
      {open ? (
        <div className="card flex h-[28rem] w-[22rem] max-w-[calc(100vw-2rem)] flex-col p-0 shadow-2xl">
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
            <div>
              <p className="text-sm font-semibold text-white">Soporte directo</p>
              <p className="text-xs text-ink-400">Te responde un administrador</p>
            </div>
            <button type="button" onClick={() => setOpen(false)} aria-label="Cerrar chat" className="text-ink-300 hover:text-white">
              <X size={18} />
            </button>
          </div>
          <div className="flex-1 space-y-2 overflow-y-auto px-4 py-3">
            {messages.length === 0 && (
              <p className="pt-10 text-center text-sm text-ink-400">¿Dudas o algún problema? Escríbenos y te ayudamos.</p>
            )}
            {messages.map((m) => (
              <div key={m.id} className={m.from_admin ? 'flex justify-start' : 'flex justify-end'}>
                <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${m.from_admin ? 'bg-white/10 text-ink-100' : 'bg-brand-600 text-white'}`}>
                  <p className="whitespace-pre-wrap break-words">{m.body}</p>
                  <p className="mt-1 text-[10px] opacity-60">
                    {m.from_admin ? 'Soporte · ' : ''}
                    {new Date(m.created_at).toLocaleString('es-ES', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>
          <form onSubmit={send} className="flex gap-2 border-t border-white/10 p-3">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={4000}
              placeholder="Escribe tu mensaje…"
              className="input flex-1"
              aria-label="Mensaje"
            />
            <button type="submit" disabled={sending || !text.trim()} className="btn-primary px-3" aria-label="Enviar">
              <Send size={16} />
            </button>
          </form>
          {error && <p className="px-3 pb-2 text-xs text-red-400">{error}</p>}
        </div>
      ) : (
        <button type="button" onClick={() => setOpen(true)} className="btn-primary relative rounded-full p-4 shadow-xl" aria-label="Abrir chat de soporte">
          <MessageCircle size={22} />
          {unread > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1 text-[11px] font-bold text-white">
              {unread}
            </span>
          )}
        </button>
      )}
    </div>
  );
}
