'use client';

import { VERTICAL_TEMPLATES, type VerticalTemplate } from '@/lib/sample-reviews';
import { SUPPORTED_LOCALES } from '@/lib/i18n';
import { Spinner } from '@/components/Skeleton';

export function TenantBrandToneSection({
  tenantId,
  tenantSlug,
  companyName,
  setCompanyName,
  companySlug,
  setCompanySlug,
  tone,
  setTone,
  brandInstructions,
  setBrandInstructions,
  brandRulesText,
  setBrandRulesText,
  forbiddenWordsText,
  setForbiddenWordsText,
  brandSignature,
  setBrandSignature,
  customerLocale,
  setCustomerLocale,
  slackWebhookUrl,
  setSlackWebhookUrl,
  teamsWebhookUrl,
  setTeamsWebhookUrl,
  outboundWebhookUrl,
  setOutboundWebhookUrl,
  saving,
  onApplyTemplate,
  onSaveSettings,
}: {
  tenantId: string;
  tenantSlug?: string | null;
  companyName: string;
  setCompanyName: (v: string) => void;
  companySlug: string;
  setCompanySlug: (v: string) => void;
  tone: string;
  setTone: (v: string) => void;
  brandInstructions: string;
  setBrandInstructions: (v: string) => void;
  brandRulesText: string;
  setBrandRulesText: (v: string) => void;
  forbiddenWordsText: string;
  setForbiddenWordsText: (v: string) => void;
  brandSignature: string;
  setBrandSignature: (v: string) => void;
  customerLocale: string;
  setCustomerLocale: (v: string) => void;
  slackWebhookUrl: string;
  setSlackWebhookUrl: (v: string) => void;
  teamsWebhookUrl: string;
  setTeamsWebhookUrl: (v: string) => void;
  outboundWebhookUrl: string;
  setOutboundWebhookUrl: (v: string) => void;
  saving: boolean;
  onApplyTemplate: (tpl: VerticalTemplate) => void;
  onSaveSettings: () => void;
}) {
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor={`${tenantId}-company-name`}>
            Nombre comercial del negocio
          </label>
          <input
            id={`${tenantId}-company-name`}
            className="input"
            maxLength={80}
            placeholder="Ej: Trattoria Bella Roma"
            value={companyName}
            onChange={(e) => setCompanyName(e.target.value)}
          />
          <p className="hint mt-1">Aparece en tu cartel QR, embudo público y respuestas de IA.</p>
        </div>
        <div>
          <label className="label" htmlFor={`${tenantId}-company-slug`}>
            Identificador URL (slug público)
          </label>
          <input
            id={`${tenantId}-company-slug`}
            className="input font-mono text-xs"
            maxLength={60}
            placeholder="trattoria-bella-roma"
            value={companySlug}
            onChange={(e) => setCompanySlug(e.target.value)}
          />
          <p className="hint mt-1">
            Define tu enlace <code>/valorar/{companySlug || tenantSlug}</code> y cartel{' '}
            <code>/cartel/{companySlug || tenantSlug}</code>.
          </p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor={`${tenantId}-tone`}>
            Cómo debe sonar tu marca
          </label>
          <select
            id={`${tenantId}-tone`}
            className="select"
            value={tone}
            onChange={(e) => setTone(e.target.value)}
          >
            <option value="profesional">Profesional — cordial y resolutivo</option>
            <option value="cercano">Cercano — amable y próximo</option>
            <option value="formal">Formal — distinguido y serio</option>
          </select>
          <p className="hint mt-1">Estilo de redacción principal de Google Gemini.</p>
        </div>
        <div>
          <label className="label" htmlFor={`${tenantId}-instructions`}>
            Contexto del negocio (opcional)
          </label>
          <input
            id={`${tenantId}-instructions`}
            className="input"
            maxLength={300}
            placeholder="Ej: Restaurante italiano con terraza en el centro y parking privado"
            value={brandInstructions}
            onChange={(e) => setBrandInstructions(e.target.value)}
          />
          <p className="hint mt-1">
            La IA usará estos detalles para responder con precisión y naturalidad.
          </p>
        </div>
      </div>

      <div>
        <p className="label">Plantillas por sector (1 clic para configurar tono, reglas y firma)</p>
        <div className="mt-1 flex flex-wrap gap-1.5">
          {VERTICAL_TEMPLATES.map((tpl) => (
            <button
              key={tpl.id}
              type="button"
              onClick={() => onApplyTemplate(tpl)}
              className="rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-2xs font-medium text-ink-200 transition hover:border-brand-400/40 hover:bg-brand-500/15 hover:text-white"
            >
              {tpl.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="label" htmlFor={`${tenantId}-rules`}>
          Reglas de marca obligatorias (1 por línea, máx. 5)
        </label>
        <textarea
          id={`${tenantId}-rules`}
          rows={3}
          className="input font-mono text-xs"
          placeholder="Mencionar aparcamiento gratuito para clientes&#10;Invitar a probar el tiramisú artesanal&#10;Agradecer de parte de todo el equipo de sala"
          value={brandRulesText}
          onChange={(e) => setBrandRulesText(e.target.value)}
        />
        <p className="hint mt-1">
          Directrices obligatorias que Gemini integrará en las respuestas públicas y privadas.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor={`${tenantId}-forbidden`}>
            Palabras prohibidas (separadas por coma)
          </label>
          <input
            id={`${tenantId}-forbidden`}
            className="input text-xs"
            placeholder="culpa vuestra, mentira, barato"
            value={forbiddenWordsText}
            onChange={(e) => setForbiddenWordsText(e.target.value)}
          />
          <p className="hint mt-1">La IA nunca utilizará estas expresiones.</p>
        </div>
        <div>
          <label className="label" htmlFor={`${tenantId}-signature`}>
            Firma personalizada al final
          </label>
          <input
            id={`${tenantId}-signature`}
            className="input text-xs"
            placeholder="Dirección y Equipo de Atención"
            value={brandSignature}
            onChange={(e) => setBrandSignature(e.target.value)}
          />
          <p className="hint mt-1">Cierre fijo en cada respuesta.</p>
        </div>
        <div>
          <label className="label" htmlFor={`${tenantId}-cust-locale`}>
            Idioma comunicaciones al cliente
          </label>
          <select
            id={`${tenantId}-cust-locale`}
            className="select text-xs"
            value={customerLocale}
            onChange={(e) => setCustomerLocale(e.target.value)}
          >
            {SUPPORTED_LOCALES.map((loc) => (
              <option key={loc.code} value={loc.code}>
                {loc.nativeName} ({loc.code.toUpperCase()})
              </option>
            ))}
          </select>
          <p className="hint mt-1">Idioma de los emails enviados a tus clientes.</p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <label className="label" htmlFor={`${tenantId}-slack`}>
            Webhook de Slack (alertas ≤3★)
          </label>
          <input
            id={`${tenantId}-slack`}
            className="input font-mono text-xs"
            placeholder="https://hooks.slack.com/services/..."
            value={slackWebhookUrl}
            onChange={(e) => setSlackWebhookUrl(e.target.value)}
          />
        </div>
        <div>
          <label className="label" htmlFor={`${tenantId}-teams`}>
            Webhook de Microsoft Teams
          </label>
          <input
            id={`${tenantId}-teams`}
            className="input font-mono text-xs"
            placeholder="https://outlook.office.com/webhook/..."
            value={teamsWebhookUrl}
            onChange={(e) => setTeamsWebhookUrl(e.target.value)}
          />
        </div>
        <div>
          <label className="label" htmlFor={`${tenantId}-webhook`}>
            Webhook saliente (Zapier / Make)
          </label>
          <input
            id={`${tenantId}-webhook`}
            className="input font-mono text-xs"
            placeholder="https://hooks.zapier.com/..."
            value={outboundWebhookUrl}
            onChange={(e) => setOutboundWebhookUrl(e.target.value)}
          />
        </div>
      </div>

      <div className="flex justify-end pt-1">
        <button onClick={onSaveSettings} disabled={saving} className="btn-primary btn-sm h-[38px]">
          {saving ? <Spinner label="Guardando…" size={13} /> : 'Guardar identidad, memoria y webhooks'}
        </button>
      </div>
    </div>
  );
}
