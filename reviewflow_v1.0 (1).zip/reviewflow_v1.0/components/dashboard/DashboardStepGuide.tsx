'use client';

import { CheckCircle2, Link2, QrCode, Sparkles } from 'lucide-react';
import type { ReviewItem, TenantInfo } from '@/components/dashboard/types';
import type { DashboardTabId } from './use-dashboard-state';
import { cn } from '@/lib/utils';

/**
 * Guía inicial paso a paso con barra de progreso accesible (WCAG AA):
 * 1. Conectar fuente (Google, Trustpilot o Place ID)
 * 2. Primera respuesta generada o publicada con IA
 * 3. Activar QR físico o email post-venta
 */
export function DashboardStepGuide({
  tenant,
  reviews,
  publishedCount,
  draftsCount,
  onSelectTab,
}: {
  tenant?: TenantInfo;
  reviews: ReviewItem[];
  publishedCount: number;
  draftsCount: number;
  onSelectTab: (tab: DashboardTabId) => void;
}) {
  if (!tenant) return null;

  const connectedProviders = new Set(
    (tenant.integrations ?? [])
      .filter((i) => i.status === 'connected')
      .map((i) => i.provider),
  );

  const hasConnectedSource = Boolean(
    connectedProviders.has('google') ||
      connectedProviders.has('trustpilot') ||
      connectedProviders.has('maps') ||
      tenant.settings?.place_id ||
      reviews.length > 0,
  );

  const hasFirstReply = Boolean(
    publishedCount > 0 || draftsCount > 0 || reviews.some((r) => r.replied || Boolean(r.reply)),
  );

  const hasQrOrEmail = Boolean(
    tenant.settings?.funnel_enabled ||
      tenant.settings?.trustpilot_url ||
      connectedProviders.has('store') ||
      connectedProviders.has('shopify') ||
      connectedProviders.has('woocommerce'),
  );

  const steps = [
    {
      id: 'connect',
      number: '01',
      title: 'Conectar fuente de opiniones',
      description: 'Vincula Google Business, Google Places o Trustpilot.',
      done: hasConnectedSource,
      ctaLabel: hasConnectedSource ? 'Conectada' : 'Conectar fuente',
      targetTab: 'empresa' as DashboardTabId,
      icon: Link2,
    },
    {
      id: 'reply',
      number: '02',
      title: 'Generar primera respuesta con IA',
      description: 'Redacta y aprueba tu primera respuesta adaptada al tono de tu marca.',
      done: hasFirstReply,
      ctaLabel: hasFirstReply ? 'Completado' : 'Ir a bandeja',
      targetTab: 'bandeja' as DashboardTabId,
      icon: Sparkles,
    },
    {
      id: 'activate',
      number: '03',
      title: 'Activar cartel QR o email post-venta',
      description: 'Activa tu enlace de valoración QR o el email post-venta de tu tienda.',
      done: hasQrOrEmail,
      ctaLabel: hasQrOrEmail ? 'Activado' : 'Activar canal',
      targetTab: 'embudo' as DashboardTabId,
      icon: QrCode,
    },
  ];

  const completedCount = steps.filter((s) => s.done).length;
  const progressPct = Math.round((completedCount / steps.length) * 100);

  if (completedCount === steps.length) return null;

  return (
    <section
      aria-label="Guía rápida de puesta en marcha"
      className="card border-brand-400/25 p-5"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-white">
            Guía inicial paso a paso · {completedCount} de {steps.length} completados
          </h2>
          <p className="mt-0.5 text-xs text-ink-300">
            Completa estos 3 pasos para automatizar la captación y respuesta de reseñas.
          </p>
        </div>
        <span className="font-mono text-xs font-semibold text-brand-200 tabular-nums">
          {progressPct}% completado
        </span>
      </div>

      <div
        role="progressbar"
        aria-label="Progreso de configuración inicial"
        aria-valuenow={progressPct}
        aria-valuemin={0}
        aria-valuemax={100}
        className="mt-3 h-2 w-full overflow-hidden rounded-full bg-white/[0.08]"
      >
        <div
          className="h-full rounded-full bg-[linear-gradient(90deg,#2563eb,#10b981)] transition-all duration-300"
          style={{ width: `${Math.max(8, progressPct)}%` }}
        />
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.id}
              className={cn(
                'flex flex-col justify-between rounded-xl border p-3.5 transition-colors',
                step.done
                  ? 'border-emerald-400/30 bg-emerald-500/[0.06]'
                  : 'border-white/[0.08] bg-white/[0.02]',
              )}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-2xs font-semibold text-ink-400">
                    {step.number}.
                  </span>
                  {step.done ? (
                    <CheckCircle2 size={15} className="text-emerald-300" aria-hidden="true" />
                  ) : (
                    <Icon size={15} className="text-brand-300" aria-hidden="true" />
                  )}
                </div>
                <h3 className="mt-1.5 text-xs font-bold text-white">{step.title}</h3>
                <p className="mt-1 text-2xs leading-relaxed text-ink-300">{step.description}</p>
              </div>

              <button
                type="button"
                onClick={() => onSelectTab(step.targetTab)}
                className={cn(
                  'mt-3 w-full justify-center py-1.5 text-xs font-semibold',
                  step.done ? 'btn-quiet' : 'btn-secondary',
                )}
              >
                {step.ctaLabel}
              </button>
            </div>
          );
        })}
      </div>
    </section>
  );
}
