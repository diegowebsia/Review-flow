'use client';

import { useMemo, useState } from 'react';
import { CheckCircle2, Clock, Rocket } from 'lucide-react';
import { useToast } from '@/components/Toast';
import type { ReviewItem, TenantInfo } from '@/components/dashboard/types';

/**
 * Checklist persistente de Onboarding (5 pasos en BD + porcentaje + Time-to-First-Value < 10 min).
 */
export function OnboardingChecklist({
  tenant,
  reviews,
  onGoTab,
  onLoadSamples,
  onSync,
}: {
  tenant?: TenantInfo;
  reviews: ReviewItem[];
  onGoTab: (tab: 'bandeja' | 'empresa' | 'embudo' | 'facturacion' | 'analitica') => void;
  onLoadSamples: () => void;
  /** Importación real (Google Business / Places / Trustpilot). */
  onSync?: (provider: 'google' | 'trustpilot' | 'places', tenantId: string) => void | Promise<void>;
}) {
  const toast = useToast();
  const [dismissed, setDismissed] = useState(false);
  const [savingStep, setSavingStep] = useState<string | null>(null);
  // Pasos marcados en esta sesión (el servidor también marca algunos solo: QR, publicar…).
  const [localSteps, setLocalSteps] = useState<Record<string, boolean>>({});
  const savedSteps = useMemo<Record<string, boolean>>(
    () => ({ ...(tenant?.settings?.onboarding_steps ?? {}), ...localSteps }),
    [tenant?.settings?.onboarding_steps, localSteps],
  );

  const steps = useMemo(() => {
    const hasGoogleOrInteg =
      Boolean(tenant && tenant.integrations.length > 0) ||
      Boolean(tenant?.settings?.place_id) ||
      Boolean(savedSteps.connect_google);
    const hasImportedReviews = reviews.length > 0 || Boolean(savedSteps.import_reviews);
    const hasBrandTone =
      Boolean(tenant?.settings?.brand_instructions) ||
      Boolean((tenant?.settings?.brand_rules ?? []).length > 0) ||
      Boolean(savedSteps.define_tone);
    const hasSentRequest =
      Boolean(savedSteps.send_first_request);
    const hasGoogleOAuth = Boolean(tenant?.integrations.some((i) => i.provider === 'google'));
    const hasTrustpilot = Boolean(tenant?.integrations.some((i) => i.provider === 'trustpilot'));
    const placeId = tenant?.settings?.place_id;
    const canImportReal = Boolean(onSync && tenant && (hasGoogleOAuth || placeId || hasTrustpilot));
    const hasPublishedReply =
      reviews.some((r) => r.replied) || Boolean(savedSteps.publish_first_reply);

    return [
      {
        id: 'connect_google',
        title: '1. Conectar Google Business o Places',
        desc: 'Vincula tu ficha oficial para importar reseñas automáticamente.',
        done: hasGoogleOrInteg,
        ctaLabel: 'Conectar ahora',
        action: () => onGoTab('empresa'),
      },
      {
        id: 'import_reviews',
        title: '2. Importar o cargar tus primeras reseñas',
        desc: canImportReal
          ? 'Trae tus reseñas reales de Google/Trustpilot (luego se sincronizan solas).'
          : 'Conecta Google o Trustpilot para traer tus reseñas reales, o carga 12 de demostración.',
        done: hasImportedReviews,
        ctaLabel: canImportReal ? 'Importar ahora' : 'Cargar demo',
        action: () => {
          if (canImportReal && tenant && onSync) {
            if (hasGoogleOAuth) void onSync('google', tenant.id);
            else if (placeId) void onSync('places', tenant.id);
            if (hasTrustpilot) void onSync('trustpilot', tenant.id);
          } else {
            onLoadSamples();
          }
        },
      },
      {
        id: 'define_tone',
        title: '3. Definir tono y memoria de marca',
        desc: 'Elige plantilla por sector, palabras prohibidas y firma de tu negocio.',
        done: hasBrandTone,
        ctaLabel: 'Configurar tono',
        action: () => onGoTab('empresa'),
      },
      {
        id: 'send_first_request',
        title: '4. Enviar primera solicitud o descargar Cartel QR',
        desc: 'Activa tu embudo /valorar/' + (tenant?.slug || 'tu-negocio') + ' para captar 5★.',
        done: hasSentRequest,
        ctaLabel: 'Descargar QR / embudo',
        action: () => onGoTab('embudo'),
      },
      {
        id: 'publish_first_reply',
        title: '5. Generar y publicar tu primera respuesta con IA',
        desc: 'Genera un borrador con IA, revísalo y pulsa «Publicar».',
        done: hasPublishedReply,
        ctaLabel: 'Responder reseña',
        action: () => onGoTab('bandeja'),
      },
    ];
  }, [tenant, reviews, savedSteps, onGoTab, onLoadSamples, onSync]);

  const completedCount = steps.filter((s) => s.done).length;
  const pct = Math.round((completedCount / steps.length) * 100);

  async function markStepComplete(stepId: string) {
    if (!tenant) return;
    setSavingStep(stepId);
    try {
      const res = await fetch('/api/tenants/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: tenant.id,
          onboarding_steps: { [stepId]: true },
        }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? `Error ${res.status}`);
      }
      setLocalSteps((prev) => ({ ...prev, [stepId]: true }));
      toast({
        kind: 'success',
        title: 'Paso de activación completado',
        body: 'Tu progreso de onboarding se ha guardado en tu cuenta.',
      });
    } catch (err: unknown) {
      toast({
        kind: 'error',
        title: 'No se pudo guardar el paso',
        body: err instanceof Error ? err.message : 'Inténtalo de nuevo.',
      });
    } finally {
      setSavingStep(null);
    }
  }

  if (!tenant || dismissed || pct === 100) return null;

  return (
    <div className="card border-brand-400/30 bg-brand-950/20 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <span className="badge-brand">
            <Rocket size={12} /> Activación guiada · Time-to-First-Value &lt; 10 min
          </span>
          <h2 className="mt-2 text-base font-bold text-white">
            Configura {tenant.name} en 5 pasos ({completedCount}/{steps.length} completados · {pct} %)
          </h2>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-36 overflow-hidden rounded-full bg-white/10 h-2.5">
            <div
              className="h-full rounded-full bg-[linear-gradient(90deg,#2563eb,#34d399)] transition-all duration-500"
              style={{ width: `${pct}%` }}
            />
          </div>
          <button
            type="button"
            onClick={() => setDismissed(true)}
            className="text-xs text-ink-400 hover:text-white"
          >
            Ocultar
          </button>
        </div>
      </div>

      <div className="mt-4 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-5">
        {steps.map((s) => (
          <div
            key={s.id}
            className={`flex flex-col justify-between rounded-xl border p-3 text-xs transition ${
              s.done
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-100'
                : 'border-white/10 bg-white/[0.02] text-ink-200'
            }`}
          >
            <div>
              <p className="flex items-center justify-between font-bold text-white">
                <span>{s.title}</span>
                {s.done ? (
                  <CheckCircle2 size={14} className="shrink-0 text-emerald-400" />
                ) : (
                  <Clock size={13} className="shrink-0 text-amber-300" />
                )}
              </p>
              <p className="mt-1 text-2xs text-ink-300">{s.desc}</p>
            </div>
            <div className="mt-3 flex items-center gap-1.5 pt-1">
              <button
                type="button"
                onClick={s.action}
                className="btn-secondary btn-sm w-full justify-center py-1 text-2xs"
              >
                {s.ctaLabel}
              </button>
              {!s.done && (
                <button
                  type="button"
                  disabled={savingStep === s.id}
                  onClick={() => markStepComplete(s.id)}
                  title="Marcar paso como completado"
                  className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-2xs text-ink-300 hover:text-white"
                >
                  ✓
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
