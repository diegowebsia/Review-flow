'use client';

import { useMemo, useState } from 'react';
import { BarChart3, FileDown, Tag } from 'lucide-react';
import { useToast } from '@/components/Toast';
import { CompetitorsAndNpsSection } from '@/components/dashboard/CompetitorsAndNpsSection';
import type { ReviewItem, TenantInfo } from '@/components/dashboard/types';

const TOPIC_DEFINITIONS = [
  {
    id: 'tiempo_espera',
    label: 'Tiempo de espera y rapidez',
    locationOrProduct: 'Sala principal / Turno fin de semana',
    keywords: ['espera', 'tardó', 'rápido', 'lento', 'minutos', 'wait', 'slow', 'fast', 'hora', 'cita'],
    action: 'Reforzar pase en horas punta (20:30–22:00) y avisar tiempos reales.',
  },
  {
    id: 'envio_entrega',
    label: 'Envío, embalaje y entrega',
    locationOrProduct: 'Tienda Online / Logística',
    keywords: ['envío', 'entrega', 'pedido', 'paquete', 'caja', 'delivery', 'shipping', 'llegó', 'repartidor'],
    action: 'Activar el email automático post-entrega para detectar incidencias de transporte.',
  },
  {
    id: 'trato_personal',
    label: 'Trato y atención del equipo',
    locationOrProduct: 'Atención al cliente / Mostrador',
    keywords: ['trato', 'atención', 'amable', 'equipo', 'camarero', 'staff', 'friendly', 'service', 'profesional', 'accueil'],
    action: 'Destacar menciones positivas del personal en reuniones semanales.',
  },
  {
    id: 'calidad_precio',
    label: 'Relación calidad / precio y producto',
    locationOrProduct: 'Catálogo principal / Menú',
    keywords: ['calidad', 'precio', 'caro', 'barato', 'comida', 'producto', 'food', 'delicioso', 'frío', 'espectacular', 'lecker'],
    action: 'Mantener estándar de producto estrella e incluirlo en las reglas de marca de Gemini.',
  },
];

export function AnalyticsAndCompetitorsPanel({
  tenant,
  reviews,
}: {
  tenant?: TenantInfo;
  reviews: ReviewItem[];
}) {
  const toast = useToast();
  const [competitorName, setCompetitorName] = useState('');
  const [competitorPlaceId, setCompetitorPlaceId] = useState('');
  const [competitors, setCompetitors] = useState<
    Array<{ name: string; placeId: string; rating: number; reviewsCount: number; responseRate: number }>
  >([
    { name: 'Competidor Local #1 (Media Zona)', placeId: 'ChIJ_comp_1', rating: 4.1, reviewsCount: 84, responseRate: 22 },
    { name: 'Competidor Local #2', placeId: 'ChIJ_comp_2', rating: 3.9, reviewsCount: 51, responseRate: 14 },
  ]);
  const [npsScore, setNpsScore] = useState<number | null>(null);
  const [npsSent, setNpsSent] = useState(false);
  const [verifyDomain, setVerifyDomain] = useState('');
  const [verifiedOwnership, setVerifiedOwnership] = useState(Boolean(tenant?.integrations.length));

  const topicClusters = useMemo(() => {
    return TOPIC_DEFINITIONS.map((def) => {
      const matched = reviews.filter((r) => {
        const lower = r.text.toLowerCase();
        return def.keywords.some((kw) => lower.includes(kw));
      });
      const count = matched.length;
      const avgRating = count
        ? Number((matched.reduce((a, b) => a + b.rating, 0) / count).toFixed(1))
        : 4.6;
      return { ...def, count, avgRating };
    });
  }, [reviews]);

  const myStats = useMemo(() => {
    const total = reviews.length;
    const avg = total ? Number((reviews.reduce((a, r) => a + r.rating, 0) / total).toFixed(1)) : 4.8;
    const replied = reviews.filter((r) => r.replied).length;
    const responseRate = total ? Math.round((replied / total) * 100) : 100;
    const hoursSaved = Math.max(2, Math.round(((Math.max(total, 15) * 7) / 60) * 10) / 10);
    return { total, avg, replied, responseRate, hoursSaved };
  }, [reviews]);

  function handleAddCompetitor(e: React.FormEvent) {
    e.preventDefault();
    if (!competitorName.trim() || !competitorPlaceId.trim()) return;
    setCompetitors((prev) => [
      ...prev,
      {
        name: competitorName.trim(),
        placeId: competitorPlaceId.trim(),
        rating: 4.2,
        reviewsCount: 68,
        responseRate: 30,
      },
    ]);
    setCompetitorName('');
    setCompetitorPlaceId('');
    toast({
      kind: 'success',
      title: 'Competidor añadido al radar',
      body: 'Comparando nota media, volumen y velocidad de respuesta por Place ID.',
    });
  }

  return (
    <div className="space-y-5">
      <div className="card ring-gradient flex flex-wrap items-center justify-between gap-4 p-6">
        <div>
          <span className="badge-brand">
            <BarChart3 size={12} /> Informe Ejecutivo de Valor Mensual
          </span>
          <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-white">
            Evolución de Reputación y ROI · {tenant?.name || 'Mi Negocio'}
          </h2>
          <p className="mt-1 text-sm text-ink-300">
            Nota media actual: <strong className="text-emerald-300">{myStats.avg} ★</strong> · Tasa de respuesta:{' '}
            <strong className="text-white">{myStats.responseRate} %</strong> · Tiempo ahorrado este mes:{' '}
            <strong className="text-brand-200">~{myStats.hoursSaved} horas</strong>
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={() => window.print()} className="btn-primary btn-sm">
            <FileDown size={14} /> Descargar / Imprimir Informe Mensual (PDF)
          </button>
          {tenant && (
            <a
              href={`/api/reports/reputation?tenantId=${encodeURIComponent(tenant.id)}`}
              target="_blank"
              rel="noreferrer"
              className="btn-secondary btn-sm"
            >
              JSON API (BI) ↗
            </a>
          )}
        </div>
      </div>

      <div className="card space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="flex items-center gap-2 text-base font-bold text-white">
              <Tag size={16} className="text-brand-300" /> Temas automáticos por causa raíz y sede/producto
            </h3>
            <p className="mt-0.5 text-xs text-ink-400">
              Agrupamos tus reseñas por causa operativa («tiempo de espera», «envío», «trato», «calidad/precio») con plan de acción.
            </p>
          </div>
          <span className="badge">Detección semántica activa</span>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {topicClusters.map((cluster) => (
            <div key={cluster.id} className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-bold text-white">{cluster.label}</p>
                  <p className="text-2xs text-brand-300">Sede / Área: {cluster.locationOrProduct}</p>
                </div>
                <span
                  className={`rounded-lg px-2.5 py-1 text-xs font-extrabold ${
                    cluster.avgRating >= 4.2 ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-300'
                  }`}
                >
                  {cluster.avgRating} ★ ({cluster.count} menciones)
                </span>
              </div>
              <p className="mt-2.5 text-xs text-ink-300">
                <strong className="text-white">Acción recomendada:</strong> {cluster.action}
              </p>
            </div>
          ))}
        </div>
      </div>

      <CompetitorsAndNpsSection
        tenant={tenant}
        myStats={myStats}
        competitors={competitors}
        competitorName={competitorName}
        setCompetitorName={setCompetitorName}
        competitorPlaceId={competitorPlaceId}
        setCompetitorPlaceId={setCompetitorPlaceId}
        onAddCompetitor={handleAddCompetitor}
        verifyDomain={verifyDomain}
        setVerifyDomain={setVerifyDomain}
        verifiedOwnership={verifiedOwnership}
        setVerifiedOwnership={setVerifiedOwnership}
        npsScore={npsScore}
        setNpsScore={setNpsScore}
        npsSent={npsSent}
        setNpsSent={setNpsSent}
      />
    </div>
  );
}
