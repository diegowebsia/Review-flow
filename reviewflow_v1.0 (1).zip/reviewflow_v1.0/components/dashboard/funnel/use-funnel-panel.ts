'use client';
import { browserOrigin } from '@/lib/public-url';

import { useCallback, useEffect, useState } from 'react';
import { useToast } from '@/components/Toast';
import { normalizeCampaign } from '@/lib/campaign';
import type { TenantInfo } from '@/components/dashboard/types';

type FunnelCampaignStat = {
  campaign: string;
  votes: number;
  clicks: number;
  tickets: number;
};

type FunnelStatsResponse = {
  ok: boolean;
  total: number;
  avgStars: number | null;
  clicks?: number;
  ticketsOpen: number;
  byStars?: Record<number, number>;
  byChannel?: {
    google?: number;
    trustpilot?: number;
    none?: number;
  };
  campaigns?: FunnelCampaignStat[];
};

type FunnelTicket = {
  id: string;
  stars: number;
  status: 'open' | 'closed' | string;
  customer_name?: string | null;
  contact?: string | null;
  order_id?: string | null;
  message?: string | null;
  created_at: string;
};

export function useFunnelPanel(t: TenantInfo) {
  const toast = useToast();
  const [stats, setStats] = useState<FunnelStatsResponse | null>(null);
  const [tickets, setTickets] = useState<FunnelTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [tpUrl, setTpUrl] = useState(t.settings.trustpilot_url ?? '');
  const [campaign, setCampaign] = useState('mostrador');
  const [enabled, setEnabled] = useState(t.settings.funnel_enabled !== false);

  const publicLink =
    `${browserOrigin()}/valorar/${t.slug}`;
  const campaignSlug = normalizeCampaign(campaign) ?? '';
  const attributedLink = campaignSlug
    ? `${publicLink}?campaign=${encodeURIComponent(campaignSlug)}`
    : publicLink;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [s, k] = await Promise.all([
        fetch(`/api/feedback/stats?tenantId=${t.id}`).then((r) => r.json() as Promise<FunnelStatsResponse>),
        fetch(`/api/feedback/tickets?tenantId=${t.id}&status=all`).then(
          (r) => r.json() as Promise<{ ok?: boolean; tickets?: FunnelTicket[] }>,
        ),
      ]);
      if (s?.ok) setStats(s);
      if (k?.ok) setTickets(k.tickets ?? []);
    } catch {
      /* se muestra el estado vacío */
    } finally {
      setLoading(false);
    }
  }, [t.id]);

  useEffect(() => {
    void load();
  }, [load]);

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(attributedLink);
      setCopied(true);
      toast({ kind: 'success', title: 'Enlace copiado', body: 'Pégalo en tu QR, ticket o web.' });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast({ kind: 'warning', title: 'No se pudo copiar', body: publicLink });
    }
  }

  async function saveUrls() {
    if (tpUrl && !/^https?:\/\//i.test(tpUrl)) {
      toast({ kind: 'warning', title: 'URL de Trustpilot inválida', body: 'Debe empezar por https://' });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/tenants/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: t.id,
          trustpilot_url: tpUrl,
          funnel_enabled: enabled,
        }),
      });
      if (!res.ok) throw new Error('No se pudo guardar.');
      toast({ kind: 'success', title: 'Embudo actualizado', body: 'URLs y estado guardados.' });
    } catch (e: unknown) {
      toast({ kind: 'error', title: 'No se pudo guardar', body: e instanceof Error ? e.message : undefined });
    } finally {
      setSaving(false);
    }
  }

  async function setTicketStatus(id: string, status: 'open' | 'closed') {
    try {
      const res = await fetch('/api/feedback/tickets', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenantId: t.id, id, status }),
      });
      if (!res.ok) throw new Error('No se pudo actualizar.');
      setTickets((prev) => prev.map((k) => (k.id === id ? { ...k, status } : k)));
      void load();
    } catch (e: unknown) {
      toast({
        kind: 'error',
        title: 'No se pudo actualizar',
        body: e instanceof Error ? e.message : undefined,
      });
    }
  }

  return {
    stats,
    tickets,
    loading,
    saving,
    copied,
    tpUrl,
    setTpUrl,
    campaign,
    setCampaign,
    enabled,
    setEnabled,
    campaignSlug,
    attributedLink,
    copyLink,
    saveUrls,
    setTicketStatus,
  };
}
