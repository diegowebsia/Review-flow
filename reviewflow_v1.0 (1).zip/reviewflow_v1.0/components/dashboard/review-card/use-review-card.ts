'use client';

import { useState } from 'react';
import { useToast } from '@/components/Toast';
import { describeApiError, type ReviewItem } from '@/components/dashboard/types';

type ReviewIntelligenceData = {
  sentiment: string;
  churnRisk: string;
  language: string;
  topics?: string[];
  recommendedAction: string;
  spamAnalysis?: {
    isSuspicious: boolean;
    confidenceScore: number;
    googlePolicyLabel: string;
    reportDossier: string;
    reasons: string[];
  };
  suggestedReplyVariant?: {
    standard?: string;
    short?: string;
    loyaltyRecovery?: string;
  };
};

export function useReviewCard({
  review: r,
  draft,
  published,
  tone,
  onDraftChange,
  onPublished,
}: {
  review: ReviewItem;
  draft?: string;
  published: boolean;
  tone: 'profesional' | 'cercano' | 'formal';
  onDraftChange: (id: string, value: string) => void;
  onPublished: (id: string) => void;
}) {
  const toast = useToast();
  const [generating, setGenerating] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [showDraft, setShowDraft] = useState(Boolean(draft));
  const [providerUsed, setProviderUsed] = useState<'gemini' | 'local-template' | null>(null);
  const [showIntelligence, setShowIntelligence] = useState(false);
  const [intelligence, setIntelligence] = useState<ReviewIntelligenceData | null>(null);
  const [loadingIntel, setLoadingIntel] = useState(false);
  const [humanizeSchedule, setHumanizeSchedule] = useState(true);

  const replied = r.replied || published;
  const isSample = r.id.startsWith('sample-');

  async function generateReply(variantText?: string) {
    if (variantText) {
      onDraftChange(r.id, variantText);
      setShowDraft(true);
      return;
    }

    setGenerating(true);
    setShowDraft(true);
    try {
      if (isSample) {
        const resIntel = await fetch('/api/reviews/intelligence', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            reviewId: r.id,
            businessName: r.tenant,
            authorName: r.author,
            rating: r.rating,
            reviewText: r.text,
            verified: r.verified,
            tone,
          }),
        });
        const intelData = (await resIntel.json().catch(() => ({}))) as {
          intelligence?: ReviewIntelligenceData;
        };
        const sampleReply =
          intelData?.intelligence?.suggestedReplyVariant?.standard ??
          `Hola ${r.author}, muchas gracias por compartir tu valoración sobre ${r.tenant}. Tomamos nota de tu comentario para seguir ofreciendo la mejor experiencia.`;
        onDraftChange(r.id, sampleReply);
        setProviderUsed('gemini');
        toast({
          kind: 'success',
          title: 'Borrador de demostración listo',
          body: 'Generado en el idioma detectado de la reseña sin consumir tu cuota mensual.',
        });
        return;
      }

      const res = await fetch('/api/reviews/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reviewId: r.id,
          businessName: r.tenant,
          authorName: r.author,
          rating: r.rating,
          reviewText: r.text,
          tone,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const described = describeApiError(res.status, data);
        toast({ kind: described.kind, title: described.title, body: described.body, action: described.action });
        return;
      }
      onDraftChange(r.id, data.reply ?? '');
      setProviderUsed(data.provider);
      const providerLabel = data.provider === 'gemini' ? 'Google Gemini 2.5 Flash' : 'Plantilla local';
      toast({
        kind: 'success',
        title: 'Borrador listo',
        body: `${providerLabel} · revísalo antes de publicar`,
      });
      window.dispatchEvent(new Event('rf:quota-refresh'));
    } catch (e: unknown) {
      toast({
        kind: 'error',
        title: 'No se pudo generar el borrador',
        body: e instanceof Error ? e.message : undefined,
      });
    } finally {
      setGenerating(false);
    }
  }

  async function toggleIntelligence() {
    if (intelligence) {
      setShowIntelligence(!showIntelligence);
      return;
    }
    setLoadingIntel(true);
    setShowIntelligence(true);
    try {
      const res = await fetch('/api/reviews/intelligence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reviewId: r.id,
          businessName: r.tenant,
          authorName: r.author,
          rating: r.rating,
          reviewText: r.text,
          tone,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { intelligence?: ReviewIntelligenceData };
      if (res.ok && data.intelligence) {
        setIntelligence(data.intelligence);
      }
    } catch {
      /* silent fallback */
    } finally {
      setLoadingIntel(false);
    }
  }

  async function publishReply() {
    const reply = (draft ?? '').trim();
    if (reply.length < 2) {
      toast({ kind: 'warning', title: 'Respuesta demasiado corta', body: 'Escribe al menos 2 caracteres.' });
      return;
    }
    setPublishing(true);
    try {
      if (isSample) {
        onPublished(r.id);
        toast({
          kind: 'success',
          title: 'Respuesta de ejemplo aprobada',
          body: humanizeSchedule
            ? 'Programada con cadencia humana (horario diurno).'
            : 'Guardada en la vista de demostración.',
        });
        return;
      }
      const res = await fetch('/api/reviews/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reviewId: r.id, reply, humanizeSchedule }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        const described = describeApiError(res.status, data);
        toast({ kind: described.kind, title: described.title, body: described.body, action: described.action });
        return;
      }
      onPublished(r.id);
      toast({
        kind: 'success',
        title: data.pushedToGoogle ? 'Publicada en Google' : 'Respuesta guardada',
        body: data.message,
      });
    } catch (e: unknown) {
      toast({ kind: 'error', title: 'No se pudo publicar', body: e instanceof Error ? e.message : undefined });
    } finally {
      setPublishing(false);
    }
  }

  return {
    toast,
    generating,
    publishing,
    showDraft,
    setShowDraft,
    providerUsed,
    showIntelligence,
    intelligence,
    loadingIntel,
    humanizeSchedule,
    setHumanizeSchedule,
    replied,
    generateReply,
    toggleIntelligence,
    publishReply,
  };
}
