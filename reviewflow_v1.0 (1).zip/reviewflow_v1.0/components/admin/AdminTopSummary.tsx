'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Eye, MonitorPlay, RefreshCw, ShieldCheck } from 'lucide-react';
import { TRIAL_DAYS } from '@/lib/plans';
import { CountUp, EASE } from '@/components/Motion';
import { Spinner } from '@/components/Skeleton';
import { cn } from '@/lib/utils';

export function AdminTopSummary({
  email,
  integrations,
  freeTrialEnabled,
  busyRow,
  toggleFreeTrial,
  stats,
  totals,
}: {
  email: string;
  integrations: Array<{ name: string; ok: boolean; hint?: string }>;
  freeTrialEnabled: boolean;
  busyRow: (key: string) => boolean;
  toggleFreeTrial: () => Promise<void>;
  stats: {
    tenants: number;
    activeSubscriptions: number;
    mrrCents: number;
    mrrFormatted: string;
    reviewsTotal: number;
    aiRepliesTotal: number;
    trialCount: number;
    aiTokensCycle?: number;
    aiCostCycleUsd?: number;
    aiFallbacksCycle?: number;
    aiModel?: string;
  };
  totals: { used: number; capped: number };
}) {
  return (
    <>
      <header className="nav-blur sticky top-0 z-50 w-full border-b border-white/10 bg-slate-900/80 backdrop-blur-lg transition-all duration-300">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3.5">
          <div>
            <h1 className="flex items-center gap-2.5 text-xl font-extrabold tracking-tighter text-white sm:text-2xl">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-brand-400/30 bg-brand-500/10 text-brand-300 shadow-[0_0_28px_-12px_rgba(59,118,240,1)]">
                <ShieldCheck size={18} />
              </span>
              Super-Admin · ReviewFlow AI
            </h1>
            <p className="mt-0.5 text-xs text-ink-400">
              Sesión <strong className="font-semibold text-ink-200">{email}</strong>
              <span className="mx-1.5 text-ink-600">·</span>
              protegido por middleware +{' '}
              <code className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-2xs">
                SUPERADMIN_EMAILS
              </code>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Link href="/admin/demo" className="btn-primary btn-sm">
              <MonitorPlay size={15} /> Simulador demo
            </Link>
            <Link href="/dashboard" className="btn-secondary btn-sm">
              <Eye size={15} /> Ver app
            </Link>
            <button
              type="button"
              className="btn-secondary btn-sm"
              onClick={() => window.location.reload()}
            >
              <RefreshCw size={15} /> Actualizar
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 pt-8">
        {integrations.some(
          (i) => (i.name.includes('SMTP') || i.name.includes('Datos fiscales')) && !i.ok,
        ) && (
          <div
            role="alert"
            className="mb-5 rounded-2xl border border-amber-400/40 bg-amber-500/10 px-5 py-4 text-xs text-amber-100"
          >
            <p className="font-bold text-amber-200">
              Configuración pendiente antes de pasar a producción real:
            </p>
            <ul className="mt-1.5 list-disc space-y-1 pl-5 text-amber-100/90">
              {integrations
                .filter((i) => (i.name.includes('SMTP') || i.name.includes('Datos fiscales')) && !i.ok)
                .map((item) => (
                  <li key={item.name}>
                    <strong>{item.name}:</strong> {item.hint}
                  </li>
                ))}
            </ul>
          </div>
        )}

        <motion.section
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: EASE }}
          className={cn(
            'card flex flex-col gap-4 border p-5 transition-colors sm:flex-row sm:items-center sm:justify-between',
            freeTrialEnabled
              ? 'border-emerald-400/30 bg-emerald-500/[0.06]'
              : 'border-amber-400/30 bg-amber-500/[0.06]',
          )}
        >
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-extrabold tracking-tight text-white">
                Control comercial: Prueba gratuita de {TRIAL_DAYS} días
              </span>
              <span className={freeTrialEnabled ? 'badge-ok' : 'badge-warn'}>
                {freeTrialEnabled ? 'ACTIVA (7 días gratis)' : 'DESACTIVADA (Cobro inmediato)'}
              </span>
            </div>
            <p className="max-w-2xl text-xs leading-relaxed text-ink-300">
              {freeTrialEnabled
                ? `Los nuevos clientes ven «Probar ${TRIAL_DAYS} días gratis» en la web y en /bienvenido, y Stripe Checkout añade trial_period_days: ${TRIAL_DAYS}.`
                : 'Se ocultan todos los textos de «7 días de prueba gratis» en la web y en /bienvenido, y Stripe Checkout cobra la primera cuota mensual de inmediato.'}
            </p>
          </div>

          <div className="flex shrink-0 items-center gap-3">
            <button
              type="button"
              role="switch"
              aria-checked={freeTrialEnabled}
              aria-label="Activar o desactivar los 7 días de prueba gratuita"
              disabled={busyRow('toggle-free-trial')}
              onClick={() => void toggleFreeTrial()}
              className={cn(
                'relative inline-flex h-8 w-14 shrink-0 cursor-pointer items-center rounded-full border transition-colors duration-200 focus:outline-none',
                freeTrialEnabled
                  ? 'border-emerald-400/50 bg-emerald-500/80'
                  : 'border-white/20 bg-slate-800',
                busyRow('toggle-free-trial') && 'cursor-wait opacity-60',
              )}
            >
              <span
                className={cn(
                  'inline-block h-6 w-6 transform rounded-full bg-white shadow-md transition-transform duration-200',
                  freeTrialEnabled ? 'translate-x-7' : 'translate-x-1',
                )}
              />
            </button>
            <button
              type="button"
              disabled={busyRow('toggle-free-trial')}
              onClick={() => void toggleFreeTrial()}
              className={cn(
                'btn-sm font-semibold',
                freeTrialEnabled ? 'btn-secondary' : 'btn-primary',
              )}
            >
              {busyRow('toggle-free-trial') ? (
                <Spinner />
              ) : freeTrialEnabled ? (
                'Desactivar 7 días gratis'
              ) : (
                'Activar 7 días gratis'
              )}
            </button>
          </div>
        </motion.section>

        <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: 'Empresas', value: stats.tenants, sub: `${stats.trialCount} en prueba` },
            {
              label: 'MRR',
              value: stats.mrrCents / 100,
              display: stats.mrrFormatted,
              sub: `${stats.activeSubscriptions} suscripciones activas`,
            },
            { label: 'Reseñas', value: stats.reviewsTotal, sub: 'importadas en total' },
            {
              label: 'Tokens de IA (ciclo)',
              value: stats.aiTokensCycle ?? 0,
              sub:
                (stats.aiCostCycleUsd ?? 0) > 0
                  ? `≈ ${(stats.aiCostCycleUsd ?? 0).toFixed(3)} USD · ${stats.aiModel ?? 'gemini-2.5-flash'}` +
                    ((stats.aiFallbacksCycle ?? 0) > 0 ? ` · ${stats.aiFallbacksCycle} fallback(s)` : '')
                  : `modelo ${stats.aiModel ?? 'gemini-2.5-flash'}`,
            },
            {
              label: 'Eventos consumidos',
              value: totals.used,
              sub: totals.capped > 0 ? `${totals.capped} empresa(s) al límite` : 'ninguna al límite',
            },
          ].map((m, i) => (
            <motion.div
              key={m.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i, duration: 0.4, ease: EASE }}
              className="card p-5"
            >
              <p className="text-xs font-semibold tracking-wider text-ink-400">{m.label}</p>
              <p className="mt-2 text-3xl font-extrabold tracking-tighter text-white tabular-nums">
                {m.display ?? <CountUp value={m.value} />}
              </p>
              <p className="mt-1 text-2xs text-ink-500">{m.sub}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
}
