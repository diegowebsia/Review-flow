'use client';

import { Ban, CheckCircle2, ChevronLeft, ChevronRight, ExternalLink, Search, Trash2 } from 'lucide-react';
import { planOf } from '@/lib/plans';
import { useI18n } from '@/lib/i18n';
import { Spinner } from '@/components/Skeleton';
import { cn } from '@/lib/utils';
import type { AdminTenant } from './use-admin-dashboard';

const STATUS_LABEL: Record<string, string> = {
  active: 'Activa',
  trialing: 'En prueba',
  past_due: 'Impago',
  unpaid: 'Impago',
  canceled: 'Cancelada',
  inactive: 'Inactiva',
  incomplete: 'Incompleta',
  incomplete_expired: 'Caducada',
  paused: 'Pausada',
  none: 'Sin suscripción',
};

function statusClass(status: string): string {
  if (status === 'active') return 'badge-ok';
  if (status === 'trialing') return 'badge-brand';
  if (status === 'past_due' || status === 'unpaid' || status === 'incomplete') return 'badge-warn';
  if (
    status === 'canceled' ||
    status === 'inactive' ||
    status === 'incomplete_expired' ||
    status === 'paused'
  ) {
    return 'badge-danger';
  }
  return 'badge';
}

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn(statusClass(status), 'whitespace-nowrap')}>
      {STATUS_LABEL[status] ?? status}
    </span>
  );
}

export function AdminTenantsSection({
  filteredCount,
  paginatedTenants,
  q,
  onSearchChange,
  page,
  totalPages,
  onPageChange,
  busy,
  busyRow,
  onImpersonate,
  onAction,
}: {
  filteredCount: number;
  paginatedTenants: AdminTenant[];
  q: string;
  onSearchChange: (v: string) => void;
  page: number;
  totalPages: number;
  onPageChange: (next: number) => void;
  busy: string | null;
  busyRow: (key: string) => boolean;
  onImpersonate: (tenantId: string) => Promise<void>;
  onAction: (
    path: string,
    body: Record<string, unknown>,
    key: string,
    okTitle: string,
  ) => Promise<void>;
}) {
  const { formatDate } = useI18n();

  return (
    <section className="card p-5" aria-label="Listado de empresas">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-bold tracking-tightish text-white">
          Empresas <span className="text-ink-400">({filteredCount})</span>
        </h2>
        <div className="relative w-full sm:w-72">
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-500"
          />
          <input
            className="input py-2 pl-9"
            placeholder="Buscar empresa, email o plan…"
            value={q}
            onChange={(e) => onSearchChange(e.target.value)}
            aria-label="Buscar empresas"
          />
        </div>
      </div>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[880px] text-sm">
          <thead>
            <tr className="text-left text-2xs tracking-wider text-ink-400">
              <th className="pb-2 font-semibold">Empresa</th>
              <th className="pb-2 font-semibold">Propietario</th>
              <th className="pb-2 font-semibold">Plan</th>
              <th className="pb-2 font-semibold">Estado</th>
              <th className="pb-2 font-semibold">Reseñas</th>
              <th className="pb-2 font-semibold">Alta</th>
              <th className="pb-2 font-semibold">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {paginatedTenants.map((t) => (
              <tr
                key={t.id}
                className={cn(
                  'border-t border-white/[0.06] transition-colors hover:bg-white/[0.025]',
                  busyRow(`row-${t.id}`) && 'opacity-60',
                )}
              >
                <td className="py-2.5 pr-3 align-top">
                  <span className="font-semibold text-white">{t.name}</span>
                  <span className="block text-2xs text-ink-500">/{t.slug}</span>
                  {t.suspended && <span className="badge-danger mt-1.5">suspendida</span>}
                </td>
                <td className="py-2.5 pr-3 align-top text-ink-300">{t.owner_email}</td>
                <td className="py-2.5 pr-3 align-top">
                  <span className="whitespace-nowrap text-xs font-medium text-ink-200">
                    {planOf(t.plan).tier}
                  </span>
                </td>
                <td className="py-2.5 pr-3 align-top">
                  <StatusBadge status={t.subscription_status} />
                </td>
                <td className="py-2.5 pr-3 align-top text-ink-300 tabular-nums">
                  {t.reviews_count}
                  <span className="block text-2xs text-ink-500">{t.ai_replies_count} con IA</span>
                </td>
                <td className="py-2.5 pr-3 align-top text-ink-400 tabular-nums">
                  {formatDate(t.created_at)}
                </td>
                <td className="py-2.5 align-top">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      title="Abrir el panel como esta empresa"
                      className="btn-quiet btn-sm"
                      disabled={!!busy}
                      onClick={() => void onImpersonate(t.id)}
                    >
                      {busyRow(`row-${t.id}`) ? <Spinner /> : <ExternalLink size={13} />} Acceder
                    </button>
                    <button
                      title={t.suspended ? 'Reactivar acceso' : 'Suspender acceso'}
                      className="btn-quiet btn-sm"
                      disabled={!!busy}
                      onClick={() =>
                        void onAction(
                          '/api/admin/tenants',
                          { tenantId: t.id, op: t.suspended ? 'unsuspend' : 'suspend' },
                          `row-${t.id}`,
                          t.suspended ? 'Empresa reactivada' : 'Empresa suspendida',
                        )
                      }
                    >
                      {t.suspended ? <CheckCircle2 size={13} /> : <Ban size={13} />}
                      {t.suspended ? 'Reactivar' : 'Suspender'}
                    </button>
                    <button
                      title="Eliminar empresa y todos sus datos"
                      aria-label={`Eliminar empresa ${t.name}`}
                      className="btn-danger btn-sm"
                      disabled={!!busy}
                      onClick={() => {
                        if (
                          window.confirm(
                            `¿Eliminar "${t.name}" y TODOS sus datos? Esta acción no se puede deshacer.`,
                          )
                        ) {
                          void onAction(
                            '/api/admin/tenants',
                            { tenantId: t.id, op: 'delete' },
                            `row-${t.id}`,
                            'Empresa eliminada',
                          );
                        }
                      }}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {paginatedTenants.length === 0 && (
          <p className="py-6 text-center text-sm text-ink-400">Sin resultados para «{q}».</p>
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between border-t border-white/[0.06] pt-3 text-xs text-ink-400">
          <span>
            Página <strong className="text-white tabular-nums">{page}</strong> de{' '}
            <strong className="text-white tabular-nums">{totalPages}</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => onPageChange(Math.max(1, page - 1))}
              className="btn-secondary btn-sm"
              aria-label="Página anterior de empresas"
            >
              <ChevronLeft size={14} /> Anterior
            </button>
            <button
              type="button"
              disabled={page >= totalPages}
              onClick={() => onPageChange(Math.min(totalPages, page + 1))}
              className="btn-secondary btn-sm"
              aria-label="Página siguiente de empresas"
            >
              Siguiente <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
