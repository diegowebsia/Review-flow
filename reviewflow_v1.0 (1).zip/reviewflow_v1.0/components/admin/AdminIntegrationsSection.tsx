'use client';

import { CheckCircle2, ChevronLeft, ChevronRight, ShieldCheck, XCircle } from 'lucide-react';
import { TRIAL_DAYS } from '@/lib/plans';
import { Spinner, TableSkeleton } from '@/components/Skeleton';
import { cn } from '@/lib/utils';
import type { AdminLogEntry } from './use-admin-dashboard';

export function AdminLogsSection({
  totalLogsCount,
  paginatedLogs,
  page,
  totalPages,
  onPageChange,
}: {
  totalLogsCount: number;
  paginatedLogs: AdminLogEntry[];
  page: number;
  totalPages: number;
  onPageChange: (next: number) => void;
}) {
  return (
    <section className="card p-5" aria-label="Logs del sistema">
      <h2 className="font-bold tracking-tightish text-white">
        Logs del sistema <span className="text-ink-400">(últimos {totalLogsCount})</span>
      </h2>
      <p className="mt-1 text-sm text-ink-400">
        Cada corte de cuota, webhook de Stripe y sincronización queda registrado en{' '}
        <code className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-2xs">
          system_logs
        </code>
        .
      </p>
      <div className="mt-4 space-y-1.5">
        {totalLogsCount === 0 && <TableSkeleton rows={5} cols={2} />}
        {paginatedLogs.map((l) => (
          <div
            key={l.id}
            className="flex gap-2.5 rounded-xl border border-white/[0.05] bg-white/[0.025] p-2.5"
          >
            <span
              className={cn(
                'h-fit shrink-0',
                l.level === 'error'
                  ? 'badge-danger'
                  : l.level === 'warn'
                    ? 'badge-warn'
                    : 'badge-ok',
              )}
            >
              {l.level}
            </span>
            <div className="min-w-0">
              <p className="truncate font-mono text-2xs text-ink-500">
                {new Date(l.created_at).toLocaleString('es-ES')} · {l.source}
              </p>
              <p className="text-sm text-ink-200">{l.message}</p>
            </div>
          </div>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between border-t border-white/[0.06] pt-3 text-xs text-ink-400">
          <span>
            Página <strong className="text-white tabular-nums">{page}</strong> de{' '}
            <strong className="text-white tabular-nums">{totalPages}</strong>
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => onPageChange(Math.max(1, page - 1))}
              className="btn-secondary btn-sm"
              aria-label="Página anterior de logs"
            >
              <ChevronLeft size={14} /> Anterior
            </button>
            <button
              type="button"
              disabled={page >= totalPages}
              onClick={() => onPageChange(Math.min(totalPages, page + 1))}
              className="btn-secondary btn-sm"
              aria-label="Página siguiente de logs"
            >
              Siguiente <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

export function AdminSystemSection({
  integrations,
  busy,
  busyRow,
  freeTrialEnabled,
  onToggleFreeTrial,
  onAction,
}: {
  integrations: Array<{ name: string; ok: boolean; hint?: string }>;
  busy: string | null;
  busyRow: (key: string) => boolean;
  freeTrialEnabled: boolean;
  onToggleFreeTrial: () => Promise<void>;
  onAction: (
    path: string,
    body: Record<string, unknown>,
    key: string,
    okTitle: string,
  ) => Promise<void>;
}) {
  return (
    <section className="grid gap-4 lg:grid-cols-2" aria-label="Estado del sistema">
      <div className="card p-5">
        <h2 className="font-bold tracking-tightish text-white">Estado de integraciones</h2>
        <p className="mt-1 text-sm text-ink-400">
          Detectado desde las variables de entorno del servidor.
        </p>
        <div className="mt-4 divide-y divide-white/[0.06]">
          {integrations.map((i) => (
            <div key={i.name} className="flex items-center justify-between gap-3 py-2.5 text-sm">
              <span className="min-w-0 text-ink-200">
                {i.name}
                {i.hint && <span className="block text-2xs text-ink-500">{i.hint}</span>}
              </span>
              {i.ok ? (
                <span className="badge-ok shrink-0">
                  <CheckCircle2 size={12} /> listo
                </span>
              ) : (
                <span className="badge-danger shrink-0">
                  <XCircle size={12} /> falta en .env
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <div className="card p-5">
          <h2 className="font-bold tracking-tightish text-white">Acciones rápidas</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            <a
              className="btn-secondary btn-sm"
              href="/api/health"
              target="_blank"
              rel="noreferrer"
            >
              Health-check JSON
            </a>
            <button
              className="btn-secondary btn-sm"
              disabled={!!busy}
              onClick={() =>
                void onAction(
                  '/api/admin/tenants',
                  { op: 'ping' },
                  'ping',
                  'Conexión con la BD correcta',
                )
              }
            >
              {busyRow('ping') ? <Spinner /> : <ShieldCheck size={15} />} Probar conexión BD
            </button>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="font-bold tracking-tightish text-white">Versión y reglas de negocio</h2>
          <ul className="mt-3 space-y-1.5 text-sm text-ink-300">
            <li className="flex justify-between gap-3">
              <span>Versión</span>
              <strong className="font-mono text-2xs text-white">1.0</strong>
            </li>
            <li className="flex items-center justify-between gap-3">
              <span>Prueba gratuita ({TRIAL_DAYS} días)</span>
              <button
                type="button"
                onClick={() => void onToggleFreeTrial()}
                disabled={busyRow('toggle-free-trial')}
                className={cn(
                  'rounded-lg px-2.5 py-1 text-2xs font-bold transition',
                  freeTrialEnabled
                    ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30',
                )}
              >
                {freeTrialEnabled
                  ? `${TRIAL_DAYS} días gratis (clic para desactivar)`
                  : 'Deshabilitada · Cobro día 1 (clic para activar)'}
              </button>
            </li>
            <li className="flex justify-between gap-3">
              <span>Corte de acceso</span>
              <strong className="text-white">
                {freeTrialEnabled ? 'día 8 si no hay pago' : 'inmediato tras pago en Stripe'}
              </strong>
            </li>
            <li className="flex justify-between gap-3">
              <span>Add-ons de cuota</span>
              <strong className="text-white">inmediatos vía webhook</strong>
            </li>
            <li className="flex justify-between gap-3">
              <span>Webhook Stripe</span>
              <strong className="font-mono text-2xs text-white">/api/stripe/webhook</strong>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
