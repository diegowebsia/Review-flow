'use client';

import type { BusinessMetricsSummary } from '@/lib/business-metrics';
import { useI18n } from '@/lib/i18n';
import { version } from '@/lib/site';

export function AdminMetricsSection({
  businessMetrics,
}: {
  businessMetrics: BusinessMetricsSummary;
}) {
  const { formatPrice, formatNumber } = useI18n();

  return (
    <section className="space-y-5" aria-label="Métricas de Negocio">
      <div className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-bold tracking-tightish text-white">
              Métricas de Negocio (BI) — Ingresos, Conversión, Churn y Coste IA
            </h2>
            <p className="mt-0.5 text-xs text-ink-400">
              Panel interno exclusivo para Super-Administración calculado en tiempo real sobre tenants y eventos de embudo.
            </p>
          </div>
          <span className="font-mono text-2xs text-brand-300">v{version} · Real-Time DB</span>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4">
            <p className="text-2xs font-bold tracking-wider text-ink-400">
              MRR (Ingreso Mensual Recurrente)
            </p>
            <p className="mt-1.5 text-2xl font-extrabold text-white tabular-nums">
              {formatPrice(businessMetrics.mrrCents)}
            </p>
            <p className="mt-1 text-2xs text-ink-500">
              ARR: {formatPrice(businessMetrics.arrCents)} · {businessMetrics.activeCount} activas
            </p>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4">
            <p className="text-2xs font-bold tracking-wider text-ink-400">
              Conversión Prueba → Pago
            </p>
            <p className="mt-1.5 text-2xl font-extrabold text-emerald-300 tabular-nums">
              {businessMetrics.trialToPaidConversionPct}%
            </p>
            <p className="mt-1 text-2xs text-ink-500">
              {businessMetrics.activeCount} de pago · {businessMetrics.trialingCount} en prueba
            </p>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4">
            <p className="text-2xs font-bold tracking-wider text-ink-400">Churn Mensual</p>
            <p className="mt-1.5 text-2xl font-extrabold text-amber-300 tabular-nums">
              {businessMetrics.monthlyChurnPct}%
            </p>
            <p className="mt-1 text-2xs text-ink-500">
              {businessMetrics.canceledOrChurnedCount} bajas · {businessMetrics.pausedCount} pausadas
            </p>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4">
            <p className="text-2xs font-bold tracking-wider text-ink-400">Upgrades / Downgrades</p>
            <p className="mt-1.5 text-2xl font-extrabold text-brand-300 tabular-nums">
              +{businessMetrics.upgradesCount} / -{businessMetrics.downgradesCount}
            </p>
            <p className="mt-1 text-2xs text-ink-500">
              Upgrades inmediatos vs Downgrades programados
            </p>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4">
            <p className="text-2xs font-bold tracking-wider text-ink-400">
              Coste Medio IA por Cliente
            </p>
            <p className="mt-1.5 text-2xl font-extrabold text-white tabular-nums">
              ${businessMetrics.avgAiCostPerCustomerUsd.toFixed(4)} USD
            </p>
            <p className="mt-1 text-2xs text-ink-500">
              Total ciclo: ${businessMetrics.totalAiCostUsd.toFixed(4)} USD
            </p>
          </div>

          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-4">
            <p className="text-2xs font-bold tracking-wider text-ink-400">Impagos / Dunning</p>
            <p className="mt-1.5 text-2xl font-extrabold text-rose-300 tabular-nums">
              {businessMetrics.pastDueCount}
            </p>
            <p className="mt-1 text-2xs text-ink-500">En periodo de gracia de 3 días</p>
          </div>
        </div>
      </div>

      {/* Desglose de Coste IA y MRR por Plan */}
      <div className="card p-5">
        <h3 className="font-bold tracking-tightish text-white">
          Coste de IA y MRR desglosado por Plan
        </h3>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[680px] text-sm">
            <thead>
              <tr className="text-left text-2xs tracking-wider text-ink-400">
                <th className="pb-2 font-semibold">Plan</th>
                <th className="pb-2 font-semibold">Clientes (Activos)</th>
                <th className="pb-2 font-semibold">MRR del Plan</th>
                <th className="pb-2 font-semibold">Tokens IA (Ciclo)</th>
                <th className="pb-2 font-semibold">Coste IA Total (USD)</th>
                <th className="pb-2 font-semibold">Coste IA / Cliente</th>
              </tr>
            </thead>
            <tbody>
              {businessMetrics.aiCostByPlan.map((row) => (
                <tr key={row.planId} className="border-t border-white/[0.06]">
                  <td className="py-2.5 font-semibold text-white">{row.planName}</td>
                  <td className="py-2.5 tabular-nums text-ink-300">
                    {row.tenantsCount} ({row.activeCount} activos)
                  </td>
                  <td className="py-2.5 tabular-nums text-emerald-300">
                    {formatPrice(row.mrrCents)}
                  </td>
                  <td className="py-2.5 tabular-nums text-ink-300">
                    {formatNumber(row.totalTokens)}
                  </td>
                  <td className="py-2.5 tabular-nums text-ink-200">
                    ${row.totalAiCostUsd.toFixed(4)} USD
                  </td>
                  <td className="py-2.5 tabular-nums text-ink-400">
                    ${row.avgAiCostPerTenantUsd.toFixed(4)} USD
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Embudo de Eventos de Producto */}
      <div className="card p-5">
        <h3 className="font-bold tracking-tightish text-white">
          Embudo de Conversión de Eventos de Producto
        </h3>
        <div className="mt-4 grid gap-3 sm:grid-cols-4">
          {[
            { label: 'Registros (Signups)', value: businessMetrics.funnel.signups, step: '01. user_signup' },
            { label: 'Cuentas Activadas', value: businessMetrics.funnel.activated, step: '02. tenant_activated' },
            {
              label: 'Primer Informe Generado',
              value: businessMetrics.funnel.firstReportGenerated,
              step: '03. first_report_generated',
            },
            { label: 'Upgrades de Plan', value: businessMetrics.funnel.upgraded, step: '04. plan_upgraded' },
          ].map((f) => (
            <div key={f.step} className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-4">
              <span className="font-mono text-2xs text-brand-300">{f.step}</span>
              <p className="mt-1 text-xs font-semibold text-ink-300">{f.label}</p>
              <p className="mt-1.5 text-2xl font-extrabold text-white tabular-nums">
                {formatNumber(f.value)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
