'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { LogIn, Send } from 'lucide-react';

type Conversation = { tenantId: string; name: string; plan: string; owner_email: string; last: string; lastAt: string; unread: number; lastFromAdmin: boolean };
type Msg = { id: string; body: string; from_admin: boolean; author_email: string | null; created_at: string };

/** Bandeja de soporte: todas las conversaciones con clientes + respuesta directa + acceso a su panel. */
export function AdminSupportSection({ onImpersonate }: { onImpersonate?: (tenantId: string) => void }) {
  const [convs, setConvs] = useState<Conversation[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const loadConvs = useCallback(async () => {
    const res = await fetch('/api/admin/support', { cache: 'no-store' });
    if (res.ok) setConvs(((await res.json()) as { conversations: Conversation[] }).conversations);
  }, []);

  const loadMessages = useCallback(async (id: string) => {
    const res = await fetch(`/api/admin/support?tenantId=${id}`, { cache: 'no-store' });
    if (res.ok) setMessages(((await res.json()) as { messages: Msg[] }).messages);
  }, []);

  useEffect(() => {
    loadConvs();
    const t = setInterval(() => {
      loadConvs();
      if (active) loadMessages(active);
    }, 6_000);
    return () => clearInterval(t);
  }, [loadConvs, loadMessages, active]);

  useEffect(() => {
    if (active) loadMessages(active);
  }, [active, loadMessages]);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!active || !text.trim()) return;
    setSending(true);
    const res = await fetch('/api/admin/support', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tenantId: active, body: text.trim() }),
    });
    if (res.ok) {
      const json = await res.json();
      setMessages((m) => [...m, json.message]);
      setText('');
      loadConvs();
    }
    setSending(false);
  }

  const current = convs.find((c) => c.tenantId === active);

  return (
    <div className="grid gap-4 md:grid-cols-[18rem_1fr]">
      <div className="card max-h-[36rem] overflow-y-auto p-0">
        <p className="border-b border-white/10 px-4 py-3 text-sm font-semibold text-white">Conversaciones ({convs.length})</p>
        {convs.length === 0 && <p className="p-4 text-sm text-ink-400">Ningún cliente ha escrito todavía.</p>}
        {convs.map((c) => (
          <button
            key={c.tenantId}
            type="button"
            onClick={() => setActive(c.tenantId)}
            className={`block w-full border-b border-white/5 px-4 py-3 text-left hover:bg-white/5 ${active === c.tenantId ? 'bg-white/10' : ''}`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-sm font-medium text-white">{c.name}</span>
              {c.unread > 0 && <span className="rounded-full bg-red-500 px-2 text-[11px] font-bold text-white">{c.unread}</span>}
            </div>
            <p className="truncate text-xs text-ink-400">{c.lastFromAdmin ? 'Tú: ' : ''}{c.last}</p>
            <p className="text-[10px] text-ink-500">{c.plan} · {new Date(c.lastAt).toLocaleString('es-ES')}</p>
          </button>
        ))}
      </div>

      <div className="card flex h-[36rem] flex-col p-0">
        {!current ? (
          <p className="m-auto text-sm text-ink-400">Elige una conversación.</p>
        ) : (
          <>
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
              <div>
                <p className="text-sm font-semibold text-white">{current.name}</p>
                <p className="text-xs text-ink-400">{current.owner_email} · plan {current.plan}</p>
              </div>
              {onImpersonate && (
                <button type="button" onClick={() => onImpersonate(current.tenantId)} className="btn-secondary text-xs">
                  <LogIn size={14} /> Abrir su panel
                </button>
              )}
            </div>
            <div className="flex-1 space-y-2 overflow-y-auto px-4 py-3">
              {messages.map((m) => (
                <div key={m.id} className={m.from_admin ? 'flex justify-end' : 'flex justify-start'}>
                  <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${m.from_admin ? 'bg-brand-600 text-white' : 'bg-white/10 text-ink-100'}`}>
                    <p className="whitespace-pre-wrap break-words">{m.body}</p>
                    <p className="mt-1 text-[10px] opacity-60">{m.author_email} · {new Date(m.created_at).toLocaleString('es-ES')}</p>
                  </div>
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <form onSubmit={send} className="flex gap-2 border-t border-white/10 p-3">
              <input value={text} onChange={(e) => setText(e.target.value)} maxLength={4000} placeholder="Responder al cliente…" className="input flex-1" aria-label="Respuesta" />
              <button type="submit" disabled={sending || !text.trim()} className="btn-primary px-3" aria-label="Enviar"><Send size={16} /></button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
