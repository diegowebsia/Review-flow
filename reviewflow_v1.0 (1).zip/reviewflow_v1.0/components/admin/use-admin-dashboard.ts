'use client';

import { useMemo, useState } from 'react';
import { errorMessage } from '@/lib/api-error';
import { planOf } from '@/lib/plans';
import { useToast } from '@/components/Toast';

export type AdminTenant = {
  id: string;
  name: string;
  slug: string;
  owner_email: string;
  plan: string;
  subscription_status: string;
  stripe_customer_id: string | null;
  reviews_count: number;
  ai_replies_count: number;
  mrr_cents: number;
  created_at: string;
  suspended: boolean;
  extra_requests?: number;
  extra_reviews?: number;
  extra_ai?: number;
  extra_syncs?: number;
  extra_stored?: number;
  used_events?: number;
  ai_tokens_cycle?: number;
  ai_tokens_limit?: number;
  ai_cost_cycle?: number;
  ai_fallbacks?: number;
};

export type AdminTabId = 'metrics' | 'capacity' | 'support' | 'tenants' | 'subs' | 'quota' | 'logs' | 'system';

export type AdminLogEntry = {
  id: string;
  created_at: string;
  level: string;
  source: string;
  message: string;
};

export function quotaOfTenant(t: AdminTenant): number {
  const plan = planOf(t.plan);
  return plan.limits.requestsPerMonth + (t.extra_requests ?? 0);
}

export function useAdminDashboard({
  tenants,
  logs,
  initialFreeTrialEnabled,
  pageSize = 15,
}: {
  tenants: AdminTenant[];
  logs: AdminLogEntry[];
  initialFreeTrialEnabled: boolean;
  pageSize?: number;
}) {
  const toast = useToast();
  const [tab, setTab] = useState<AdminTabId>('metrics');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [freeTrialEnabled, setFreeTrialEnabled] = useState<boolean>(initialFreeTrialEnabled);
  const [tenantPage, setTenantPage] = useState(1);
  const [logPage, setLogPage] = useState(1);

  const filtered = useMemo(() => {
    if (!q.trim()) return tenants;
    const s = q.toLowerCase();
    return tenants.filter(
      (t) =>
        t.name.toLowerCase().includes(s) ||
        t.owner_email.toLowerCase().includes(s) ||
        t.slug.toLowerCase().includes(s) ||
        t.plan.toLowerCase().includes(s),
    );
  }, [tenants, q]);

  const tenantTotalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paginatedTenants = useMemo(() => {
    const safePage = Math.min(tenantPage, tenantTotalPages);
    const start = (safePage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, tenantPage, tenantTotalPages, pageSize]);

  const logTotalPages = Math.max(1, Math.ceil(logs.length / pageSize));
  const paginatedLogs = useMemo(() => {
    const safePage = Math.min(logPage, logTotalPages);
    const start = (safePage - 1) * pageSize;
    return logs.slice(start, start + pageSize);
  }, [logs, logPage, logTotalPages, pageSize]);

  const totals = useMemo(() => {
    const extras = tenants.reduce(
      (a, t) =>
        a +
        (t.extra_requests ?? 0) +
        (t.extra_reviews ?? 0) +
        (t.extra_ai ?? 0) +
        (t.extra_syncs ?? 0),
      0,
    );
    const used = tenants.reduce((a, t) => a + (t.used_events ?? 0), 0);
    const capped = tenants.filter((t) => (t.used_events ?? 0) >= quotaOfTenant(t)).length;
    return { extras, used, capped };
  }, [tenants]);

  async function toggleFreeTrial() {
    const next = !freeTrialEnabled;
    setBusy('toggle-free-trial');
    try {
      const res = await fetch('/api/admin/tenants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ op: 'set-free-trial', enabled: next }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error ?? `Error ${res.status}`);
      setFreeTrialEnabled(next);
      toast({
        kind: 'success',
        title: next ? 'Prueba gratuita de 7 días ACTIVADA' : 'Prueba gratuita de 7 días DESACTIVADA',
        body: data.message,
      });
    } catch (err: unknown) {
      toast({
        kind: 'error',
        title: 'No se pudo cambiar la prueba gratuita',
        body: errorMessage(err, 'Error de red.'),
      });
    } finally {
      setBusy(null);
    }
  }

  async function action(
    path: string,
    body: Record<string, unknown>,
    key: string,
    okTitle: string,
  ) {
    setBusy(key);
    try {
      const res = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        message?: string;
        url?: string;
      };
      if (!res.ok) throw new Error(data.error ?? `Error ${res.status}`);
      toast({ kind: 'success', title: okTitle, body: data.message });
      if (data.url) {
        window.location.assign(data.url);
        return;
      }
      setTimeout(() => window.location.reload(), 700);
    } catch (err: unknown) {
      toast({
        kind: 'error',
        title: 'No se pudo completar',
        body: errorMessage(err, 'Error de red.'),
      });
    } finally {
      setBusy(null);
    }
  }

  async function impersonate(tenantId: string, reason?: string, ticket?: string) {
    const resolvedReason =
      reason ??
      window.prompt('Motivo detallado del acceso de soporte (mín. 10 caracteres):')?.trim();
    if (!resolvedReason || resolvedReason.length < 10) return;
    const resolvedTicket = ticket ?? window.prompt('ID del ticket o incidencia:')?.trim();
    if (!resolvedTicket || resolvedTicket.length < 3) return;
    await action(
      '/api/admin/impersonate',
      { tenantId, reason: resolvedReason, ticket: resolvedTicket },
      `row-${tenantId}`,
      'Sesión de soporte abierta',
    );
  }

  const busyRow = (key: string) => busy === key;

  function handleSearchChange(value: string) {
    setQ(value);
    setTenantPage(1);
  }

  return {
    tab,
    setTab,
    q,
    setQ: handleSearchChange,
    busy,
    busyRow,
    freeTrialEnabled,
    toggleFreeTrial,
    filtered,
    paginatedTenants,
    tenantPage,
    setTenantPage,
    tenantTotalPages,
    paginatedLogs,
    logPage,
    setLogPage,
    logTotalPages,
    totals,
    action,
    impersonate,
  };
}
