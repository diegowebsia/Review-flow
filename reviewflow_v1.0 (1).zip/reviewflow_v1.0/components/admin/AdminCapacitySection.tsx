'use client';

import { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';

type Advice = { metric: string; threshold: number; service: string; action: string; monthlyCost: string; current: number; reached: boolean; pct: number };
type Data = {
  snapshot: Record<string, number>;
  totals: { tenantsTotal: number; tenantsActive: number; reviewsDay: number; aiDay: number; unreadSupport: number };
  db: { ok?: boolean; latencyMs?: number } & Record<string, unknown>;
  ai: Array<{ provider: string; model: string }>;
  advice: Advice[];
  generatedAt: string;
};

const LABEL: Record<string, string> = {
  tenants: 'Empresas activas',
  reviewsPerHour: 'Reseñas / hora',
  aiCallsPerHour: 'Llamadas IA / hora',
  aiCostMonthUsd: 'Coste IA del mes (USD)',
  dbMb: 'Base de datos (MB)',
  dbConnections: 'Conexiones BD',
};

/** Capacidad en tiempo real y qué contratar después. Se refresca cada 30 s. */
export function AdminCapacitySection() {
  const [data, setData] = useState<Data | null>(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/capacity', { cache: 'no-store' });
      if (res.ok) setData(await res.json());
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const t = setInterval(load, 30_000);
    return () => clearInterval(t);
  }, []);

  if (!data) return <div className="card text-sm text-ink-400">Cargando capacidad…</div>;

  const kpis = [
    { label: 'Empresas totales', value: data.totals.tenantsTotal },
    { label: 'Activas / prueba', value: data.totals.tenantsActive },
    { label: 'Reseñas 24 h', value: data.totals.reviewsDay },
    { label: 'Respuestas IA 24 h', value: data.totals.aiDay },
    { label: 'Chats sin leer', value: data.totals.unreadSupport },
    { label: 'Latencia BD', value: data.db.latencyMs != null ? `${data.db.latencyMs} ms` : '—' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-ink-400">
          IA: {data.ai.length ? data.ai.map((a) => `${a.provider}/${a.model}`).join(' → ') : 'sin clave (plantillas locales)'}
        </p>
        <button type="button" onClick={load} className="btn-secondary text-xs" disabled={loading}>
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> Actualizar
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        {kpis.map((k) => (
          <div key={k.label} className="card p-4">
            <p className="text-xs text-ink-400">{k.label}</p>
            <p className="mt-1 text-2xl font-bold text-white">{k.value}</p>
          </div>
        ))}
      </div>

      <div className="card space-y-4">
        <p className="text-sm font-semibold text-white">Capacidad y siguiente paso a contratar</p>
        {data.advice.map((a) => {
          const warn = a.pct >= 80;
          return (
            <div key={a.metric} className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-ink-200">{LABEL[a.metric] ?? a.metric}</span>
                <span className="text-ink-300">{a.current} / {a.threshold}</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-white/10">
                <div className={`h-full ${warn ? 'bg-amber-400' : 'bg-brand-500'}`} style={{ width: `${a.pct}%` }} />
              </div>
              <p className="flex items-start gap-1.5 text-xs text-ink-400">
                {warn ? <AlertTriangle size={13} className="mt-0.5 shrink-0 text-amber-400" /> : <CheckCircle2 size={13} className="mt-0.5 shrink-0 text-emerald-400" />}
                <span><b className="text-ink-200">{a.service}</b> ({a.monthlyCost}) — {a.action}</span>
              </p>
            </div>
          );
        })}
      </div>
      <p className="text-[11px] text-ink-500">Actualizado {new Date(data.generatedAt).toLocaleTimeString('es-ES')} · umbrales en lib/scaling.ts</p>
    </div>
  );
}
