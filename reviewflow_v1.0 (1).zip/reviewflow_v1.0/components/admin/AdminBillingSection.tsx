'use client';

import { motion } from 'framer-motion';
import { PLANS, TRIAL_DAYS, formatEur, planOf } from '@/lib/plans';
import { CountUp } from '@/components/Motion';
import { Spinner, TableSkeleton } from '@/components/Skeleton';
import { cn } from '@/lib/utils';
import { StatusBadge } from './AdminTenantsSection';
import { quotaOfTenant, type AdminTenant } from './use-admin-dashboard';

function QuotaBar({ used, quota }: { used: number; quota: number }) {
  const pct = quota > 0 ? Math.min(100, Math.round((used / quota) * 100)) : 0;
  const tone =
    pct >= 100
      ? 'bg-rose-400'
      : pct >= 80
        ? 'bg-amber-400'
        : 'bg-[linear-gradient(90deg,#2563eb,#8b5cf6)]';
  return (
    <span className="flex w-28 items-center gap-2" title={`${used} de ${quota} eventos`}>
      <span className="meter flex-1">
        <span className={tone} style={{ width: `${pct}%` }} />
      </span>
      <span className={cn('text-2xs tabular-nums', pct >= 100 ? 'text-rose-300' : 'text-ink-400')}>
        {pct}%
      </span>
    </span>
  );
}

export function AdminSubscriptionsSection({
  filtered,
  busy,
  busyRow,
  onAction,
}: {
  filtered: AdminTenant[];
  busy: string | null;
  busyRow: (key: string) => boolean;
  onAction: (
    path: string,
    body: Record<string, unknown>,
    key: string,
    okTitle: string,
  ) => Promise<void>;
}) {
  return (
    <section className="space-y-4" aria-label="Suscripciones de Stripe">
      <div className="card p-5">
        <h2 className="font-bold tracking-tightish text-white">Suscripciones de Stripe</h2>
        <p className="mt-1 text-sm text-ink-400">
          El estado se sincroniza por webhooks en{' '}
          <code className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-2xs">
            /api/stripe/webhook
          </code>
          . Prueba de {TRIAL_DAYS} días con tarjeta; si el primer cobro falla, el middleware corta
          el acceso al panel el día 8 (
          <code className="font-mono text-2xs">?reason=trial-ended</code>).
        </p>
        <div className="mt-3 flex flex-wrap gap-3 text-2xs text-ink-300">
          {(['local_starter', 'ecommerce_starter', 'local_pro', 'ecommerce_pro'] as const).map(
            (id) => (
              <span key={id}>
                <strong className="font-bold text-white">{PLANS[id].tier}</strong> ·{' '}
                {formatEur(PLANS[id].priceCents)}/mes ·{' '}
                {PLANS[id].limits.requestsPerMonth.toLocaleString('es-ES')} peticiones
              </span>
            ),
          )}
        </div>
      </div>

      {filtered.map((t) => (
        <motion.div
          key={t.id}
          layout
          className={cn(
            'card flex flex-wrap items-center justify-between gap-3 p-4',
            busyRow(`plan-${t.id}`) && 'opacity-70',
          )}
        >
          <div className="min-w-0">
            <p className="truncate font-semibold text-white">{t.name}</p>
            <p className="mt-0.5 truncate font-mono text-2xs text-ink-500">
              {t.stripe_customer_id ?? 'sin customer id'} · {formatEur(t.mrr_cents)}/mes
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={t.subscription_status} />
            <label className="sr-only" htmlFor={`plan-${t.id}`}>
              Cambiar plan de {t.name}
            </label>
            <select
              id={`plan-${t.id}`}
              className="select w-auto py-1.5 text-xs"
              defaultValue={t.plan}
              disabled={!!busy}
              onChange={(e) =>
                void onAction(
                  '/api/admin/tenants',
                  { tenantId: t.id, op: 'set-plan', plan: e.target.value },
                  `plan-${t.id}`,
                  'Plan actualizado',
                )
              }
            >
              <option value="local_starter">
                {PLANS.local_starter.name} ({formatEur(PLANS.local_starter.priceCents)}/mes)
              </option>
              <option value="local_pro">
                {PLANS.local_pro.name} ({formatEur(PLANS.local_pro.priceCents)}/mes)
              </option>
              <option value="ecommerce_starter">
                {PLANS.ecommerce_starter.name} ({formatEur(PLANS.ecommerce_starter.priceCents)}/mes)
              </option>
              <option value="ecommerce_pro">
                {PLANS.ecommerce_pro.name} ({formatEur(PLANS.ecommerce_pro.priceCents)}/mes)
              </option>
            </select>
            {busyRow(`plan-${t.id}`) && <Spinner />}
          </div>
        </motion.div>
      ))}
    </section>
  );
}

export function AdminQuotaSection({
  tenantsCount,
  filtered,
  totals,
}: {
  tenantsCount: number;
  filtered: AdminTenant[];
  totals: { used: number; extras: number; capped: number };
}) {
  return (
    <section className="space-y-4" aria-label="Cuotas y extras">
      <div className="grid gap-3 sm:grid-cols-3">
        {[
          { label: 'Consumo total del ciclo', value: totals.used },
          { label: 'Recargas concedidas', value: totals.extras },
          { label: 'Empresas al 100 % de cuota', value: totals.capped },
        ].map((m) => (
          <div key={m.label} className="card p-5">
            <p className="text-xs font-semibold tracking-wider text-ink-400">{m.label}</p>
            <p className="mt-2 text-3xl font-extrabold tracking-tighter text-white tabular-nums">
              <CountUp value={m.value} />
            </p>
          </div>
        ))}
      </div>

      <div className="card p-5">
        <h2 className="font-bold tracking-tightish text-white">Consumo por empresa</h2>
        <p className="mt-1 text-sm text-ink-400">
          Cuota del ciclo = peticiones del plan + recargas puntuales compradas. Cuando llega al
          100 %, las APIs devuelven{' '}
          <code className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-2xs">402</code>{' '}
          (falta plan/feature),{' '}
          <code className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-2xs">429</code>{' '}
          (cuota agotada) o{' '}
          <code className="rounded bg-white/[0.07] px-1.5 py-0.5 font-mono text-2xs">507</code>{' '}
          (tope de filas/almacenamiento).
        </p>
        <div className="mt-4 space-y-2">
          {tenantsCount === 0 && <TableSkeleton rows={4} cols={3} />}
          {filtered.map((t) => {
            const quota = quotaOfTenant(t);
            const used = t.used_events ?? 0;
            const extras =
              (t.extra_requests ?? 0) +
              (t.extra_reviews ?? 0) +
              (t.extra_ai ?? 0) +
              (t.extra_syncs ?? 0);
            return (
              <div
                key={t.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] p-3.5"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-white">{t.name}</p>
                  <p className="mt-0.5 text-2xs text-ink-500">
                    {planOf(t.plan).tier} · {quota.toLocaleString('es-ES')} peticiones/ciclo
                    {extras > 0 && (
                      <span className="ml-1 text-emerald-300">
                        (+{extras.toLocaleString('es-ES')} extra)
                      </span>
                    )}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xs tabular-nums text-ink-400">
                    {used.toLocaleString('es-ES')} usados
                  </span>
                  <QuotaBar used={used} quota={quota} />
                  {used >= quota && <span className="badge-danger">bloqueada</span>}
                </div>
                {(t.ai_tokens_cycle ?? 0) > 0 && (
                  <div className="w-full border-t border-white/[0.05] pt-2 text-2xs text-ink-500 sm:w-auto sm:border-0 sm:pt-0">
                    <span className="text-ink-400">IA:</span>{' '}
                    <span className="tabular-nums text-white">
                      {(t.ai_tokens_cycle ?? 0).toLocaleString('es-ES')}
                    </span>{' '}
                    / {(t.ai_tokens_limit ?? 0).toLocaleString('es-ES')} tokens ·{' '}
                    <span className="tabular-nums">≈ {(t.ai_cost_cycle ?? 0).toFixed(3)} USD</span>
                    {(t.ai_fallbacks ?? 0) > 0 && (
                      <span className="ml-1 text-amber-200">· {t.ai_fallbacks} fallback(s)</span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
