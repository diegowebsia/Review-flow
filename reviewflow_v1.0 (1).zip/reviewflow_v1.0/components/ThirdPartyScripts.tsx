'use client';

/**
 * Carga condicional de scripts de terceros según consentimiento.
 * - Sin consentimiento → NO se carga nada (cumple ePrivacy por diseño).
 */
export function ThirdPartyScripts() {
  return null;
}
