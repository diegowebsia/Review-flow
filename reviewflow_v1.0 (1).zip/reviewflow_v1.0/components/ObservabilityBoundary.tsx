'use client';

import { useEffect } from 'react';
import { SENTRY_RELEASE } from '@/lib/observability';
import { errorToReport, reportClientError } from '@/lib/client-error-report';

/**
 * Captura errores no controlados y promesas rechazadas en el navegador y los
 * envía al registro del servidor (`/api/client-errors` → `system_logs` + Sentry).
 */
export function ObservabilityBoundary() {
  useEffect(() => {
    function onError(event: ErrorEvent) {
      const message = event.message || 'Unhandled frontend error';
      console.error(`[ReviewFlow AI][${SENTRY_RELEASE}]`, message);
      reportClientError({
        ...errorToReport('frontend.window_onerror', event.error ?? message),
        message,
        filename: event.filename || undefined,
        lineno: event.lineno || undefined,
        colno: event.colno || undefined,
      });
    }

    function onUnhandledRejection(event: PromiseRejectionEvent) {
      console.error(`[ReviewFlow AI][${SENTRY_RELEASE}] Promesa rechazada`, event.reason);
      reportClientError(errorToReport('frontend.unhandled_rejection', event.reason));
    }

    window.addEventListener('error', onError);
    window.addEventListener('unhandledrejection', onUnhandledRejection);
    return () => {
      window.removeEventListener('error', onError);
      window.removeEventListener('unhandledrejection', onUnhandledRejection);
    };
  }, []);

  return null;
}
