'use client';

import { useEffect, useRef } from 'react';

/**
 * ============================================================
 * ReviewFlow AI — Widget anti-bot Cloudflare Turnstile
 * ============================================================
 * Protege los formularios PÚBLICOS (registro y página de valoración) frente a
 * bots, spam y trolls automatizados.
 *
 * Funcionamiento:
 *  - Si NO existe `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, el componente no pinta nada
 *    y el formulario sigue funcionando (el servidor tampoco exige captcha).
 *  - Si existe, carga el script oficial de Cloudflare, muestra el widget y
 *    devuelve el token por `onToken`. El servidor lo verifica en
 *    `lib/antibot.ts` contra `TURNSTILE_SECRET_KEY`.
 *
 * IMPORTANTE: la clave pública (site key) y la secreta van SIEMPRE en pareja.
 * Configura las dos o ninguna (ver GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md, sección de seguridad).
 */

type TurnstileRenderOptions = {
  sitekey: string;
  theme?: 'light' | 'dark' | 'auto';
  size?: 'normal' | 'compact' | 'flexible';
  action?: string;
  callback?: (token: string) => void;
  'expired-callback'?: () => void;
  'error-callback'?: () => void;
};

type TurnstileApi = {
  render: (el: HTMLElement, options: TurnstileRenderOptions) => string | undefined;
  remove: (widgetId: string) => void;
  reset: (widgetId?: string) => void;
};

declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}

const SITE_KEY = (process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY ?? '').trim();

/** `true` cuando el widget está configurado y debe mostrarse. */
export const turnstileEnabled = SITE_KEY.length > 0;

const SCRIPT_ID = 'cf-turnstile-script';
const SCRIPT_SRC = 'https://challenges.cloudflare.com/turnstile/v0/api.js';

export function Turnstile({
  onToken,
  action,
  className,
}: {
  /** Recibe el token válido, o `null` cuando caduca o falla. */
  onToken: (token: string | null) => void;
  /** Etiqueta del formulario (analítica de Cloudflare). */
  action?: string;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const callbackRef = useRef(onToken);
  useEffect(() => {
    callbackRef.current = onToken;
  }, [onToken]);

  useEffect(() => {
    if (!turnstileEnabled) return;
    let cancelled = false;
    let widgetId: string | undefined;

    const render = () => {
      const api = window.turnstile;
      if (cancelled || !api || !containerRef.current) return;
      containerRef.current.innerHTML = '';
      widgetId = api.render(containerRef.current, {
        sitekey: SITE_KEY,
        theme: 'dark',
        size: 'flexible',
        action,
        callback: (token: string) => callbackRef.current(token),
        'expired-callback': () => callbackRef.current(null),
        'error-callback': () => callbackRef.current(null),
      });
    };

    if (window.turnstile) {
      render();
    } else {
      const existing = document.getElementById(SCRIPT_ID);
      if (existing) {
        existing.addEventListener('load', render);
      } else {
        const script = document.createElement('script');
        script.id = SCRIPT_ID;
        script.src = SCRIPT_SRC;
        script.async = true;
        script.defer = true;
        script.addEventListener('load', render);
        document.head.appendChild(script);
      }
    }

    return () => {
      cancelled = true;
      if (widgetId && window.turnstile) {
        try {
          window.turnstile.remove(widgetId);
        } catch {
          /* el widget ya no existe en el DOM */
        }
      }
    };
  }, [action]);

  if (!turnstileEnabled) return null;

  return (
    <div className={className}>
      <div ref={containerRef} />
      <p className="mt-1.5 text-2xs text-ink-500">
        Verificación anti-bot de Cloudflare. No usa cookies publicitarias.
      </p>
    </div>
  );
}

/**
 * Campo trampa (honeypot) invisible para personas y visible para bots.
 * Debe llamarse `website`: es el nombre que valida `lib/antibot.ts`.
 */
export function HoneypotField({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div aria-hidden className="pointer-events-none absolute -left-[9999px] h-0 w-0 overflow-hidden">
      <label htmlFor="website">Tu web</label>
      <input
        id="website"
        name="website"
        type="text"
        tabIndex={-1}
        autoComplete="off"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}
