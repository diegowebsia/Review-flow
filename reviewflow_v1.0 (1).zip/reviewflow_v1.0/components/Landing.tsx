'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  Bot,
  Check,
  CheckCircle2,
  CreditCard,
  Gauge,
  MapPin,
  Plug,
  Send,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Store,
  TrendingUp,
  Zap,
} from 'lucide-react';
import { SITE } from '@/lib/site';
import { Footer } from '@/components/Footer';
import { AddonPicker } from '@/components/AddonPicker';
import { SiteHeader } from '@/components/SiteHeader';
import { useI18n } from '@/lib/i18n';
import { Aurora, EASE, GlowCard, Reveal, fadeUp } from '@/components/Motion';
import {
  PLAN_CATALOG,
  PLANS,
  LOCAL_PLANS,
  ECOMMERCE_PLANS,
  TRIAL_DAYS,
  annualMonthlyEquivalentCents,
  annualPriceCentsOf,
} from '@/lib/plans';

/* ------------------------------------------------------------------ */
/* Datos                                                               */
/* ------------------------------------------------------------------ */

/* v1.0 — Esquema visual de 3 pasos (menos texto, más claridad). */
const flowSteps = [
  {
    icon: Plug,
    step: '1',
    title: 'Conecta',
    desc: 'Vincula Google Maps o tu tienda (Shopify / WooCommerce) en unos clics. Tus reseñas y pedidos empiezan a fluir solos.',
    tag: 'Google Maps · Shopify · WooCommerce',
  },
  {
    icon: Bot,
    step: '2',
    title: 'Automatiza',
    desc: 'Configura una vez tus plantillas de email y la ingesta de reseñas. La IA redacta cada respuesta con el tono de tu marca.',
    tag: 'Email · Plantillas IA · Ingesta',
  },
  {
    icon: TrendingUp,
    step: '3',
    title: 'Crece',
    desc: 'Ofrece un canal privado para resolver quejas y responde a todas las reseñas. ',
    tag: 'Atención privada · Reputación',
  },
];

const problems = [
  {
    icon: Star,
    title: 'Los clientes contentos no opinan',
    desc: 'Un QR en el local o un email tras la entrega les pide la reseña en el momento adecuado.',
  },
  {
    icon: Bot,
    title: 'Responder lleva tiempo',
    desc: 'La IA prepara un borrador con el tono de tu marca; tú lo revisas y lo publicas.',
  },
  {
    icon: ShieldCheck,
    title: 'Las quejas se enquistan',
    desc: 'Quien tuvo un problema puede escribirte en privado, sin impedir que opine en Google.',
  },
];

const bento = [
  {
    icon: Bot,
    title: 'Respuestas con IA',
    desc: 'Borradores con el tono de tu marca. Si se agota el presupuesto de IA del plan, sigues con plantillas, sin cargos extra.',
    span: 'lg:col-span-2',
    accent: 'from-brand-500/25 to-transparent',
  },
  {
    icon: ShieldCheck,
    title: 'Gestión privada de quejas',
    desc: 'Las reseñas de 3★ o menos entran en una cola con mensaje conciliador y nota de seguimiento.',
    span: '',
    accent: 'from-amber-400/20 to-transparent',
  },
  {
    icon: ShoppingBag,
    title: 'Petición al entregar',
    desc: 'Shopify o WooCommerce avisan al entregar un pedido y el cliente recibe tu enlace de Google.',
    span: '',
    accent: 'from-emerald-400/20 to-transparent',
  },
  {
    icon: Gauge,
    title: 'Cuotas claras y cumplimiento UE',
    desc: 'Ves en todo momento lo consumido de tu plan. Solo reseñas reales de plataformas oficiales y RGPD por diseño.',
    span: 'lg:col-span-2',
    accent: 'from-violet-500/20 to-transparent',
  },
];


/* ------------------------------------------------------------------ */
/* Landing                                                             */
/* ------------------------------------------------------------------ */

export function Landing({ freeTrialEnabled = true }: { freeTrialEnabled?: boolean } = {}) {
  const { formatPrice } = useI18n();
  const [businessFilter, setBusinessFilter] = useState<'all' | 'local' | 'ecommerce'>('all');
  const [billingCycle, setBillingCycle] = useState<'month' | 'year'>('month');


  const displayedPlans =
    businessFilter === 'local'
      ? LOCAL_PLANS
      : businessFilter === 'ecommerce'
        ? ECOMMERCE_PLANS
        : PLAN_CATALOG;

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-ink-950 text-ink-100">
      <SiteHeader freeTrialEnabled={freeTrialEnabled} />

      {/* HERO */}
      <section id="inicio" className="relative">
        <Aurora />
        <div className="relative mx-auto max-w-6xl px-4 pb-20 pt-16 text-center sm:pt-24">
          <motion.div {...fadeUp} initial="hidden" animate="show" transition={{ duration: 0.5 }}>
            <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-sm text-ink-200">
              <Sparkles size={14} className="text-amber-300" />
              {"Para negocios locales y tiendas online"}
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.08, ease: EASE }}
            className="mx-auto mt-7 max-w-4xl text-balance text-4xl font-extrabold leading-[1.05] tracking-tighter text-white sm:text-6xl md:text-[4.25rem]"
          >
            {'Todas tus reseñas.'}{' '}
            <span className="text-gradient">{"Respondidas con IA"}</span> {"antes de que enfríen."}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.16, ease: EASE }}
            className="mx-auto mt-6 max-w-2xl text-balance text-lg leading-relaxed text-ink-300"
          >
            {"Pide opiniones con un QR o un email, y responde todas tus reseñas de Google en segundos con IA."}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.24, ease: EASE }}
            className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <Link href="/registro" className="btn-primary btn-lg group w-full sm:w-auto">
              {freeTrialEnabled ? "Probar 7 días" : "Empezar ahora"}
              <ArrowRight size={17} className="transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
            <a
              href="#planes"
              className="btn-secondary btn-lg w-full sm:w-auto text-brand-200 border-brand-500/30 hover:bg-brand-500/10"
            >
              <CreditCard size={16} className="text-brand-300" />
              {"Ver Planes y Precios"}
            </a>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.32 }}
            className="mt-4 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-sm text-ink-400"
          >
            <span className="inline-flex items-center gap-1.5">
              <CreditCard size={14} /> {"Pago seguro con Stripe"}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Check size={14} className="text-emerald-400" />{' '}
              {freeTrialEnabled ? "No se cobra nada en la prueba" : "Cancela en 1 clic sin permanencia"}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck size={14} className="text-brand-300" /> {"Datos alojados en la UE (RGPD)"}
            </span>
          </motion.p>

          {/* Vista previa del panel en tiempo real */}
          <motion.div
            initial={{ opacity: 0, y: 56, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.85, delay: 0.38, ease: EASE }}
            className="relative mx-auto mt-16 max-w-4xl"
          >
            <div className="absolute -inset-x-10 -top-10 bottom-0 -z-10 rounded-[2rem] bg-[radial-gradient(60%_60%_at_50%_0%,rgba(59,118,240,0.28),transparent_70%)] blur-2xl" aria-hidden />
            <div className="glass overflow-hidden rounded-[1.4rem] text-left shadow-[0_50px_120px_-50px_rgba(2,6,23,1)]">
              <div className="flex items-center gap-1.5 border-b border-white/[0.07] px-4 py-3">
                <span className="h-2.5 w-2.5 rounded-full bg-rose-500/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/70" />
                <Link
                  href="/dashboard"
                  className="ml-3 inline-flex items-center gap-2 rounded-md bg-white/[0.05] px-3 py-1 font-mono text-2xs text-ink-300 transition hover:bg-white/[0.1] hover:text-white"
                  title="Acceder al panel de cliente"
                >
                  {SITE.domain.replace(/[[\]]/g, '') || 'tu-dominio.com'}/dashboard
                  <span className="font-sans text-brand-300">↗ Abrir panel</span>
                </Link>
                <Link
                  href="/registro"
                  className="badge-ok ml-auto hidden sm:inline-flex transition hover:opacity-80"
                >
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> en tiempo real
                </Link>
              </div>

              <div className="grid gap-3 p-4 sm:grid-cols-[0.95fr_1.25fr]">
                <div className="space-y-3">
                  {[
                    { n: 'Google Business', l: 'OAuth conectado', d: 'sincronizado hace 2 min', ok: true },
                    { n: 'Trustpilot', l: 'API Business activa', d: 'sincronizado hoy', ok: true },
                  ].map((s) => (
                    <div key={s.n} className="panel">
                      <p className="flex items-center gap-2 text-sm font-bold text-white">
                        {s.n}
                        <span className="badge-ok ml-auto">
                          <Check size={11} strokeWidth={3} /> {s.ok ? 'ok' : '—'}
                        </span>
                      </p>
                      <p className="mt-0.5 text-xs text-ink-400">{s.l}</p>
                      <p className="mt-1 text-2xs text-emerald-300/90">{s.d}</p>
                    </div>
                  ))}
                  <div className="panel">
                    <p className="flex items-center justify-between text-xs font-semibold text-ink-300">
                      <span className="inline-flex items-center gap-1.5">
                        <Gauge size={13} className="text-brand-300" /> Cuota del ciclo
                      </span>
                      <span className="tabular-nums text-white">184 / 300</span>
                    </p>
                    <div className="meter mt-2">
                      <motion.span
                        className="bg-[linear-gradient(90deg,#2563eb,#5f92fb_55%,#8b5cf6)]"
                        initial={{ width: 0 }}
                        animate={{ width: '61%' }}
                        transition={{ duration: 1.1, delay: 0.9, ease: EASE }}
                      />
                    </div>
                    <p className="mt-1.5 text-2xs text-ink-500">97 reseñas · 71 IA · 16 emails</p>
                  </div>
                </div>

                <div className="panel">
                  <p className="flex items-center gap-2 text-sm font-bold text-white">
                    <Bot size={15} className="text-brand-300" /> Borrador IA listo
                    <span className="badge-brand ml-auto">IA</span>
                  </p>
                  <div className="mt-2.5 flex items-center gap-2">
                    <span className="flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <Star key={i} size={13} className="fill-amber-400 text-amber-400" />
                      ))}
                    </span>
                    <span className="badge">google · verificada</span>
                  </div>
                  <p className="mt-2.5 rounded-xl border border-brand-400/25 bg-brand-500/10 p-3 text-sm leading-relaxed text-brand-100">
                    «Hola Marta, muchísimas gracias por tu reseña. Nos alegra saber que el trato del
                    equipo te hizo sentir como en casa. ¡Te esperamos pronto! — La Brasa»
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <span className="btn-primary btn-sm">
                      <Send size={13} /> Publicar en Google
                    </span>
                    <span className="btn-secondary btn-sm">Editar</span>
                    <span className="btn-quiet btn-sm ml-auto">Gestión privada</span>
                  </div>
                </div>
              </div>
            </div>

          </motion.div>
        </div>
      </section>

      {/* QUÉ RESUELVE */}
      <section id="que-resuelve" className="relative scroll-mt-20 py-20">
        <div className="mx-auto max-w-6xl px-4">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="kicker">Qué resuelve</p>
            <h2 className="mt-3 text-balance text-3xl font-extrabold tracking-tighter text-white sm:text-4xl">
              Pocas reseñas y sin responder alejan clientes
            </h2>
          </Reveal>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {problems.map((x, i) => (
              <Reveal key={x.title} delay={i * 0.07} className="h-full">
                <div className="card h-full border-white/[0.08] bg-white/[0.02] p-6">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-brand-200">
                    <x.icon size={18} />
                  </span>
                  <h3 className="mt-4 text-base font-bold text-white">{x.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink-300">{x.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CÓMO FUNCIONA — v1.0: esquema visual de 3 pasos */}
      <section id="como-funciona" className="relative mx-auto max-w-6xl px-4 py-24">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="kicker">Cómo funciona</p>
          <h2 className="mt-3 text-balance text-3xl font-extrabold tracking-tighter text-white sm:text-4xl">
            Tres pasos para empezar
          </h2>
          <p className="mt-3 text-ink-300">
            Conecta tus fuentes, automatiza la petición y responde desde un solo panel.
          </p>
        </Reveal>

        <div className="relative mt-14 grid gap-5 md:grid-cols-3">
          {/* Línea conectora entre pasos */}
          <div
            className="pointer-events-none absolute left-[16%] right-[16%] top-[4.4rem] hidden h-0.5 bg-[linear-gradient(90deg,transparent,rgba(59,118,240,0.55)_25%,rgba(139,92,246,0.55)_75%,transparent)] md:block"
            aria-hidden
          />
          {flowSteps.map((s, i) => (
            <Reveal key={s.title} delay={i * 0.1}>
              <GlowCard className="relative flex h-full flex-col items-center p-7 text-center">
                <div className="relative">
                  <span className="flex h-20 w-20 items-center justify-center rounded-3xl border border-white/10 bg-[linear-gradient(140deg,rgba(59,118,240,0.32),rgba(139,92,246,0.2))] text-brand-100 shadow-[0_16px_40px_-16px_rgba(37,99,235,0.95)]">
                    <s.icon size={30} strokeWidth={1.8} />
                  </span>
                  <span className="absolute -right-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] text-sm font-extrabold text-white shadow-[0_8px_20px_-8px_rgba(37,99,235,1)]">
                    {s.step}
                  </span>
                </div>
                <h3 className="mt-5 text-xl font-extrabold tracking-tightish text-white">{s.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-300">{s.desc}</p>
                <p className="mt-4 text-2xs font-semibold uppercase tracking-wider text-brand-300/80">{s.tag}</p>
              </GlowCard>
            </Reveal>
          ))}
        </div>
      </section>

      {/* FUNCIONES (bento) */}
      <section id="funciones" className="relative border-y border-white/[0.06] bg-white/[0.012] py-24">
        <div className="mx-auto max-w-6xl px-4">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="kicker">Funciones</p>
            <h2 className="mt-3 text-balance text-3xl font-extrabold tracking-tighter text-white sm:text-4xl">
              Lo esencial para pedir, responder y cuidar tus reseñas
            </h2>
          </Reveal>

          <div className="mt-12 grid gap-4 lg:grid-cols-3">
            {bento.map((b, i) => (
              <Reveal key={b.title} delay={i * 0.07} className={b.span}>
                <GlowCard className="relative h-full overflow-hidden p-6">
                  <div
                    className={`pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-gradient-to-br ${b.accent} blur-2xl`}
                    aria-hidden
                  />
                  <div className="relative">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.05] text-brand-200">
                      <b.icon size={18} />
                    </span>
                    <h3 className="mt-4 text-base font-bold tracking-tightish text-white">{b.title}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink-300">{b.desc}</p>
                  </div>
                </GlowCard>
              </Reveal>
            ))}
          </div>

        </div>
      </section>

      {/* PRECIOS */}
      <section id="planes" className="relative py-24">
        <div className="mx-auto max-w-6xl px-4">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-3.5 py-1 text-xs font-bold text-brand-200">
              <Store size={13} /> 1 Plan = 1 Negocio o Local completo
            </span>
            <h2 className="mt-4 text-balance text-3xl font-extrabold tracking-tighter text-white sm:text-4xl">
              Precios justos según tu modelo de negocio.
            </h2>
            <p className="mt-3 text-ink-300">
              Cada suscripción cubre la gestión integral de <strong>1 ubicación o empresa</strong> (Google, Trustpilot y web).{' '}
              {freeTrialEnabled ? (
                <>
                  Prueba <strong>{TRIAL_DAYS} días gratis con tarjeta</strong> y cancela en 1 clic si no es para ti.
                </>
              ) : (
                <>Sin permanencia: activa tu cuenta hoy y cancela en 1 clic cuando quieras.</>
              )}
            </p>

            {/* Selector de tipo de negocio */}
            <div className="mx-auto mt-8 inline-flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1.5 backdrop-blur-md">
              <button
                type="button"
                onClick={() => setBusinessFilter('local')}
                className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                  businessFilter === 'local'
                    ? 'bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] text-white shadow-sm'
                    : 'text-ink-400 hover:text-white'
                }`}
              >
                <Store size={14} />
                Negocio Físico (Local)
              </button>
              <button
                type="button"
                onClick={() => setBusinessFilter('ecommerce')}
                className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                  businessFilter === 'ecommerce'
                    ? 'bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] text-white shadow-sm'
                    : 'text-ink-400 hover:text-white'
                }`}
              >
                <ShoppingBag size={14} />
                Tienda Online (E-commerce)
              </button>
              <button
                type="button"
                onClick={() => setBusinessFilter('all')}
                className={`rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
                  businessFilter === 'all'
                    ? 'bg-[linear-gradient(135deg,#2563eb,#8b5cf6)] text-white shadow-sm'
                    : 'text-ink-400 hover:text-white'
                }`}
              >
                Ver todos (4)
              </button>
            </div>

            <div className="mt-4 inline-flex items-center gap-1 rounded-xl border border-white/10 bg-white/[0.04] p-1">
              <button
                type="button"
                onClick={() => setBillingCycle('month')}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                  billingCycle === 'month' ? 'bg-brand-600 text-white' : 'text-ink-300 hover:text-white'
                }`}
              >
                Facturación mensual
              </button>
              <button
                type="button"
                onClick={() => setBillingCycle('year')}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                  billingCycle === 'year' ? 'bg-brand-600 text-white' : 'text-ink-300 hover:text-white'
                }`}
              >
                Anual (2 meses gratis)
                <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-2xs font-bold text-emerald-300">
                  -17 %
                </span>
              </button>
            </div>
          </Reveal>

          <div
            className={`mx-auto mt-10 grid gap-5 ${
              businessFilter === 'all'
                ? 'max-w-6xl lg:grid-cols-2 xl:grid-cols-4'
                : 'max-w-4xl lg:grid-cols-2'
            }`}
          >
            {displayedPlans.map((p, i) => {
              const featured = p.id === 'local_starter' || p.id === 'ecommerce_starter';
              const info = PLAN_HIGHLIGHTS[p.id] ?? {
                forWhom: 'Todo tipo de empresas.',
                microCopy: 'Incluye 1 negocio / local completo',
                keyPoints: [
                  '1 Negocio o Ubicación gestionada (Google, Trustpilot y web)',
                  'Canal privado para atender quejas',
                  'Respuestas con IA en segundos',
                  'Soporte incluido',
                ],
              };

              return (
                <Reveal key={p.id} delay={i * 0.08} className="h-full">
                  <div
                    className={`card relative flex h-full flex-col justify-between p-6 sm:p-7 ${
                      featured
                        ? 'ring-gradient bg-[linear-gradient(165deg,rgba(37,99,235,0.16),rgba(124,58,237,0.08)_45%,rgba(255,255,255,0.01))] shadow-glow-lg border-brand-500/40'
                        : 'border-white/[0.08] bg-white/[0.02]'
                    }`}
                  >
                    <div>
                      {featured && (
                        <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-[linear-gradient(120deg,#2563eb,#8b5cf6)] px-3 py-1 text-2xs font-bold uppercase tracking-wider text-white shadow-[0_10px_24px_-12px_rgba(37,99,235,1)]">
                          Más popular
                        </span>
                      )}

                      <div className="flex flex-wrap items-center justify-between gap-1.5">
                        <span className="badge-brand">{p.tier}</span>
                        {freeTrialEnabled && (
                          <span className="badge-ok">{TRIAL_DAYS} días gratis</span>
                        )}
                      </div>

                      <h3 className="mt-3 text-xl font-bold tracking-tight text-white">{p.name}</h3>

                      <div className="mt-2 flex items-baseline gap-1.5">
                        <span className="text-4xl font-extrabold tracking-tighter text-white">
                          {billingCycle === 'year'
                            ? formatPrice(annualMonthlyEquivalentCents(p))
                            : formatPrice(p.priceCents)}
                        </span>
                        <span className="text-sm font-medium text-ink-400">{"/mes"}</span>
                      </div>
                      {billingCycle === 'year' && (
                        <p className="mt-0.5 text-2xs font-semibold text-emerald-300">
                          {"Facturado anualmente (2 meses gratis)"} ({formatPrice(annualPriceCentsOf(p))}/año · {"-17 %"})
                        </p>
                      )}
                      <p className="mt-1 text-2xs font-semibold text-emerald-300/95">
                        {info.microCopy}
                      </p>

                      <div className="mt-3 rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
                        <p className="text-xs text-ink-300 leading-snug">
                          <strong className="text-brand-300 font-semibold">Para quién:</strong> {info.forWhom}
                        </p>
                      </div>

                      <ul className="mt-5 space-y-3 text-xs text-ink-200">
                        {info.keyPoints.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2.5">
                            <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-400" />
                            <span className={idx === 0 ? 'font-semibold text-white leading-snug' : 'leading-snug'}>
                              {item}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-8 pt-4 border-t border-white/[0.08]">
                      <Link
                        href={`/registro?plan=${p.id}`}
                        className={`w-full ${featured ? 'btn-primary shadow-glow-md' : 'btn-secondary'} py-3 text-xs font-bold text-center flex items-center justify-center gap-2`}
                      >
                        <CreditCard size={14} />
                        {freeTrialEnabled ? `Probar ${TRIAL_DAYS} días gratis` : `Contratar ${p.name}`}
                      </Link>
                      <p className="mt-2 text-center text-2xs text-ink-400">
                        Cancela en 1 clic · Sin letra pequeña
                      </p>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>

          <p className="mx-auto mt-8 max-w-3xl text-center text-xs leading-relaxed text-ink-400">
            <Store size={13} className="mr-1 inline text-brand-300" />
            Cada plan cubre <strong className="text-ink-200">un negocio o ubicación</strong>: 1 ficha de Google, 1 perfil de Trustpilot
            y, en planes E-commerce, 1 tienda online. Varios locales necesitan un plan cada uno.
          </p>

          {/* COMPARADOR DE PLANES CON TABLA DE CARACTERÍSTICAS */}
          <div id="comparativa" className="mx-auto mt-16 max-w-5xl scroll-mt-24">
            <Reveal>
              <div className="card overflow-hidden p-6 sm:p-8">
                <div className="text-center">
                  <span className="badge-brand">{"Transparencia total"}</span>
                  <h3 className="mt-3 text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
                    {"Comparativa detallada de planes y límites técnicos"}
                  </h3>
                  <p className="mt-2 text-sm text-ink-400">{"Todos los planes incluyen aislamiento multi-tenant, cumplimiento de la Directiva UE 2019/2161 y cambio de plan en 1 clic sin permanencia."}</p>
                </div>

                <div className="mt-6 overflow-x-auto">
                  <table className="w-full min-w-[720px] text-left text-xs sm:text-sm">
                    <thead>
                      <tr className="border-b border-white/10 text-2xs uppercase tracking-wider text-ink-400">
                        <th className="py-3 pr-4 font-bold text-white">{"Característica / Cuota mensual"}</th>
                        <th className="px-3 py-3 font-bold text-white">
                          Local Básico
                          <span className="block font-mono text-2xs text-brand-300">{formatPrice(PLANS.local_starter.priceCents)}{"/mes"}</span>
                        </th>
                        <th className="px-3 py-3 font-bold text-white">
                          Local Pro
                          <span className="block font-mono text-2xs text-brand-300">{formatPrice(PLANS.local_pro.priceCents)}{"/mes"}</span>
                        </th>
                        <th className="px-3 py-3 font-bold text-white">
                          E-commerce Básico
                          <span className="block font-mono text-2xs text-emerald-300">{formatPrice(PLANS.ecommerce_starter.priceCents)}{"/mes"}</span>
                        </th>
                        <th className="px-3 py-3 font-bold text-white">
                          E-commerce Scale
                          <span className="block font-mono text-2xs text-emerald-300">{formatPrice(PLANS.ecommerce_pro.priceCents)}{"/mes"}</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06] text-ink-200">
                      {[
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.requests, '250 / mes', '1.500 / mes', '800 / mes', '4.000 / mes'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.reviewsStored, '2.500', '15.000', '7.500', '35.000'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.aiReplies, '200 / mes', '1.000 / mes', '500 / mes', '2.500 / mes'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.channels, '✓', '✓', '✓', '✓'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.privateTriage, '✓', '✓', '✓', '✓'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.brandMemory, '✓', '✓', '✓', '✓'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.spamDetector, '✓', '✓', '✓', '✓'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.ecommerceWebhooks, '—', '—', '✓', '✓'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.publicApi, '—', '✓', '✓', '✓'],
                        [{"requests":"Solicitudes de reseña (Email / QR)","reviewsStored":"Reseñas sincronizadas y almacenadas","aiReplies":"Respuestas generadas con IA (Google Gemini)","channels":"Canales conectados (Google, Trustpilot)","privateTriage":"Gestión privada de incidencias","brandMemory":"Memoria de marca y detección automática de idioma","spamDetector":"Detector de reseñas falsas y expediente de reporte","ecommerceWebhooks":"Webhooks Shopify / WooCommerce post-entrega","publicApi":"API de ingesta con rotación 24h y Webhooks salientes","supportLevel":"SLA y nivel de soporte"}.supportLevel, 'Email 24h', 'Prioritario', 'Email 24h', 'Prioritario VIP'],
                      ].map(([feature, ls, lp, es, ep]) => (
                        <tr key={feature} className="transition-colors hover:bg-white/[0.02]">
                          <td className="py-3 pr-4 font-medium text-white">{feature}</td>
                          <td className="px-3 py-3 tabular-nums">{ls}</td>
                          <td className="px-3 py-3 font-semibold text-white tabular-nums">{lp}</td>
                          <td className="px-3 py-3 tabular-nums">{es}</td>
                          <td className="px-3 py-3 font-semibold text-white tabular-nums">{ep}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </Reveal>
          </div>

          {/* AMPLIACIONES PUNTUALES */}
          <div id="ampliaciones" className="mx-auto mt-12 max-w-4xl scroll-mt-24">
            <Reveal>
              <AddonPicker variant="landing" />
            </Reveal>
          </div>

          {/* PREGUNTAS FRECUENTES (FAQ MULTILINGÜE) */}
          <div id="faq" className="mx-auto mt-16 max-w-4xl scroll-mt-24">
            <Reveal>
              <div className="text-center">
                <span className="badge-brand">{"Preguntas frecuentes"}</span>
                <h3 className="mt-3 text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
                  {"Todo claro antes de empezar tu prueba de 7 días"}
                </h3>
                <p className="mt-2 text-sm text-ink-400">{"Respuestas directas sobre facturación, cuotas, privacidad RGPD y funcionamiento de la IA."}</p>
              </div>
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {[{"q":"¿Se realiza algún cobro durante los 7 días de prueba?","a":"No. Durante los 7 días de prueba el cargo es 0 €. Recibirás un recordatorio automático con el resumen de valor generado antes de que termine la prueba y puedes cancelar o pausar en 1 clic desde tu panel."},{"q":"¿Cumple con las normas de Google Business Profile y la Directiva UE 2019/2161?","a":"Sí. Nuestro flujo neutral de valoración nunca oculta las plataformas públicas según la nota (sin review gating prohibido): muestra siempre todas las opciones y ofrece además un canal de atención privada."},{"q":"¿Cómo funciona la respuesta de IA en varios idiomas?","a":"El sistema separa 3 capas de idioma: el idioma de tu panel, el idioma de envío de email de tu local, y el idioma detectado automáticamente en cada reseña para que la IA responda siempre en el idioma exacto del cliente."},{"q":"¿Qué ocurre si llego al 100 % de mi cuota mensual?","a":"Nunca recibes cargos automáticos imprevistos. Recibirás avisos al 50 %, 80 % y 100 % del consumo y podrás ampliar tu cuota con un pack puntual o subir de plan en 1 clic con prorrateo exacto."},{"q":"¿Puedo cambiar entre plan mensual y anual o pausar mi cuenta?","a":"Sí. Desde la pestaña Facturación puedes subir de plan al instante, programar una bajada a fin de ciclo, pasar a facturación anual con 2 meses gratis (-17 %) o pausar tu suscripción 1 mes sin perder tus datos."}].map((item) => (
                  <div
                    key={item.q}
                    className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5 transition hover:border-white/15"
                  >
                    <h4 className="text-sm font-bold text-white">{item.q}</h4>
                    <p className="mt-2 text-xs leading-relaxed text-ink-300">{item.a}</p>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>

          <p className="mt-10 flex items-center justify-center gap-2 text-center text-sm text-ink-400">
            <Zap size={15} className="text-brand-300" /> ¿Tienes dudas sobre tu caso? Escríbenos en{' '}
            <Link href="/contacto" className="font-semibold text-brand-200 underline-offset-4 hover:underline">
              contacto
            </Link>{' '}
            y te orientamos en minutos.
          </p>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="mx-auto max-w-6xl px-4 pb-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-[linear-gradient(135deg,rgba(37,99,235,0.9),rgba(124,58,237,0.85))] p-10 text-center shadow-glow-lg sm:p-16">
            <div className="hero-grid absolute inset-0 opacity-25" aria-hidden />
            <div className="absolute -bottom-24 left-1/2 h-56 w-[36rem] -translate-x-1/2 rounded-full bg-white/20 blur-[100px]" aria-hidden />
            <div className="relative">
              <h2 className="mx-auto max-w-2xl text-balance text-3xl font-extrabold tracking-tighter text-white sm:text-4xl">
                Tu próxima reseña, respondida en minutos y no en semanas
              </h2>
              <p className="mx-auto mt-4 max-w-xl text-balance text-brand-50/90">
                {freeTrialEnabled ? `${TRIAL_DAYS} días gratis. ` : ''}Conecta tu ficha y publica tu primera respuesta hoy.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <Link href="/registro" className="btn-light btn-lg group w-full sm:w-auto">
                  {freeTrialEnabled ? `Probar ${TRIAL_DAYS} días gratis` : 'Crear cuenta ahora'}
                  <ArrowRight size={17} className="transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
                <Link href="/contacto" className="btn btn-lg w-full border border-white/25 bg-white/10 text-white hover:bg-white/20 sm:w-auto">
                  Hablar con nosotros
                </Link>
              </div>
              <p className="mt-5 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-white/70">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin size={12} /> Datos en la UE
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck size={12} /> RGPD + Dir. UE 2019/2161
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <CreditCard size={12} />{' '}
                  {freeTrialEnabled ? 'Sin cobro durante la prueba' : 'Cancela cuando quieras en 1 clic'}
                </span>
              </p>
            </div>
          </div>
        </Reveal>
      </section>

      <Footer />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Piezas                                                              */
/* ------------------------------------------------------------------ */

const PLAN_HIGHLIGHTS: Record<string, { forWhom: string; microCopy: string; keyPoints: string[] }> = {
  local_starter: {
    forWhom: 'Bares, restaurantes, clínicas y comercios a pie de calle.',
    microCopy: 'Incluye 1 negocio / local físico completo',
    keyPoints: [
      '1 Negocio o Ubicación gestionada (Google y Trustpilot)',
      'Cartel QR listo para imprimir en mesas y mostrador',
      'Canal privado: el cliente puede contarte su problema directamente',
      'Respuestas amables con IA en segundos (hasta 250 peticiones/mes)',
    ],
  },
  local_pro: {
    forWhom: 'Un local físico con gran volumen diario de clientes y reseñas.',
    microCopy: 'Incluye 1 negocio / local físico de alto volumen',
    keyPoints: [
      '1 Negocio o Ubicación gestionada (Google y Trustpilot)',
      'Capacidad ampliada: hasta 1.500 peticiones y 1.000 respuestas IA/mes',
      'Avisos urgentes al móvil si entra una queja y sincronización cada 2 h',
      'Soporte prioritario el mismo día laborable',
    ],
  },
  ecommerce_starter: {
    forWhom: 'Tiendas online Shopify, WooCommerce y comercios con envíos.',
    microCopy: 'Incluye 1 tienda online / negocio completo',
    keyPoints: [
      '1 Tienda Online / Negocio gestionado (Google, Trustpilot y web)',
      'Email automático tras entregar cada pedido (800/mes)',
      'Canal privado para incidencias de producto o envío',
      'Muestra reseñas reales con compra verificada',
    ],
  },
  ecommerce_pro: {
    forWhom: 'Una tienda online o marca con gran volumen mensual de pedidos.',
    microCopy: 'Incluye 1 tienda online / marca de alto volumen',
    keyPoints: [
      '1 Tienda Online / Negocio gestionado (Google, Trustpilot y web)',
      'Capacidad máxima: hasta 4.000 peticiones y 2.500 respuestas IA/mes',
      'Sincronización continua de pedidos entregados y opiniones',
      'Soporte VIP prioritario y acceso a API',
    ],
  },
  pro: {
    forWhom: 'Negocios con presencia en Google Maps y Trustpilot.',
    microCopy: 'Incluye 1 negocio / local completo',
    keyPoints: [
      '1 Negocio o Ubicación gestionada (Google y Trustpilot)',
      'Canal privado para atender quejas',
      'Respuestas con IA adaptadas al tono de tu marca',
      'Enlace directo para pedir opiniones por email o QR',
    ],
  },
  business: {
    forWhom: 'Tiendas online con alto volumen de ventas y envíos.',
    microCopy: 'Incluye 1 negocio / tienda online completa',
    keyPoints: [
      '1 Negocio o Tienda Online gestionada al completo',
      'Envío automático al entregar cada pedido',
      'Respuestas de IA de alta capacidad para tu equipo',
      'Soporte prioritario en el mismo día laborable',
    ],
  },
};
