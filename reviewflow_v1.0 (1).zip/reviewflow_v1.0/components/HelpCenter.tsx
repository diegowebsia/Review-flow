'use client';

import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { BookOpenText, CircleHelp, CreditCard, KeyRound, MessageCircle, Plug, Rocket, Search, Sparkles, X } from 'lucide-react';
import { Accordion } from '@/components/Accordion';
import { EASE } from '@/components/Motion';
import { useToast } from '@/components/Toast';

/**
 * Centro de ayuda contextual (v1.0).
 *
 * Sustituye la necesidad de leer las guías extensas (ahora en `docs/`):
 * condensamos solo lo que el cliente necesita, como FAQs desplegables
 * cortas y accionables. Se abre desde el icono «Ayuda» de la cabecera del
 * panel y desde la pestaña «Facturación y cuota».
 */

type HelpCenterProps = {
  open: boolean;
  onClose: () => void;
};

function StepList({ items }: { items: string[] }) {
  return (
    <ol className="list-decimal space-y-1.5 pl-4 text-sm leading-relaxed text-ink-300">
      {items.map((x, i) => (
        <li key={i}>{x}</li>
      ))}
    </ol>
  );
}

const Kbd = ({ children }: { children: React.ReactNode }) => (
  <code className="rounded bg-white/[0.08] px-1.5 py-0.5 font-mono text-2xs text-ink-200">{children}</code>
);

export function HelpCenter({ open, onClose }: HelpCenterProps) {
  const toast = useToast();
  const [searchQuery, setSearchQuery] = useState('');

  // Cierra con Escape y bloquea el scroll de fondo.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  function copyApiKey() {
    try {
      const key = localStorage.getItem('rf-api-key');
      if (key) {
        navigator.clipboard?.writeText(key).then(
          () => toast({ kind: 'success', title: 'API key copiada' }),
          () => toast({ kind: 'error', title: 'No se pudo copiar' }),
        );
        return;
      }
    } catch {
      /* sin clipboard */
    }
    toast({
      kind: 'info',
      title: 'Tu API key está en «Empresa y conexiones»',
      body: 'Cópiala desde ahí para usar la API de ingesta o el webhook de tu tienda.',
    });
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-ink-950/75 p-4 backdrop-blur-sm sm:p-6"
          onClick={onClose}
          role="dialog"
          aria-modal="true"
          aria-label="Ayuda"
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.28, ease: EASE }}
            className="card my-4 w-full max-w-2xl overflow-hidden sm:my-10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-3 border-b border-white/[0.07] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-[linear-gradient(135deg,rgba(37,99,235,0.3),rgba(139,92,246,0.25))] text-brand-200">
                  <CircleHelp size={17} />
                </span>
                <div>
                  <h2 className="text-base font-extrabold tracking-tightish text-white">Ayuda</h2>
                  <p className="text-2xs text-ink-400">Lo esencial en minutos · guías completas en el repositorio</p>
                </div>
              </div>
              <button onClick={onClose} className="btn-quiet btn-sm" aria-label="Cerrar ayuda">
                <X size={15} />
              </button>
            </div>

            <div className="border-b border-white/[0.07] px-5 py-3">
              <div className="relative">
                <Search size={14} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar en la base de conocimiento (ej: Google, Stripe, API, webhooks, 429, RGPD)…"
                  aria-label="Buscar en el centro de ayuda"
                  className="input pl-9 text-xs"
                />
              </div>
            </div>

            <div className="max-h-[65vh] overflow-y-auto p-2">
              <Accordion
                defaultOpen={0}
                items={[
                  {
                    id: 'help-primeros',
                    title: 'Primeros pasos (5 min)',
                    icon: <Rocket size={16} className="text-brand-300" />,
                    meta: 'Para empezar',
                    content: (
                      <div className="space-y-3">
                        <StepList
                          items={[
                            'Elegir plan y activar la prueba de 7 días con tarjeta (no se cobra durante la prueba).',
                            'Crear la empresa (o déjala que se cree sola al confirmar Stripe).',
                            'Conectar al menos una fuente de reseñas en «Empresa y conexiones».',
                            'Elegir el tono de la IA y probar una respuesta con una reseña real.',
                          ]}
                        />
                      </div>
                    ),
                  },
                  {
                    id: 'help-credenciales',
                    title: 'Credenciales y .env (servidor)',
                    icon: <KeyRound size={16} className="text-amber-300" />,
                    meta: 'Dueño del proyecto',
                    content: (
                      <div className="space-y-3">
                        <p className="text-sm text-ink-300">
                          Se configuran <strong>una sola vez</strong> en el servidor (<Kbd>cp .env.example .env</Kbd>).
                          Las obligatorias:
                        </p>
                        <StepList
                          items={[
                            'Supabase: NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY y SUPABASE_SERVICE_ROLE_KEY (Project Settings → API).',
                            'Stripe: STRIPE_SECRET_KEY, NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY, STRIPE_WEBHOOK_SECRET y los Price IDs.',
                            'Seguridad crítica: APP_SIGNING_SECRET y PRIVACY_HASH_PEPPER (mínimo 32 caracteres cada uno, aislados de Supabase).',
                          ]}
                        />
                      </div>
                    ),
                  },
                  {
                    id: 'help-stripe',
                    title: 'Planes, prorrateo 1 clic, plan anual y recargas (Stripe)',
                    icon: <CreditCard size={16} className="text-emerald-300" />,
                    meta: 'Cobros',
                    content: (
                      <div className="space-y-3">
                        <StepList
                          items={[
                            'Cambio de plan in-app en 1 clic con prorrateo exacto (always_invoice) o plan anual con 2 meses gratis (-17 %).',
                            'Periodo de gracia de 3 días ante fallo puntual de tarjeta (Smart Retries + secuencia dunning sin cortar acceso el día 1).',
                            'Pausa de 1 mes sin coste desde Facturación para conservar todos tus datos en temporada baja.',
                          ]}
                        />
                      </div>
                    ),
                  },
                  {
                    id: 'help-cuotas',
                    title: 'Límites: entender 402, 403, 429 y 507',
                    icon: <BookOpenText size={16} className="text-violet-300" />,
                    meta: 'Resolución',
                    content: (
                      <div className="space-y-2 text-sm leading-relaxed text-ink-300">
                        <p>
                          <strong className="text-rose-300">402</strong> — suscripción sin acceso (prueba caducada o gracia agotada). Reactiva con -20 % el primer mes.
                        </p>
                        <p>
                          <strong className="text-amber-300">403</strong> — la acción requiere un rol superior (RBAC: owner/admin/agent/viewer) o un plan con tienda online.
                        </p>
                        <p>
                          <strong className="text-rose-300">429</strong> — cuota del mes agotada. Recibes avisos al 50 %, 80 % y 100 % y puedes ampliar en 1 clic.
                        </p>
                      </div>
                    ),
                  },
                  {
                    id: 'help-ia',
                    title: 'IA: memoria de marca, idioma automático y anti-spam',
                    icon: <Sparkles size={16} className="text-brand-300" />,
                    meta: 'IA',
                    content: (
                      <div className="space-y-3">
                        <StepList
                          items={[
                            'Detección automática del idioma de la reseña (es, en, ca, pt, fr, de, it) para responder en el idioma del cliente.',
                            'Memoria de marca: tono, plantillas por sector, palabras prohibidas y firma fija.',
                            'Detector de reseñas falsas/spam con generación de dossier formal para reportar a Google.',
                          ]}
                        />
                      </div>
                    ),
                  },
                  {
                    id: 'help-conexiones',
                    title: 'Conexiones: Google, Trustpilot, Booking, Amazon',
                    icon: <Plug size={16} className="text-brand-300" />,
                    meta: 'Integraciones',
                    content: (
                      <div className="space-y-3">
                        <StepList
                          items={[
                            'Google Business (OAuth 1 clic) o Google Places pegando tu Place ID.',
                            'Trustpilot, Booking, Amazon, Yelp, Glassdoor e Idealista.',
                            'Alertas en tiempo real de reseñas ≤3★ por email, Slack y Microsoft Teams.',
                          ]}
                        />
                      </div>
                    ),
                  },
                  {
                    id: 'help-api',
                    title: 'API pública, rotación 24h y Webhooks salientes (Zapier / Make)',
                    icon: <MessageCircle size={16} className="text-emerald-300" />,
                    meta: 'Integración',
                    content: (
                      <div className="space-y-3">
                        <StepList
                          items={[
                            'API key con prefijo rf_live_, hash SHA-256 en base de datos y rotación con solape de 24 horas.',
                            'Ingesta: POST /api/integrations/ingest con tu api_key.',
                            'Webhooks salientes firmados con HMAC hacia Zapier, Make, Slack o Teams.',
                          ]}
                        />
                        <button type="button" onClick={copyApiKey} className="btn-secondary btn-sm">
                          <KeyRound size={13} /> Copiar mi API key
                        </button>
                      </div>
                    ),
                  },
                ].filter((item) => {
                  const q = searchQuery.trim().toLowerCase();
                  if (!q) return true;
                  return item.title.toLowerCase().includes(q) || item.meta.toLowerCase().includes(q) || item.id.includes(q);
                })}
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.07] px-5 py-3">
              <p className="text-2xs text-ink-500">
                ¿Necesitas algo más? Escríbenos y respondemos en 24 h laborables.
              </p>
              <a href="/contacto" className="btn-secondary btn-sm" onClick={onClose}>
                Contactar
              </a>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
