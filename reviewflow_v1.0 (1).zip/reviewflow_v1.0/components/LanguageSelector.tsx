'use client';

import { useEffect, useState } from 'react';
import { Globe } from 'lucide-react';
import { SUPPORTED_LOCALES, useI18n, type SupportedCurrency, type SupportedLocale } from '@/lib/i18n';

/**
 * Traductor automático de toda la web (Google Website Translator, el mismo que
 * usan muchas empresas). Traduce TODO el texto visible, incluido el que se añada
 * en el futuro, sin diccionarios manuales.
 *
 * Para que algo NO se traduzca (respuestas de la IA, reseñas de clientes,
 * nombres de marca) basta con ponerle `translate="no"` y `className="notranslate"`.
 *
 * El idioma elegido se guarda en la cookie `googtrans` y se aplica en todas las páginas.
 */
const SOURCE: SupportedLocale = 'es';
const SCRIPT_ID = 'google-translate-script';

declare global {
  interface Window {
    googleTranslateElementInit?: () => void;
    google?: {
      translate: {
        TranslateElement: new (options: Record<string, unknown>, elementId: string) => unknown;
      };
    };
  }
}

function readCurrent(): SupportedLocale {
  if (typeof document === 'undefined') return SOURCE;
  const m = document.cookie.match(/(?:^|;\s*)googtrans=\/[a-z-]+\/([a-z-]+)/i);
  const code = (m?.[1] ?? SOURCE).slice(0, 2) as SupportedLocale;
  return SUPPORTED_LOCALES.some((l) => l.code === code) ? code : SOURCE;
}

function setCookie(value: string | null) {
  const host = window.location.hostname;
  const domains = ['', host, host.split('.').slice(-2).join('.')];
  for (const d of domains) {
    const domainPart = d ? `; domain=.${d.replace(/^\./, '')}` : '';
    document.cookie = value
      ? `googtrans=${value}; path=/${domainPart}; max-age=31536000`
      : `googtrans=; path=/${domainPart}; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
  }
}

function ensureTranslatorLoaded() {
  if (document.getElementById(SCRIPT_ID)) return;
  if (!document.getElementById('google_translate_element')) {
    const holder = document.createElement('div');
    holder.id = 'google_translate_element';
    document.body.appendChild(holder);
  }
  window.googleTranslateElementInit = () => {
    if (!window.google) return;
    new window.google.translate.TranslateElement(
      {
        pageLanguage: SOURCE,
        includedLanguages: SUPPORTED_LOCALES.map((l) => l.code).join(','),
        autoDisplay: false,
      },
      'google_translate_element',
    );
  };
  const s = document.createElement('script');
  s.id = SCRIPT_ID;
  s.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
  s.async = true;
  document.body.appendChild(s);
}

export function LanguageSelector({
  showCurrency = false,
  className = '',
}: {
  showCurrency?: boolean;
  className?: string;
}) {
  const { currency, setCurrency } = useI18n();
  const [locale, setLocale] = useState<SupportedLocale>(SOURCE);

  useEffect(() => {
    setLocale(readCurrent());
    ensureTranslatorLoaded();
  }, []);

  const change = (next: SupportedLocale) => {
    setLocale(next);
    if (next === SOURCE) setCookie(null);
    else setCookie(`/${SOURCE}/${next}`);
    // Recargar garantiza que toda la página (y las siguientes) salgan traducidas.
    window.location.reload();
  };

  return (
    <div translate="no" className={`notranslate inline-flex items-center gap-1.5 ${className}`}>
      <label className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2.5 py-1.5 text-xs font-medium text-ink-200 transition hover:border-white/20">
        <Globe size={13} className="text-brand-300" aria-hidden="true" />
        <span className="sr-only">Idioma</span>
        <select
          aria-label="Idioma"
          value={locale}
          onChange={(e) => change(e.target.value as SupportedLocale)}
          className="cursor-pointer bg-transparent text-xs font-semibold text-white focus:outline-none"
        >
          {SUPPORTED_LOCALES.map((item) => (
            <option key={item.code} value={item.code} className="bg-ink-900 text-white">
              {item.nativeName}
            </option>
          ))}
        </select>
      </label>

      {showCurrency && (
        <label className="inline-flex items-center rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1.5 text-xs font-medium text-ink-200 transition hover:border-white/20">
          <span className="sr-only">Moneda</span>
          <select
            aria-label="Moneda"
            value={currency}
            onChange={(e) => setCurrency(e.target.value as SupportedCurrency)}
            className="cursor-pointer bg-transparent text-xs font-semibold text-white focus:outline-none"
          >
            <option value="EUR" className="bg-ink-900 text-white">EUR (€)</option>
            <option value="GBP" className="bg-ink-900 text-white">GBP (£)</option>
            <option value="USD" className="bg-ink-900 text-white">USD ($)</option>
          </select>
        </label>
      )}
    </div>
  );
}
