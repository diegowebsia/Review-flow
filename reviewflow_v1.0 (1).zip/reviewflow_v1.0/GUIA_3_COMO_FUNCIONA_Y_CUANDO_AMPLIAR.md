# Guía 3 — ReviewFlow AI v1.0: funcionamiento, seguridad y mantenimiento

**Índice de las 3 guías:** [1 · Probar en local](./GUIA_1_PROBAR_EN_LOCALHOST.md) → [2 · Publicar y cobrar](./GUIA_2_PUBLICAR_Y_PAGAR.md) → [3 · Funcionamiento, seguridad y mantenimiento](./GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md).

## 1. Lo esencial como propietario

ReviewFlow centraliza opiniones, solicita valoraciones por QR y correo y prepara respuestas con IA. El cliente se registra, confirma su correo en producción, elige plan con tarjeta, crea su empresa y conecta sus fuentes.

- **No hay plan gratuito**: la primera prueba dura 7 días; después Stripe cobra automáticamente. La prueba se controla por cuenta/correo normalizado, no prueba la identidad de una persona ni impide que use otro correo diferente.
- **Cada empresa paga su propio plan** y tiene límites independientes. Se añade desde «Empresa y conexiones → Añadir otra empresa» y se cambia con el selector del panel; las adicionales no tienen otra prueba gratis.
- Cambios y bajas: «Facturación → Gestionar suscripción». Los códigos promocionales se crean en Stripe (Guía 2, paso 5.6). Un impago tiene 3 días de margen.
- **Tú administras** soporte, cuentas, proveedores, impuestos y copias; la automatización no sustituye la supervisión. `/admin` muestra clientes, ingresos, uso y capacidad; Stripe es la referencia para cobros, reembolsos e impagos.
- Antes de vender, completa las pruebas de la Guía 2 y revisa textos legales, IVA/facturas, privacidad, consentimiento de correos y condiciones de los proveedores con tu asesor. No prometas opiniones positivas ni ocultes las negativas; solicita valoraciones de forma neutral y respeta las políticas de Google/Trustpilot.

## Los 4 planes (precios sin IVA)

| | Local Básico | E-commerce Básico | Local Pro | E-commerce Scale |
|---|---|---|---|---|
| Precio/mes | **19 €** | **29 €** | **39 €** | **69 €** |
| Peticiones de opinión/mes | 250 | 800 | 1.500 | 4.000 |
| Opiniones importadas/mes | 500 | 1.500 | 3.000 | 10.000 |
| Respuestas con IA/mes | 200 | 500 | 1.000 | 2.500 |
| Sincronizaciones automáticas/mes | 60 | 180 | 360 | 1.000 |
| Opiniones guardadas | 2.500 | 7.500 | 15.000 | 35.000 |
| Integraciones | 4 | 8 | 12 | 25 |
| Conexión con tienda online | — | ✓ | — | ✓ |
| API pública | — | ✓ | ✓ | ✓ |
| Soporte | Correo | Correo | Prioritario | Prioritario |

- Pago anual: 10 mensualidades (2 meses gratis).
- Si un cliente llega al límite, puede comprar **packs extra** (por ejemplo +500 respuestas IA) o subir de plan.
- Los precios y límites se cambian en un solo archivo: `lib/plans.ts`. Si cambias un precio, cambia también el producto en Stripe.

## 2. Qué no debes compartir

**Nunca adjuntes un `.env`, su copia ni una exportación de producción a un chat, una IA, un correo de soporte, una captura o un repositorio.** Tampoco distribuyas un ZIP que los contenga. Un repositorio privado no es un almacén de secretos.

| Información | Tratamiento |
|---|---|
| `.env`, `.env.local-backup`, listados de variables, contraseñas, sesiones, enlaces de acceso/recuperación, códigos de doble verificación | Privados; guarda las claves en un gestor de contraseñas y en las variables de Vercel. Guarda códigos de recuperación fuera del ordenador habitual. |
| `SUPABASE_SERVICE_ROLE_KEY`, `DATABASE_URL` y contraseña de la base | Llaves maestras: solo servidor; nunca navegador, clientes ni prefijo `NEXT_PUBLIC_`. |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, claves de IA/Resend, `GOOGLE_CLIENT_SECRET`, `TURNSTILE_SECRET_KEY` | Secretos privados, incluso los de prueba. |
| `APP_SIGNING_SECRET`, `OAUTH_STATE_SECRET`, `INTEGRATION_ENCRYPTION_KEY`, `PRIVACY_HASH_PEPPER`, `HEALTH_KEY`, `HEALTHCHECK_SECRET`, `CRON_SECRET` | Secretos internos; no pegarlos en direcciones web ni enviarlos a servicios ajenos. |
| Claves de integraciones de clientes, datos personales, facturas, copias de la base y registros de errores | Confidenciales; comparte únicamente lo imprescindible y anonimizado con personas autorizadas. |
| URL de Supabase y clave `anon`, Stripe `pk_`, Turnstile site key, datos fiscales públicos | Diseñados para uso público; no dan acceso de administrador. La clave `anon` depende de las políticas de acceso del esquema. Nunca añadas un secreto a una variable `NEXT_PUBLIC_`. |
| `.env.example`, las 3 guías y `supabase/schema.sql` | Plantillas/código sin credenciales: compartibles si no les has pegado valores reales ni datos de clientes. |

**Para pedir ayuda:** comparte el texto del error, fecha/hora, página, pasos y código de incidencia (`correlationId`); oculta valores, correos, teléfonos, cabeceras de acceso y datos de clientes. Revisa también los archivos antes de adjuntarlos.

### Protección de tus accesos

- Activa doble verificación en tu correo, GitHub, Vercel, Supabase y Stripe. Protege especialmente el correo de `SUPERADMIN_EMAILS`: da acceso de administrador, no es una lista de empleados.
- Invita colaboradores con su propia cuenta y el permiso mínimo; no entregues tu contraseña ni acceso completo a producción para una consulta. Revoca sus accesos al terminar.
- Mantén prueba y producción separados. Usa `pk_test_`/`sk_test_` solo en pruebas, `pk_live_`/`sk_live_` en producción y el `whsec_` del destino correcto. Desactiva `ALLOW_PLACEHOLDER_SITE_CONFIG` en producción.
- Turnstile necesita **las dos** claves: pública y privada (Guía 2, paso 6.6). No desactives políticas de acceso ni controles de seguridad para resolver un error.

### Si se filtra una clave

1. Revócala o sustitúyela inmediatamente en el proveedor; borrar el mensaje o el archivo no basta.
2. Actualiza las variables de Vercel y redespliega. Revisa accesos, cobros, envíos, consumo y registros; invalida sesiones comprometidas y avisa a los afectados si corresponde.
3. Si llegó a GitHub, retírala también del historial con ayuda técnica y comprueba copias existentes. Consulta a tu asesor si hubo datos personales: una brecha puede exigir notificación en 72 horas.
4. **No regeneres todas las claves a ciegas con `npm run setup -- --force` en producción.** Cambiar `INTEGRATION_ENCRYPTION_KEY` sin conservar la anterior y recifrar los datos deja las conexiones guardadas ilegibles. La rotación usa `INTEGRATION_ENCRYPTION_KEY_PREVIOUS` y la operación administrativa protegida `/api/admin/credentials/rotate`: requiere doble verificación y ayuda técnica; verifica todos los lotes antes de retirar la anterior. Cambiar firmas o el pepper también requiere revisar enlaces y controles existentes.

## 3. Copias y mantenimiento

- `supabase/schema.sql` es el **único SQL** de esta entrega: contiene tablas, funciones y permisos actualizados. No hay carpeta de migraciones ni historial duplicado. **No es una copia de tus datos.** No lo ejecutes en otro proyecto por confusión ni aceptes avisos destructivos sin comprobar lo que ejecutas.
- Antes de cambios de base, claves o publicación, conserva una copia recuperable del código, de los datos (incluidas cuentas y archivos almacenados, si los hay) y de las claves de cifrado, por separado y protegidas. Comprueba la política y retención de tu plan de Supabase; los archivos almacenados necesitan su propia copia.
- Prueba la restauración en un entorno separado antes de depender de una copia. Volver a un despliegue anterior de Vercel **no restaura** la base ni revierte cobros de Stripe.
- Revisa diariamente al lanzar: altas, confirmaciones de correo, pagos/webhooks, IA y fallos. Semanalmente: capacidad, gasto, correos, tareas y copias. Usa alertas de consumo de cada proveedor; sus tarifas y límites cambian.
- Conserva código, `package-lock.json`, pruebas, scripts, configuración y `.env.example`: no son archivos obsoletos. Actualiza dependencias con revisión y pruebas; no uses arreglos forzados que puedan romper el proyecto.

## 4. Proveedores y cuándo ampliar

Importes orientativos, no presupuestos garantizados; comprueba precios y límites actuales en cada proveedor.

| Servicio | Cuándo actuar |
|---|---|
| Supabase | Pasa a Pro antes del primer cliente de pago (referencia: 25 $/mes); Free puede pausarse por inactividad y no sustituye una estrategia de copias. Vigila tamaño, conexiones y uso. |
| Vercel | Pro para uso comercial y las tareas horarias; referencia: 20 $/mes más posibles extras. Vigila uso y duración de ejecuciones. |
| Gemini / proveedor de IA | Activa facturación o ajusta límites cuando las cuotas o errores lo exijan, no por un número fijo de clientes. Revisa coste y presupuesto por empresa. |
| Resend | Gratis: referencia de 3.000 correos/mes y 100/día; amplía antes de superar cualquiera (Pro: referencia de 20 $/mes). Los correos de acceso también consumen cuota si usan su SMTP. |
| Google / Trustpilot / tienda | Configura permisos, credenciales y autorizaciones reales. Google Business Profile puede requerir aprobación; Places no equivale a acceso completo a todas las opiniones. Trustpilot necesita API key y Business Unit ID con acceso habilitado por su plan. Verifica cada conexión antes de ofrecerla. |
| Límite de peticiones | Usa Supabase (`api_rate_limits`); v1.0 no requiere Upstash Redis. Si falta la configuración en producción, bloquea peticiones por seguridad. |
| Sentry / Turnstile | Opcionales: errores y protección anti-bots. Revisa sus permisos, límites y datos enviados. |

**Regla práctica:** revisa `/admin` → Capacidad cada semana; al 80 %, revisa y planifica antes de agotar recursos. Ese panel no sustituye la factura ni los límites oficiales de los proveedores.

## 5. Tareas automáticas y pruebas

Vercel ejecuta estas 3 tareas de `vercel.json` en producción; **horarios UTC**, no hora de Madrid:

| Tarea | Frecuencia |
|---|---|
| Sincronizar opiniones | Cada hora, minuto 07 |
| Resumen semanal | Lunes, 08:00 UTC |
| Recordatorios de prueba/registro | Diario, 09:30 UTC |

Configura `CRON_SECRET` y mantén `ENABLE_INTERNAL_CRON=false` en producción. Confirma ejecuciones reales en Vercel → Cron Jobs y los resultados; no basta con que aparezcan listadas. Si fallan, revisa autorización, límites, tiempos y conexión a los proveedores.

| Comando (terminal de VS Code, carpeta del proyecto) | Alcance |
|---|---|
| `npm run typecheck`, `npm run lint`, `npm test`, `npm run build` | Tipos, calidad, pruebas y preparación del código; no certifican servicios de producción. |
| `npm run test:ia` | Simula Gemini, OpenAI, Anthropic y OpenRouter; no usa claves reales ni demuestra una respuesta real del proveedor. Sin claves la app puede responder con plantillas: no lo confundas con IA conectada. |
| `npm run test:pagos` | Avanzado: requiere PostgreSQL local con el esquema, PostgREST en puerto 3001 y `node e2e/fake-supabase.mjs`. Simula eventos firmados; no cobra ni prueba Stripe real. |
| `npm run verify -- --url https://tudominio.es` | Comprueba acceso, configuración y firma del webhook; revisa avisos. Usa solo tu dominio y claves correspondientes al destino, guardadas de forma privada. No confirma por sí solo pagos reales, entrega de correo, todas las integraciones ni aislamiento con sesiones reales. |

`/api/health` sin clave solo confirma que la aplicación responde; no demuestra que Stripe o la IA funcionen. El estado privado exige `HEALTH_KEY`/`HEALTHCHECK_SECRET` en una cabecera de autorización, nunca en la URL. Completa siempre registro/confirmación, cobro y activación, cancelación, una respuesta real de IA, correo recibido y acceso denegado a otra cuenta (Guías 1 y 2).

## 6. Dónde guardar cada configuración

| Entorno | Qué guardar |
|---|---|
| Local (`.env`) | Credenciales de pruebas. Reinicia `npm run dev` tras cambiarlas. |
| Vercel → Settings → Environment Variables | Credenciales reales solo en producción; separa Preview/Development y redespliega tras cambios. |
| Secretos de GitHub | Ninguno obligatorio para las comprobaciones incluidas; no subas `.env` ni uses claves reales para las pruebas simuladas. |

## 7. Indexación, SEO y últimos límites

- **Dominio único:** configura `NEXT_PUBLIC_APP_URL` con tu dominio HTTPS antes de publicar. Si existe `PUBLIC_APP_URL`, tiene prioridad: elimínala si está obsoleta o haz que ambas coincidan. Revisa también `NEXT_PUBLIC_DOMAIN`. Después redespliega y comprueba que QR, correos, pagos y direcciones canónicas usan el mismo dominio.
- **Qué entra en Google:** portada, precios, contacto, sobre nosotros y páginas legales. Registro, acceso, recuperación, paneles, estado, carteles y valoraciones llevan `noindex` y no están en el sitemap. Las respuestas privadas y API también llevan `X-Robots-Tag`. **`noindex` y `robots.txt` no son seguridad**: la privacidad depende de los controles de acceso.
- **Después de publicar:** abre `/robots.txt` y `/sitemap.xml` en tu dominio; no deben contener localhost, dominios de pruebas ni `invalid.example`. En Google Search Console → Añadir propiedad → Dominio, verifica el TXT en tu proveedor DNS y envía `sitemap.xml` en «Sitemaps». Usa «Inspección de URLs» para portada y precios. Puede tardar días o semanas; ningún cambio garantiza posiciones ni que Google indexe todas las páginas.
- Cada página tiene título, descripción y etiquetas para compartir propios. Los datos de empresa y producto se publican solo en portada; no se publican preguntas frecuentes estructuradas que difieran del texto visible. No declares valoraciones, premios, certificaciones ni descuentos no acreditados.
- **IA y privacidad:** el código incluye varios proveedores y respaldos. Comprueba cuáles activas y adapta el DPA y la política de privacidad a los proveedores, regiones y contratos reales. La guía de pruebas usa Gemini gratis, pero el DPA menciona la API de pago: sus condiciones de tratamiento no son necesariamente iguales. No uses datos sensibles de clientes con una modalidad sin revisar sus condiciones; minimiza los datos enviados y revisa las respuestas antes de publicarlas.
- **Claves de la API de clientes:** «API pública» significa un punto de conexión accesible, **no una clave pública**. La clave `rf_live_...` de cada empresa es privada; se gestiona en «Empresa y conexiones» y solo se entrega al responsable autorizado de su integración. Rotar permite un solape de 24 horas; en una filtración usa **Revocar**, que bloquea de inmediato, y reconfigura las integraciones. No compartas capturas del panel con claves.
- **No confundas aprobación con código listo:** las pruebas incluidas y preparar la aplicación no prueban tu cuenta de Stripe, entrega de correo, Google/Trustpilot, fiscalidad ni aislamiento con usuarios reales. Verifica esos pasos en tu propia producción. Mantener v1.0 no significa renunciar a futuros parches de seguridad.

El ZIP conserva **v1.0** y solo estas tres guías; el índice está al inicio de cada una. Publicar el código no equivale a verificar el negocio: no anuncies el lanzamiento hasta completar las comprobaciones reales de la Guía 2.
