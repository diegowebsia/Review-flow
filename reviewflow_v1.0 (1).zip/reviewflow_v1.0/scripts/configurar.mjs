#!/usr/bin/env node
/**
 * ============================================================
 * ReviewFlow AI — Asistente de configuracion inicial
 * ============================================================
 * Crea el archivo `.env` a partir de `.env.example` y genera
 * automaticamente TODAS las claves internas de seguridad.
 *
 * Uso:
 *   node scripts/configurar.mjs           # crea .env si no existe
 *   node scripts/configurar.mjs --force   # regenera las claves internas
 *
 * Despues solo tienes que rellenar a mano las claves externas
 * (Supabase, Gemini, Stripe...). El script te dice cuales faltan.
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import process from 'node:process';

const force = process.argv.includes('--force');
const root = process.cwd();
const examplePath = path.join(root, '.env.example');
const envPath = path.join(root, '.env');

const c = {
  b: (t) => `\u001b[1m${t}\u001b[0m`,
  ok: (t) => `\u001b[32m${t}\u001b[0m`,
  warn: (t) => `\u001b[33m${t}\u001b[0m`,
  bad: (t) => `\u001b[31m${t}\u001b[0m`,
  dim: (t) => `\u001b[2m${t}\u001b[0m`,
};

if (!fs.existsSync(examplePath)) {
  console.error(c.bad('No encuentro .env.example. Ejecuta el script desde la raiz del proyecto.'));
  process.exit(1);
}

/** Claves internas que el propio proyecto puede generar solo. */
const GENERATED = {
  APP_SIGNING_SECRET: () => crypto.randomBytes(32).toString('hex'),
  OAUTH_STATE_SECRET: () => crypto.randomBytes(32).toString('hex'),
  INTEGRATION_ENCRYPTION_KEY: () => crypto.randomBytes(32).toString('base64'),
  PRIVACY_HASH_PEPPER: () => crypto.randomBytes(24).toString('hex'),
  HEALTH_KEY: () => crypto.randomBytes(16).toString('hex'),
  HEALTHCHECK_SECRET: () => crypto.randomBytes(24).toString('hex'),
  CRON_SECRET: () => crypto.randomBytes(24).toString('hex'),
};

/** Claves externas imprescindibles para que el panel de clientes funcione. */
const REQUIRED_EXTERNAL = [
  ['NEXT_PUBLIC_SUPABASE_URL', 'Supabase > Project Settings > API > Project URL'],
  ['NEXT_PUBLIC_SUPABASE_ANON_KEY', 'Supabase > Project Settings > API > anon public'],
  ['SUPABASE_SERVICE_ROLE_KEY', 'Supabase > Project Settings > API > service_role'],
];

/** Claves externas opcionales (la app arranca sin ellas). */
const OPTIONAL_EXTERNAL = [
  ['GEMINI_API_KEY', 'aistudio.google.com > Get API key (respuestas con IA)'],
  ['STRIPE_SECRET_KEY', 'dashboard.stripe.com > Developers > API keys (cobros)'],
  ['STRIPE_WEBHOOK_SECRET', 'stripe listen --forward-to localhost:3000/api/stripe/webhook'],
  ['RESEND_API_KEY', 'resend.com > API Keys (emails)'],
  ['GOOGLE_PLACES_API_KEY', 'console.cloud.google.com > Places API (importar resenas)'],
];

function parse(text) {
  const map = new Map();
  for (const line of text.split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=(.*)$/);
    if (m) map.set(m[1], m[2].trim());
  }
  return map;
}

const exampleText = fs.readFileSync(examplePath, 'utf8');
const existed = fs.existsSync(envPath);
let envText = existed ? fs.readFileSync(envPath, 'utf8') : exampleText;
const current = parse(envText);

function setValue(key, value) {
  const re = new RegExp(`^\\s*${key}\\s*=.*$`, 'm');
  if (re.test(envText)) envText = envText.replace(re, `${key}=${value}`);
  else envText += `\n${key}=${value}`;
}

const generated = [];
for (const [key, make] of Object.entries(GENERATED)) {
  const value = current.get(key);
  if (!value || force) {
    setValue(key, make());
    generated.push(key);
  }
}

fs.writeFileSync(envPath, envText, 'utf8');
const after = parse(fs.readFileSync(envPath, 'utf8'));

console.log(c.b('\nReviewFlow AI - configuracion inicial\n'));
console.log(
  existed
    ? c.ok('OK  .env ya existia y se ha actualizado.')
    : c.ok('OK  .env creado a partir de .env.example.'),
);
console.log(
  generated.length
    ? c.ok(`OK  ${generated.length} claves internas generadas automaticamente:`) +
        c.dim(`\n    ${generated.join(', ')}`)
    : c.dim('--  Las claves internas ya estaban puestas (usa --force para regenerarlas).'),
);

const missingRequired = REQUIRED_EXTERNAL.filter(([k]) => !after.get(k));
const missingOptional = OPTIONAL_EXTERNAL.filter(([k]) => !after.get(k));

if (missingRequired.length) {
  console.log(c.warn('\nFALTA (obligatorio para el panel de clientes):'));
  for (const [k, where] of missingRequired) console.log(`  - ${c.b(k)}  ${c.dim(where)}`);
} else {
  console.log(c.ok('\nOK  Base de datos y login configurados.'));
}

if (missingOptional.length) {
  console.log(c.dim('\nOpcional (la app arranca igual, esas funciones quedan desactivadas):'));
  for (const [k, where] of missingOptional) console.log(c.dim(`  - ${k}  ${where}`));
}

console.log(
  c.b('\nSiguiente paso: ') +
    (missingRequired.length
      ? 'abre .env, pega las claves de Supabase y vuelve a ejecutar este comando.\n'
      : 'npm run dev  y abre http://localhost:3000\n'),
);
console.log(c.dim('Guia completa paso a paso: GUIA_1_PROBAR_EN_LOCALHOST.md\n'));
