#!/usr/bin/env node
/**
 * ============================================================
 * ReviewFlow AI — Verificación de lanzamiento (v1.0)
 * ============================================================
 * Comprueba, contra tu propia app desplegada, que lo comercial está listo
 * ANTES de vender. No necesita claves de Stripe: usa el `whsec_` de tu .env
 * para FIRMAR un evento de prueba y verifica que tu webhook lo acepta.
 *
 * Uso:
 *   node scripts/verify-launch.mjs                      # contra http://localhost:3000
 *   node scripts/verify-launch.mjs --url https://tu-dominio.com
 *   node scripts/verify-launch.mjs --url … --quiet
 *
 * Qué verifica:
 *   1. /api/health responde y qué integraciones están configuradas.
 *   2. IA: configuración local del proveedor y modelo (no ejecuta una llamada real).
 *   3. PostgreSQL: latencia y conexiones del pool (?db=1, si hay DATABASE_URL).
 *   4. Stripe: presencia local de precios de los cuatro planes y recargas.
 *   5. Webhook: firma válida → 2xx · firma inválida → 400 (seguridad).
 *   6. Rutas de IA protegidas: sin sesión → 401 (nunca ejecuta IA gratis).
 *
 * Requiere `.env` (o variables de entorno) con STRIPE_WEBHOOK_SECRET y, si
 * quieres comprobar precios, las variables STRIPE_PRICE_*.
 */

import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

/* ----------------------------- utilidades ----------------------------- */

function loadEnv(file = '.env') {
  const p = path.resolve(process.cwd(), file);
  if (!fs.existsSync(p)) return {};
  const out = {};
  for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let value = m[2].trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    out[m[1]] = value;
  }
  return out;
}

const args = process.argv.slice(2);
const quiet = args.includes('--quiet');
const urlArg = args.find((a, i) => args[i - 1] === '--url') ?? args.find((a) => a.startsWith('http://') || a.startsWith('https://'));
const env = { ...loadEnv('.env'), ...process.env };
const BASE = (urlArg ?? env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000').replace(/\/$/, '');

let pass = 0;
let warn = 0;
let fail = 0;

const C = {
  ok: (s) => `\x1b[32m${s}\x1b[0m`,
  bad: (s) => `\x1b[31m${s}\x1b[0m`,
  warn: (s) => `\x1b[33m${s}\x1b[0m`,
  dim: (s) => `\x1b[2m${s}\x1b[0m`,
  bold: (s) => `\x1b[1m${s}\x1b[0m`,
};

function ok(label, detail = '') {
  pass += 1;
  console.log(`${C.ok('  ✓')} ${label}${detail ? C.dim(` — ${detail}`) : ''}`);
}
function bad(label, detail = '') {
  fail += 1;
  console.log(`${C.bad('  ✗')} ${label}${detail ? C.dim(` — ${detail}`) : ''}`);
}
function soft(label, detail = '') {
  warn += 1;
  console.log(`${C.warn('  !')} ${label}${detail ? C.dim(` — ${detail}`) : ''}`);
}
function title(text) {
  if (!quiet) console.log(`\n${C.bold(text)}`);
}

async function safeFetch(url, init) {
  try {
    return await fetch(url, { cache: 'no-store', ...init });
  } catch (e) {
    return {
      status: 0,
      ok: false,
      networkError: e?.message ?? String(e),
      json: async () => null,
      text: async () => '',
    };
  }
}

async function getJson(url, init) {
  try {
    const res = await fetch(url, { cache: 'no-store', ...init });
    const body = await res.json().catch(() => null);
    return { status: res.status, body, headers: res.headers };
  } catch (e) {
    return { status: 0, body: null, error: e?.message ?? String(e) };
  }
}

/* ------------------------------- pruebas ------------------------------ */

async function checkHealth() {
  title('1. Liveness y readiness');
  const live = await getJson(`${BASE}/api/health?mode=live`);
  if (live.status !== 200 || !live.body?.ok) {
    bad('La app no responde en liveness', `status ${live.status}`);
    return null;
  }
  ok('Liveness público mínimo', 'respuesta pública correcta');

  const healthSecret = env.HEALTH_KEY || env.HEALTHCHECK_SECRET;
  if (healthSecret) {
    const ready = await getJson(`${BASE}/api/health?mode=ready`, {
      headers: { Authorization: `Bearer ${healthSecret}` },
    });
    if (ready.status === 200 && ready.body?.ok) ok('Readiness privado: configuración y BD listas');
    else bad('Readiness no superado', `HTTP ${ready.status}`);
  } else {
    soft('Readiness no comprobado', 'falta HEALTHCHECK_SECRET en el entorno local');
  }

  return {
    integrations: {
      supabase: Boolean(env.NEXT_PUBLIC_SUPABASE_URL && env.NEXT_PUBLIC_SUPABASE_ANON_KEY),
      supabaseAdmin: Boolean(env.SUPABASE_SERVICE_ROLE_KEY),
      stripe: Boolean(env.STRIPE_SECRET_KEY),
      stripeWebhook: Boolean(env.STRIPE_WEBHOOK_SECRET),
      stripePrices: Boolean(env.STRIPE_PRICE_LOCAL_STARTER && env.STRIPE_PRICE_ECOMMERCE_STARTER && env.STRIPE_PRICE_LOCAL_PRO && env.STRIPE_PRICE_ECOMMERCE_PRO),
      database: Boolean(env.DATABASE_URL),
    },
    ai: {
      model: env.GEMINI_MODEL || 'gemini-2.5-flash',
    },
  };
}

async function checkAi(health) {
  title('2. Configuración local de IA');
  const ai = health?.ai;
  if (!ai) {
    soft('La app no expone el bloque `ai` en /api/health', 'comprueba el estado del sistema');
    return;
  }
  const provider = env.AI_PROVIDER || 'gemini';
  const model = env.AI_MODEL || (provider === 'gemini' ? ai.model : 'predeterminado del proveedor');
  soft('Proveedor y modelo declarados en el entorno local', `${provider} / ${model}; no verificados en el servidor`);
  if (env.AI_API_KEY || (provider === 'gemini' && env.GEMINI_API_KEY)) {
    soft('Clave de IA presente en el entorno local', 'no se ha ejecutado una llamada real al proveedor');
  } else {
    soft('Sin clave de IA principal en el entorno local', 'revisa las claves principal y de respaldo del servidor');
  }
  soft('Concurrencia, límites y reintentos no verificados', 'consulta el estado privado y las pruebas del motor de IA');
}

async function checkDatabase(health) {
  title('3. PostgreSQL / pool de conexiones');
  if (!health?.integrations?.database) {
    soft('DATABASE_URL no configurada', 'la app funciona con PostgREST; añádela para mantenimiento');
    return;
  }
  ok('DATABASE_URL presente');
  soft('Detalle del pool protegido', 'compruébalo con sesión super-admin en GET /api/admin/db');
}

async function checkStripeConfig(health) {
  title('4. Stripe (planes y recargas)');
  const integ = health?.integrations ?? {};
  if (!integ.stripe) {
    bad('STRIPE_SECRET_KEY no configurada');
    return;
  }
  if (integ.stripePrices) ok('Precios de los cuatro planes configurados');
  else soft('Faltan uno o más STRIPE_PRICE_* de los cuatro planes', 'el checkout responderá 500');

  const addons = ['STRIPE_PRICE_ADDON_REQUESTS', 'STRIPE_PRICE_ADDON_REVIEWS', 'STRIPE_PRICE_ADDON_AI', 'STRIPE_PRICE_ADDON_SYNCS'];
  const hasAny = addons.some((k) => env[k]);
  if (hasAny) ok('Recargas con Price ID propio');
  else soft('Recargas sin Price ID', 'se crean con price_data inline (importes de lib/plans.ts): funciona igual');
}

async function checkWebhookSignature() {
  title('5. Webhook de Stripe (validación de firma)');
  const secret = env.STRIPE_WEBHOOK_SECRET;
  if (!secret) {
    bad('STRIPE_WEBHOOK_SECRET no está en el entorno/.env', 'no se puede firmar el evento de prueba');
    return;
  }

  let generateTestHeaderString;
  try {
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(env.STRIPE_SECRET_KEY || 'sk_test_dummy', { apiVersion: '2024-06-20' });
    generateTestHeaderString = (payload) => stripe.webhooks.generateTestHeaderString({ payload, secret });
  } catch (e) {
    soft('No se pudo cargar el SDK de Stripe para firmar', e?.message ?? '');
    return;
  }

  // Evento sintético: no crea ni cobra nada, solo verifica la cadena de firma.
  const payload = JSON.stringify({
    id: `evt_verify_${Date.now()}`,
    object: 'event',
    type: 'customer.subscription.updated',
    api_version: '2024-06-20',
    created: Math.floor(Date.now() / 1000),
    livemode: false,
    pending_webhooks: 1,
    request: { id: null, idempotency_key: null },
    data: {
      object: {
        id: 'sub_verify_launch',
        object: 'subscription',
        status: 'active',
        metadata: { plan: 'local_pro', verification: 'verify-launch-script' },
        items: { data: [{ price: { id: env.STRIPE_PRICE_LOCAL_PRO ?? 'price_verify' } }] },
      },
    },
  });

  const good = await safeFetch(`${BASE}/api/stripe/webhook`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'stripe-signature': generateTestHeaderString(payload) },
    body: payload,
  });
  if (good.status >= 200 && good.status < 300) ok('El webhook acepta un evento con firma válida', `HTTP ${good.status}`);
  else if (good.status === 503) soft('El webhook responde 503: falta STRIPE_WEBHOOK_SECRET en el servidor', 'revisa el despliegue');
  else bad('El webhook rechazó una firma válida', `HTTP ${good.status} — revisa el secreto y que no haya un proxy alterando el body`);

  const badRes = await safeFetch(`${BASE}/api/stripe/webhook`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'stripe-signature': 't=1,v1=firmafalsa' },
    body: payload,
  });
  if (badRes.status === 400) ok('El webhook rechaza firmas inválidas (400)');
  else bad('El webhook no rechazó una firma inválida', `HTTP ${badRes.status}: riesgo de seguridad`);
}

async function checkAiEndpointGuards() {
  title('6. Rutas de IA protegidas');
  const noSession = await safeFetch(`${BASE}/api/ai`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      tenantId: '00000000-0000-0000-0000-000000000000',
      task: 'reply',
      businessName: 'X',
      authorName: 'Y',
      rating: 5,
      reviewText: 'Prueba de verificación (sin sesión).',
    }),
  });
  const expected = [401, 503];
  if (expected.includes(noSession.status)) {
    ok('Sin sesión no se ejecuta IA', `HTTP ${noSession.status}`);
  } else {
    bad('La ruta de IA respondió sin sesión', `HTTP ${noSession.status}: revisa proxy.ts`);
  }

  const badBody = await safeFetch(`${BASE}/api/ai`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ task: 'reply' }),
  });
  if (badBody.status === 400) ok('Zod rechaza el cuerpo inválido', 'HTTP 400');
  else if (expected.includes(badBody.status)) ok('El middleware bloquea peticiones sin sesión antes de llegar a Zod', `HTTP ${badBody.status}`);
  else bad('Respuesta inesperada para una petición inválida sin sesión', `HTTP ${badBody.status}`);
}

/* -------------------------------- main -------------------------------- */

console.log(C.bold(`\nReviewFlow AI · verificación de lanzamiento\n${C.dim(`Destino: ${BASE}`)}`));

const health = await checkHealth();
if (!health) {
  console.log(
    C.bad(`\nNo se puede completar la verificacion: ${BASE} no responde correctamente.`) +
      C.dim('\nArranca la app antes de verificar:  npm run dev\n'),
  );
  process.exit(1);
}
await checkAi(health);
await checkDatabase(health);
await checkStripeConfig(health);
await checkWebhookSignature();
await checkAiEndpointGuards();

console.log(
  `\n${C.bold('Resultado:')} ${C.ok(`${pass} correctas`)} · ${C.warn(`${warn} avisos`)} · ${C.bad(`${fail} fallos`)}`,
);
if (fail > 0) {
  console.log(C.bad('\nCorrige los fallos antes de vender. Detalles en GUIA_2_PUBLICAR_Y_PAGAR.md.\n'));
  process.exit(1);
}
console.log(C.ok('\nComprobaciones terminadas sin fallos detectados. Revisa los avisos; los cobros reales, la IA y los flujos con sesión requieren comprobación adicional.\n'));
