// Pasarela mínima tipo Supabase: /rest/v1 -> PostgREST real ; /auth/v1/admin -> auth.users en Postgres
import http from 'node:http'; import pg from 'pg';
const db = new pg.Pool({ host: '/tmp', port: 5499, user: 'postgres', database: 'postgres' });
http.createServer(async (req, res) => {
  const chunks = []; for await (const c of req) chunks.push(c); const body = Buffer.concat(chunks);
  const send = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (req.url.startsWith('/rest/v1')) {
    const p = http.request({ host: '127.0.0.1', port: 3001, path: req.url.slice(8) || '/', method: req.method, headers: { ...req.headers, host: 'x' } }, (r) => { res.writeHead(r.statusCode, r.headers); r.pipe(res); });
    p.end(body); return;
  }
  if (req.url.startsWith('/auth/v1/admin/users') && req.method === 'GET') {
    const { rows } = await db.query('select id, email from auth.users'); return send(200, { users: rows, aud: 'authenticated' });
  }
  if (req.url.startsWith('/auth/v1/admin/users') && req.method === 'POST') {
    const j = JSON.parse(body.toString()); const { rows } = await db.query('insert into auth.users(email, raw_user_meta_data) values ($1,$2) returning id, email', [j.email, j.user_metadata ?? {}]);
    return send(200, { ...rows[0], aud: 'authenticated', user_metadata: j.user_metadata });
  }
  if (req.url.startsWith('/auth/v1/admin/generate_link')) return send(200, { properties: {} });
  send(404, { msg: 'not mocked ' + req.url });
}).listen(54321, () => console.log('fake supabase :54321'));
