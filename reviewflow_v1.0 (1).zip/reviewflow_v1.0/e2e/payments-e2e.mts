// Prueba de extremo a extremo de pagos SIN claves reales:
// eventos de Stripe firmados -> ruta real /api/stripe/webhook -> base de datos real (Postgres + RLS).
import crypto from 'node:crypto';
const SECRET = 'super-secret-jwt-token-with-at-least-32-characters-long';
const jwt = (role: string, sub?: string) => {
  const b = (o: object) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const h = b({ alg: 'HS256', typ: 'JWT' }), p = b({ role, sub, aud: 'authenticated', exp: Math.floor(Date.now() / 1000) + 3600 });
  return `${h}.${p}.${crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url')}`;
};
Object.assign(process.env, {
  NEXT_PUBLIC_SUPABASE_URL: 'http://127.0.0.1:54321', NEXT_PUBLIC_SUPABASE_ANON_KEY: jwt('anon'),
  SUPABASE_SERVICE_ROLE_KEY: jwt('service_role'), STRIPE_SECRET_KEY: 'sk_test_fake', STRIPE_WEBHOOK_SECRET: 'whsec_test_fake',
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY: 'pk_test_fake',
});
const ok = (c: boolean, m: string) => { console.log(`${c ? 'OK ' : 'FALLO'} ${m}`); if (!c) process.exitCode = 1; };

const { getStripe } = await import('../lib/stripe');
const { POST } = await import('../app/api/stripe/webhook/route');
const { createAdminClient } = await import('../lib/supabase/admin');
const stripe = getStripe()!; const admin = createAdminClient()!;
const trialEnd = Math.floor(Date.now() / 1000) + 7 * 86400;
const subs: Record<string, any> = {};
(stripe.subscriptions as any).retrieve = async (id: string) => subs[id];
(stripe.subscriptions as any).update = async (id: string, p: any) => Object.assign(subs[id], p);

async function send(event: any) {
  const payload = JSON.stringify(event);
  const sig = stripe.webhooks.generateTestHeaderString({ payload, secret: 'whsec_test_fake' });
  const res = await POST(new Request('http://x/api/stripe/webhook', { method: 'POST', body: payload, headers: { 'stripe-signature': sig } }));
  return { status: res.status, body: await res.json() };
}
const ev = (type: string, object: any) => ({ id: 'evt_' + crypto.randomUUID(), object: 'event', type, data: { object }, api_version: '2024-06-20', created: Date.now() / 1000 });

// 0. firma falsa
{ const r = await POST(new Request('http://x', { method: 'POST', body: '{}', headers: { 'stripe-signature': 't=1,v1=bad' } })); ok(r.status === 400, 'rechaza webhook con firma falsa (400)'); }

// 1. alta con prueba de 7 días, plan Local Pro
const email = `cliente${Date.now()}@test.es`;
subs.sub_1 = { id: 'sub_1', status: 'trialing', trial_end: trialEnd, metadata: { plan: 'local_pro' }, items: { data: [{ price: { id: 'price_x' } }] } };
const e1 = ev('checkout.session.completed', { id: 'cs_1', object: 'checkout.session', mode: 'subscription', customer: 'cus_1', subscription: 'sub_1', customer_details: { email, name: 'Bar Pepe' }, metadata: { plan: 'local_pro', businessName: 'Bar Pepe' }, amount_total: 3900 });
let r = await send(e1); ok(r.status === 200, `checkout.session.completed procesado (${r.status} ${JSON.stringify(r.body).slice(0, 120)})`);
let { data: t } = await admin.from('tenants').select('*').eq('stripe_subscription_id', 'sub_1').single();
ok(!!t, 'se crea la empresa en la base de datos');
ok(t?.plan === 'local_pro', `plan guardado = local_pro (es ${t?.plan})`);
ok(t?.subscription_status === 'trialing', `estado = trialing (es ${t?.subscription_status})`);
const { data: m } = await admin.from('memberships').select('role').eq('tenant_id', t?.id);
ok(m?.[0]?.role === 'owner', 'el comprador queda como propietario');
ok(subs.sub_1.metadata?.tenantId === t?.id, 'la suscripción de Stripe queda vinculada a la empresa');

// 2. reenvío del mismo evento (Stripe reintenta) -> no duplica
r = await send(e1); ok(r.body.duplicate === true, 'evento repetido se ignora (no duplica cobros)');
const { count } = await admin.from('tenants').select('id', { count: 'exact', head: true }).eq('stripe_subscription_id', 'sub_1');
ok(count === 1, 'sigue habiendo una sola empresa');

// 3. cambio de plan a E-commerce Scale y activa
subs.sub_1 = { ...subs.sub_1, status: 'active', trial_end: null, metadata: { ...subs.sub_1.metadata, plan: 'ecommerce_pro' } };
r = await send(ev('customer.subscription.updated', { ...subs.sub_1, object: 'subscription', customer: 'cus_1' }));
({ data: t } = await admin.from('tenants').select('*').eq('id', t.id).single());
ok(r.status === 200 && t.plan === 'ecommerce_pro', `cambio de plan aplicado (plan ${t.plan}, estado ${t.subscription_status})`);

// 4. pago fallido -> past_due
r = await send(ev('invoice.payment_failed', { id: 'in_1', object: 'invoice', customer: 'cus_1', subscription: 'sub_1', customer_email: email, attempt_count: 1 }));
({ data: t } = await admin.from('tenants').select('*').eq('id', t.id).single());
ok(r.status === 200 && t.subscription_status === 'past_due', `pago fallido corta acceso (estado ${t.subscription_status})`);

// 5. baja
r = await send(ev('customer.subscription.deleted', { ...subs.sub_1, status: 'canceled', object: 'subscription', customer: 'cus_1' }));
({ data: t } = await admin.from('tenants').select('*').eq('id', t.id).single());
ok(r.status === 200 && t.subscription_status === 'inactive', `baja marca inactive (estado ${t.subscription_status})`);

// 6. aislamiento entre clientes (RLS): otro usuario no ve esta empresa
const { createClient } = await import('@supabase/supabase-js');
const intruder = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, jwt('authenticated', crypto.randomUUID()), { auth: { persistSession: false } });
const { data: seen } = await intruder.from('tenants').select('id').eq('id', t.id);
ok((seen ?? []).length === 0, 'otro usuario NO puede ver la empresa (aislamiento)');
const owner = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, jwt('authenticated', t.owner_id), { auth: { persistSession: false } });
const { data: mine, error: oe } = await owner.from('tenants').select('id').eq('id', t.id);
ok((mine ?? []).length === 1, `el propietario SÍ ve su empresa ${oe?.message ?? ''}`);
process.exit(process.exitCode ?? 0);
