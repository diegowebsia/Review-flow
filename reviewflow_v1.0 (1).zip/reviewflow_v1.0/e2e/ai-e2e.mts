// Prueba de la IA SIN claves reales: intercepta las llamadas a Gemini, OpenAI y Anthropic
// y comprueba que la app envía la petición correcta y usa la respuesta (y el respaldo).
const ok = (c: boolean, m: string) => { console.log(`${c ? 'OK ' : 'FALLO'} ${m}`); if (!c) process.exitCode = 1; };
const calls: { url: string; body: any; headers: any }[] = [];
let down = new Set<string>();
const realFetch = globalThis.fetch;
globalThis.fetch = (async (input: any, init: any = {}) => {
  const url = String(input?.url ?? input); const body = init.body ? JSON.parse(String(init.body)) : null;
  const headers = Object.fromEntries(new Headers(init.headers ?? input?.headers).entries());
  calls.push({ url, body, headers });
  const j = (s: number, o: any) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json' } });
  if (url.includes('generativelanguage.googleapis.com')) {
    if (down.has('gemini')) return j(429, { error: { code: 429, message: 'quota', status: 'RESOURCE_EXHAUSTED' } });
    return j(200, { candidates: [{ content: { role: 'model', parts: [{ text: 'Gracias Ana, nos alegra que te gustara. Respuesta GEMINI.' }] }, finishReason: 'STOP' }], usageMetadata: { promptTokenCount: 50, candidatesTokenCount: 20, totalTokenCount: 70 } });
  }
  if (url.endsWith('/chat/completions')) {
    if (down.has('openai')) return j(500, {});
    return j(200, { choices: [{ message: { content: 'Gracias Ana, nos alegra que te gustara. Respuesta OPENAI.' } }], usage: { prompt_tokens: 40, completion_tokens: 15 } });
  }
  if (url.endsWith('/messages')) return j(200, { content: [{ type: 'text', text: 'Gracias Ana, nos alegra que te gustara. Respuesta CLAUDE.' }], usage: { input_tokens: 30, output_tokens: 12 } });
  return realFetch(input, init);
}) as typeof fetch;

const clear = () => { for (const k of ['AI_PROVIDER','AI_MODEL','AI_API_KEY','AI_BASE_URL','GEMINI_API_KEY','AI_FALLBACK_PROVIDER','AI_FALLBACK_MODEL','AI_FALLBACK_API_KEY']) delete process.env[k]; calls.length = 0; down = new Set(); };
const { generateWithLlm } = await import('../lib/llm');
const ask = () => generateWithLlm({ systemPrompt: 'Eres un asistente', userPrompt: 'Ana: Muy buen servicio', maxAttempts: 1 });

clear(); let r = await ask(); ok(!r.ok && r.code === 'llm_not_configured', 'sin clave: no llama a nadie y la app usa plantillas');

clear(); process.env.GEMINI_API_KEY = 'g-key'; r = await ask();
ok(r.ok && r.text!.includes('GEMINI'), `Gemini (solo GEMINI_API_KEY, como la Guía 1): ${r.text}`);
ok(calls[0]?.url.includes('gemini-2.5-flash'), 'usa el modelo gemini-2.5-flash');
ok(calls[0]?.headers['x-goog-api-key'] === 'g-key' || calls[0]?.url.includes('key=g-key'), 'envía la clave de Gemini');

clear(); Object.assign(process.env, { AI_PROVIDER: 'openai', AI_MODEL: 'gpt-4.1-mini', AI_API_KEY: 'sk-x' }); r = await ask();
ok(r.ok && r.text!.includes('OPENAI') && calls[0].url === 'https://api.openai.com/v1/chat/completions', 'OpenAI: endpoint correcto');
ok(calls[0].headers.authorization === 'Bearer sk-x' && calls[0].body.model === 'gpt-4.1-mini', 'OpenAI: clave y modelo correctos');

clear(); Object.assign(process.env, { AI_PROVIDER: 'openai', AI_MODEL: 'gpt-5-mini', AI_API_KEY: 'sk-x' }); r = await ask();
ok(r.ok && calls[0].body.max_completion_tokens && !('max_tokens' in calls[0].body), 'OpenAI gpt-5: usa max_completion_tokens');

clear(); Object.assign(process.env, { AI_PROVIDER: 'anthropic', AI_MODEL: 'claude-haiku-4-5', AI_API_KEY: 'sk-ant' }); r = await ask();
ok(r.ok && r.text!.includes('CLAUDE') && calls[0].url === 'https://api.anthropic.com/v1/messages' && calls[0].headers['x-api-key'] === 'sk-ant' && calls[0].headers['anthropic-version'], 'Anthropic: endpoint, clave y versión correctos');

clear(); Object.assign(process.env, { AI_PROVIDER: 'openai', AI_API_KEY: 'sk-x', AI_BASE_URL: 'https://openrouter.ai/api/v1', AI_MODEL: 'meta/llama' }); r = await ask();
ok(r.ok && calls[0].url === 'https://openrouter.ai/api/v1/chat/completions', 'OpenRouter/compatibles: usa AI_BASE_URL');

clear(); Object.assign(process.env, { AI_PROVIDER: 'openai', AI_API_KEY: 'sk-x', AI_FALLBACK_PROVIDER: 'anthropic', AI_FALLBACK_API_KEY: 'sk-ant' }); down.add('openai'); r = await ask();
ok(r.ok && r.text!.includes('CLAUDE'), 'si el principal cae, salta al respaldo');

const { generateReviewReply } = await import('../lib/ai');
clear(); const rep = await generateReviewReply({ reviewText: 'Muy buen servicio', rating: 5, authorName: 'Ana', businessName: 'Bar Pepe' } as any);
ok(rep.provider === 'local-template' && rep.reply.length > 20, `sin IA: responde con plantilla local ("${rep.reply.slice(0, 50)}…")`);
process.exit(process.exitCode ?? 0);
