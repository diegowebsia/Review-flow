# Guía 1 — Probar ReviewFlow AI v1.0 en tu ordenador

**Índice de las 3 guías:** [1 · Probar en local](./GUIA_1_PROBAR_EN_LOCALHOST.md) → [2 · Publicar y cobrar](./GUIA_2_PUBLICAR_Y_PAGAR.md) → [3 · Funcionamiento, seguridad y mantenimiento](./GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md).

Al terminar tendrás la aplicación funcionando en `http://localhost:3000`: podrás registrarte, elegir un plan con una tarjeta de prueba y usar el panel. **Todo gratis.**

> **Cómo leer esta guía:** los bloques grises son comandos. Cópialos, pégalos donde indique la etiqueta y pulsa **Enter**. Espera a que termine uno antes del siguiente.
>
> Cada comando lleva una etiqueta que dice **dónde** escribirlo:
> - 🟦 **PowerShell (ventana aparte)** — solo en el Paso 1, para instalar programas. Se abre así: tecla **Windows** → escribe `PowerShell` → pulsa **Windows PowerShell**.
> - 🟩 **Terminal de Visual Studio Code** — todo lo demás (desde el Paso 3). Es la ventana de abajo dentro de VS Code. Por dentro también es PowerShell, pero ya está situada en la carpeta del proyecto, que es lo importante.
>
> Si escribes un comando del proyecto (`npm ...`) en la PowerShell aparte, fallará con «no se encuentra package.json»: usa siempre la de VS Code.

---

## Paso 1 — Instalar los programas (una sola vez)

1. **Node.js 22** → <https://nodejs.org/es/download> → en el selector elige la versión **v22 (LTS)**, Windows y «Instalador de Windows (.msi)» → descarga e instala con todo por defecto. **Ojo:** el botón grande «LTS» de la portada ahora instala Node 24, que no es la versión que usa el proyecto (si ya lo instalaste, desinstálalo desde Configuración → Aplicaciones e instala la 22).
2. **Visual Studio Code** → <https://code.visualstudio.com/> → instalar con todo por defecto.
3. Abre 🟦 **PowerShell (ventana aparte)**: tecla **Windows** → escribe `PowerShell` → **Windows PowerShell**.
4. 🟦 **En esa PowerShell**, permite que Windows ejecute los comandos de Node (sin esto, `npm` da el error «no se pueden cargar scripts»). Pega y responde `S` si pregunta:
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
   ```
5. 🟦 **En la misma PowerShell**, instala la **Stripe CLI** (para pagos de prueba). Si pregunta por los términos, escribe `Y`:
   ```powershell
   winget install Stripe.StripeCLI
   ```
   (En Mac usa la app **Terminal**: `brew install stripe/stripe-cli/stripe`.)
6. **Cierra esa PowerShell y abre otra nueva** (para que reconozca lo recién instalado). 🟦 Comprueba:
   ```powershell
   node -v
   stripe --version
   ```
   El primero debe mostrar `v22...` y el segundo un número de versión. Ya puedes **cerrar PowerShell**: no la volverás a usar.

## Paso 2 — Abrir el proyecto en Visual Studio Code

1. Descomprime el ZIP en una carpeta fácil, por ejemplo `C:\reviewflow`. Dentro aparecerá la carpeta `reviewflow_v1.0`.
2. Abre Visual Studio Code → **Archivo → Abrir carpeta** → elige **`C:\reviewflow\reviewflow_v1.0`** (la que contiene `package.json`, `GUIA_1...` y la carpeta `app`). Si pregunta «¿Confía en los autores?», pulsa **Sí, confío**.
3. Abre la terminal de VS Code: menú **Terminal → Nueva terminal**. Aparece abajo y termina en `...\reviewflow_v1.0>`. Si no termina así, abriste la carpeta equivocada: repite el punto 2.
4. A partir de aquí, **todos** los comandos se escriben en 🟩 **esta terminal de VS Code**.

> Si en algún momento 🟩 dice que `stripe` o `node` «no se reconoce», cierra Visual Studio Code por completo y vuelve a abrirlo.

## Paso 3 — Instalar y crear la configuración

🟩 **Terminal de Visual Studio Code:**
```powershell
npm ci
npm run setup
```

- `npm ci` descarga lo necesario (2–5 min).
- `npm run setup` crea el archivo **`.env`** y rellena solo las claves de seguridad. Al final te lista lo que falta.

Abre `.env` en Visual Studio Code (panel izquierdo; si no lo ves, pulsa el icono de recargar del explorador). Los próximos pasos consisten en rellenar huecos de ese archivo: `NOMBRE=valor`, sin espacios ni comillas.

## Paso 4 — Base de datos y cuentas de usuario (Supabase, gratis)

1. Entra en <https://supabase.com/> → crea cuenta → **New project**. Nombre: `reviewflow`. Región: **Frankfurt** o **París**. Guarda la contraseña.
2. Cuando esté listo: menú izquierdo **SQL Editor → New query**.
3. En Visual Studio Code abre `supabase/schema.sql` → **Ctrl+A**, **Ctrl+C** → pega en Supabase → **Run**. Si sale un aviso de «operaciones destructivas», pulsa **Run this query** (es normal). Debe decir «Success».
4. En Supabase: **Project Settings → API Keys** → pestaña **Legacy API keys** (en versiones antiguas: **Project Settings → API**). La Project URL está en el botón **Connect** o en **Data API**. Copia a tu `.env`:

   | En Supabase | En `.env` |
   |---|---|
   | Project URL | `NEXT_PUBLIC_SUPABASE_URL=` |
   | anon public | `NEXT_PUBLIC_SUPABASE_ANON_KEY=` |
   | service_role (pulsa «Reveal») | `SUPABASE_SERVICE_ROLE_KEY=` |

5. En Supabase: **Authentication → URL Configuration**:
   - Site URL: `http://localhost:3000`
   - Redirect URLs → añade: `http://localhost:3000/**`

## Paso 5 — Tú como administrador y datos legales

En `.env`:

```text
SUPERADMIN_EMAILS=tu-correo@ejemplo.com
ALLOW_PLACEHOLDER_SITE_CONFIG=true
```

- Usa el **mismo correo** con el que te registrarás: así tendrás acceso a `/admin`.
- `ALLOW_PLACEHOLDER_SITE_CONFIG=true` permite probar sin datos de empresa. Los pondrás en la Guía 2.

## Paso 6 — Inteligencia artificial (Google Gemini, gratis)

1. <https://aistudio.google.com/apikey> → **Create API key** → copiar.
2. En `.env`:
   ```text
   GEMINI_API_KEY=la-clave-copiada
   ```

Sin este paso todo funciona, salvo las respuestas automáticas con IA.

> **Comprobación rápida (opcional):** 🟩 `npm run test:ia` revisa que la conexión con la IA está bien programada sin gastar nada. Deben salir todas las líneas con `OK`.

## Paso 7 — Pagos de prueba (Stripe, gratis)

1. Crea cuenta en <https://dashboard.stripe.com/register>. Arriba a la derecha activa **Modo de prueba** (Test mode).
2. **Developers → API keys**. Copia a `.env`:
   ```text
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
   STRIPE_SECRET_KEY=sk_test_...
   ```
3. Conecta la Stripe CLI con tu cuenta y obtén la firma del webhook (el «aviso» que manda Stripe cuando alguien paga). 🟩 **Terminal de Visual Studio Code**, de uno en uno:
   ```powershell
   stripe login
   stripe listen --print-secret
   ```
   Con `stripe login` se abrirá el navegador para autorizar: pulsa **Allow access** y vuelve a VS Code. Después de `stripe listen --print-secret` copia el `whsec_...` que aparece (es el mismo cada vez que uses `stripe listen` en este ordenador):
   ```text
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```

4. **Activa el portal de clientes (modo de prueba):** en Stripe, con **Modo de prueba** activado, ve a **Configuración → Billing → Portal de clientes** → permite cambiar de plan, actualizar tarjeta y cancelar → **Guardar**. Sin esto, «Gestionar suscripción» da error.

> **Descuentos:** se crean en Stripe, no en la app. Mira «Descuentos» en la Guía 2. Para probar uno: en modo de prueba crea un cupón y un código (por ejemplo `PRUEBA10`) y escríbelo en la casilla «Añadir código promocional» al pagar.

> **Precios:** no hace falta crear productos en Stripe para probar. Si dejas vacías las variables `STRIPE_PRICE_...`, la app cobra el precio correcto de cada plan automáticamente. En la Guía 2 verás cómo crear productos reales (recomendado para producción).

## Paso 8 — Arrancar

Necesitas **dos terminales de Visual Studio Code** abiertas a la vez. Para abrir la segunda: en el panel de la terminal, pulsa el botón **+** (arriba a la derecha del panel). Puedes cambiar entre ellas en la lista de la derecha del panel.

🟩 **Terminal 1 de VS Code** — la aplicación:
```powershell
npm run dev
```

🟩 **Terminal 2 de VS Code** (pulsa **+** para abrirla) — los avisos de pago:
```powershell
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Abre el navegador en **<http://localhost:3000>**. Deja ambas terminales abiertas mientras pruebas (si cierras VS Code, la app se apaga). Para pararla: **Ctrl+C** en esa terminal.

## Paso 9 — Prueba completa (marca cada casilla)

| ✓ | Haz esto | Debe pasar |
|---|---|---|
| ☐ | Abre la portada y **Precios** | Ves los 4 planes: 19 €, 29 €, 39 € y 69 € |
| ☐ | **Registro** con el correo del paso 5 | Entras en la página de bienvenida |
| ☐ | Elige un plan → pagar con tarjeta `4242 4242 4242 4242`, fecha futura, CVC `123` | Vuelves a la app con «Pago completado». En la terminal 2 aparece `checkout.session.completed` con `200` |
| ☐ | Entra en el **Panel** | Ves tu plan, días de prueba y los medidores de uso |
| ☐ | Crea tu empresa y añade una opinión a mano | La opinión aparece en la lista |
| ☐ | Pulsa **Responder con IA** | Aparece una respuesta escrita (necesita paso 6) |
| ☐ | Abre el **QR / enlace de valoración** de tu empresa en otra pestaña | Ves la página pública para valorar |
| ☐ | **Facturación → Gestionar suscripción** | Se abre el portal de Stripe; puedes cambiar de plan o cancelar |
| ☐ | Cambia a otro plan desde el panel | El plan nuevo aparece en el panel en segundos |
| ☐ | **Empresa y conexiones → Añadir otra empresa**: escribe un nombre (p. ej. «Bar 2»), elige plan y paga | Vuelves al panel; arriba a la izquierda puedes cambiar entre tus empresas. La nueva se cobra al momento (sin 7 días gratis) |
| ☐ | Cambia de empresa con el selector de arriba | Opiniones, facturación y ajustes son los de la empresa elegida |
| ☐ | Cancela la suscripción y vuelve a contratar | Ya **no** aparecen los 7 días gratis (solo 1 prueba por cuenta) |
| ☐ | Abre `/admin` | Ves el panel de administración con tus clientes |
| ☐ | Cierra sesión, regístrate con **otro** correo y abre `/admin` | Acceso denegado |
| ☐ | Con la otra cuenta **sin pagar**, intenta usar el panel | Te pide elegir un plan (no puede usarlo gratis) |

**Comprobación automática:** con las terminales 1 y 2 funcionando, abre una 🟩 **tercera terminal de VS Code** (botón **+**) y escribe:
```powershell
npm run verify
```
Lo verde funciona; lo rojo te dice qué falta.

Si todo está marcado: **el producto funciona**. Sigue con la [Guía 2](./GUIA_2_PUBLICAR_Y_PAGAR.md).

---

## Opcional — Más funciones para probar

| Función | Qué rellenar en `.env` | Dónde se consigue |
|---|---|---|
| Enviar correos (peticiones de opinión, avisos) | `RESEND_API_KEY` | <https://resend.com> (gratis 3.000/mes, máximo 100 al día) |
| Buscar tu negocio en Google | `GOOGLE_PLACES_API_KEY` | <https://console.cloud.google.com> → APIs → Places API |
| Conectar Google Business Profile | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Google Cloud → Credenciales → OAuth. URL de retorno: `http://localhost:3000/api/integrations/google/callback` |
| Anti-bots en formularios | `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | <https://dash.cloudflare.com> → Turnstile |
| Tareas automáticas en local | `ENABLE_INTERNAL_CRON=true` | — |
| Apartados «Base de datos» y «Capacidad» de `/admin` | `DATABASE_URL` | Supabase → **Connect** → **Transaction pooler** (puerto **6543**). Sustituye `[YOUR-PASSWORD]` por tu contraseña. No uses la conexión directa `db.xxx.supabase.co` |
| Avisos de errores | `SENTRY_DSN`, `NEXT_PUBLIC_SENTRY_DSN` | <https://sentry.io> → proyecto Next.js → DSN |

Cada variable tiene una explicación en `.env.example`.

## Si algo falla

| Problema | Solución |
|---|---|
| `npm` no se reconoce | Reinstala Node.js 22 y **reinicia** el ordenador |
| «No se pueden cargar scripts» | Repite el punto 4 del Paso 1 y cierra y abre VS Code |
| «No se encuentra package.json» / `ENOENT` | Estás en la carpeta equivocada o en la PowerShell aparte: usa la terminal de VS Code con la carpeta del Paso 2.2 |
| `stripe` o `winget` no se reconoce | Cierra y abre VS Code. Si `winget` no existe (Windows 10 antiguo), instala **App Installer** desde Microsoft Store y repite el Paso 1.5 |
| Puerto 3000 ocupado | Cierra la otra terminal con `npm run dev`, o reinicia el ordenador |
| Al registrarte: error de base de datos | Repite el paso 4.3 (`schema.sql`) y revisa las 3 claves |
| No llega el correo de confirmación | En local no hace falta: deja `SIGNUP_EMAIL_CONFIRMATION` vacío |
| Pagué pero el plan no cambia | La terminal 2 debe estar abierta y el `whsec_` igual que en `.env`. Tras cambiar `.env`, para la app (**Ctrl+C**) y vuelve a `npm run dev` |
| «Falta configurar STRIPE_SECRET_KEY» | Revisa el paso 7 y reinicia la app |
| Error al añadir otra empresa o la prueba gratis se repite | Vuelve a ejecutar `supabase/schema.sql` en Supabase (SQL Editor). Se puede repetir sin perder datos |
| La IA no responde | Revisa `GEMINI_API_KEY` y reinicia la app |
| Cambié `.env` y no pasa nada | Siempre que cambies `.env`: **Ctrl+C** y `npm run dev` de nuevo |
