# Guía 2 — Poner ReviewFlow AI v1.0 en internet y cobrar a clientes reales

**Índice de las 3 guías:** [1 · Probar en local](./GUIA_1_PROBAR_EN_LOCALHOST.md) → [2 · Publicar y cobrar](./GUIA_2_PUBLICAR_Y_PAGAR.md) → [3 · Funcionamiento, seguridad y mantenimiento](./GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md).

Requisito: haber completado la [Guía 1](./GUIA_1_PROBAR_EN_LOCALHOST.md) con todas las casillas marcadas.

Al terminar tendrás la web en `https://tudominio.es`, con registro de clientes, cobro real de los 4 planes, correos y tareas automáticas funcionando.

> **Cómo leer esta guía:** haz los pasos **en orden**. Donde ponga `tudominio.es`, escribe tu dominio real. Los bloques grises son comandos para la terminal de Visual Studio Code.

```text
1 Legal → 2 Dominio → 3 Correo (Resend) → 4 Base de datos real (Supabase)
→ 5 Stripe real → 6 Preparar claves → 7 Subir a GitHub → 8 Publicar en Vercel
→ 9 Conectar dominio → 10 Webhook de Stripe → 11 Prueba final
```

---

## Qué vas a pagar

| Servicio | Para qué | Precio orientativo |
|---|---|---|
| Dominio | `tudominio.es` | ~10 €/año |
| Vercel **Pro** | Alojar la web. **Obligatorio Pro**: el plan gratis (Hobby) no permite uso comercial ni las tareas automáticas cada hora que usa la app (el despliegue fallaría) | 20 $/mes |
| Supabase | Base de datos y cuentas de usuario | Gratis al inicio; Pro 25 $/mes con clientes reales (el gratis se pausa tras 7 días sin uso) |
| Stripe | Cobros | ~1,5 % + 0,25 € por pago en la UE (sin cuota) |
| Resend | Correos | Gratis hasta 3.000/mes (máximo 100 al día); Pro 20 $/mes si envías más |
| Google Gemini | IA | Gratis con límites; luego pago por uso |
| GitHub | Guardar el código | Gratis |

---

## Paso 1 — Lo legal (antes de vender)

1. Date de alta como autónomo o empresa (necesario para facturar y para activar Stripe).
2. Apunta: nombre fiscal, CIF/NIF, dirección completa, correo legal y correo de soporte. Los usarás en el paso 6.
3. Revisa los textos de `/aviso-legal`, `/privacidad`, `/terminos`, `/cookies` y `/dpa` (carpeta `app/`). Si tienes dudas, consulta a un asesor.

> La app **se niega a arrancar** en internet si faltan estos datos. Es a propósito: evita publicar avisos legales vacíos.

## Paso 2 — Comprar el dominio

Cómpralo en Cloudflare, Namecheap, IONOS, DonDominio… Guarda el usuario y la contraseña del panel: ahí añadirás los registros DNS de los pasos 3 y 9.

> **DNS** = la «agenda» de tu dominio. Cada servicio te pedirá añadir unas líneas (tipo, nombre, valor). Cópialas exactamente.

## Paso 3 — Correo (Resend)

1. <https://resend.com> → crea cuenta → **Domains → Add domain** → escribe `tudominio.es` → región **Ireland (eu-west-1)**.
2. Resend te muestra 3–4 registros DNS (tipo `TXT` y `MX`). En el panel de tu dominio → **DNS** → añade cada uno copiando **Tipo**, **Nombre** y **Valor**.
   - Si tu proveedor añade el dominio automáticamente al nombre, escribe solo la parte de delante (p. ej. `resend._domainkey`, no `resend._domainkey.tudominio.es`).
3. Vuelve a Resend → **Verify DNS records**. Espera a que salga **Verified** (de minutos a unas horas).
4. **API Keys → Create API key** → permiso **Sending access** → copia la clave `re_...` (solo se muestra una vez).

## Paso 4 — Base de datos de producción (Supabase)

1. En <https://supabase.com> → **New project** → nombre `reviewflow-prod`, región **Frankfurt** o **Paris**. Crea una contraseña fuerte y **guárdala** (la necesitas en el punto 6).
   > No reutilices el proyecto de la Guía 1: el de pruebas tiene datos falsos.
2. **SQL Editor → New query** → en Visual Studio Code abre `supabase/schema.sql` → **Ctrl+A**, **Ctrl+C** → pega en Supabase → **Run**.
   - Si aparece un aviso de «operaciones destructivas», pulsa **Run this query**: es normal.
   - Debe terminar con **Success. No rows returned**.
3. **Project Settings → API Keys** → pestaña **Legacy API keys** (si no aparece, está en **Project Settings → API**). Apunta:
   - **Project URL** (en **Project Settings → Data API** o en el botón **Connect**) → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role** (pulsa **Reveal**) → `SUPABASE_SERVICE_ROLE_KEY` — **es la llave maestra, nunca la compartas**.
4. **Authentication → URL Configuration**:
   - **Site URL**: `https://tudominio.es`
   - **Redirect URLs → Add URL**: `https://tudominio.es/**` → **Save**.
5. **Authentication → Sign In / Providers → Email**: deja activado **Confirm email**.
6. **Authentication → Emails → SMTP Settings** → **Enable custom SMTP** (sin esto Supabase solo envía 2–4 correos por hora y van a spam):

   | Campo | Valor |
   |---|---|
   | Sender email | `hola@tudominio.es` (del dominio verificado en el paso 3) |
   | Sender name | `ReviewFlow` |
   | Host | `smtp.resend.com` |
   | Port | `465` |
   | Username | `resend` |
   | Password | tu clave de Resend `re_...` |

   → **Save changes**.
7. (Opcional, para los apartados «Base de datos» y «Capacidad» de `/admin`) Botón **Connect** arriba → **Transaction pooler** → copia la dirección (termina en `:6543/postgres`) y cambia `[YOUR-PASSWORD]` por la contraseña del punto 1. Es `DATABASE_URL`. No uses la conexión directa `db.xxx.supabase.co`.

## Paso 5 — Stripe en modo real

1. En Stripe → **Activar cuenta**: datos fiscales, identidad y cuenta bancaria. Tarda 1–2 días. **No sigas hasta que esté activada.**
2. Desactiva **Modo de prueba** (interruptor arriba a la derecha). Todo lo que hagas a partir de aquí debe ser con el modo de prueba **apagado**.
3. **Catálogo de productos → Añadir producto**. Crea estos 4 con precio **Recurrente**, **Mensual**, en **EUR**. Al guardar, abre el precio y copia su ID (empieza por `price_...`, **no** `prod_...`):

   | Producto | Precio | Variable |
   |---|---|---|
   | Local Básico | 19 € | `STRIPE_PRICE_LOCAL_STARTER` |
   | E-commerce Básico | 29 € | `STRIPE_PRICE_ECOMMERCE_STARTER` |
   | Local Pro | 39 € | `STRIPE_PRICE_LOCAL_PRO` |
   | E-commerce Scale | 69 € | `STRIPE_PRICE_ECOMMERCE_PRO` |

   Opcional — packs extra (precio **Único**, no recurrente):

   | Pack | Precio | Variable |
   |---|---|---|
   | +1.000 peticiones | 9 € | `STRIPE_PRICE_ADDON_REQUESTS` |
   | +2.000 opiniones | 12 € | `STRIPE_PRICE_ADDON_REVIEWS` |
   | +500 respuestas IA | 15 € | `STRIPE_PRICE_ADDON_AI` |
   | +500 sincronizaciones | 6 € | `STRIPE_PRICE_ADDON_SYNCS` |

   Si dejas vacías las variables `STRIPE_PRICE_...`, la app cobra igualmente el importe correcto; crearlos solo sirve para ver los productos ordenados en Stripe.
4. **Developers → API keys**: copia la **Publishable key** (`pk_live_...`) y la **Secret key** (`sk_live_...`, pulsa «Revelar»).
5. **Configuración → Billing → Portal de clientes** → activa: cambiar de plan (añade los 4 productos), actualizar método de pago y cancelar suscripción → **Guardar**. Sin esto, «Gestionar suscripción» da error.
6. **Descuentos (opcional).** Se crean **en Stripe**, no en la app:
   1. **Catálogo de productos → Cupones → Crear cupón**: % o € de descuento y duración.
   2. Dentro del cupón → **Crear código promocional** (p. ej. `BIENVENIDA20`).
   3. El cliente lo escribe en **«Añadir código promocional»** al pagar. Para ocultar esa casilla: `STRIPE_ALLOW_PROMOTION_CODES=false`.
   4. A un cliente ya suscrito: **Clientes → su suscripción → Añadir cupón**.
   > Los cupones del modo de prueba no existen en modo real: créalos otra vez.
7. El webhook se crea en el paso 10 (necesita la web publicada).

## Paso 6 — Preparar las claves de producción

Vas a crear un archivo **aparte** con las claves de producción, sin tocar el `.env` que usas en tu ordenador.

1. En la terminal de Visual Studio Code, haz una copia de seguridad de tu `.env` local:
   ```powershell
   Copy-Item .env .env.local-backup
   ```
   (Mac/Linux: `cp .env .env.local-backup`.)
2. Genera claves de seguridad **nuevas** (no reutilices las de local):
   ```powershell
   npm run setup -- --force
   ```
3. Abre `.env` y copia a un bloc de notas los valores de: `APP_SIGNING_SECRET`, `OAUTH_STATE_SECRET`, `INTEGRATION_ENCRYPTION_KEY`, `PRIVACY_HASH_PEPPER`, `HEALTH_KEY`, `HEALTHCHECK_SECRET`, `CRON_SECRET`.
4. Recupera tu `.env` local para que localhost siga funcionando:
   ```powershell
   Copy-Item .env.local-backup .env -Force
   ```
5. Completa el bloc de notas con esta lista (formato `NOMBRE=valor`, una por línea, sin comillas ni espacios). Es lo que pegarás en Vercel:

   ```text
   # Dirección pública (sin barra al final, con https)
   NEXT_PUBLIC_APP_URL=https://tudominio.es

   # Claves internas (punto 3)
   APP_SIGNING_SECRET=...
   OAUTH_STATE_SECRET=...
   INTEGRATION_ENCRYPTION_KEY=...
   PRIVACY_HASH_PEPPER=...
   HEALTH_KEY=...
   HEALTHCHECK_SECRET=...
   CRON_SECRET=...

   # Supabase de producción (paso 4)
   NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   SUPABASE_SERVICE_ROLE_KEY=...

   # Stripe real (paso 5)
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
   STRIPE_SECRET_KEY=sk_live_...
   STRIPE_PRICE_LOCAL_STARTER=price_...
   STRIPE_PRICE_ECOMMERCE_STARTER=price_...
   STRIPE_PRICE_LOCAL_PRO=price_...
   STRIPE_PRICE_ECOMMERCE_PRO=price_...

   # IA
   GEMINI_API_KEY=...

   # Correo (paso 3)
   RESEND_API_KEY=re_...
   SMTP_FROM=ReviewFlow <hola@tudominio.es>

   # Tú como administrador
   SUPERADMIN_EMAILS=tu-correo@ejemplo.com

   # Datos legales (paso 1) — obligatorios
   NEXT_PUBLIC_COMPANY_NAME=Nombre fiscal
   NEXT_PUBLIC_CIF=B12345678
   NEXT_PUBLIC_ADDRESS=Calle, número, CP, ciudad
   NEXT_PUBLIC_LEGAL_EMAIL=legal@tudominio.es
   NEXT_PUBLIC_SUPPORT_EMAIL=soporte@tudominio.es
   NEXT_PUBLIC_DOMAIN=tudominio.es

   # Comportamiento en producción
   SIGNUP_EMAIL_CONFIRMATION=true
   ENABLE_INTERNAL_CRON=false
   ```

6. **Recomendadas / opcionales** (añádelas a la lista si las usas):

   | Variable | Para qué | Dónde se consigue |
   |---|---|---|
   | `DATABASE_URL` | Apartados de `/admin` | Paso 4.7 |
   | `SENTRY_DSN`, `NEXT_PUBLIC_SENTRY_DSN` | Avisos de errores | <https://sentry.io> → proyecto Next.js → DSN |
   | `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | Anti-bots en formularios | Cloudflare → Turnstile (añade `tudominio.es`) |
   | `GOOGLE_PLACES_API_KEY`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Google Business Profile | Google Cloud (final del paso 10) |
   | `STRIPE_PRICE_ADDON_...` | Packs extra | Paso 5.3 |

   **Ajustes avanzados** (si no los pones, se usan valores seguros; explicados en `.env.example`): `ENABLE_FREE_TRIAL` / `NEXT_PUBLIC_ENABLE_FREE_TRIAL` (mismo valor en ambas), `GEMINI_MODEL`, `AI_MAX_COST_USD_PER_TENANT`, `AI_TIMEOUT_MS`, `ADMIN_IMPERSONATION_ENABLED`, `SMTP_HOST`/`SMTP_PORT`/`SMTP_USER`/`SMTP_PASS` (solo si no usas `RESEND_API_KEY`), `QUEUE_BATCH_SIZE`, `QUEUE_CONCURRENCY`, `DATABASE_POOL_MAX`.

> **Nunca** pongas en producción `ALLOW_PLACEHOLDER_SITE_CONFIG` ni claves `pk_test_` / `sk_test_`.
> `STRIPE_WEBHOOK_SECRET` se añade en el paso 10.
> Guarda este bloc de notas en un sitio seguro y **no lo subas a GitHub**.

## Paso 7 — Subir el código a GitHub (privado)

1. Crea cuenta en <https://github.com> e instala **GitHub Desktop** (<https://desktop.github.com>). Inicia sesión.
2. GitHub Desktop → **File → Add local repository** → elige la carpeta del proyecto. Si dice que no es un repositorio, pulsa **create a repository** → **Create repository**.
3. Comprueba en la lista de cambios que **no** aparecen `.env`, `.env.local-backup`, `node_modules` ni `.next` (están excluidos automáticamente). Si aparece `.env.local-backup`, haz clic derecho → **Ignore file**.
4. Abajo a la izquierda escribe un resumen (p. ej. `Primera versión`) → **Commit to main**.
5. **Publish repository** → deja marcado **Keep this code private** → **Publish**.

> Cada vez que cambies algo: **Commit to main** → **Push origin**. Vercel publicará la nueva versión solo.

## Paso 8 — Publicar en Vercel

1. <https://vercel.com> → **Sign up** con tu cuenta de GitHub → elige el plan **Pro**.
2. **Add New… → Project** → junto a tu repositorio pulsa **Import** (si no aparece: **Adjust GitHub App Permissions** y dale acceso).
3. En la pantalla de configuración:
   - **Framework Preset**: `Next.js` (lo detecta solo).
   - **Root Directory**: déjalo como está (`./`). Si al descomprimir te quedó una carpeta dentro de otra, elige la que contiene `package.json`.
   - **Build and Output Settings**: no toques nada.
4. Despliega **Environment Variables**. Copia **todo** el bloque de tu bloc de notas y pégalo en la casilla **Key** (Vercel separa las variables solo). Comprueba que aparecen todas con su valor.
5. Pulsa **Deploy** y espera (~3–5 min).
   - La web aún **no** funcionará en la dirección `xxx.vercel.app`: la app solo acepta tu dominio. Es normal; lo conectas en el paso 9.
   - Si el despliegue sale en rojo, mira «Si algo falla».
6. **Settings → General → Node.js Version**: comprueba que pone **22.x**.

## Paso 9 — Conectar tu dominio

1. Vercel → tu proyecto → **Settings → Domains** → escribe `tudominio.es` → **Add**. Acepta también añadir `www.tudominio.es` (redirigirá al principal).
2. Vercel te muestra los registros DNS. En el panel de tu dominio añade:

   | Tipo | Nombre | Valor |
   |---|---|---|
   | `A` | `@` (o vacío) | la IP que muestra Vercel (normalmente `76.76.21.21`) |
   | `CNAME` | `www` | el valor que muestra Vercel (p. ej. `cname.vercel-dns.com`) |

   - Borra cualquier otro registro `A` o `CNAME` antiguo de `@` o `www` (los que pone el proveedor por defecto). **No borres** los de Resend.
   - En Cloudflare: pon la nube en **gris** («DNS only»), no naranja.
3. Espera a que Vercel muestre **Valid Configuration** (de minutos a 24 h). El certificado HTTPS se crea solo.
4. **Deployments** → en el último → **⋯ → Redeploy**. Abre `https://tudominio.es`: debe verse la portada.

## Paso 10 — Conectar el webhook de Stripe

El webhook es el aviso que manda Stripe a tu web cuando alguien paga. Sin él, los clientes pagan pero su plan no se activa.

1. Stripe (modo de prueba **apagado**) → **Developers → Webhooks → Añadir destino / Add endpoint**.
2. URL: `https://tudominio.es/api/stripe/webhook`
3. **Seleccionar eventos** → marca estos 8:
   `checkout.session.completed`, `invoice.paid`, `invoice.payment_succeeded`, `invoice.payment_failed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `customer.subscription.trial_will_end`.
4. Guarda. Abre el webhook creado → **Signing secret → Revelar** → copia `whsec_...`.
5. Vercel → **Settings → Environment Variables → Add** → `STRIPE_WEBHOOK_SECRET` = `whsec_...` → **Save**.
6. **Deployments → ⋯ → Redeploy** (las variables nuevas solo se aplican tras redesplegar).

> Este `whsec_` es **distinto** del que usabas en local con la Stripe CLI. No los mezcles.

Opcional, Google Business Profile: en Google Cloud → Credenciales → tu cliente OAuth → **URI de redireccionamiento autorizados** → añade `https://tudominio.es/api/integrations/google/callback`.

## Paso 11 — Prueba final en producción

| ✓ | Haz esto | Debe pasar |
|---|---|---|
| ☐ | Abre `https://tudominio.es/api/health` | Muestra `"ok":true` |
| ☐ | Abre `/aviso-legal` | Salen tus datos reales (no `[NOMBRE...]`) |
| ☐ | Regístrate con el correo de `SUPERADMIN_EMAILS` | Llega el correo de confirmación (mira spam) y entras |
| ☐ | Contrata el plan más barato con **tu tarjeta real** | Vuelves con «Pago completado»; en Stripe → Webhooks el evento sale con `200` |
| ☐ | Panel: crea empresa, añade opinión y **Responder con IA** | Todo funciona |
| ☐ | Abre `/admin` | Ves tu cuenta como cliente |
| ☐ | **Facturación → Gestionar suscripción** → cancela. Luego en Stripe → **Pagos** → reembolsa | El panel muestra la cancelación |
| ☐ | Vercel → **Settings → Cron Jobs** | Las 3 tareas aparecen y hay ejecuciones correctas |
| ☐ | Abre `/robots.txt` y `/sitemap.xml` | Solo dominio real y páginas públicas; registro y paneles fuera del sitemap |
| ☐ | Portada y precios → ver código fuente | Título, descripción, dirección canónica y etiquetas para compartir propios |

Comprobación automática desde tu ordenador:
```powershell
npm run verify -- --url https://tudominio.es
```

Este comando lee tu `.env` o las variables de esa terminal: deben corresponder al dominio que compruebas. No uses el `whsec_` de localhost contra producción. Si tu `.env` sigue siendo de pruebas, la firma fallará y el comando no verificará la configuración real. Usa un entorno separado con las claves correctas, sin subirlo a GitHub ni compartirlo. Los avisos y pruebas manuales siguen siendo necesarios.

**Antes de vender:** completa las casillas, revisa los avisos de la comprobación automática y lee la [Guía 3](./GUIA_3_COMO_FUNCIONA_Y_CUANDO_AMPLIAR.md).

---

## Publicar cambios más adelante

1. Prueba el cambio en local (`npm run dev`).
2. GitHub Desktop → **Commit to main** → **Push origin**.
3. Vercel lo publica solo en ~3 min (míralo en **Deployments**).
4. Si cambias una variable en Vercel: **Redeploy** siempre.
5. Antes de cambios en `supabase/schema.sql`, haz copia y prueba en una base separada. Esta entrega usa solo ese esquema; ejecuta únicamente cambios revisados en producción (precauciones en la Guía 3).

## Si algo falla

| Problema | Solución |
|---|---|
| El despliegue sale en rojo con `Cron Jobs` / «Hobby accounts are limited to daily cron jobs» | Tu cuenta de Vercel es gratis: pasa a **Pro** y **Redeploy** |
| La web da error 500 al abrir | Vercel → **Deployments → el último → Logs / Runtime Logs**. El mensaje dice qué variable falta (p. ej. `Falta HEALTHCHECK_SECRET` o `Dominio o datos legales sin configurar`). Añádela y **Redeploy** |
| `NEXT_PUBLIC_APP_URL debe ser HTTPS y no localhost` | Pon `https://tudominio.es` sin barra final y **Redeploy** |
| `xxx.vercel.app` no funciona pero el dominio sí | Normal: la app trabaja solo con tu dominio |
| El dominio no carga tras horas | Revisa los registros `A`/`CNAME` del paso 9; en Cloudflare, nube en gris |
| No llegan los correos | Resend: dominio en **Verified**. Supabase: SMTP del paso 4.6 con la clave `re_...` correcta |
| Enlaces de correo llevan a localhost | Corrige `NEXT_PUBLIC_APP_URL` y la **Site URL** de Supabase (paso 4.4) y **Redeploy** |
| Pagan y el plan no se activa | Stripe → Webhooks → el evento: si da `400`, el `whsec_` no coincide; si da `404`, la URL está mal. Corrige y **Redeploy** |
| Stripe dice «No such price» | Copiaste un `prod_...` o un precio del modo de prueba: usa el `price_...` del modo real |
| «Gestionar suscripción» da error | Activa el Portal de clientes en modo real (paso 5.5) |
| No sale la casilla de descuento | `STRIPE_ALLOW_PROMOTION_CODES` no debe ser `false` y el código debe estar **activo** en modo real |
| «Demasiadas peticiones» o abusos | El límite se guarda en la base de datos: revisa que `NEXT_PUBLIC_SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` estén bien y que ejecutaste `supabase/schema.sql`. Para frenar bots, añade Turnstile (paso 6.6) y **Redeploy** |
| `/admin` → Base de datos vacío | Falta `DATABASE_URL` o usas la conexión directa: usa la del pooler (puerto 6543) |
| Error de base de datos al registrarse | Ejecuta `supabase/schema.sql` en el proyecto de **producción** y revisa las 3 claves de Supabase |
